# 4D HOSPITAL — Final A-to-Z Audit Report

## Audit scope
এই release-এ source tree, analysis catalog, core scoring engine, 3-stage pipeline, validation layer, research-cycle layer এবং SQLite data layer staticভাবে পর্যালোচনা করা হয়েছে।

## 107 Analysis Catalog
- Public catalog: **107 unique entries**
- IDs: **1–107**, duplicate-free
- UI label এখন স্পষ্টভাবে বলে: **107 catalog entries · 28 active signals**
- গুরুত্বপূর্ণ: 107টি নামকে 107টি আলাদা prediction algorithm হিসেবে দাবি করা হচ্ছে না। এগুলো analysis catalog-এর research/analysis options। বাস্তবে প্রধান ranking engine বর্তমানে 28টি active signal ব্যবহার করে।
- Source-এ আরও 8টি research idea আগে লেখা ছিল; public 107-এর বাইরে এগুলো এখন আর ভুলভাবে ID পায় না।

## Core fixes in this release
1. **Pipeline memo dependency** — 3-stage pipeline এখন `engineResult` পরিবর্তন হলে stale result ধরে রাখে না।
2. **Blocked K-fold validation** — validation function নিজেই chronological order normalize করে এবং প্রতিটি test block-এর জন্য strictly earlier observations দিয়ে training করে। ফলে caller newest-first বা oldest-first data দিলেও look-ahead leakage কমানো হয়।
3. **Duplicate validation helper removed** — scorer-এর unused duplicate `blockedKFoldSafe` সরানো হয়েছে, যাতে দুইটি আলাদা implementation নিয়ে confusion না থাকে।
4. **Analysis category classification** — Statistics/Dependency/Randomness divisions এখন `statistical` category-তে সঠিকভাবে আসে।
5. **LSTM documentation corrected** — lightweight recurrent/LSTM-style model-টিকে full back-propagation-through-time LSTM হিসেবে অতিরঞ্জিত করা হয়নি।
6. **Static audit script added** — `npm run audit:static` দিয়ে 107-entry catalog, uniqueness এবং critical guards পরীক্ষা করা যায়।

## Verification performed
- Static catalog audit: **PASS**
- Core TypeScript type-check for pure analysis modules: **PASS**
- Core runtime smoke test: **PASS** — 60 synthetic historical rows দিয়ে engine top-20, backtest এবং K-fold path চালানো হয়েছে।
- Full Vite/Android build: **NOT VERIFIED in this environment**, কারণ dependency installation (`npm install`) network timeout করেছে এবং project-এ `node_modules` ছিল না।

## Important product limitation
এটি একটি offline/free client application। Client-side password hashing এবং local storage convenience/security controls দেয়, কিন্তু server-side authentication-এর সমান security guarantee দেয় না। একইভাবে prediction score/confidence historical ranking signal; ভবিষ্যৎ 4-digit ফল নিশ্চিত করে না।

## Recommended final build command
1. `npm install`
2. `npm run audit:static`
3. `npm run typecheck`
4. `npm run build`
5. Android হলে `npm run android:build`

Build-এর পরে `dist/` এবং Android project/device test করা উচিত।

## Old + New Data Merge Pass
- Native SQLite এবং retained legacy localStorage একই launch-এ উভয় source থেকে পড়া হয়।
- Union merge `company + date` key-তে করা হয়; duplicate draw একবারই রাখা হয়।
- একই draw দুই source-এ থাকলে native SQLite record canonical হিসেবে রাখা হয়।
- Merge করা সম্পূর্ণ dataset SQLite-তে পুনরায় persist করা হয়।
- আলাদা package/signed app sandbox থেকে private data auto-read করা যায় না; সে ক্ষেত্রে old app export/backup → Migration/Restore প্রয়োজন।

## Final Hardening Pass — 2026-09-17

এই pass-এ তিনটি priority এবং storage/data-integrity-এর অতিরিক্ত guard যোগ করা হয়েছে:

1. **Master Data Merge Safety**
   - native SQLite + retained localStorage একসাথে merge হয়; কোনো source silently discard করা হয় না।
   - company+date একই হলে exact/duplicate draw dedupe হয়; ভিন্ন result হলে existing master row overwrite না করে Migration Conflict Log-এ রাখা হয়।
   - merged dataset-এর primary IDs deterministicভাবে unique করা হয়; legacy ID collision আর SQLite insert ভাঙবে না।
   - Add Result একই company+date আগে থাকলে silent overwrite না করে user-কে Edit করতে বলে।
2. **Storage Durability**
   - localStorage primary copy-এর সঙ্গে mirror এবং previous snapshot backup রাখা হয়।
   - primary localStorage corrupt হলে mirror/backup recovery চেষ্টা করা হয়।
   - Android native SQLite transaction rollback guard বজায় আছে; replace/import-এ invalid rows বাদ দিয়ে valid rows safely commit হয়।
3. **107 Analysis Traceability**
   - catalog এখন প্রতিটি option-এর implementation state এবং linked active signal metadata বহন করে।
   - UI-তে Implementation এবং Engine Link দেখানো হয়, যাতে catalog entry-কে ভুল করে active prediction algorithm হিসেবে বোঝানো না হয়।
   - 28 active scoring signals-এর catalog exported metadata UI-তে দেখানো হয়।
4. **Conflict Recovery**
   - Migration Conflict Log full backup-এর localData অংশে অন্তর্ভুক্ত করা হয়েছে।

Static audit remains PASS: 107 public analysis entries, unique; core files present; validation/pipeline guards present.
