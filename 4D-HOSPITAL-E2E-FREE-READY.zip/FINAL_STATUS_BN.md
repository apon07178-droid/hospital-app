# 4D HOSPITAL — বর্তমান বাস্তব অবস্থা

এই build-এ যাচাই করা অংশ:
- 28 base signals রাখা আছে (scorer.ts)
- Advanced Mathematical Engine UI ও engine metrics আছে
- Position/transition/pair/triplet/entropy/correlation/rolling window/overdue/reliability/ensemble আছে
- Walk-forward backtest engine আছে
- Candidate score breakdown আছে
- Data Vault-এ Backup/Restore/Data Migration UI আছে
- Agent/KYC UI আছে
- Android package id: com.cbc.lt4my.hospital

গুরুত্বপূর্ণ:
- পুরনো Android app-এর private SQLite data নতুন package নিজে থেকে পড়তে পারে না।
- তাই পুরনো app-এর 101 draw নতুন app-এ স্বয়ংক্রিয়ভাবে চলে আসবে—এমন দাবি এই build করে না।
- পুরনো app uninstall বা Clear Data করা যাবে না, যতক্ষণ data উদ্ধার নিশ্চিত না হয়।
- Backup/Restore code আছে, কিন্তু পুরনো app-এর Backup যদি কাজ না করে, migration-এর জন্য পুরনো data export/access-এর আলাদা পথ দরকার।
- Lottery ranking statistical analysis; guaranteed future result নয়।


## সর্বশেষ Scientific Correction Pass
- K-Fold placeholder ranker সরানো হয়েছে এবং real ranking callback যুক্ত হয়েছে।
- Look-ahead separation newest-first data অনুযায়ী corrected: test draw-এর পরে থাকা পুরোনো records-ই training।
- প্রতিটি signal 0–1 normalize করে ensemble-এ যায়।
- Walk-forward signal reliability এখন final ranking-এ adaptive weight হিসেবে ব্যবহৃত।
- Correlated/redundant signal group-এর weight discount করা হয়।
- 3-stage pipeline-এর Stage 3-এ scientific ranking score secondary evidence হিসেবে যুক্ত।
- ACF চারটি digit position-এর historical autocorrelation থেকে গণনা করা হয়।
- Confidence descriptive ranking index; winning probability নয়।
- Existing data/storage/OCR/Agent-KYC/analysis modules বাদ দেওয়া হয়নি।

### Verification
Core scientific TypeScript files (`scorer.ts`, `advanced-validation.ts`, `pipeline.ts`) strict TypeScript compilation-এ pass করেছে। A synthetic 25-draw runtime smoke test-এ engine ranking, K-Fold, score normalization এবং Stage-3 scientific integration কাজ করেছে। Full Android APK build এই environment-এ dependency installation/network timeout-এর কারণে পুনরায় সম্পন্ন করা যায়নি; তাই APK runtime success এখানে দাবি করা হচ্ছে না।

## Advanced Models Upgrade
- Added `src/lib/advanced-models.ts`.
- Added a compact offline trained LSTM signal to candidate ranking.
- Added a genuine genetic optimizer with selection, crossover, mutation, elitism and deterministic seed.
- Added LSTM score to the ensemble as a separate normalized signal.
- Existing scientific validation, walk-forward safeguards and redundancy weighting remain in place.
- This is still an analytical ranking system, not a guarantee of future lottery results.


## Research Cycle Upgrade
- Added leakage-safe Research Cycle UI: current data → locked prediction snapshot → actual batch → validation/trace → apply to dataset.
- Snapshot stores dataset fingerprint and rejects validation if the dataset changes after lock.
- Added historical cycle ledger and cumulative method coverage report.
- Added a 107-option Analysis Catalog in the Research Cycle screen.
- Actual batch is kept outside the dataset until validation is completed.

## Latest Priority Hardening — 2026-09-17

Priority 1: old+new master-data merge, conflict logging, unique ID remapping এবং non-destructive Add guard completed.
Priority 2: 107 Analysis Catalog এখন implementation state এবং active signal linkage দেখায়; 28 active signals remain the production ranking layer.
Priority 3: static/runtime-source checks were rerun. Full Android device E2E still requires an Android build environment/device; npm dependency installation timed out in this environment.
Storage: native SQLite transaction safety + localStorage mirror/backup recovery guard added.
