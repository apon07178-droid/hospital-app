# 4D HOSPITAL — Build Ready Project

এটি 4D HOSPITAL-এর Replit-মুক্ত build-ready source project। মূল `src` কোড ও UI ফাইলগুলো রাখা হয়েছে। Replit-specific configuration সরানো হয়েছে।

## Web build

প্রয়োজনীয় Node.js ইনস্টল থাকা অবস্থায় project folder-এ:

```bash
npm install
npm run build
```

তারপর `dist/` folder তৈরি হবে।

## গুরুত্বপূর্ণ

- `node_modules` এবং `dist` এই ZIP-এ ইচ্ছাকৃতভাবে নেই। এগুলো build করার সময় তৈরি হবে।
- Android APK বানাতে Android wrapper/build step এখনও আলাদা ধাপ; এই ZIP হলো Replit-মুক্ত web/PWA build-ready source।
- মূল অ্যাপের কোড ইচ্ছাকৃতভাবে redesign করা হয়নি।


## Backup fix (2026-09-16)
Android backup uses Capacitor Filesystem + native Share instead of browser Blob/anchor. Backup is written to the device Documents area and the Android share/save sheet is opened. No SMS/OTP, Firebase, Replit, or paid backend is used.
