# 4D HOSPITAL — Old Data Migration

এই সংস্করণে Data Vault-এ **Data Migration** যোগ করা হয়েছে।

## কী করা যায়
- JSON backup ফাইল import করে existing data-এর সাথে merge করা যায়।
- JSON ছাড়াও প্রতি লাইনে `YYYY-MM-DD` + অন্তত ৩টি 4-digit number দিলে draw record বানানো যায়।
- একই `company + date` থাকলে duplicate record যোগ করা হয় না।
- নতুন data যোগ করার সময় existing data মুছে ফেলা হয় না।

## গুরুত্বপূর্ণ Android সীমাবদ্ধতা
পুরনো APK-এর private SQLite/localStorage নতুন APK সরাসরি পড়তে পারে না, কারণ Android প্রতিটি app/package-এর private storage আলাদা রাখে। তাই পুরনো APK-এর data নিজে থেকে তুলে আনার জন্য পুরনো app থেকে কোনো export/backup বা একই signed package দরকার।

এই migration ব্যবস্থা সেই exported data পাওয়ার পর নিরাপদে নতুন app-এ ঢোকানোর জন্য তৈরি করা হয়েছে। পুরনো app আনইনস্টল বা data clear করার দরকার নেই।


## Automatic old+new merge behavior

অ্যাপ update করার সময় নতুন release প্রথমে native SQLite এবং পুরনো retained localStorage—দুই জায়গার result পড়ার চেষ্টা করে। দুই source-এর data `company + date` key দিয়ে merge করা হয়; একই draw দুই জায়গায় থাকলে native SQLite record-কে canonical ধরা হয়, কিন্তু এক source-এ থাকা পুরনো draw অন্য source-এর কারণে হারিয়ে যায় না। Merge-এর union আবার SQLite-তে সংরক্ষণ করা হয়।

তবে Android-এর package identity/signing আলাদা হলে পুরনো app sandbox নিজে থেকে পাওয়া যায় না। এই ক্ষেত্রে পুরনো app থেকে Backup/Export করে Data Migration/Restore-এ import করতে হবে।

## 2026-09-17 Storage/Data Safety Hardening

- পুরাতন localStorage + native SQLite একসাথে master merge হয়।
- একই company+date-এ ভিন্ন result হলে existing record overwrite করা হয় না; conflict log-এ রাখা হয়।
- merge-এর সময় ID collision হলে unique ID remap করা হয়।
- normal Add Result একই company+date overwrite করে না।
- migration conflict log backup-এর সঙ্গে রাখা হয়।
- localStorage-এর primary copy-এর সঙ্গে mirror এবং previous snapshot backup রাখা হয়।
