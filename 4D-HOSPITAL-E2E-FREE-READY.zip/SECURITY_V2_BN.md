# 4D HOSPITAL — Security V2

এই build-এ ফোন নম্বর/SMS/OTP, Firebase, Replit backend বা paid verification service ব্যবহার করা হয়নি।

## Implemented
- Admin password source-code থেকে সরানো হয়েছে।
- Admin credential PBKDF2-SHA-256 + random salt দিয়ে সংরক্ষণ করা হয়।
- Password plain text হিসেবে নতুন করে সংরক্ষণ করা হয় না।
- পুরনো `4d_ls_admin_password_v1` থাকলে একবার hash-এ migrate করে পরে মুছে ফেলা হয়।
- Admin session `sessionStorage`-এ রাখা হয়; app restart-এর পর পুনরায় authentication প্রয়োজন।
- Guest access code hash করা হয় এবং unlock session-only রাখা হয়।
- Failed login audit event তৈরি হয়।
- Email/Replit backup path disabled.
- Existing SQLite database encryption mode পরিবর্তন করা হয়নি, যাতে পুরনো 101 Draw/2320 data migration-এর সময় ঝুঁকিতে না পড়ে।

## Important limitation
Offline JavaScript app-এ rooted/debuggable device বা modified app থেকে 100% tamper-proof security সম্ভব নয়। এই build-এর লক্ষ্য হলো সাধারণ localStorage manipulation, plain-text credential exposure এবং accidental session persistence-এর ঝুঁকি উল্লেখযোগ্যভাবে কমানো।
