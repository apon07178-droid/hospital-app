# 4D HOSPITAL — Scientific Validation Correction Pass

এই সংশোধন পাসে বৈজ্ঞানিক validation layer-কে শুধু আলাদা module হিসেবে রাখা হয়নি; ranking/backtest pipeline-এর সঙ্গে বাস্তবভাবে যুক্ত করা হয়েছে।

## কী সংশোধন হয়েছে
1. **Look-ahead bias**: newest-first historical data convention অনুযায়ী validation/test draw-এর জন্য কেবল তার চেয়ে পুরোনো draw training-এ ব্যবহার হয়।
2. **K-Fold**: placeholder `()=>[]` বাদ দিয়ে বাস্তব ranking function ব্যবহার করা হয়েছে। Android UI responsive রাখার জন্য automatic validation-এ 3 contiguous blocked folds ব্যবহার করা হয়েছে; প্রতিটি fold-এ full 0000–9999 candidate space rank করা হয়।
3. **Score normalization**: প্রতিটি signal একই 0000–9999 candidate universe-এ 0–1 range-এ normalize হয়ে তারপর ensemble weighting-এ যায়।
4. **Adaptive reliability**: সাম্প্রতিক historical walk-forward tests থেকে signal reliability weight শেখানো হয়; অল্প sample-এ Beta(1,1) prior দিয়ে extreme weight আটকানো হয়।
5. **Redundancy control**: খুব বেশি correlated signal group হলে group-size অনুযায়ী weight discount হয়, যাতে একই evidence বারবার count না হয়।
6. **Walk-forward backtest**: প্রতিটি test draw-এর ranking শুধুমাত্র older training data থেকে তৈরি হয়।
7. **ACF**: raw 4-digit magnitude-এর বদলে চারটি digit-position-এর autocorrelation গড় করে historical dependence পরীক্ষা করা হয়।
8. **Pipeline integration**: 3-stage consensus pipeline-এর Stage 3-এ normalized scientific score secondary evidence হিসেবে যুক্ত হয়েছে; scientific channel-এর maximum influence 25% of the normalized Borda scale, যাতে এটি model consensus-কে অযথা dominate না করে।
9. **Confidence wording**: confidence-কে win probability হিসেবে ব্যবহার করা হয়নি; এটি ranking evidence-এর descriptive index।

## যা এখনও claim করা হচ্ছে না
- কোনো lottery result guaranteed predict করা হচ্ছে না।
- `LSTM`, `Genetic-style`, `Benford-style` নামের signalগুলো প্রকৃত trained LSTM/neural network বা causal generator নয়; এগুলো deterministic statistical/heuristic signals হিসেবে ব্যবহার করা হয়েছে।
- Statistical significance randomness-এর বিরুদ্ধে evidence দিতে পারে, কিন্তু ভবিষ্যৎ draw predictable প্রমাণ করে না।

## Data safety
এই pass data-entry/storage schema পরিবর্তন করে না। SQLite/local fallback, JSON backup/restore এবং existing app modules রাখা হয়েছে।
