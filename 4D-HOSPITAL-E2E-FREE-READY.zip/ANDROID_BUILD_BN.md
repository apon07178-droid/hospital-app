# 4D HOSPITAL — Android wrapper

এই project-এ Capacitor configuration যোগ করা হয়েছে, যাতে Vite web app-টিকে Android app হিসেবে package করা যায়।

## Build sequence

```bash
npm install
npm run build
npx cap add android
npx cap sync android
```

তারপর Android Studio-তে `android/` project খুলে APK/AAB build করতে হবে।

> `android/` folder এই ZIP-এ ইচ্ছাকৃতভাবে pre-generated রাখা হয়নি; এটি Capacitor CLI দিয়ে generate করা হবে।
