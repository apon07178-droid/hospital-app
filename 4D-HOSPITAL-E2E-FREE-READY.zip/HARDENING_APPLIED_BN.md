# 4D HOSPITAL — Hardening Applied

এই build-এ source-level hardening করা হয়েছে:

- SQLite replace operation transaction-এর মধ্যে চলে; মাঝপথে error হলে rollback হবে।
- Result upsert-এর আগে company/date এবং 1st/2nd/3rd-এর basic validation করা হয়।
- Special/Consolation-এ কেবল valid 4-digit values রাখা হয় এবং সর্বোচ্চ 50টি করে নেওয়া হয়।
- Full backup-এ version 3 checksum যোগ করা হয়েছে। Backup ফাইল পরিবর্তিত/অসম্পূর্ণ হলে Restore তা প্রত্যাখ্যান করবে।
- Full backup-এর Results, Agent/KYC, Settings, preferences এবং local app data রাখা হয়।
- Android backup native Documents + Share flow ব্যবহার করে।

## সীমাবদ্ধতা

- SQLite database encryption এখনো চালু করা হয়নি, কারণ existing data compatibility না ভেঙে encryption migration আলাদা ধাপ।
- OCR engine-এর প্রথম load এখনো CDN-নির্ভর; সম্পূর্ণ offline OCR-এর জন্য engine assets app-এর মধ্যে bundle করতে হবে।
- Android APK compile/runtime test এই পরিবেশে সম্পূর্ণ করা যায়নি।
