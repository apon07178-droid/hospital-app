# 4D HOSPITAL — Data Storage

- Live data stays on the Android device; Gmail is not the database.
- JSON backup/restore is used for portable backups.
- The project includes a storage abstraction ready for a native SQLite backend.
- SQLite is recommended for very large historical datasets because it supports indexed search/filtering and avoids browser localStorage limits.
- A fixed GB guarantee cannot be promised; practical capacity depends on device storage and the database implementation.
- Google Drive should be a backup destination, not the live database.
