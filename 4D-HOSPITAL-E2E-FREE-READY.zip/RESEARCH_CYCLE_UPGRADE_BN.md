# 4D HOSPITAL — Research Cycle Upgrade

এই build-এ analysis → prediction lock → actual batch → validation → dataset update workflow যুক্ত করা হয়েছে।

## Cycle protocol
1. Current dataset select করা হয় (company অনুযায়ী)।
2. Minimum 10 valid historical 4D row ছাড়া নতুন lock তৈরি হয় না।
3. বর্তমান dataset থেকে analysis engine candidate pool তৈরি করে।
4. Prediction Snapshot-এ dataset fingerprint, training count, candidate pool এবং method evidence সংরক্ষণ হয়।
5. Snapshot lock হওয়ার পরে actual batch analysis-এ পাঠানো হয় না।
6. Actual batch আলাদা করে input করা হয়।
7. Validation actual number বনাম locked candidate pool exact-match trace তৈরি করে।
8. প্রতিটি matched number-এর জন্য যে signal/method candidate-টিকে support করেছে তা দেখানো হয়।
9. Validate না করা পর্যন্ত actual batch dataset-এ apply করা যায় না।
10. Apply-এর পরে dataset version বদলায়; পরের cycle নতুন dataset দিয়ে শুরু করতে হয়।

## Leakage protection
- Locked cycle-এর dataset fingerprint validation-এর সময় পুনরায় গণনা করা হয়।
- Lock-এর পরে dataset বদলে গেলে validation/apply বন্ধ করা হয়।
- Actual batch validation-এর আগে analysis snapshot-এর input ছিল না।
- Cycle snapshot localStorage-এ historical record হিসেবে রাখা হয়।

## Analysis catalog
UI-তে 107-option research catalog আছে। এটি descriptive, structural, predictive এবং validation স্তরের analysis ধারণাগুলোকে এক জায়গায় দেখায়।

## Scientific interpretation
- Candidate rank/confidence একটি descriptive ranking index; এটি নিশ্চিত ভবিষ্যৎ ফল বা winning probability নয়।
- Historical backtest এবং cycle validation আলাদা রাখা হয়েছে।
- কোনো pattern historical data-তে দেখা গেলেই সেটি ভবিষ্যৎ causal mechanism প্রমাণ করে না।
- অনেক test একসঙ্গে চালালে false-discovery/multiple-testing সমস্যা হতে পারে; তাই out-of-sample এবং walk-forward validation গুরুত্বপূর্ণ।
