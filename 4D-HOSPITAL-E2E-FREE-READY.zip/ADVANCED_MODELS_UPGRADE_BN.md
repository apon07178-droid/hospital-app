# 4D HOSPITAL — Advanced Models Upgrade

এই সংস্করণে আগের placeholder-style Genetic signal সরিয়ে একটি বাস্তব offline genetic optimizer এবং একটি compact trained recurrent LSTM signal যোগ করা হয়েছে।

## Trained LSTM signal
- চারটি digit position আলাদাভাবে sequence model করা হয়।
- LSTM cell-এ input/forget/output gates, cell state এবং hidden state আছে।
- Historical sequence দিয়ে supervised output fitting করা হয়।
- ভবিষ্যৎ draw guarantee করে না; candidate ranking-এ একটি signal হিসেবে কাজ করে।
- পর্যাপ্ত history না থাকলে neutral score ব্যবহার করে।

## Genetic optimizer
- Population initialization
- Fitness evaluation
- Elitist selection
- One-point crossover
- Mutation
- Multiple generations
- Deterministic seed

Genetic optimizer historical position-frequency fitness ব্যবহার করে candidate search-এ সহায়তা করে। এটি কোনো guaranteed winning algorithm নয়।

## গুরুত্বপূর্ণ সীমা
- LSTM/Genetic model-এর statistical usefulness historical data-এর quality ও sample size-এর ওপর নির্ভর করে।
- এটি lottery outcome নিশ্চিতভাবে predict করে না।
- SQLite encryption, fully bundled offline OCR, এবং Android end-to-end runtime verification এই source upgrade-এর বাইরে এখনও আলাদা কাজ।
