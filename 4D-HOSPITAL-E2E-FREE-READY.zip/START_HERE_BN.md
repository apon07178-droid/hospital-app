# 4D HOSPITAL — Final Build

## Build flow
- `npm install`
- `npm run typecheck`
- `npm run build`
- Android: `npm run android:build`

## নতুন Research Cycle
Sidebar → 📐 বিশ্লেষণ → 🔒 Research Cycle

ব্যবহার:
1. Current company ও historical data প্রস্তুত করুন।
2. Batch size (যেমন 23) ও candidate pool (যেমন 100) দিন।
3. `LOCK NEW PREDICTION` চাপুন।
4. Actual batch আসার আগে snapshot সংরক্ষিত থাকবে।
5. Actual batch একসঙ্গে paste করুন।
6. `VALIDATE & TRACE` চাপুন।
7. কোন actual number locked pool-এ ছিল এবং কোন method signal সেটিকে support করেছে দেখুন।
8. সবকিছু যাচাই করার পরে `APPLY TO DATASET` চাপুন।
9. Dataset update হলে নতুন cycle lock করুন।

## গুরুত্বপূর্ণ
এই app historical mathematical/statistical analysis ও validation করে। কোনো model ভবিষ্যৎ 4D ফল নিশ্চিত করে না।
