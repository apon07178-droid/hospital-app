import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const catalog = fs.readFileSync(path.join(root, 'src/lib/analysis-catalog.ts'), 'utf8');
const names = [...catalog.matchAll(/\['([^']+)',\[(.*?)\],'[^']*'\]/gs)]
  .flatMap(m => [...m[2].matchAll(/'([^']+)'/g)].map(x => x[1]));
const publicCount = Math.min(names.length, 107);
const unique = new Set(names.slice(0, publicCount));
const required = [
  'src/App.tsx','src/lib/scorer.ts','src/lib/pipeline.ts','src/lib/advanced-models.ts',
  'src/lib/advanced-validation.ts','src/lib/research-cycle.ts','src/lib/sqlite-results.ts'
];
const missing = required.filter(f => !fs.existsSync(path.join(root, f)));
if (publicCount !== 107) throw new Error(`Expected 107 public catalog entries, found ${publicCount}`);
if (unique.size !== 107) throw new Error(`Duplicate analysis names detected: ${107-unique.size}`);
if (missing.length) throw new Error(`Missing core files: ${missing.join(', ')}`);
const app = fs.readFileSync(path.join(root, 'src/App.tsx'), 'utf8');
if (!app.includes('}, [analysis, engineResult]);')) throw new Error('Pipeline memo dependency guard missing');
const validation = fs.readFileSync(path.join(root, 'src/lib/advanced-validation.ts'), 'utf8');
if (!validation.includes('const train=validDraws.slice(0,start);')) throw new Error('Chronological blocked K-fold guard missing');
console.log(`STATIC AUDIT PASS: ${publicCount} public analysis entries, unique; core files present; validation/pipeline guards present.`);
