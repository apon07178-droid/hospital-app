from pathlib import Path
import html
import re

from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    PageBreak,
    Paragraph,
    Preformatted,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)
from reportlab.lib import colors


ROOT = Path(__file__).resolve().parents[1]
source = ROOT / "APP_DOCUMENTATION_BN.md"
output = ROOT / "APP_DOCUMENTATION_BN.pdf"
font_path = ROOT / "assets" / "NotoSansBengali.ttf"

pdfmetrics.registerFont(TTFont("NotoBengali", str(font_path)))

styles = getSampleStyleSheet()
styles.add(
    ParagraphStyle(
        name="BNTitle",
        parent=styles["Title"],
        fontName="NotoBengali",
        fontSize=19,
        leading=27,
        alignment=TA_CENTER,
        textColor=colors.HexColor("#102a43"),
        spaceAfter=12,
    )
)
styles.add(
    ParagraphStyle(
        name="BNH1",
        parent=styles["Heading1"],
        fontName="NotoBengali",
        fontSize=14,
        leading=21,
        textColor=colors.HexColor("#0b7285"),
        spaceBefore=10,
        spaceAfter=6,
    )
)
styles.add(
    ParagraphStyle(
        name="BNH2",
        parent=styles["Heading2"],
        fontName="NotoBengali",
        fontSize=11.5,
        leading=17,
        textColor=colors.HexColor("#243b53"),
        spaceBefore=7,
        spaceAfter=4,
    )
)
styles.add(
    ParagraphStyle(
        name="BNBody",
        parent=styles["BodyText"],
        fontName="NotoBengali",
        fontSize=9.5,
        leading=15,
        spaceAfter=4,
    )
)
styles.add(
    ParagraphStyle(
        name="BNBullet",
        parent=styles["BodyText"],
        fontName="NotoBengali",
        fontSize=9.5,
        leading=15,
        leftIndent=12,
        firstLineIndent=-8,
        bulletIndent=0,
        spaceAfter=2,
    )
)
styles.add(
    ParagraphStyle(
        name="BNCode",
        parent=styles["Code"],
        fontName="NotoBengali",
        fontSize=8.5,
        leading=12,
        leftIndent=8,
        backColor=colors.HexColor("#f0f4f8"),
        borderPadding=5,
        spaceAfter=7,
    )
)


def inline(text: str) -> str:
    text = html.escape(text)
    text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"`(.+?)`", r"<font name='NotoBengali'>\1</font>", text)
    return text


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("NotoBengali", 8)
    canvas.setFillColor(colors.HexColor("#627d98"))
    canvas.drawString(18 * mm, 10 * mm, "4D HOSPITAL — সম্পূর্ণ অ্যাপ ডকুমেন্টেশন")
    canvas.drawRightString(192 * mm, 10 * mm, f"পৃষ্ঠা {doc.page}")
    canvas.restoreState()


story = []
lines = source.read_text(encoding="utf-8").splitlines()
i = 0
while i < len(lines):
    line = lines[i].rstrip()
    if not line:
        story.append(Spacer(1, 3))
        i += 1
        continue
    if line.startswith("# "):
        story.append(Paragraph(inline(line[2:]), styles["BNTitle"]))
    elif line.startswith("## "):
        story.append(Paragraph(inline(line[3:]), styles["BNH1"]))
    elif line.startswith("### "):
        story.append(Paragraph(inline(line[4:]), styles["BNH2"]))
    elif line.startswith("> "):
        story.append(Paragraph(inline(line[2:]), styles["BNBody"]))
    elif line.startswith("- "):
        story.append(Paragraph("• " + inline(line[2:]), styles["BNBullet"]))
    elif re.match(r"^\d+\.\s+", line):
        story.append(Paragraph(inline(line), styles["BNBullet"]))
    elif line.startswith("```"):
        code = []
        i += 1
        while i < len(lines) and not lines[i].startswith("```"):
            code.append(lines[i])
            i += 1
        story.append(Preformatted("\n".join(code), styles["BNCode"]))
    elif line.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip("|").split("|")]
            if not all(set(c) <= {"-", ":", " "} for c in cells):
                rows.append([Paragraph(inline(c), styles["BNBody"]) for c in cells])
            i += 1
        if rows:
            table = Table(rows, repeatRows=1, colWidths=[55 * mm, 115 * mm])
            table.setStyle(
                TableStyle(
                    [
                        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#d9eaf7")),
                        ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#9fb3c8")),
                        ("VALIGN", (0, 0), (-1, -1), "TOP"),
                        ("LEFTPADDING", (0, 0), (-1, -1), 5),
                        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                        ("TOPPADDING", (0, 0), (-1, -1), 4),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                    ]
                )
            )
            story.append(table)
            continue
    else:
        story.append(Paragraph(inline(line), styles["BNBody"]))
    i += 1

doc = SimpleDocTemplate(
    str(output),
    pagesize=A4,
    rightMargin=18 * mm,
    leftMargin=18 * mm,
    topMargin=16 * mm,
    bottomMargin=17 * mm,
    title="4D HOSPITAL — সম্পূর্ণ অ্যাপ ডকুমেন্টেশন",
    author="4D HOSPITAL",
)
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print(output)