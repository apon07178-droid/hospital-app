# 4D HOSPITAL — Applied Fixes

এই build-এ মূল source-এর বিদ্যমান feature set রেখে Android/local-data ব্যবহারের জন্য কয়েকটি গুরুত্বপূর্ণ স্থায়িত্বের fix করা হয়েছে।

## 1. SQLite edit fix
Company বা date Edit করলে আগের primary-key row-এর সঙ্গে conflict না করে আগে `id` দিয়ে UPDATE করা হয়। ফলে Data Vault-এর Edit থেকে company/date বদলানো নিরাপদ হয়েছে।

## 2. Full local backup
Backup JSON এখন শুধু draw results নয়, একই সঙ্গে local Agent/KYC records, local settings এবং theme/language/compact preferences-ও রাখে।

## 3. Full restore
Full 4D HOSPITAL backup restore করলে results-এর সঙ্গে Agent/KYC, settings ও preferences থাকলে সেগুলিও restore হয়। পুরোনো সাধারণ results-only JSON-ও import করা যাবে।

## 4. Android backup route
Android-এ browser download-এর বদলে Capacitor Filesystem-এর Documents area-তে backup লেখা হয় এবং native Share/Save sheet খোলা হয়।

## 5. Project ZIP structure
ZIP-এর root-এ সরাসরি `package.json`, `src/`, `public/`, `capacitor.config.ts` ইত্যাদি আছে। আলাদা `v2/` wrapper folder নেই। তাই GitHub Actions-এর existing ZIP workflow-এর সঙ্গে ব্যবহার করা সহজ।

## Important limitation
পুরোনো APK-এর private SQLite database নতুন APK সরাসরি পড়তে পারে না। পুরোনো app-এর data আনতে পুরোনো app থেকে export/recovery বা user-mediated JSON/text migration দরকার।

Screenshot OCR-এর প্রথম engine load বর্তমানে CDN-নির্ভর; তাই প্রথম OCR run-এ internet প্রয়োজন হতে পারে।
