# 4D HOSPITAL — সম্পূর্ণ অ্যাপ ডকুমেন্টেশন

**অ্যাপের নাম:** 4D HOSPITAL — 4D Data & Analysis  
**বর্তমান ভার্শন:** 1.0.0  
**ভাষা:** বাংলা UI, English analysis labels  
**ডেটা সংরক্ষণ:** Browser `localStorage`  
**বর্তমান মডেল:** Free/local 4D data analytics  

> এই অ্যাপ 4D result-এর historical pattern বিশ্লেষণ করে সম্ভাব্য number দেখায়। এটি কোনো নিশ্চিত ভবিষ্যদ্বাণী নয়। 4D ফলাফল random হতে পারে। নিজের দায়িত্বে ব্যবহার করুন।

---

## ১. অ্যাপের মূল উদ্দেশ্য

4D HOSPITAL হলো Malaysia 4D 4D result রাখার এবং historical data বিশ্লেষণ করার একটি browser-based app।

অ্যাপটি:

- Magnum, Damacai এবং Toto কোম্পানির result আলাদা করে রাখে
- Result copy-paste করে দ্রুত save করতে দেয়
- 4-digit number-এর historical frequency বিশ্লেষণ করে
- 25টি formula combine করে Smart Generator-এ সম্ভাব্য 5টি number দেখায়
- প্রতিটি company-র জন্য আলাদা result ও আলাদা generated set দেখায়
- JSON backup export/import করতে দেয়
- কোনো paid API, OCR API, database বা login server-এর উপর নির্ভর করে না

---

## ২. অ্যাপ চালু করার পর প্রথম কাজ

### Admin Mode চালু করা

1. বাম পাশের menu খুলুন।
2. নিচে **Admin Mode চালু করুন** চাপুন।
3. Admin password দিন:

```text
Rrm.92@26
```

4. Admin Mode চালু হলে Data Entry এবং Settings দেখা যাবে।

### Admin Mode বন্ধ করা

Sidebar থেকে **Admin Mode বন্ধ করুন** চাপলে browser-এ admin session মুছে যাবে।

> Password browser-এর frontend code-এ থাকে। এটি production-grade server authentication নয়। তাই এই app-কে sensitive business system হিসেবে ব্যবহার করবেন না।

---

## ৩. Result input করার সবচেয়ে সহজ পদ্ধতি: Quick Paste

### ধাপসমূহ

1. Admin Mode চালু করুন।
2. Sidebar থেকে **✏️ Manual Entry** খুলুন।
3. **📋 Quick Paste** tab নির্বাচন করুন।
4. Company নির্বাচন করুন:
   - Magnum
   - Damacai
   - Toto
5. Result-এর তারিখ নির্বাচন করুন।
6. চাইলে Draw Number দিন।
7. 4D result source থেকে result-এর text copy করুন।
8. বড় paste box-এ text paste করুন।
9. **Save** চাপুন।

### Auto-detection কীভাবে কাজ করে

App text-এর মধ্যে থাকা 4-digit number খুঁজে বের করে:

| ধারাবাহিকতা | ব্যবহার |
|---|---|
| প্রথম number | 1st Prize |
| দ্বিতীয় number | 2nd Prize |
| তৃতীয় number | 3rd Prize |
| পরের ১০টি | Special |
| তার পরের ১০টি | Consolation |

উদাহরণ:

```text
1234 5678 9012
3456 7890 2345 6789 1111 2222 3333 4444 5555 6666
7777 8888 9999 0000 1212 3434 5656 7878 9090 1357
```

App যেকোনো text-এর মধ্য থেকে 4-digit number বের করে preview দেখাবে। Save করার আগে preview দেখে নিন।

### গুরুত্বপূর্ণ সতর্কতা

- একই date এবং একই company-র result আবার save করলে আগের record replace হবে।
- Date সঠিক না হলে Calendar Analysis ভুল হবে।
- Copy করা text-এ draw number বা year-এর মতো 4-digit সংখ্যা থাকলে সেটিও detect হতে পারে। Save করার আগে 1st/2nd/3rd preview পরীক্ষা করুন।
- 1st, 2nd এবং 3rd prize না থাকলে Save হবে না।

---

## ৪. Manual Entry

Quick Paste ব্যবহার না করতে চাইলে **✏️ Manual Entry** tab ব্যবহার করুন।

এখানে আলাদা করে পূরণ করতে পারবেন:

- Company
- Date
- Draw Number
- 1st Prize
- 2nd Prize
- 3rd Prize
- Special numbers
- Consolation numbers

একাধিক Special বা Consolation number space অথবা comma দিয়ে লিখুন:

```text
1234 5678 9012, 3456, 7890
```

---

## ৫. Dashboard এবং Company Result

### Dashboard & Stats

Dashboard-এ সাধারণ summary দেখা যায়:

- মোট result সংখ্যা
- Company-wise result
- Digit frequency
- Recent result
- Historical overview

### Company pages

প্রতিটি company-র জন্য আলাদা page আছে। সেখানে:

- Result history
- Prize number
- Date
- Draw number
- Company-specific analysis
- Admin হলে result edit/reset option

Company বদলালে analysis-ও সেই company অনুযায়ী বদলে যাবে।

---

## ৬. Smart Generator Mode

Sidebar-এর একেবারে উপরে **🎯 Smart Generator** আছে।

### ব্যবহার

1. Smart Generator খুলুন।
2. **Generate করুন** চাপুন।
3. প্রতিটি company-র জন্য আলাদা 5 সেট 4-digit number দেখাবে।
4. **▶ পরবর্তী সেট** চাপলে পরের 5টি ranked number আসবে।

Generator-এর জন্য অন্তত 3টি result দরকার। বেশি historical data থাকলে pattern analysis তুলনামূলকভাবে বেশি meaningful হবে।

### প্রতিটি company-র output

প্রতিটি company আলাদা card হিসেবে দেখায়:

- Generated 4-digit number
- Confidence percentage
- Formula count
- কোন কোন formula support করেছে
- পরবর্তী set button

### Confidence-এর অর্থ

- **High:** অনেক formula একই number বা pattern support করেছে
- **Medium:** কিছু formula support করেছে
- **Low:** কম formula support করেছে

Confidence কোনো জয়ের নিশ্চয়তা নয়।

---

## ৭. Smart Generator-এর ২৫টি Formula

Generator historical result থেকে নিচের model ও pattern combine করে score তৈরি করে:

1. Position Frequency
2. Hot Digit
3. Pair Frequency
4. Triplet Frequency
5. Markov Chain
6. Mirror Number
7. Neighbor +1 / -1
8. High/Low Pattern
9. Benford-style First Digit Weight
10. Overdue / Gap Analysis
11. Digit Sum Pattern
12. Even/Odd Balance
13. Calendar / Weekday Pattern
14. Recent Trending Digits
15. Permutation Filter
16. Digit Diversity
17. Cross-Company Pattern
18. Regression-style Sum Trend
19. LSTM-like Recent Sequence Matching
20. Genetic-style Best Digit Combination
21. Skip-Draw Gap Pattern
22. Cold Digit / Due Digit
23. Backtest-style Triplet Extension
24. Digit Spread
25. Consensus Boost

### Score কীভাবে ব্যবহার করবেন

Score যত বেশি:

- তত বেশি formula number-টিকে support করেছে
- ranking তত উপরে এসেছে
- confidence bar তত বড় হয়েছে

Score probability বা guaranteed winning chance নয়।

---

## ৮. Advanced Mathematical Engine

বর্তমান engine-এ ২৭টি base signal-এর সঙ্গে অতিরিক্ত data-analysis layer যুক্ত করা হয়েছে:

- Position Matrix — ১ম/২য়/৩য়/৪র্থ position আলাদা বিশ্লেষণ
- Transition Matrix — draw-to-draw digit transition
- Pair Matrix ও Triplet Pattern
- Digit Entropy / Stability
- Mutual Correlation
- Recency ও Overdue/GAP analysis
- Rolling 10/20/30/50 draw windows
- Bayesian smoothing
- Pattern classification, Sum, Even/Odd, High/Low, Spread
- Walk-forward backtest
- Historical signal reliability weighting
- Adaptive ensemble ranking
- Anti-repeat / diversity guard
- Candidate score breakdown ও quality information

এই ফলাফল historical data-এর ভিত্তিতে ranking/analysis; কোনো future lottery result-এর নিশ্চয়তা নয়।

## ৮. অন্যান্য Analysis Menu

### Deep Analysis

একাধিক historical pattern একসাথে দেখায়:

- Position-wise frequency
- Hot/cold digits
- Recent trend
- Gap
- Candidate pattern

### Triplet এবং Pair Analysis

- 3-digit sequence কতবার এসেছে
- 2-digit pair কতবার এসেছে
- কোন sequence সাম্প্রতিকভাবে বেশি দেখা গেছে

### High/Low & Odd/Even

প্রতিটি number-এর digit-কে:

- High: 5–9
- Low: 0–4
- Odd
- Even

এইভাবে pattern করা হয়।

### Pattern Heatmap

Digit pair বা position transition-এর frequency visual heatmap হিসেবে দেখায়।

### Calendar Correlation

Date এবং weekday অনুযায়ী historical pattern তুলনা করে।

### Regression Trends

Digit sum এবং historical movement-এর trend দেখায়।

### Mirror Number

শেষ result-এর digit mirror mapping ব্যবহার করে candidate দেখায়।

### Benford's Law

First digit distribution-এর একটি statistical comparison দেখায়। 4D results can be random হওয়ায় এটিকে নিশ্চিত rule হিসেবে ব্যবহার করা যাবে না।

### Permutation Filter

একটি number-এর digit arrangement বদলে সম্ভাব্য permutation দেখায়।

### Skip-Draw এবং Neighbor Digits

- কোনো number কত draw ধরে আসেনি
- শেষ digit থেকে কাছাকাছি digit pattern

### Cross-Company এবং Correlation

ভিন্ন company-র result-এর মধ্যে digit/pattern মিল দেখায়।

### AI & ML menu

App-এ label করা model views:

- LSTM Sequence
- Markov Chain
- Genetic Algorithm
- Cluster & Outlier
- Backtesting
- Sliding Window
- Consensus

এই frontend version-এ এগুলো historical/local calculation ব্যবহার করে। কোনো paid AI API call করে না।

---

## ৯. Data সংরক্ষণ ব্যবস্থা

এই app browser `localStorage` ব্যবহার করে। প্রধান data keys:

| Key | ব্যবহার |
|---|---|
| `4d_ls_results_v1` | 4D result |
| `4d_ls_admin_v1` | Local admin session |
| `4d_ls_picks_v1` | Admin picks |
| `4d_ls_guest_code_v1` | Guest access code |
| `4d_ls_guest_epoch_v1` | Guest revoke version |
| `4d_ls_guest_unlocked_v1` | Local guest unlock state |

### এর সুবিধা

- Server cost নেই
- Database cost নেই
- Paid API নেই
- Offline/local browser usage সম্ভব
- Data save দ্রুত হয়

### এর সীমাবদ্ধতা

- Data browser/device-specific
- Browser data clear করলে result মুছে যেতে পারে
- অন্য device-এ automatically data দেখা যাবে না
- Browser বদলালে data দেখা যাবে না
- Multiple users-এর shared live database নেই
- Remote access revoke সম্পূর্ণভাবে সম্ভব নয়

---

## ১০. Backup এবং Restore

### Export

1. Admin Mode চালু করুন।
2. Settings খুলুন।
3. **Export JSON** চাপুন।
4. Download করা `.json` file নিরাপদে রাখুন।

সপ্তাহে অন্তত একবার backup রাখা ভালো।

### Import

1. Settings খুলুন।
2. Export করা JSON file-এর text copy করুন।
3. Import box-এ paste করুন।
4. Import চাপুন।
5. App reload হলে data দেখা যাবে।

> Import করার আগে current data export করে রাখুন। ভুল JSON import করলে পুরনো data replace হতে পারে।

### Data delete

Settings-এর **সব Data মুছুন** button permanentভাবে local result মুছে দেয়। Delete করার আগে Export করুন।

---

## ১১. Guest Access Control

Admin Settings থেকে:

- Access Code সেট করা
- Access Code পরিবর্তন করা
- সব guest session revoke করা
- Guest lock বন্ধ করা

### বাস্তব সীমাবদ্ধতা

এই control localStorage-ভিত্তিক। তাই:

- একই browser/device-এ lock কাজ করে
- Access Code পরিবর্তন করলে নতুন visitor-এর জন্য নতুন code দরকার হয়
- আগের visitor-এর browser data remoteভাবে মুছতে পারে না
- সব visitor-এর remote revoke দরকার হলে backend/database লাগবে

সম্পূর্ণ remote access management free browser-only architecture-এ সম্ভব নয়।

---

## ১২. Free Architecture

বর্তমান free version-এ:

- React + Vite frontend
- Browser localStorage
- Client-side calculation
- Static production build
- কোনো OpenAI/OCR call নেই
- কোনো paid external API নেই
- কোনো required database নেই
- কোনো required email service নেই

API Server project workspace-এ থাকলেও 4D HOSPITAL frontend-এর normal free operation তার উপর নির্ভর করে না।

---

## ১৩. Publishing নির্দেশনা

### Publish-এর আগে checklist

- Quick Paste কাজ করছে
- Smart Generator খুলছে
- Data save হচ্ছে
- Export/Import পরীক্ষা করা হয়েছে
- Admin password জানা আছে
- Backup রাখা হয়েছে
- Production settings-এ 4D HOSPITAL artifact নির্বাচন করা হয়েছে

### Publish করার পরে

- নতুন browser/device থেকে link খুলে দেখুন
- Access Code সেট থাকলে code দিয়ে প্রবেশ পরীক্ষা করুন
- Admin Mode খুলে দেখুন
- Quick Paste-এ test result save করুন
- Generator-এ Generate চাপুন

### Publish option না দেখা গেলে

Replit workspace-এর Deploy/Publish panel খুলে:

1. **4D HOSPITAL Dashboard** নির্বাচন করুন
2. Static deployment নির্বাচন করুন
3. Publish চাপুন

যদি Publish button একেবারেই না থাকে, workspace plan বা permission-এর কারণে publishing disabled হতে পারে। Replit account-এর Publishing panel-এর screenshot দেখে এই সমস্যা নির্দিষ্টভাবে যাচাই করতে হবে।

> অ্যাপের code-এ paid API নেই। তবে Replit-এর hosting/publishing plan-এর নিজস্ব usage limit বা billing policy থাকতে পারে। Publish করার আগে Replit Publishing settings-এ plan ও usage limit দেখে নিন।

---

## ১৪. ভবিষ্যতে Update করার নিয়ম

ভবিষ্যতে নতুন feature যোগ করার সময়:

1. আগে Settings থেকে JSON Export করুন।
2. App code update করুন।
3. Typecheck ও build চালান।
4. Preview-তে পরীক্ষা করুন।
5. নতুন version publish করুন।
6. পুরনো backup রেখে দিন।

### Update-এর সময় data কী হবে

সাধারণ frontend update-এ browser localStorage data থাকা উচিত। তবে browser storage key বদলালে বা clear করলে data হারাতে পারে। তাই update-এর আগে Export বাধ্যতামূলক রাখুন।

### ভবিষ্যতে backend যোগ করতে চাইলে

Backend যোগ করলে সম্ভব হবে:

- সব device-এ shared data
- Remote revoke
- Real authentication
- Multiple admin
- Server backup
- Centralized result database

কিন্তু তখন app আর সম্পূর্ণ browser-only free architecture থাকবে না; hosting/database/API cost বা service limit বিবেচনা করতে হবে।

---

## ১৫. Troubleshooting

### Result save হচ্ছে না

- Admin Mode চালু আছে কিনা দেখুন
- অন্তত 3টি 4-digit number detect হয়েছে কিনা দেখুন
- Date নির্বাচন করা হয়েছে কিনা দেখুন
- Browser localStorage blocked কিনা দেখুন

### Data হঠাৎ নেই

- একই browser/device ব্যবহার করছেন কিনা দেখুন
- Incognito mode ব্যবহার করছেন কিনা দেখুন
- Browser data clear হয়েছে কিনা দেখুন
- Export backup থেকে Import করুন

### Generator number দেখাচ্ছে না

- অন্তত 3টি result দিন
- সঠিক company-তে result আছে কিনা দেখুন
- Number অবশ্যই 4-digit হতে হবে
- Page reload করে আবার Generate করুন

### App blank দেখালে

- Page reload করুন
- Browser cache clear না করে hard refresh চেষ্টা করুন
- Replit workflow running কিনা দেখুন
- Preview console error দেখুন

### Publishing ব্যর্থ হলে

- Publishing logs দেখুন
- Build command ও production settings পরীক্ষা করুন
- 4D HOSPITAL artifact নির্বাচন করুন
- Error text সংরক্ষণ করে troubleshooting করুন

---

## ১৬. Recommended Daily Workflow

1. 4D result website খুলুন।
2. Result text copy করুন।
3. Admin Mode চালু করুন।
4. Quick Paste-এ paste করুন।
5. Preview যাচাই করুন।
6. Save করুন।
7. Dashboard এবং analysis দেখুন।
8. Smart Generator-এ Generate করুন।
9. প্রয়োজনে JSON backup নিন।

---

## ১৭. Final Summary

4D HOSPITAL-এর বর্তমান ভার্শন:

- Free browser-based
- LocalStorage-powered
- Quick Paste enabled
- 25-formula Smart Generator enabled
- Company-wise 5-set candidate numbers
- JSON backup/restore enabled
- Admin local mode enabled
- No required paid API
- No required database
- ভবিষ্যতে update করা যাবে

তবে localStorage architecture-এর কারণে data sharing, remote revoke এবং centralized backup সীমিত থাকবে। এই সীমাবদ্ধতাগুলো দূর করতে ভবিষ্যতে backend/database version আলাদাভাবে তৈরি করতে হবে।
