export type CompanyId = "magnum" | "toto" | "damacai" | "singapore";

export type View =
  | "master" | "dashboard" | "company" | "triplets" | "pairs" | "cross"
  | "correlation" | "predictions" | "deep" | "heatmap" | "regression"
  | "calendar" | "highlowmatrix" | "mirror" | "benford" | "lstm" | "markov"
  | "genetic" | "outlier2" | "backtest" | "sliding" | "consensus" | "alerts"
  | "performance" | "scan" | "live" | "users" | "settings" | "permutation"
  | "skipdraw" | "neighbor";

export interface AuthUser {
  id: number;
  username: string;
  role: "admin" | "user";
}

export interface LotteryResult {
  id: number;
  company: string;
  date: string;
  drawNo: string | null;
  first: string;
  second: string;
  third: string;
  special: string[];
  consolation: string[];
}

export interface ManagedUser {
  id: number;
  username: string;
  role: string;
  isActive: boolean;
  createdAt: string;
  lastLogin: string | null;
}

export type ModelKey =
  | "pos30" | "pos90" | "triplet" | "hotFreq" | "benford"
  | "mirror4d" | "neighbor" | "highlow" | "calendar" | "permutation" | "markov";
