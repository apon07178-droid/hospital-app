/**
 * 4D HOSPITAL — Statistical Validation Layer
 *
 * Pure TypeScript, offline. These tests evaluate the historical dataset and
 * the ranking engine; they do not claim to make a random draw predictable.
 */

export interface ValidationDraw { first: string; date?: string }

export interface ChiSquareResult {
  position: number; observed: number[]; expected: number[]; statistic: number;
  degreesOfFreedom: number; pValue: number; significantAt05: boolean;
}

export interface ACFResult { lag: number; correlation: number; sampleSize: number }

export interface IndependenceResult {
  positions: string; correlation: number; chiSquare?: number; pValue?: number;
  significantAt05: boolean;
}

export interface RedundancyGroup { members: string[]; representative: string; maxCorrelation: number }

export interface MonteCarloResult {
  simulations: number; observedHits: number; expectedHits: number;
  pValue: number; zScore: number; baselineTopN: number;
}

export interface KFoldResult {
  folds: number; tests: number; exactHits: number; exactRate: number;
  foldRates: number[]; meanRate: number; stdDev: number;
}

export interface ConfidenceResult {
  estimate: number; lower: number; upper: number; sampleSize: number;
}

export interface ValidationReport {
  sampleSize: number;
  chiSquare: ChiSquareResult[];
  acf: ACFResult[];
  independence: IndependenceResult[];
  redundancy: RedundancyGroup[];
  monteCarlo: MonteCarloResult;
  kFold: KFoldResult;
  confidence: ConfidenceResult;
  scoreNormalization: { min: number; max: number; mean: number };
  lookAheadSafe: boolean;
  notes: string[];
}

function valid(n: string): boolean { return /^\d{4}$/.test(n); }
function firsts(draws: ValidationDraw[]): string[] { return draws.map(d => d.first).filter(valid); }

/** Lanczos approximation of log-gamma, used for chi-square CDF without dependencies. */
function logGamma(z: number): number {
  const p = [676.5203681218851,-1259.1392167224028,771.32342877765313,-176.61502916214059,12.507343278686905,-0.13857109526572012,9.984369578019572e-6,1.5056327351493116e-7];
  if (z < 0.5) return Math.log(Math.PI) - Math.log(Math.sin(Math.PI*z)) - logGamma(1-z);
  let x = 0.9999999999998099;
  const t = z - 1;
  for (let i=0;i<p.length;i++) x += p[i] / (t+i+1);
  const q = t + p.length - 0.5;
  return 0.5*Math.log(2*Math.PI) + (t+0.5)*Math.log(q) - q + Math.log(x);
}

function gammaP(a: number, x: number): number {
  if (x <= 0) return 0;
  if (x < a + 1) {
    let ap=a, sum=1/a, del=sum;
    for(let n=1;n<=100;n++){ ap += 1; del *= x/ap; sum += del; if(Math.abs(del)<Math.abs(sum)*1e-12) break; }
    return sum*Math.exp(-x+a*Math.log(x)-logGamma(a));
  }
  let b=x+1-a, c=1/1e-300, d=1/b, h=d;
  for(let i=1;i<=100;i++){
    const an=-i*(i-a); b+=2; d=an*d+b; if(Math.abs(d)<1e-300)d=1e-300; c=b+an/c; if(Math.abs(c)<1e-300)c=1e-300; d=1/d; const del=d*c; h*=del; if(Math.abs(del-1)<1e-12)break;
  }
  return 1-Math.exp(-x+a*Math.log(x)-logGamma(a))*h;
}

function chiSquarePValue(statistic: number, df: number): number {
  return Math.max(0, Math.min(1, 1-gammaP(df/2, statistic/2)));
}

export function chiSquareUniform(draws: ValidationDraw[]): ChiSquareResult[] {
  const ns=firsts(draws); const out:ChiSquareResult[]=[];
  for(let p=0;p<4;p++){
    const observed=Array(10).fill(0); for(const n of ns) observed[Number(n[p])]++;
    const expected=Array(10).fill(ns.length/10); let stat=0;
    for(let d=0;d<10;d++) stat += (observed[d]-expected[d])**2/Math.max(expected[d],1e-12);
    const pv=chiSquarePValue(stat,9);
    out.push({position:p,observed,expected,statistic:stat,degreesOfFreedom:9,pValue:pv,significantAt05:pv<0.05});
  }
  return out;
}

export function autocorrelation(draws: ValidationDraw[], maxLag=12): ACFResult[] {
  const ns=firsts(draws);
  if(ns.length<3)return [];
  const out:ACFResult[]=[];
  const lags=Math.min(maxLag,Math.max(0,ns.length-2));
  for(let lag=1;lag<=lags;lag++){
    const perPos:number[]=[];
    for(let p=0;p<4;p++){
      const values=ns.map(n=>Number(n[p]));
      const mean=values.reduce((a,b)=>a+b,0)/values.length;
      let den=0,num=0;
      for(let i=0;i<values.length;i++)den+=(values[i]-mean)**2;
      for(let i=lag;i<values.length;i++)num+=(values[i]-mean)*(values[i-lag]-mean);
      perPos.push(den?num/den:0);
    }
    out.push({lag,correlation:perPos.reduce((a,b)=>a+b,0)/perPos.length,sampleSize:ns.length-lag});
  }
  return out;
}

/** Pearson correlation plus a chi-square independence test on 10x10 digit pairs. */
export function digitIndependence(draws: ValidationDraw[]): IndependenceResult[] {
  const ns=firsts(draws); const out:IndependenceResult[]=[];
  for(let a=0;a<4;a++) for(let b=a+1;b<4;b++){
    const table=Array.from({length:10},()=>Array(10).fill(0));
    const xa:number[]=[], xb:number[]=[];
    for(const n of ns){const x=Number(n[a]),y=Number(n[b]);table[x][y]++;xa.push(x);xb.push(y);}
    const rows=table.map(r=>r.reduce((s,v)=>s+v,0)), cols=Array(10).fill(0);
    for(let i=0;i<10;i++)for(let j=0;j<10;j++)cols[j]+=table[i][j];
    let stat=0; for(let i=0;i<10;i++)for(let j=0;j<10;j++){const e=(rows[i]*cols[j])/Math.max(ns.length,1);if(e>=1)stat+=(table[i][j]-e)**2/e;}
    const meanA=xa.reduce((s,v)=>s+v,0)/(xa.length||1), meanB=xb.reduce((s,v)=>s+v,0)/(xb.length||1);
    let num=0,da=0,db=0;for(let i=0;i<xa.length;i++){const x=xa[i]-meanA,y=xb[i]-meanB;num+=x*y;da+=x*x;db+=y*y;}
    const r=da&&db?num/Math.sqrt(da*db):0; const pv=chiSquarePValue(stat,81);
    out.push({positions:`${a+1}↔${b+1}`,correlation:r,chiSquare:stat,pValue:pv,significantAt05:pv<0.05});
  }
  return out;
}

export function normalizeScores(values:number[]): {values:number[];min:number;max:number;mean:number} {
  if(!values.length)return{values:[],min:0,max:0,mean:0};
  const min=Math.min(...values),max=Math.max(...values),mean=values.reduce((a,b)=>a+b,0)/values.length;
  const range=max-min||1; return{values:values.map(v=>(v-min)/range),min,max,mean};
}

/** Group highly correlated signal series so ensemble weighting can discount redundancy. */
export function redundancyGroups(signalSeries: Record<string,number[]>): RedundancyGroup[] {
  const keys=Object.keys(signalSeries), used=new Set<string>();
  const out:RedundancyGroup[]=[];
  const correlation=(a:number[],b:number[])=>{const n=Math.min(a.length,b.length);if(n<3)return 0;const ma=a.slice(0,n).reduce((s,v)=>s+v,0)/n,mb=b.slice(0,n).reduce((s,v)=>s+v,0)/n;let num=0,da=0,db=0;for(let i=0;i<n;i++){const x=a[i]-ma,y=b[i]-mb;num+=x*y;da+=x*x;db+=y*y;}return da&&db?num/Math.sqrt(da*db):0;};
  for(const k of keys){if(used.has(k))continue;const members=[k];used.add(k);let max=0;for(const q of keys){if(used.has(q))continue;const c=Math.abs(correlation(signalSeries[k]||[],signalSeries[q]||[]));if(c>=0.85){members.push(q);used.add(q);max=Math.max(max,c);}}out.push({members,representative:k,maxCorrelation:max});}
  return out;
}

/**
 * Monte Carlo null test: under a uniform 4D draw, the probability of the
 * actual winning number appearing in a random top-N set is N/10000.
 */
export function monteCarloRandomBaseline(observedHits:number, tests:number, topN:number, simulations=5000, seed=1234567): MonteCarloResult {
  const n=Math.max(1,tests), k=Math.max(1,Math.min(10000,topN));
  const expected=n*k/10000; let state=seed>>>0, ge=0;
  const rand=()=>{state=(1664525*state+1013904223)>>>0;return state/4294967296;};
  for(let s=0;s<simulations;s++){let hits=0;for(let t=0;t<n;t++)if(rand()<k/10000)hits++;if(hits>=observedHits)ge++;}
  const p=(ge+1)/(simulations+1), variance=n*(k/10000)*(1-k/10000), z=variance? (observedHits-expected)/Math.sqrt(variance):0;
  return{simulations,observedHits,expectedHits:expected,pValue:p,zScore:z,baselineTopN:k};
}

/** Blocked K-fold validation: folds remain contiguous and training is restricted to data before each test block. */
export function blockedKFold(draws: ValidationDraw[], ranker:(train:ValidationDraw[], topN:number)=>string[], folds=5, topN=20): KFoldResult {
  // Normalize to chronological order first. Each test block is evaluated only
  // against observations strictly earlier in time, so this remains safe whether
  // the caller stores newest-first or oldest-first.
  const validDraws=draws.filter(d=>valid(d.first)).sort((a,b)=>String(a.date??'').localeCompare(String(b.date??'')));
  const k=Math.max(2,Math.min(folds,validDraws.length));
  if(validDraws.length<k+5)return{folds:k,tests:0,exactHits:0,exactRate:0,foldRates:[],meanRate:0,stdDev:0};
  const rates:number[]=[];let hits=0,tests=0;
  for(let f=0;f<k;f++){
    const start=Math.floor(f*validDraws.length/k), end=Math.floor((f+1)*validDraws.length/k);
    const test=validDraws.slice(start,end); const train=validDraws.slice(0,start);
    if(train.length<5||!test.length)continue;
    const top=ranker(train,topN);let fh=0;for(const row of test)if(top.includes(row.first))fh++;
    hits+=fh;tests+=test.length;rates.push(fh/test.length);
  }
  const mean=rates.length?rates.reduce((a,b)=>a+b,0)/rates.length:0;const sd=rates.length?Math.sqrt(rates.reduce((s,v)=>s+(v-mean)**2,0)/rates.length):0;
  return{folds:k,tests,exactHits:hits,exactRate:tests?hits/tests:0,foldRates:rates,meanRate:mean,stdDev:sd};
}

export function wilsonInterval(successes:number,trials:number,z=1.96): ConfidenceResult {
  const n=Math.max(0,trials), p=n?successes/n:0;
  if(!n)return{estimate:0,lower:0,upper:0,sampleSize:0};
  const den=1+z*z/n, center=(p+z*z/(2*n))/den, half=(z*Math.sqrt((p*(1-p)/n)+(z*z/(4*n*n))))/den;
  return{estimate:p,lower:Math.max(0,center-half),upper:Math.min(1,center+half),sampleSize:n};
}

export function buildValidationReport(
  draws:ValidationDraw[],
  observedHits=0,
  backtestTests=0,
  topN=20,
  signalSeries:Record<string,number[]>={},
  ranker?:(train:ValidationDraw[],topN:number)=>string[],
  scoreValues:number[]=[],
): ValidationReport {
  const ns=firsts(draws);
  const chi=chiSquareUniform(draws), acf=autocorrelation(draws), ind=digitIndependence(draws);
  const redundancy=redundancyGroups(signalSeries);
  const mc=monteCarloRandomBaseline(observedHits,backtestTests,topN);
  const kFold=ranker ? blockedKFold(draws,ranker,3,topN) : blockedKFold(draws,()=>[],5,topN);
  const confidence=wilsonInterval(observedHits,backtestTests);
  const normalized=normalizeScores(scoreValues);
  const notes:string[]=[];
  if(ns.length<100)notes.push('Small historical sample: statistical conclusions have high uncertainty.');
  if(chi.some(x=>x.significantAt05))notes.push('At least one position differs from uniform at the 5% test level; this is evidence of non-uniformity, not proof of a predictable mechanism.');
  if(acf.some(x=>Math.abs(x.correlation)>0.1))notes.push('Some ACF lags show non-trivial historical autocorrelation; inspect stability across time windows.');
  if(ind.some(x=>x.significantAt05))notes.push('At least one position pair rejects the independence null at 5%; confirm with out-of-sample tests.');
  if(!ranker)notes.push('Model-level K-fold ranking was not supplied to this report.');
  if(scoreValues.length)notes.push('Ensemble inputs are normalized to the 0–1 range before adaptive weighting.');
  return{
    sampleSize:ns.length,chiSquare:chi,acf,independence:ind,redundancy,monteCarlo:mc,kFold,confidence,
    scoreNormalization:{min:normalized.min,max:normalized.max,mean:normalized.mean},
    lookAheadSafe:Boolean(ranker),notes
  };
}
