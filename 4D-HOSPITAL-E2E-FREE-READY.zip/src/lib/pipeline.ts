/**
 * 3-Stage Prediction Pipeline
 *
 * Stage 1 — Centralized Data Collection & Frequency Mapping
 *   Collect every model's 4D prediction, build a frequency matrix.
 *
 * Stage 2 — Probability Filtering & Elimination (Thresholding)
 *   Drop numbers predicted by too few models or with too low weighted score.
 *
 * Stage 3 — Final Consensus & Borda Count Weighted Importance Matrix
 *   Rank survivors using Borda Count (each model votes, weight amplifies score).
 */

export interface MPredEntry {
  key: string;
  pred: string;
}

export interface MInfoEntry {
  label: string;
  group: string;
  icon: string;
  defaultW: number;
}

export interface Stage1Entry {
  num: string;
  models: { key: string; label: string; icon: string; weight: number }[];
  totalWeight: number;
  modelCount: number;
}

export interface Stage3Entry extends Stage1Entry {
  bordaScore: number;
  scientificScore: number;
  combinedScore: number;
  rank: number;
  bordaPct: number;
  probLabel: "HIGH" | "MED" | "LOW";
}

export interface PipelineResult {
  stage1: Stage1Entry[];
  stage2Survived: Stage1Entry[];
  stage2Eliminated: Stage1Entry[];
  stage3: Stage3Entry[];
  threshold: { minModels: number; minWeight: number };
  final4: string[];
  final3: string[];
  final2: string[];
  final1: string[];
  methodBoard: {
    key: string; label: string; icon: string;
    pred: string; pair3: string; pair2: string; digit: string;
  }[];
}

function posMatch(a: string, b: string): number {
  if (a.length !== 4 || b.length !== 4) return 0;
  let n = 0;
  for (let i = 0; i < 4; i++) if (a[i] === b[i]) n++;
  return n;
}

export function run3StagePipeline(
  mPreds: MPredEntry[],
  modelInfo: Record<string, MInfoEntry>,
  topTrips4: { seq: string; count: number }[],
  ultimateDigit: string,
  secondDigit: string,
  cutDigits: { digit: string; conf: number }[],
  scientificScores: { num: string; score: number }[] = [],
): PipelineResult {

  // ─── STAGE 1 ────────────────────────────────────────────────────────────────
  const s1Map: Record<string, Stage1Entry> = {};
  for (const m of mPreds) {
    if (!/^\d{4}$/.test(m.pred)) continue;
    const info = modelInfo[m.key];
    if (!info) continue;
    if (!s1Map[m.pred]) s1Map[m.pred] = { num: m.pred, models: [], totalWeight: 0, modelCount: 0 };
    s1Map[m.pred].models.push({ key: m.key, label: info.label, icon: info.icon, weight: info.defaultW });
    s1Map[m.pred].totalWeight += info.defaultW;
    s1Map[m.pred].modelCount += 1;
  }
  const stage1 = Object.values(s1Map).sort((a, b) => b.totalWeight - a.totalWeight);

  // ─── STAGE 2 ────────────────────────────────────────────────────────────────
  const maxWeight = stage1[0]?.totalWeight ?? 1;
  const weightThreshold = Math.max(8, maxWeight * 0.20);
  const minModels = 2;
  const threshold = { minModels, minWeight: Math.round(weightThreshold) };

  const stage2Survived = stage1.filter(e => e.modelCount >= minModels || e.totalWeight >= weightThreshold);
  const stage2Eliminated = stage1.filter(e => e.modelCount < minModels && e.totalWeight < weightThreshold);
  const stage2 = stage2Survived.length >= 2 ? stage2Survived : stage1.slice(0, Math.min(6, stage1.length));

  // ─── STAGE 3: Borda Count ───────────────────────────────────────────────────
  const n = stage2.length;
  const borda: Record<string, number> = {};

  for (const m of mPreds) {
    const info = modelInfo[m.key];
    if (!info || !/^\d{4}$/.test(m.pred)) continue;
    const ranked = [...stage2].sort((a, b) => {
      if (a.num === m.pred && b.num !== m.pred) return -1;
      if (b.num === m.pred && a.num !== m.pred) return 1;
      return posMatch(b.num, m.pred) - posMatch(a.num, m.pred);
    });
    ranked.forEach((e, rank) => {
      borda[e.num] = (borda[e.num] ?? 0) + info.defaultW * (n - rank);
    });
  }

  const maxBorda = Math.max(...Object.values(borda), 1);
  const sciMap = new Map(scientificScores.map(x => [x.num, x.score]));
  const sciVals = stage2.map(e => sciMap.get(e.num) ?? 0);
  const sciMin = Math.min(...sciVals, 0), sciMax = Math.max(...sciVals, 1), sciRange = sciMax - sciMin || 1;
  const stage3: Stage3Entry[] = stage2
    .map(e => {
      const bs = borda[e.num] ?? 0;
      const rawSci = sciMap.get(e.num) ?? 0;
      const ss = Math.max(0, Math.min(1, (rawSci - sciMin) / sciRange));
      // Scientific score is a secondary, normalized evidence channel; it cannot dominate model consensus.
      const combined = bs + ss * maxBorda * 0.25;
      const pct = combined / Math.max(maxBorda * 1.25, 1);
      return {
        ...e,
        bordaScore: bs,
        scientificScore: ss,
        combinedScore: combined,
        rank: 0,
        bordaPct: Math.round(pct * 100),
        probLabel: (pct >= 0.7 ? "HIGH" : pct >= 0.4 ? "MED" : "LOW") as "HIGH" | "MED" | "LOW",
      };
    })
    .sort((a, b) => b.combinedScore - a.combinedScore || b.bordaScore - a.bordaScore || a.num.localeCompare(b.num))
    .map((e, i) => ({ ...e, rank: i + 1 }));

  // ─── Derive final4 ─────────────────────────────────────────────────────────
  const final4: string[] = [];
  const used4 = new Set<string>();
  for (const e of stage3) {
    if (!used4.has(e.num) && final4.length < 5) { used4.add(e.num); final4.push(e.num); }
  }
  while (final4.length < 5) final4.push("????");

  // ─── Derive final3 ─────────────────────────────────────────────────────────
  const t3Score: Record<string, number> = {};
  for (const m of mPreds) {
    if (!/^\d{4}$/.test(m.pred)) continue;
    const w = modelInfo[m.key]?.defaultW ?? 1;
    const d = m.pred.split("");
    [d[0]+d[1]+d[2], d[1]+d[2]+d[3], d[0]+d[1]+d[3], d[0]+d[2]+d[3]].forEach(t => {
      t3Score[t] = (t3Score[t] ?? 0) + w;
    });
  }
  for (const t of topTrips4) t3Score[t.seq] = (t3Score[t.seq] ?? 0) + t.count * 3;
  const final3: string[] = [];
  const used3 = new Set<string>();
  for (const [s] of Object.entries(t3Score).sort((a, b) => b[1] - a[1])) {
    if (!used3.has(s) && final3.length < 5) { used3.add(s); final3.push(s); }
  }
  while (final3.length < 5) final3.push("???");

  // ─── Derive final2 ─────────────────────────────────────────────────────────
  const p2Score: Record<string, number> = {};
  for (const m of mPreds) {
    if (!/^\d{4}$/.test(m.pred)) continue;
    const w = modelInfo[m.key]?.defaultW ?? 1;
    const d = m.pred.split("");
    [d[0]+d[1], d[1]+d[2], d[2]+d[3], d[0]+d[2], d[1]+d[3], d[0]+d[3]].forEach(p => {
      p2Score[p] = (p2Score[p] ?? 0) + w;
    });
  }
  for (const num of final4) {
    if (!/^\d{4}$/.test(num)) continue;
    const d = num.split("");
    [d[0]+d[1], d[1]+d[2], d[2]+d[3]].forEach(p => { p2Score[p] = (p2Score[p] ?? 0) + 5; });
  }
  const final2: string[] = [];
  const used2 = new Set<string>();
  for (const [p] of Object.entries(p2Score).sort((a, b) => b[1] - a[1])) {
    if (!used2.has(p) && final2.length < 5) { used2.add(p); final2.push(p); }
  }
  while (final2.length < 5) final2.push("??");

  // ─── Derive final1 ─────────────────────────────────────────────────────────
  const digScore: Record<string, number> = {};
  for (let i = 0; i < 10; i++) digScore[String(i)] = 0;
  for (const m of mPreds) {
    const w = modelInfo[m.key]?.defaultW ?? 1;
    for (const c of m.pred.split("")) if (/\d/.test(c)) digScore[c] += w;
  }
  digScore[ultimateDigit] = (digScore[ultimateDigit] ?? 0) + 20;
  digScore[secondDigit]   = (digScore[secondDigit]   ?? 0) + 10;
  const cutSet = new Set(cutDigits.map(c => c.digit));
  const final1: string[] = [];
  const used1 = new Set<string>();
  for (const [d] of Object.entries(digScore).sort((a, b) => {
    const aS = cutSet.has(a[0]) ? a[1] * 0.3 : a[1];
    const bS = cutSet.has(b[0]) ? b[1] * 0.3 : b[1];
    return bS - aS;
  })) {
    if (!used1.has(d) && final1.length < 5) { used1.add(d); final1.push(d); }
  }
  while (final1.length < 5) final1.push("?");

  // ─── Method board ───────────────────────────────────────────────────────────
  const methodBoard = mPreds.map(m => {
    const info = modelInfo[m.key] ?? { label: m.key, icon: "?", group: "", defaultW: 1 };
    const d = /^\d{4}$/.test(m.pred) ? m.pred.split("") : ["?","?","?","?"];
    return { key: m.key, label: info.label, icon: info.icon, pred: m.pred,
      pair3: d[0]+d[1]+d[2], pair2: d[0]+d[1], digit: d[0] };
  });

  return { stage1, stage2Survived, stage2Eliminated, stage3, threshold,
    final4, final3, final2, final1, methodBoard };
}
