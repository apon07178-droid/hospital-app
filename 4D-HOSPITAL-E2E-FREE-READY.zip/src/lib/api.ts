export const TOKEN_KEY = "4d_analytics_token";
export function getToken() { return localStorage.getItem(TOKEN_KEY); }
export function setToken(t: string) { localStorage.setItem(TOKEN_KEY, t); }
export function clearToken() { localStorage.removeItem(TOKEN_KEY); }

export async function apiFetch(method: string, path: string, body?: unknown) {
  const token = getToken();
  const headers: Record<string, string> = {};
  if (body) headers["Content-Type"] = "application/json";
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const res = await fetch(`/api${path}`, {
    method, headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let data: unknown;
  try { data = JSON.parse(text); } catch { data = { error: text }; }
  if (!res.ok) throw new Error((data as Record<string,string>)?.error ?? `HTTP ${res.status}`);
  return data;
}

export const api = {
  get:    (p: string)              => apiFetch("GET",    p),
  post:   (p: string, b: unknown)  => apiFetch("POST",   p, b),
  put:    (p: string, b: unknown)  => apiFetch("PUT",    p, b),
  patch:  (p: string, b: unknown)  => apiFetch("PATCH",  p, b),
  del:    (p: string, b?: unknown) => apiFetch("DELETE", p, b),
  delete: (p: string, b?: unknown) => apiFetch("DELETE", p, b),
};
