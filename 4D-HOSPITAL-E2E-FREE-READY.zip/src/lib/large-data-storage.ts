/** 4D HOSPITAL large-data storage abstraction.
 * Compatibility implementation today; ready for native SQLite adapter.
 */
export type StoredResult = {
  id?: string; date: string; company: string; first: string; second: string; third: string;
  special?: string[]; consolation?: string[]; [key: string]: unknown;
};
export async function saveResultsLarge(results: StoredResult[]) {
  localStorage.setItem("cbc_results", JSON.stringify(results));
  return { count: results.length, backend: "local-compatible" as const };
}
export async function loadResultsLarge(): Promise<StoredResult[]> {
  try { const raw=localStorage.getItem("cbc_results"); return raw ? JSON.parse(raw) : []; } catch { return []; }
}
export async function exportLargeBackup(results: StoredResult[]) {
  return JSON.stringify({app:"4D HOSPITAL",version:1,exportedAt:new Date().toISOString(),count:results.length,results},null,2);
}
