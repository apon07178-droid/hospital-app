import { Capacitor } from '@capacitor/core';
import { CapacitorSQLite, SQLiteConnection, SQLiteDBConnection } from '@capacitor-community/sqlite';

export interface DbResult {
  id: number;
  company: string;
  date: string;
  drawNo: string | null;
  first: string;
  second: string;
  third: string;
  special: string[];
  consolation: string[];
}

const DB_NAME = '4d_hospital_data';
const sqlite = new SQLiteConnection(CapacitorSQLite);
let db: SQLiteDBConnection | null = null;
let readyPromise: Promise<boolean> | null = null;

const webFallback = () => typeof window !== 'undefined' && Capacitor.getPlatform() === 'web';

async function openDb(): Promise<SQLiteDBConnection> {
  const consistency = await sqlite.checkConnectionsConsistency();
  const connected = await sqlite.isConnection(DB_NAME, false);
  if (consistency.result && connected.result) {
    db = await sqlite.retrieveConnection(DB_NAME, false);
  } else {
    db = await sqlite.createConnection(DB_NAME, false, 'no-encryption', 1, false);
  }
  await db.open();
  await db.execute(`
    CREATE TABLE IF NOT EXISTS results (
      id INTEGER PRIMARY KEY NOT NULL,
      company TEXT NOT NULL,
      date TEXT NOT NULL,
      draw_no TEXT,
      first TEXT NOT NULL,
      second TEXT NOT NULL,
      third TEXT NOT NULL,
      special_json TEXT NOT NULL DEFAULT '[]',
      consolation_json TEXT NOT NULL DEFAULT '[]',
      UNIQUE(company, date)
    );
    CREATE INDEX IF NOT EXISTS idx_results_company_date ON results(company, date DESC);
    CREATE INDEX IF NOT EXISTS idx_results_first ON results(first);
    CREATE INDEX IF NOT EXISTS idx_results_second ON results(second);
    CREATE INDEX IF NOT EXISTS idx_results_third ON results(third);
  `);
  return db;
}

export async function initResultsDatabase(): Promise<boolean> {
  if (webFallback()) return false;
  if (!readyPromise) {
    readyPromise = openDb().then(() => true).catch((e) => {
      console.warn('4D HOSPITAL SQLite unavailable; falling back to local storage.', e);
      db = null;
      return false;
    });
  }
  return readyPromise;
}

function mapRow(r: any): DbResult {
  let special: string[] = [], consolation: string[] = [];
  try { special = JSON.parse(r.special_json || '[]'); } catch {}
  try { consolation = JSON.parse(r.consolation_json || '[]'); } catch {}
  return { id: Number(r.id), company: String(r.company), date: String(r.date), drawNo: r.draw_no == null ? null : String(r.draw_no), first: String(r.first), second: String(r.second), third: String(r.third), special, consolation };
}

export async function loadResultsFromSQLite(): Promise<DbResult[] | null> {
  if (!(await initResultsDatabase()) || !db) return null;
  const res = await db.query('SELECT * FROM results ORDER BY date DESC, id DESC');
  return (res.values ?? []).map(mapRow);
}

export async function replaceResultsInSQLite(rows: DbResult[]): Promise<boolean> {
  if (!(await initResultsDatabase()) || !db) return false;
  await db.execute('BEGIN TRANSACTION');
  try {
    await db.execute('DELETE FROM results');
    // Never trust imported IDs: a legacy localStorage database and native SQLite
    // can contain overlapping primary keys. Preserve unique valid IDs where possible
    // and deterministically remap collisions before the transaction commits.
    const used=new Set<number>(); let cursor=1;
    for (const raw of rows) {
      let id=Number(raw.id);
      if(!Number.isSafeInteger(id)||id<1||used.has(id)){ while(used.has(cursor)) cursor++; id=cursor; }
      used.add(id); cursor=Math.max(cursor,id+1);
      const company=String(raw.company??'').trim();
      const date=String(raw.date??'').trim();
      const first=String(raw.first??'').trim(), second=String(raw.second??'').trim(), third=String(raw.third??'').trim();
      if(!company || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{4}$/.test(first) || !/^\d{4}$/.test(second) || !/^\d{4}$/.test(third)) continue;
      await db.run(
        `INSERT INTO results (id,company,date,draw_no,first,second,third,special_json,consolation_json)
         VALUES (?,?,?,?,?,?,?,?,?)`,
        [id, company, date, raw.drawNo??null, first, second, third, JSON.stringify((raw.special??[]).filter(x=>/^\d{4}$/.test(String(x))).slice(0,50)), JSON.stringify((raw.consolation??[]).filter(x=>/^\d{4}$/.test(String(x))).slice(0,50))]
      );
    }
    await db.execute('COMMIT');
    return true;
  } catch (e) {
    try { await db.execute('ROLLBACK'); } catch {}
    throw e;
  }
}

export async function upsertResultInSQLite(r: DbResult): Promise<boolean> {
  if (!(await initResultsDatabase()) || !db) return false;
  const company = String(r.company ?? '').trim();
  const date = String(r.date ?? '').trim();
  const first = String(r.first ?? '').trim();
  const second = String(r.second ?? '').trim();
  const third = String(r.third ?? '').trim();
  if (!company || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{4}$/.test(first) || !/^\d{4}$/.test(second) || !/^\d{4}$/.test(third)) throw new Error('Invalid result data');
  const special = JSON.stringify((r.special ?? []).filter(x=>/^\d{4}$/.test(String(x))).map(String).slice(0,50));
  const consolation = JSON.stringify((r.consolation ?? []).filter(x=>/^\d{4}$/.test(String(x))).map(String).slice(0,50));

  // Never silently delete another user's draw during an edit. If the new
  // company+date belongs to a different row, reject the edit and let the UI
  // ask the user to choose the correct existing record instead.
  const conflict = await db.query(
    'SELECT id FROM results WHERE company=? AND date=? AND id<>? LIMIT 1',
    [company, date, r.id]
  );
  if ((conflict.values ?? []).length) throw new Error('এই company ও date-এর আরেকটি record আগে থেকেই আছে। অন্য record overwrite করা হয়নি।');

  const existing = await db.query('SELECT id FROM results WHERE id=? LIMIT 1', [r.id]);
  if ((existing.values ?? []).length) {
    await db.run(
      `UPDATE results SET company=?, date=?, draw_no=?, first=?, second=?, third=?, special_json=?, consolation_json=? WHERE id=?`,
      [company, date, r.drawNo, first, second, third, special, consolation, r.id]
    );
    return true;
  }

  await db.run(
    `INSERT INTO results (id,company,date,draw_no,first,second,third,special_json,consolation_json)
     VALUES (?,?,?,?,?,?,?,?,?)`,
    [r.id, company, date, r.drawNo, first, second, third, special, consolation]
  );
  return true;
}

export async function deleteResultFromSQLite(id: number): Promise<boolean> {
  if (!(await initResultsDatabase()) || !db) return false;
  await db.run('DELETE FROM results WHERE id=?', [id]);
  return true;
}

export async function clearResultsSQLite(): Promise<boolean> {
  if (!(await initResultsDatabase()) || !db) return false;
  await db.execute('DELETE FROM results');
  return true;
}

export async function syncResultsInSQLite(previous: DbResult[], next: DbResult[]): Promise<boolean> {
  if (!(await initResultsDatabase()) || !db) return false;
  const prev = new Map(previous.map(r => [r.id, r]));
  const curr = new Map(next.map(r => [r.id, r]));
  const changed = (a: DbResult, b: DbResult) => JSON.stringify(a) !== JSON.stringify(b);
  for (const r of next) if (!prev.has(r.id) || changed(prev.get(r.id)!, r)) await upsertResultInSQLite(r);
  for (const r of previous) if (!curr.has(r.id)) await deleteResultFromSQLite(r.id);
  return true;
}
