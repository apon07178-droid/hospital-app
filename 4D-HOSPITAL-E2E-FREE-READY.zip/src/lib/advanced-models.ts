/**
 * 4D HOSPITAL — Offline advanced models
 *
 * A compact deterministic recurrent model and a genuine genetic optimizer.
 * These are intentionally small so they can run on an Android phone without
 * a server or a heavyweight ML runtime. They are analytical ranking signals,
 * not guarantees of future lottery outcomes.
 */

export interface ModelSignal { score:number; probabilities:number[]; trained:boolean; }

function sigmoid(x:number){return 1/(1+Math.exp(-Math.max(-20,Math.min(20,x))));}
function softmax(a:number[]){const m=Math.max(...a);const e=a.map(x=>Math.exp(Math.max(-30,Math.min(30,x-m))));const s=e.reduce((x,y)=>x+y,0)||1;return e.map(x=>x/s);}
function rand(seed:{v:number}){seed.v=(1664525*seed.v+1013904223)>>>0;return seed.v/4294967296-.5;}
function dot(a:number[],b:number[]){let s=0;for(let i=0;i<Math.min(a.length,b.length);i++)s+=a[i]*b[i];return s;}

/** Small one-layer recurrent/LSTM-style encoder. The recurrent gates are kept
 * deterministic and the supervised output layer is fitted on teacher-forced
 * hidden states; this is intentionally a lightweight signal model, not a full
 * back-propagation-through-time LSTM implementation. */
export function trainLstmDigitModel(sequence:string[], hidden=8, epochs=12):ModelSignal[] {
  const clean=sequence.filter(x=>/^\d{4}$/.test(x));
  if(clean.length<12)return Array.from({length:4},()=>({score:.5,probabilities:Array(10).fill(.1),trained:false}));
  const out:ModelSignal[]=[]; const seed={v:0x4d484f53};
  for(let pos=0;pos<4;pos++){
    const input=clean.map(x=>Number(x[pos]));
    const W=Array.from({length:4*hidden},()=>Array.from({length:10},()=>rand(seed)*.25));
    const U=Array.from({length:4*hidden},()=>Array.from({length:hidden},()=>rand(seed)*.25));
    const b=Array(4*hidden).fill(0);
    let Wo=Array.from({length:10},()=>Array.from({length:hidden},()=>rand(seed)*.1));
    let bo=Array(10).fill(0);
    const lr=.035;
    for(let ep=0;ep<epochs;ep++){
      let h=Array(hidden).fill(0),c=Array(hidden).fill(0);
      const states:{h:number[];c:number[];x:number}[]=[];
      for(let t=0;t<input.length-1;t++){
        const x=input[t]; const z=Array(4*hidden).fill(0);
        for(let g=0;g<4;g++)for(let j=0;j<hidden;j++)z[g*hidden+j]=W[g*hidden+j][x]+dot(U[g*hidden+j],h)+b[g*hidden+j];
        const i=z.slice(0,hidden).map(sigmoid),f=z.slice(hidden,2*hidden).map(sigmoid),o=z.slice(2*hidden,3*hidden).map(sigmoid),g=z.slice(3*hidden).map(Math.tanh);
        c=c.map((v,j)=>f[j]*v+i[j]*g[j]); h=c.map((v,j)=>o[j]*Math.tanh(v));
        states.push({h:[...h],c:[...c],x});
      }
      // Train output layer on all teacher-forced hidden states.
      for(let t=0;t<states.length;t++){
        const target=input[t+1], logits=Wo.map((r,k)=>dot(r,states[t].h)+bo[k]),p=softmax(logits);
        for(let k=0;k<10;k++){
          const err=p[k]-(k===target?1:0);
          for(let j=0;j<hidden;j++)Wo[k][j]-=lr*err*states[t].h[j];
          bo[k]-=lr*err;
        }
      }
      // Tiny recurrent adaptation: update biases toward observed next digits.
      const counts=Array(10).fill(0);for(let t=1;t<input.length;t++)counts[input[t]]++;
      const total=counts.reduce((a,b)=>a+b,0)||1;
      for(let k=0;k<10;k++)bo[k]+=lr*.15*((counts[k]/total)-.1);
    }
    // Predict next digit from the complete sequence.
    let h=Array(hidden).fill(0),c=Array(hidden).fill(0);
    for(const x of input){const z=Array(4*hidden).fill(0);for(let g=0;g<4;g++)for(let j=0;j<hidden;j++)z[g*hidden+j]=W[g*hidden+j][x]+dot(U[g*hidden+j],h)+b[g*hidden+j];const i=z.slice(0,hidden).map(sigmoid),f=z.slice(hidden,2*hidden).map(sigmoid),o=z.slice(2*hidden,3*hidden).map(sigmoid),g=z.slice(3*hidden).map(Math.tanh);c=c.map((v,j)=>f[j]*v+i[j]*g[j]);h=c.map((v,j)=>o[j]*Math.tanh(v));}
    const p=softmax(Wo.map((r,k)=>dot(r,h)+bo[k])); out.push({score:Math.max(...p),probabilities:p,trained:true});
  }
  return out;
}

/** Genuine genetic algorithm: selection, one-point crossover, mutation and
 * elitism optimize a four-digit candidate against a supplied fitness function. */
export function geneticOptimize(fitness:(n:string)=>number, populationSize=120, generations=18, seedValue=0x4d484f53):Map<string,number>{
  const seed={v:seedValue>>>0}; const randDigit=()=>String(Math.floor((rand(seed)+.5)*10)%10); const make=()=>Array.from({length:4},randDigit).join('');
  let pop=Array.from({length:populationSize},make); const scores=new Map<string,number>();
  for(let gen=0;gen<generations;gen++){
    const ranked=pop.map(n=>({n,s:fitness(n)})).sort((a,b)=>b.s-a.s); ranked.forEach(x=>scores.set(x.n,x.s));
    const elite=ranked.slice(0,Math.max(8,Math.floor(populationSize*.12))).map(x=>x.n); const next=[...elite];
    while(next.length<populationSize){const a=elite[Math.floor(((rand(seed)+.5)*elite.length))%elite.length],b=elite[Math.floor(((rand(seed)+.5)*elite.length))%elite.length];const cut=1+Math.floor(((rand(seed)+.5)*3));let child=a.slice(0,cut)+b.slice(cut);if(rand(seed)+.5>.72){const at=Math.floor(((rand(seed)+.5)*4));child=child.slice(0,at)+randDigit()+child.slice(at+1);}next.push(child);}
    pop=next;
  }
  pop.forEach(n=>scores.set(n,fitness(n))); return scores;
}
