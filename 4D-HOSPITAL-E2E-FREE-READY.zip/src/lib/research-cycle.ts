import { runPatternEngine, type EngineAnalysis, type NumberScore } from './scorer';

export type ResearchCycleStatus = 'LOCKED' | 'VALIDATED' | 'APPLIED';
export type ResearchCompany = string;

export interface LockedCandidate {
  num: string;
  rank: number;
  confidence: number;
  signalsAgreed: number;
  methods: { key: string; label: string; score: number; contribution: number }[];
}

export interface ResearchCycle {
  id: string;
  company: ResearchCompany;
  createdAt: string;
  status: ResearchCycleStatus;
  batchSize: number;
  trainingCount: number;
  trainingLatestDate: string;
  datasetFingerprint: string;
  candidateLimit: number;
  lockedCandidates: LockedCandidate[];
  analysisFinal: {
    top: LockedCandidate[];
    methodCount: number;
    backtest: EngineAnalysis['backtest'];
    validation: EngineAnalysis['advanced']['validation'];
  };
  actualBatch: string[];
  actualDate?: string;
  validationFinal?: {
    totalActual: number;
    exactMatches: string[];
    trace: { num: string; predicted: boolean; rank?: number; methods: string[]; evidence: string[] }[];
    methodHits: { key: string; label: string; hits: number; rate: number; actualNumbers: string[] }[];
    unmatched: string[];
  };
  appliedAt?: string;
}

const STORAGE_KEY = '4d_hospital_research_cycles_v1';

export function loadResearchCycles(): ResearchCycle[] {
  try {
    const x = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    return Array.isArray(x) ? x : [];
  } catch { return []; }
}

export function saveResearchCycles(rows: ResearchCycle[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(rows.slice(0, 250)));
}

function hashString(input: string): string {
  // Deterministic 32-bit FNV-1a; used as a version fingerprint, not cryptographic security.
  let h = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) { h ^= input.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return (h >>> 0).toString(16).padStart(8, '0');
}

export function fingerprintDraws(rows: { id:number; company:string; date:string; drawNo:string|null; first:string }[]): string {
  const stable = rows.map(r => [r.id,r.company,r.date,r.drawNo,r.first]).sort((a,b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
  return hashString(JSON.stringify(stable));
}

function candidateFromScore(s: NumberScore): LockedCandidate {
  const methods = (s.contributions || [])
    .filter(c => c.score >= 0.6)
    .sort((a,b) => b.contribution - a.contribution)
    .map(c => ({ key:c.key, label:c.label, score:c.score, contribution:c.contribution }));
  return { num:s.num, rank:s.rank, confidence:s.confidence, signalsAgreed:s.signalsAgreed, methods };
}

export function createLockedCycle(
  company: string,
  draws: { id:number; company:string; date:string; drawNo:string|null; first:string; second?:string; third?:string; special?:string[]; consolation?:string[] }[],
  batchSize = 23,
  candidateLimit = 100,
): ResearchCycle {
  const filtered = draws
    .filter(r => r.company === company && /^\d{4}$/.test(r.first))
    .sort((a,b) => b.date.localeCompare(a.date) || b.id-a.id);
  if (filtered.length < 10) throw new Error('কমপক্ষে ১০টি valid historical draw প্রয়োজন।');

  // IMPORTANT: this function receives only the pre-lock dataset. No future/actual batch is accepted.
  const engine = runPatternEngine(filtered.map(r => ({
    date:r.date, first:r.first, second:r.second || '', third:r.third || '', special:r.special || [], consolation:r.consolation || []
  })), Math.max(20, Math.min(250, candidateLimit)));
  const top = engine.scores.slice(0, Math.max(1, Math.min(candidateLimit, engine.scores.length))).map(candidateFromScore);
  const now = new Date().toISOString();
  const token = typeof crypto !== 'undefined' && crypto.getRandomValues ? Array.from(crypto.getRandomValues(new Uint32Array(2))).map(x=>x.toString(36)).join('').slice(0,8).toUpperCase() : hashString(now + company);
  const id = `RC-${now.replace(/[-:.TZ]/g,'').slice(0,14)}-${token}`;
  return {
    id, company, createdAt:now, status:'LOCKED', batchSize:Math.max(1,batchSize), trainingCount:filtered.length,
    trainingLatestDate:filtered[0]?.date || '', datasetFingerprint:fingerprintDraws(filtered), candidateLimit:top.length,
    lockedCandidates:top,
    analysisFinal:{top:top.slice(0,Math.min(20,top.length)),methodCount:28,backtest:engine.backtest,validation:engine.advanced.validation},
    actualBatch:[],
  };
}

export function validateLockedCycle(cycle: ResearchCycle, actualInput: string[], actualDate?: string): ResearchCycle {
  if (cycle.status !== 'LOCKED') throw new Error('এই cycle ইতিমধ্যে validate করা হয়েছে।');
  const actual = actualInput.map(x => x.trim()).filter(Boolean).map(x => x.padStart(4,'0')).filter(x => /^\d{4}$/.test(x));
  if (!actual.length) throw new Error('কমপক্ষে ১টি valid 4-digit actual number দিন।');
  const byNum = new Map(cycle.lockedCandidates.map(c => [c.num,c]));
  const trace = actual.map(num => {
    const c = byNum.get(num);
    const methods = c?.methods.map(m => m.label) || [];
    const evidence = c ? c.methods.slice(0,8).map(m => `${m.label}: ${Math.round(m.score*100)}% signal`) : [];
    return {num,predicted:!!c,rank:c?.rank,methods,evidence};
  });
  const exactMatches = [...new Set(actual.filter(n => byNum.has(n)))];
  const keys = new Map<string,{key:string;label:string;hits:number;actualNumbers:string[]}>();
  for (const t of trace) for (const c of (byNum.get(t.num)?.methods || [])) {
    const x=keys.get(c.key) || {key:c.key,label:c.label,hits:0,actualNumbers:[]};
    x.hits++; if(!x.actualNumbers.includes(t.num)) x.actualNumbers.push(t.num); keys.set(c.key,x);
  }
  const methodHits = [...keys.values()].map(x => ({...x,rate:actual.length?x.hits/actual.length:0})).sort((a,b)=>b.hits-a.hits || a.label.localeCompare(b.label));
  return {...cycle,status:'VALIDATED',actualBatch:actual,actualDate:actualDate || new Date().toISOString().slice(0,10),validationFinal:{totalActual:actual.length,exactMatches,trace,methodHits,unmatched:[...new Set(actual.filter(n=>!byNum.has(n)))]}};
}

export function markCycleApplied(cycle: ResearchCycle): ResearchCycle {
  if (cycle.status !== 'VALIDATED') throw new Error('Validate করার আগে dataset-এ apply করা যাবে না।');
  return {...cycle,status:'APPLIED',appliedAt:new Date().toISOString()};
}

export function cycleSummary(cycles: ResearchCycle[]) {
  const validated = cycles.filter(c => c.validationFinal);
  const methodMap = new Map<string,{key:string;label:string;cycles:number;hits:number;opportunities:number;cycleRates:number[]}>();
  for (const c of validated) for (const m of (c.validationFinal?.methodHits || [])) {
    const x=methodMap.get(m.key)||{key:m.key,label:m.label,cycles:0,hits:0,opportunities:0,cycleRates:[]};
    x.cycles++; x.hits+=m.hits; x.opportunities+=c.validationFinal?.totalActual || 0; x.cycleRates.push(m.rate); methodMap.set(m.key,x);
  }
  const methods=[...methodMap.values()].map(x=>({...x,rate:x.opportunities?x.hits/x.opportunities:0,stability:x.cycleRates.length?x.cycleRates.reduce((a,b)=>a+b,0)/x.cycleRates.length:0})).sort((a,b)=>b.rate-a.rate);
  return {totalCycles:cycles.length,locked:cycles.filter(c=>c.status==='LOCKED').length,validated:validated.length,applied:cycles.filter(c=>c.status==='APPLIED').length,methods};
}
