import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { Capacitor } from "@capacitor/core";
import { Filesystem, Directory, Encoding } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";
import { run3StagePipeline } from "./lib/pipeline";
import { runPatternEngine, ACTIVE_SIGNAL_CATALOG } from "./lib/scorer";
import { ANALYSIS_CATALOG } from "./lib/analysis-catalog";
import { createLockedCycle, validateLockedCycle, markCycleApplied, loadResearchCycles, saveResearchCycles, fingerprintDraws, cycleSummary, type ResearchCycle } from "./lib/research-cycle";
import { trainLstmDigitModel, geneticOptimize } from "./lib/advanced-models";
import { initResultsDatabase, loadResultsFromSQLite, replaceResultsInSQLite, syncResultsInSQLite } from "./lib/sqlite-results";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  LineChart, Line, CartesianGrid, Legend,
} from "recharts";

// ─── Types ────────────────────────────────────────────────────────────────────
type CompanyId = "magnum" | "toto" | "damacai" | "singapore";
type View = "researchCycle" | "master" | "generator" | "dashboard" | "company" | "triplets" | "pairs" | "cross" | "correlation" | "predictions" | "deep" | "heatmap" | "regression" | "calendar" | "highlowmatrix" | "mirror" | "benford" | "lstm" | "markov" | "genetic" | "outlier2" | "backtest" | "sliding" | "consensus" | "alerts" | "performance" | "scan" | "ocr" | "patterns" | "agents" | "live" | "users" | "settings" | "permutation" | "vault" | "skipdraw" | "neighbor";

interface AuthUser { id: number; username: string; role: "admin" | "user"; }
interface LotteryResult {
  id: number; company: string; date: string; drawNo: string | null;
  first: string; second: string; third: string; special: string[]; consolation: string[];
}
interface ManagedUser {
  id: number; username: string; role: string; isActive: boolean;
  createdAt: string; lastLogin: string | null;
}

// ─── Constants ────────────────────────────────────────────────────────────────
const COMPANIES: Record<CompanyId, { name: string; short: string; color: string }> = {
  magnum:    { name: "Magnum 4D",    short: "MAG", color: "#ef4444" },
  toto:      { name: "Toto 4D",      short: "TOT", color: "#3b82f6" },
  damacai:   { name: "Da Ma Cai",    short: "DMC", color: "#22c55e" },
  singapore: { name: "Singapore 4D", short: "SGP", color: "#f59e0b" },
};
const COMPANY_IDS = Object.keys(COMPANIES) as CompanyId[];

// ─── Local Storage Data Layer (Free Version — No Backend Required) ────────────
const LS_RESULTS      = "4d_ls_results_v1";
const LS_RESULTS_MIRROR = "4d_ls_results_mirror_v1";
const LS_RESULTS_BACKUP = "4d_ls_results_backup_v1";
const LS_MIGRATION_CONFLICTS = "4d_ls_migration_conflicts_v1";
const LS_ADMIN        = "4d_ls_admin_v2_session";
const LS_PICKS        = "4d_ls_picks_v1";
const LS_GUEST_CODE   = "4d_ls_guest_code_v1";   // admin sets this code for guest access
const LS_GUEST_EPOCH  = "4d_ls_guest_epoch_v1";  // epoch version; bump to revoke all
const LS_GUEST_UNLOCKED = "4d_ls_guest_unlocked_v2_session"; // session-only unlock
const LS_ADMIN_CRED    = "4d_ls_admin_credential_v2"; // {salt,hash,iterations}
const LS_GUEST_CODE_HASH = "4d_ls_guest_code_hash_v2"; // {salt,hash,iterations}
const LS_PASSWORD_LEGACY = "4d_ls_admin_password_v1"; // one-time migration only

function parseStoredResults(raw:string|null): LotteryResult[]|null {
  if(!raw) return null;
  try {
    const v=JSON.parse(raw);
    if(!Array.isArray(v)) return null;
    return v.filter((r:any)=>r && typeof r==='object' && /^\d{4}-\d{2}-\d{2}$/.test(String(r.date||'')) && /^\d{4}$/.test(String(r.first||'')) && /^\d{4}$/.test(String(r.second||'')) && /^\d{4}$/.test(String(r.third||'')));
  } catch { return null; }
}

function normalizeMasterRows(rows:LotteryResult[]):LotteryResult[]{
  const byKey=new Map<string,LotteryResult>();
  for(const r of rows){
    const company=String(r.company||'').toLowerCase().trim();
    const date=String(r.date||'').slice(0,10);
    if(!COMPANY_IDS.includes(company as CompanyId) || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{4}$/.test(r.first) || !/^\d{4}$/.test(r.second) || !/^\d{4}$/.test(r.third)) continue;
    byKey.set(`${company}|${date}`,{...r,company,date,drawNo:r.drawNo??null,special:Array.isArray(r.special)?r.special.filter(x=>/^\d{4}$/.test(String(x))).slice(0,50):[],consolation:Array.isArray(r.consolation)?r.consolation.filter(x=>/^\d{4}$/.test(String(x))).slice(0,50):[]});
  }
  const out=[...byKey.values()]; const used=new Set<number>(); let cursor=1;
  return out.map(r=>{let id=Number(r.id);if(!Number.isSafeInteger(id)||id<1||used.has(id)){while(used.has(cursor))cursor++;id=cursor;}used.add(id);cursor=Math.max(cursor,id+1);return {...r,id};}).sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id);
}

function lsGetResults(): LotteryResult[] {
  const primary=parseStoredResults(localStorage.getItem(LS_RESULTS));
  if(primary) return primary;
  const mirror=parseStoredResults(localStorage.getItem(LS_RESULTS_MIRROR));
  if(mirror) return mirror;
  const backup=parseStoredResults(localStorage.getItem(LS_RESULTS_BACKUP));
  return backup ?? [];
}
function lsSaveResults(r: LotteryResult[]): void {
  const clean=Array.isArray(r)?r:[];
  const payload=JSON.stringify(clean);
  try {
    const previous=localStorage.getItem(LS_RESULTS);
    if(previous && previous!==payload) localStorage.setItem(LS_RESULTS_BACKUP,previous);
    localStorage.setItem(LS_RESULTS,payload);
    localStorage.setItem(LS_RESULTS_MIRROR,payload);
  } catch(e) {
    // Keep the in-memory dataset alive if localStorage quota is reached; native SQLite
    // remains the durable Android source of truth when available.
    console.warn('4D HOSPITAL localStorage persistence warning',e);
  }
}
function lsIsAdmin(): boolean { return sessionStorage.getItem(LS_ADMIN) === "1"; }
function lsSetAdmin(v: boolean): void {
  if (v) sessionStorage.setItem(LS_ADMIN, "1"); else sessionStorage.removeItem(LS_ADMIN);
}

const PBKDF2_ITERATIONS = 150000;
async function derivePasswordHash(password:string, saltB64:string, iterations=PBKDF2_ITERATIONS):Promise<string>{
  const salt=Uint8Array.from(atob(saltB64),c=>c.charCodeAt(0));
  const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(password),"PBKDF2",false,["deriveBits"]);
  const bits=await crypto.subtle.deriveBits({name:"PBKDF2",salt,iterations,hash:"SHA-256"},key,256);
  return btoa(String.fromCharCode(...new Uint8Array(bits)));
}
function newSaltB64(){ const a=crypto.getRandomValues(new Uint8Array(16)); return btoa(String.fromCharCode(...a)); }
async function setAdminPassword(password:string){
  if(password.length<10) throw new Error("Admin password must be at least 10 characters");
  const salt=newSaltB64();
  const hash=await derivePasswordHash(password,salt);
  localStorage.setItem(LS_ADMIN_CRED,JSON.stringify({salt,hash,iterations:PBKDF2_ITERATIONS,createdAt:nowIso()}));
  localStorage.removeItem(LS_PASSWORD_LEGACY);
}
async function hasAdminPassword(){ return !!localStorage.getItem(LS_ADMIN_CRED) || !!localStorage.getItem(LS_PASSWORD_LEGACY); }
async function verifyAdminPassword(password:string):Promise<boolean>{
  try{
    const raw=localStorage.getItem(LS_ADMIN_CRED);
    if(raw){ const c=JSON.parse(raw); const h=await derivePasswordHash(password,c.salt,Number(c.iterations)||PBKDF2_ITERATIONS); return h===c.hash; }
    const legacy=localStorage.getItem(LS_PASSWORD_LEGACY);
    if(legacy){ await setAdminPassword(legacy); return password===legacy; }
    return false;
  }catch{return false;}
}

function lsGetPicks(): AdminPicks | null {
  try { return JSON.parse(localStorage.getItem(LS_PICKS) ?? "null"); } catch { return null; }
}
function lsSavePicks(p: AdminPicks): void { localStorage.setItem(LS_PICKS, JSON.stringify(p)); }

// Guest lock helpers
function lsGetGuestCode(): string { return localStorage.getItem(LS_GUEST_CODE) ?? ""; }
async function setGuestCodeSecure(c:string){
  if(!c){ localStorage.removeItem(LS_GUEST_CODE); localStorage.removeItem(LS_GUEST_CODE_HASH); return; }
  const salt=newSaltB64(); const hash=await derivePasswordHash(c,salt);
  localStorage.setItem(LS_GUEST_CODE_HASH,JSON.stringify({salt,hash,iterations:PBKDF2_ITERATIONS}));
  localStorage.setItem(LS_GUEST_CODE,"••••••••");
}
function lsSetGuestCode(c: string): void {
  if(c) localStorage.setItem(LS_GUEST_CODE, c); else { localStorage.removeItem(LS_GUEST_CODE); localStorage.removeItem(LS_GUEST_CODE_HASH); }
}
async function verifyGuestCode(c:string):Promise<boolean>{
  try{ const raw=localStorage.getItem(LS_GUEST_CODE_HASH); if(raw){const x=JSON.parse(raw); return (await derivePasswordHash(c,x.salt,Number(x.iterations)||PBKDF2_ITERATIONS))===x.hash;} return false; }catch{return false;}
}
function lsGetGuestEpoch(): number {
  return parseInt(localStorage.getItem(LS_GUEST_EPOCH) ?? "0", 10);
}
function lsSetGuestEpoch(n: number): void { localStorage.setItem(LS_GUEST_EPOCH, String(n)); }
function lsIsGuestUnlocked(): boolean {
  try { const d=JSON.parse(sessionStorage.getItem(LS_GUEST_UNLOCKED)??"null"); return !!d && d.epoch===lsGetGuestEpoch(); } catch { return false; }
}
function lsSetGuestUnlocked(_code: string): void {
  sessionStorage.setItem(LS_GUEST_UNLOCKED, JSON.stringify({ epoch: lsGetGuestEpoch(), unlockedAt:Date.now() }));
}
function lsRevokeAllGuests(): void {
  lsSetGuestEpoch(lsGetGuestEpoch() + 1);
}

// Token stubs — kept for unused LoginPage/InvitePage that remain in file
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function getToken() { return null; }
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function setToken(_t: string) {}
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function clearToken() {}

// ─── Local API compatibility layer ────────────────────────────────────────────
// The original UI contains a number of admin/user screens that were written for
// a server API.  The Android/free build has no server, so those screens use this
// localStorage-backed adapter instead of silently failing.
const LS_SETTINGS = "4d_ls_settings_v1";
const LS_THEME = "4d_hospital_theme_v1";
const LS_LANGUAGE = "4d_hospital_language_v1";
const LS_COMPACT = "4d_hospital_compact_v1";

function applyAppPreferences(){
  try{
    const color=localStorage.getItem(LS_THEME) || "#22c55e";
    document.documentElement.style.setProperty("--app-accent", color);
    document.documentElement.lang=localStorage.getItem(LS_LANGUAGE) || "bn";
    document.documentElement.classList.toggle("app-compact", localStorage.getItem(LS_COMPACT)==="1");
  }catch{}
}
const LS_USERS = "4d_ls_users_v1";
const LS_MESSAGES = "4d_ls_messages_v1";
const LS_SECURITY_EVENTS = "4d_ls_security_events_v1";
const LS_AUDIT = "4d_ls_audit_v1";
const LS_EMAIL = "4d_ls_email_v1";
const LS_INVITES = "4d_ls_invites_v1";
const LS_AGENTS = "4d_ls_agents_v1";

function jsonLs<T>(key:string, fallback:T):T {
  try { return JSON.parse(localStorage.getItem(key) ?? JSON.stringify(fallback)) as T; }
  catch { return fallback; }
}
function saveLs<T>(key:string, value:T):void { localStorage.setItem(key, JSON.stringify(value)); }
function nowIso(){ return new Date().toISOString(); }
function localAudit(action:string, detail:string, success=true){
  const rows = jsonLs<any[]>(LS_AUDIT, []);
  rows.unshift({id:Date.now(), username:"CBC LT4 APON", action, ip:null, success, detail, createdAt:nowIso()});
  saveLs(LS_AUDIT, rows.slice(0,200));
}
function defaultSettings(){
  return {
    algo_weights:{statFreq:40,markov:40,humanFilter:20}, data_window:90,
    single_device_login:true, special_draw_mode:false, block_vpn_proxy:false,
    ocr_remap:{}, invite_ttl_hours:720, support_url:"",
    security_alerts_enabled:true, alert_email:"", security_alert_min_severity:"medium",
    recovery_email: jsonLs<string>(LS_EMAIL, ""), openai_set:false,
  };
}

async function apiFetch(method: string, path: string, body?: any): Promise<any> {
  const [pathname, query=""] = path.split("?");
  const q = new URLSearchParams(query);
  const settings = jsonLs<any>(LS_SETTINGS, defaultSettings());

  if (pathname === "/auth/me" && method === "GET") {
    return lsIsAdmin() ? { id:1, username:"CBC LT4 APON", role:"admin", email:jsonLs<string>(LS_EMAIL, "") } : { id:1, username:"Guest", role:"user", email:"" };
  }

  if (pathname === "/auth/login" && method === "POST") {
    if (body?.username === "CBC LT4 APON" && await verifyAdminPassword(String(body?.password??""))) {
      lsSetAdmin(true); localAudit("login", "Local admin login", true);
      return { id:1, username:"CBC LT4 APON", role:"admin", token:"local-admin" };
    }
    localAudit("login_failed", "Invalid local admin credentials", false);
    throw new Error("ভুল ইউজারনেম বা পাসওয়ার্ড");
  }

  if (pathname === "/auth/invite" && method === "POST") {
    const token = (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`).replace(/-/g,"");
    const expiresAt = new Date(Date.now() + Number(settings.invite_ttl_hours ?? 720)*3600000).toISOString();
    const invites = jsonLs<any[]>(LS_INVITES, []);
    invites.push({token,expiresAt,used:false}); saveLs(LS_INVITES, invites);
    return {token,expiresAt};
  }
  const inviteMatch = pathname.match(/^\/auth\/invite\/([^/]+)$/);
  if (inviteMatch && method === "GET") {
    const inv = jsonLs<any[]>(LS_INVITES, []).find(x=>x.token===inviteMatch[1] && !x.used);
    if (!inv || new Date(inv.expiresAt).getTime() < Date.now()) throw new Error("Invalid or expired invite.");
    return inv;
  }
  if (pathname === "/auth/accept-invite" && method === "POST") {
    const invites=jsonLs<any[]>(LS_INVITES, []); const inv=invites.find(x=>x.token===body?.token && !x.used);
    if(!inv || new Date(inv.expiresAt).getTime()<Date.now()) throw new Error("Invalid or expired invite.");
    const users=jsonLs<any[]>(LS_USERS, [{id:1,username:"CBC LT4 APON",role:"admin",isActive:true,createdAt:nowIso(),lastLogin:nowIso()}]);
    if(users.some(u=>u.username===body?.username)) throw new Error("Username already exists");
    const passwordHash=body?.password?await (async()=>{const salt=newSaltB64();return {salt,hash:await derivePasswordHash(String(body.password),salt),iterations:PBKDF2_ITERATIONS};})():null;
    const u={id:Date.now(),username:String(body?.username??"user"),role:"user",isActive:true,createdAt:nowIso(),lastLogin:null,passwordHash};
    users.push(u); saveLs(LS_USERS,users); inv.used=true; saveLs(LS_INVITES,invites); localAudit("invite_accept",`Created user ${u.username}`,true);
    return {id:u.id,username:u.username,role:u.role,token:`local-${u.id}`};
  }

  if (pathname === "/admin/settings" && method === "GET") return {...settings, recovery_email:jsonLs<string>(LS_EMAIL, settings.recovery_email ?? "")};
  if (pathname === "/admin/settings" && method === "POST") {
    const merged={...settings,...body}; saveLs(LS_SETTINGS,merged); localAudit("settings", "Local settings updated", true); return merged;
  }

  if (pathname === "/admin/export" && method === "GET") {
    const rows=lsGetResults(); const fmt=q.get("format")||"json"; const filename=`cbc-lt4-my-${new Date().toISOString().slice(0,10)}.${fmt}`;
    if(fmt==="csv"){
      const esc=(v:any)=>`"${String(v??"").replace(/"/g,'""')}"`;
      const header="id,company,date,drawNo,first,second,third,special,consolation";
      const csv=[header,...rows.map(r=>[r.id,r.company,r.date,r.drawNo,r.first,r.second,r.third,r.special.join(" "),r.consolation.join(" ")].map(esc).join(","))].join("\n");
      return {csvContent:csv,filename,totalRows:rows.length};
    }
    return {version:1,exportedAt:nowIso(),rows,filename,totalRows:rows.length};
  }
  if (pathname === "/admin/import" && method === "POST") {
    const rows=Array.isArray(body?.rows)?body.rows:[]; let inserted=0, skipped=0; const current=lsGetResults();
    for(const r of rows){ if(!r?.company||!r?.date||!r?.first||!r?.second||!r?.third){skipped++;continue;} const nr={...r,id:Number(r.id)||Date.now()+inserted};
      const i=current.findIndex(x=>x.company===nr.company&&x.date===nr.date); if(i>=0) current[i]=nr; else {current.push(nr); inserted++;}
    }
    lsSaveResults(current); localAudit("import",`Imported ${inserted} draws`,true); return {inserted,skipped};
  }

  if (pathname === "/auth/change-password" && method === "POST") {
    if(!(await verifyAdminPassword(String(body?.currentPassword??"")))) throw new Error("Current password is incorrect");
    await setAdminPassword(String(body?.newPassword??"")); localAudit("change_password","Admin password changed",true); return {ok:true};
  }
  if (pathname === "/auth/profile" && method === "PATCH") {
    localStorage.setItem(LS_EMAIL,String(body?.email??"")); return {email:String(body?.email??"")};
  }

  if (pathname === "/auth/users" && method === "GET") {
    return jsonLs<any[]>(LS_USERS,[{id:1,username:"CBC LT4 APON",role:"admin",isActive:true,createdAt:nowIso(),lastLogin:nowIso()}]).map(({password,passwordHash,...u})=>u);
  }
  if (pathname === "/auth/users" && method === "POST") {
    const users=jsonLs<any[]>(LS_USERS,[{id:1,username:"CBC LT4 APON",role:"admin",isActive:true,createdAt:nowIso(),lastLogin:nowIso()}]);
    if(users.some(u=>u.username===body?.username)) throw new Error("Username already exists");
    const passwordHash=body?.password?await (async()=>{const salt=newSaltB64();return {salt,hash:await derivePasswordHash(String(body.password),salt),iterations:PBKDF2_ITERATIONS};})():null;
    const u={id:Date.now(),username:String(body?.username??"user"),role:body?.role==="admin"?"admin":"user",isActive:true,createdAt:nowIso(),lastLogin:null,passwordHash}; users.push(u); saveLs(LS_USERS,users); localAudit("user_create",`Created ${u.username}`,true); const {passwordHash:_,...safe}=u; return safe;
  }
  const userMatch=pathname.match(/^\/auth\/users\/(\d+)$/);
  if(userMatch && method === "PATCH"){
    const id=Number(userMatch[1]); const users=jsonLs<any[]>(LS_USERS,[]); const i=users.findIndex(u=>u.id===id); if(i<0) throw new Error("User not found");
    const patch={...body}; delete patch.passwordHash;
    if(typeof body?.password==="string"){const salt=newSaltB64();patch.passwordHash={salt,hash:await derivePasswordHash(body.password,salt),iterations:PBKDF2_ITERATIONS}; delete patch.password;}
    users[i]={...users[i],...patch}; saveLs(LS_USERS,users); localAudit("user_update",`Updated user #${id}`,true); const {passwordHash:_,password:__,...safe}=users[i]; return safe;
  }
  if(userMatch && (method === "DELETE" || method === "DEL")){
    const id=Number(userMatch[1]); const users=jsonLs<any[]>(LS_USERS,[]); saveLs(LS_USERS,users.filter(u=>u.id!==id)); localAudit("user_delete",`Deleted user #${id}`,true); return {ok:true};
  }

  const companyMatch=pathname.match(/^\/malaysia-lottery\/company\/([^/]+)$/);
  if(companyMatch && method === "DELETE"){
    const company=companyMatch[1]; lsSaveResults(lsGetResults().filter(r=>r.company!==company)); localAudit("company_reset",`Reset ${company}`,true); return {ok:true};
  }

  if (pathname === "/admin/logs" && method === "GET") return {logs:jsonLs<any[]>(LS_AUDIT,[]).map(x=>({ts:new Date(x.createdAt).getTime(),level:x.success?"info":"error",msg:x.detail??x.action}))};
  if (pathname === "/admin/audit-logs" && method === "GET") return {logs:jsonLs<any[]>(LS_AUDIT,[]).slice(0,Number(q.get("limit")||100))};
  if (pathname === "/admin/email-backup" && method === "POST") throw new Error("Email backup is disabled in the free offline build. Use local encrypted backup instead.");
  if (pathname === "/admin/restart" && method === "POST") return {ok:true};
  if (pathname === "/admin/security-alerts/test" && method === "POST") return {message:"Local test alert recorded."};

  if (pathname === "/messages" && method === "POST") {
    const msgs=jsonLs<any[]>(LS_MESSAGES,[]); msgs.unshift({id:`m-${Date.now()}`,senderName:body?.senderName??"Guest",text:String(body?.text??""),read:false,createdAt:nowIso()}); saveLs(LS_MESSAGES,msgs); return {ok:true};
  }
  if (pathname === "/admin/messages" && method === "GET") { const messages=jsonLs<any[]>(LS_MESSAGES,[]); return {messages,unread:messages.filter(m=>!m.read).length}; }
  if (pathname === "/admin/messages/mark-read" && method === "POST") { const messages=jsonLs<any[]>(LS_MESSAGES,[]).map(m=>({...m,read:true})); saveLs(LS_MESSAGES,messages); return {ok:true,unread:0}; }
  const msgMatch=pathname.match(/^\/admin\/messages\/([^/]+)$/);
  if(msgMatch && method === "DELETE"){ const messages=jsonLs<any[]>(LS_MESSAGES,[]).filter(m=>String(m.id)!==msgMatch[1]); saveLs(LS_MESSAGES,messages); return {ok:true,unread:messages.filter(m=>!m.read).length}; }
  if(pathname==="/admin/messages" && method==="DELETE"){saveLs(LS_MESSAGES,[]);return {ok:true,unread:0};}

  if (pathname === "/admin/security-events" && method === "GET") { const events=jsonLs<any[]>(LS_SECURITY_EVENTS,[]); return {events,unread:events.filter(e=>!e.read).length}; }
  if (pathname === "/admin/security-events/mark-read" && method === "POST") { const events=jsonLs<any[]>(LS_SECURITY_EVENTS,[]).map(e=>({...e,read:true})); saveLs(LS_SECURITY_EVENTS,events); return {ok:true}; }
  if (pathname === "/admin/security-events" && method === "DELETE") {saveLs(LS_SECURITY_EVENTS,[]);return {ok:true};}

  throw new Error(`Local feature not implemented: ${method} ${path}`);
}
const api = {
  get:   (p: string)              => apiFetch("GET", p),
  post:  (p: string, b: unknown)  => apiFetch("POST", p, b),
  put:   (p: string, b: unknown)  => apiFetch("PUT", p, b),
  patch: (p: string, b: unknown)  => apiFetch("PATCH", p, b),
  del:   (p: string, b?: unknown) => apiFetch("DELETE", p, b),
  delete:(p: string, b?: unknown) => apiFetch("DELETE", p, b),
};

// ─── CSPRNG helper — uses Web Crypto API, never Math.random for 4D analysis logic ─
function cryptoRandFloat(): number {
  const buf = new Uint32Array(1);
  crypto.getRandomValues(buf);
  return buf[0]! / 0x100000000;
}
function cryptoRandInt(max: number): number { return Math.floor(cryptoRandFloat() * max); }

// ─── Analysis Helpers ─────────────────────────────────────────────────────────
function allNums(r: LotteryResult) {
  return [r.first, r.second, r.third, ...r.special, ...r.consolation];
}
function digitFrequency(results: LotteryResult[], company?: CompanyId) {
  const filtered = company ? results.filter(r => r.company === company) : results;
  const freq: Record<string, number> = {};
  for (let i = 0; i < 10; i++) freq[String(i)] = 0;
  for (const r of filtered) for (const n of allNums(r)) for (const d of n) if (/\d/.test(d)) freq[d] = (freq[d] ?? 0) + 1;
  return Object.entries(freq).map(([digit, count]) => ({ digit, count }));
}
function tripletFrequency(results: LotteryResult[], company?: CompanyId) {
  const filtered = company ? results.filter(r => r.company === company) : results;
  const freq: Record<string, number> = {};
  for (const r of filtered) for (const num of [r.first, r.second, r.third]) {
    if (num.length === 4) {
      const d = num.split("");
      [`${d[0]}${d[1]}${d[2]}`,`${d[0]}${d[1]}${d[3]}`,`${d[0]}${d[2]}${d[3]}`,`${d[1]}${d[2]}${d[3]}`].forEach(t => freq[t] = (freq[t]??0)+1);
    }
  }
  return Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,30).map(([triplet,count])=>({triplet,count}));
}
function pairFrequency(results: LotteryResult[], company?: CompanyId) {
  const filtered = company ? results.filter(r => r.company === company) : results;
  const freq: Record<string, number> = {};
  for (const r of filtered) for (const num of [r.first, r.second, r.third]) {
    if (num.length === 4) {
      const d = num.split("");
      [d[0]+d[1],d[0]+d[2],d[0]+d[3],d[1]+d[2],d[1]+d[3],d[2]+d[3]].forEach(p => freq[p]=(freq[p]??0)+1);
    }
  }
  return Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,30).map(([pair,count])=>({pair,count}));
}
function crossCompanyMatrix(results: LotteryResult[]) {
  const matrix: Record<CompanyId, Record<CompanyId, number>> = {} as any;
  for (const c of COMPANY_IDS) { matrix[c]={} as any; for (const d of COMPANY_IDS) matrix[c][d]=0; }
  const byDate: Record<string, Record<CompanyId, string[]>> = {};
  for (const r of results) {
    const c = r.company as CompanyId;
    if (!COMPANY_IDS.includes(c)) continue;
    if (!byDate[r.date]) byDate[r.date]={} as any;
    byDate[r.date][c] = allNums(r);
  }
  for (const [,companies] of Object.entries(byDate)) {
    const cIds = Object.keys(companies) as CompanyId[];
    for (let i=0;i<cIds.length;i++) for (let j=i+1;j<cIds.length;j++) {
      const a=cIds[i], b=cIds[j];
      const ov = companies[a].filter(n=>companies[b].includes(n)).length;
      matrix[a][b]+=ov; matrix[b][a]+=ov;
    }
  }
  return matrix;
}

// ─── Small shared components ──────────────────────────────────────────────────
function PrizeBadge({ label, number, size="md" }: { label: string; number: string; size?: "sm"|"md"|"lg" }) {
  const sz = size==="lg" ? "text-2xl font-black" : size==="md" ? "text-lg font-bold" : "text-sm font-semibold";
  return (
    <div className="text-center">
      <div className="text-slate-500 text-xs uppercase tracking-wide mb-1">{label}</div>
      <div className={`font-mono ${sz} text-white bg-slate-800 rounded-lg px-3 py-1.5 border border-slate-700`}>{number}</div>
    </div>
  );
}

function CompanySelector({ value, onChange }: { value: CompanyId|"all"; onChange: (v: CompanyId|"all")=>void }) {
  return (
    <select value={value} onChange={e=>onChange(e.target.value as any)}
      className="bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500">
      <option value="all">All Companies</option>
      {COMPANY_IDS.map(id=><option key={id} value={id}>{COMPANIES[id].name}</option>)}
    </select>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function AppFooter({ dark=false }: { dark?:boolean }) {
  return (
    <footer className={`flex-shrink-0 text-center py-2.5 px-4 ${dark?"border-t border-red-900/30 bg-black":"border-t border-red-900/20"}`}>
      <p className="text-zinc-700 text-[11px] tracking-wide">
        © 2026 <span className="text-red-700 font-medium">4D HOSPITAL</span>
        <span className="mx-1.5 text-zinc-800">·</span>
        Directed by <span className="text-yellow-700">মোঃ আপন</span>
      </p>
    </footer>
  );
}

// ─── Login Page ───────────────────────────────────────────────────────────────
function LoginPage({ onLogin, onInvite }: { onLogin:(u:AuthUser)=>void; onInvite:()=>void }) {
  const [username,setUsername]=useState(""); const [password,setPassword]=useState("");
  const [error,setError]=useState(""); const [loading,setLoading]=useState(false);
  async function handleLogin(e: React.FormEvent) {
    e.preventDefault(); setLoading(true); setError("");
    try {
      const data = await api.post("/auth/login",{username,password});
      if (data.token) setToken(data.token);
      onLogin(data);
    }
    catch(err:any) { setError(err.message); }
    finally { setLoading(false); }
  }
  return (
    <div className="min-h-screen flex flex-col" style={{background:"linear-gradient(135deg,#0f0f0f 0%,#1a0a0a 40%,#130a1f 100%)"}}>
      <div className="flex-1 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl mb-4 shadow-2xl overflow-hidden border-2 border-red-800/50" style={{boxShadow:"0 0 40px rgba(220,38,38,0.3)"}}>
            <img src="/cbc-logo.png" alt="4D HOSPITAL" className="w-full h-full object-cover"/>
          </div>
          <h1 className="text-3xl font-black text-white tracking-wide">4D <span className="text-red-500">HOSPITAL</span></h1>
          <p className="text-zinc-500 text-sm mt-1">Malaysia 4D Data & Analysis Platform</p>
          <div className="flex items-center justify-center gap-2 mt-3">
            <span className="h-px w-12 bg-gradient-to-r from-transparent to-red-800"/>
            <span className="text-yellow-600 text-xs font-semibold tracking-widest uppercase">Premium Analytics</span>
            <span className="h-px w-12 bg-gradient-to-l from-transparent to-red-800"/>
          </div>
        </div>
        <div className="rounded-2xl p-8 shadow-2xl border border-red-900/30" style={{background:"rgba(20,10,10,0.95)"}}>
          <h2 className="text-white font-bold text-lg mb-6">আপনার অ্যাকাউন্টে প্রবেশ করুন</h2>
          {error&&<div className="mb-4 p-3 bg-red-950/60 border border-red-700 rounded-xl text-red-300 text-sm">{error}</div>}
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-zinc-400 text-sm font-medium mb-1.5">ইউজারনেম</label>
              <input type="text" value={username} onChange={e=>setUsername(e.target.value)}
                className="w-full rounded-xl px-4 py-3 text-white placeholder-zinc-600 focus:outline-none transition border border-zinc-800 focus:border-red-600"
                style={{background:"#0f0f0f"}}
                placeholder="username লিখুন" autoFocus required />
            </div>
            <div>
              <label className="block text-zinc-400 text-sm font-medium mb-1.5">পাসওয়ার্ড</label>
              <input type="password" value={password} onChange={e=>setPassword(e.target.value)}
                className="w-full rounded-xl px-4 py-3 text-white placeholder-zinc-600 focus:outline-none transition border border-zinc-800 focus:border-red-600"
                style={{background:"#0f0f0f"}}
                placeholder="পাসওয়ার্ড লিখুন" required />
            </div>
            <button type="submit" disabled={loading}
              className="w-full font-bold rounded-xl py-3.5 text-white transition disabled:opacity-50 text-base"
              style={{background:loading?"#7f1d1d":"linear-gradient(135deg,#dc2626,#7c3aed)",boxShadow:loading?"none":"0 4px 20px rgba(220,38,38,0.35)"}}>
              {loading?"লগইন হচ্ছে…":"🔐 প্রবেশ করুন"}
            </button>
          </form>
          <div className="mt-4 text-center">
            <button onClick={onInvite} className="text-red-500 hover:text-red-400 text-sm transition">Invite code আছে? →</button>
          </div>
        </div>
      </div>
      </div>
      <AppFooter/>
    </div>
  );
}

// ─── Invite Page ──────────────────────────────────────────────────────────────
function InvitePage({ token, onSuccess }: { token:string; onSuccess:(u:AuthUser)=>void }) {
  const [username,setUsername]=useState(""); const [password,setPassword]=useState(""); const [confirm,setConfirm]=useState("");
  const [manualToken,setManualToken]=useState(token);
  const [error,setError]=useState(""); const [loading,setLoading]=useState(false);
  const [checking,setChecking]=useState(!!token); const [valid,setValid]=useState(false);

  useEffect(()=>{
    if(!manualToken) return;
    setChecking(true);
    api.get(`/auth/invite/${manualToken}`).then(()=>setValid(true)).catch(()=>setError("Invalid or expired invite.")).finally(()=>setChecking(false));
  },[]);

  async function handleCheckToken(e: React.FormEvent) {
    e.preventDefault(); setChecking(true); setError("");
    api.get(`/auth/invite/${manualToken}`).then(()=>{setValid(true);setChecking(false);}).catch(()=>{setError("Invalid or expired invite.");setChecking(false);});
  }
  async function handleAccept(e: React.FormEvent) {
    e.preventDefault();
    if(password!==confirm){setError("Passwords do not match");return;}
    setLoading(true); setError("");
    try {
      const u=await api.post("/auth/accept-invite",{token:manualToken,username,password});
      if (u.token) setToken(u.token);
      onSuccess({id:u.id??0,username:u.username,role:u.role});
    } catch(err:any){setError(err.message);}
    finally{setLoading(false);}
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900">
      <div className="flex-1 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4 shadow-lg overflow-hidden">
            <img src="/cbc-logo.png" alt="4D HOSPITAL" className="w-full h-full object-cover"/>
          </div>
          <h1 className="text-2xl font-bold text-white">4D HOSPITAL</h1>
          <p className="text-slate-400 text-sm mt-1">Accept Your Invitation</p>
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-8 shadow-2xl">
          {error&&<div className="mb-4 p-3 bg-red-900/30 border border-red-700 rounded-lg text-red-300 text-sm">{error}</div>}
          {checking&&<p className="text-slate-400 text-sm text-center py-4">Validating invite…</p>}
          {!checking&&!valid&&(
            <form onSubmit={handleCheckToken} className="space-y-4">
              <h2 className="text-white font-semibold text-lg">Enter Invite Code</h2>
              <input value={manualToken} onChange={e=>setManualToken(e.target.value)}
                className="w-full bg-slate-900 border border-slate-600 rounded-lg px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono text-sm"
                placeholder="Paste invite code here" required />
              <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg py-2.5 transition">Validate Code</button>
            </form>
          )}
          {!checking&&valid&&(
            <form onSubmit={handleAccept} className="space-y-4">
              <h2 className="text-white font-semibold text-lg">✅ Set up your account</h2>
              {[["text","Choose Username","e.g. john",username,setUsername],["password","Password (min 6 chars)","Secure password",password,setPassword],["password","Confirm Password","Repeat password",confirm,setConfirm]].map(([t,l,ph,v,sv],i)=>(
                <div key={i}>
                  <label className="block text-slate-300 text-sm font-medium mb-1.5">{l as string}</label>
                  <input type={t as string} value={v as string} onChange={e=>(sv as any)(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-600 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-blue-500" placeholder={ph as string} required />
                </div>
              ))}
              <button type="submit" disabled={loading} className="w-full bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold rounded-lg py-2.5 transition">{loading?"Creating account…":"Create Account & Sign In"}</button>
            </form>
          )}
        </div>
      </div>
      </div>
      <AppFooter/>
    </div>
  );
}

// ─── Support Button ───────────────────────────────────────────────────────────
function SupportButton() {
  const [url,setUrl]=useState<string|null>(null);
  useEffect(()=>{
    api.get("/admin/settings").then(d=>setUrl(d.support_url||null)).catch(()=>{});
  },[]);
  if(!url) return null;
  return (
    <a href={url} target="_blank" rel="noopener noreferrer"
      className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-400 hover:text-green-300 hover:bg-green-500/10 transition-all w-full">
      <span className="text-base">💬</span>
      <span>Help &amp; Support</span>
    </a>
  );
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────
interface SidebarProps { view:View; company:CompanyId; user:AuthUser; results:LotteryResult[]; onView:(v:View)=>void; onCompany:(c:CompanyId)=>void; onLogout:()=>void; onAdminLogin:()=>void; isOpen:boolean; onClose:()=>void; }

function Sidebar({ view,company,user,results=[],onView,onCompany,onLogout,onAdminLogin,isOpen,onClose }: SidebarProps) {
  const navItem = (label:string, icon:string, v:View) => {
    const active = view===v && view!=="company";
    return (
      <button key={v} onClick={()=>{onView(v);onClose();}}
        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${active?"text-white shadow-lg":"text-zinc-500 hover:text-white hover:bg-white/5"}`}
        style={active?{background:"linear-gradient(135deg,rgba(220,38,38,0.3),rgba(124,58,237,0.2))",border:"1px solid rgba(220,38,38,0.4)"}:{border:"1px solid transparent"}}>
        <span className="text-base">{icon}</span>
        <span className="flex-1 text-left">{label}</span>
        {active&&<span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"/>}
      </button>
    );
  };

  const companyItem = (id:CompanyId) => {
    const c = COMPANIES[id];
    const active = view==="company"&&company===id;
    return (
      <button key={id} onClick={()=>{onCompany(id);onView("company");onClose();}}
        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${active?"text-white":"text-zinc-500 hover:text-white hover:bg-white/5"}`}
        style={active?{background:"linear-gradient(135deg,rgba(220,38,38,0.25),rgba(124,58,237,0.15))",border:"1px solid rgba(220,38,38,0.35)"}:{border:"1px solid transparent"}}>
        <span className="w-3 h-3 rounded-full flex-shrink-0 shadow-sm" style={{background:c.color,boxShadow:`0 0 6px ${c.color}60`}} />
        <span className="flex-1 text-left">{c.name}</span>
        {active&&<span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"/>}
      </button>
    );
  };

  const todayDraw = results.filter(r=>r.company===company).sort((a,b)=>b.date.localeCompare(a.date))[0];

  const [openSections, setOpenSections] = useState<Record<string,boolean>>({
    "results": true,
    "analysis": true,
    "ai":      false,
    "admin":   true,
  });
  const toggleSection = (key: string) => setOpenSections(s => ({...s,[key]:!s[key]}));

  const sectionHeader = (key:string, label:string, children: React.ReactNode) => {
    const open = openSections[key] ?? true;
    return (
      <div className="mt-3">
        <button onClick={()=>toggleSection(key)}
          className="w-full flex items-center gap-2 px-2 py-1.5 rounded-lg group transition"
          style={{background:"rgba(220,38,38,0.05)"}}>
          <span className="flex-1 text-left text-[11px] font-bold uppercase tracking-widest text-red-700 group-hover:text-red-500 transition">{label}</span>
          <svg className={`w-3 h-3 text-red-800 transition-transform duration-200 ${open?"rotate-90":"rotate-0"}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7"/>
          </svg>
        </button>
        <div className="overflow-hidden transition-all duration-200" style={{maxHeight:open?"800px":"0px",opacity:open?1:0}}>
          <div className="space-y-0.5 pt-1">{children}</div>
        </div>
      </div>
    );
  };

  const content = (
    <div className="flex flex-col h-full" style={{background:"#0d0d0d"}}>
      {/* Logo header */}
      <div className="p-4 flex-shrink-0" style={{borderBottom:"1px solid rgba(220,38,38,0.2)"}}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl overflow-hidden flex-shrink-0" style={{border:"1px solid rgba(220,38,38,0.4)",boxShadow:"0 0 16px rgba(220,38,38,0.25)"}}>
            <img src="/cbc-logo.png" alt="4D HOSPITAL" className="w-full h-full object-cover"/>
          </div>
          <div>
            <div className="text-white font-black text-sm">4D <span className="text-red-500">HOSPITAL</span></div>
            <div className="text-zinc-600 text-xs">4D Data & Analysis</div>
          </div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto p-3 space-y-1">

        {/* Latest Draw Mini-Card */}
        {todayDraw && (
          <div className="rounded-xl p-3 mb-2" style={{background:"linear-gradient(135deg,rgba(220,38,38,0.12),rgba(124,58,237,0.08))",border:"1px solid rgba(220,38,38,0.2)"}}>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-red-400 text-[10px] font-bold uppercase tracking-widest">সর্বশেষ ড্র</span>
              <span className="text-zinc-600 text-[10px]">{todayDraw.date}</span>
            </div>
            <div className="flex gap-1.5">
              {[todayDraw.first,todayDraw.second,todayDraw.third].map((num,i)=>(
                <div key={i} className="flex-1 rounded-lg py-1.5 text-center" style={{background:i===0?"rgba(234,179,8,0.15)":"rgba(255,255,255,0.04)",border:i===0?"1px solid rgba(234,179,8,0.3)":"1px solid rgba(255,255,255,0.06)"}}>
                  <div className={`font-mono font-black text-base leading-none ${i===0?"text-yellow-400":"text-zinc-300"}`}>{num}</div>
                  <div className="text-zinc-700 text-[9px] mt-0.5">{i===0?"1st":i===1?"2nd":"3rd"}</div>
                </div>
              ))}
            </div>
            <div className="text-zinc-700 text-[10px] text-center mt-1.5">{COMPANIES[company as CompanyId]?.name??company}</div>
          </div>
        )}

        {/* GENERATOR — pinned very top */}
        <button onClick={()=>{onView("generator");onClose();}}
          className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-bold transition-all border ${view==="generator"
            ?"text-green-300":"text-zinc-400 hover:text-green-300"}`}
          style={view==="generator"
            ?{background:"linear-gradient(135deg,rgba(34,197,94,0.18),rgba(16,185,129,0.1))",border:"1px solid rgba(34,197,94,0.4)",boxShadow:"0 4px 20px rgba(34,197,94,0.12)"}
            :{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.06)"}}>
          <span className="text-lg">🎯</span>
          <span className="flex-1 text-left">Smart Generator</span>
          <span className="text-[10px] font-bold text-green-400 border border-green-600/40 rounded-full px-2 py-0.5" style={{background:"rgba(34,197,94,0.1)"}}>25 Formula</span>
        </button>

        {/* MASTER — pinned top */}
        <button onClick={()=>{onView("master");onClose();}}
          className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-bold transition-all border ${view==="master"
            ?"text-yellow-300":"text-zinc-400 hover:text-yellow-300"}`}
          style={view==="master"
            ?{background:"linear-gradient(135deg,rgba(234,179,8,0.15),rgba(180,83,9,0.1))",border:"1px solid rgba(234,179,8,0.35)",boxShadow:"0 4px 20px rgba(234,179,8,0.1)"}
            :{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.06)"}}>
          <span className="text-lg">⭐</span>
          <span className="flex-1 text-left">Master Prediction</span>
          {view==="master"&&<span className="text-[10px] font-bold text-yellow-400 border border-yellow-600/40 rounded-full px-2 py-0.5" style={{background:"rgba(234,179,8,0.1)"}}>LIVE</span>}
        </button>

        {/* Data Entry — local/offline, available to all users */}
        {sectionHeader("results","📥 ডেটা এন্ট্রি",<>
          {navItem("✏️ ম্যানুয়াল / Paste","✏️","scan")}
          {navItem("📷 Screenshot OCR","📷","ocr")}
          {navItem("🔢 Number Pattern Explorer","🔢","patterns")}
          {navItem("🗄️ Data Vault / History","🗄️","vault")}
        </>)}

        {/* 🏢 Company Results — all users */}
        {sectionHeader("results2" as any,"🏢 কোম্পানি রেজাল্ট",<>
          {navItem("Dashboard & Stats","📊","dashboard")}
          {COMPANY_IDS.map(companyItem)}
        </>)}

        {/* 📐 Analysis — all users */}
        {sectionHeader("analysis","📐 বিশ্লেষণ",<>
          {navItem("Deep Analysis","🔬","deep")}
          {navItem("৩D ট্রিপলেট & পেয়ার","⏹️","triplets")}
          {navItem("Pairs Analysis","💞","pairs")}
          {navItem("High/Low & Odd/Even","🌗","highlowmatrix")}
          {navItem("Pattern Heatmap","🔥","heatmap")}
          {navItem("Calendar Correlation","📅","calendar")}
          {navItem("Regression Trends","📉","regression")}
          {navItem("মিরর নাম্বার","🪞","mirror")}
          {navItem("Benford's Law","📊","benford")}
          {navItem("Permutation Filter","🎲","permutation")}
          {navItem("Skip-Draw","⏭️","skipdraw")}
          {navItem("Neighbor Digits","🔢","neighbor")}
          {navItem("Cross-Company","🔀","cross")}
          {navItem("Correlation","📈","correlation")}
          {navItem("🔒 Research Cycle","🧪","researchCycle")}
        </>)}

        {/* 🤖 AI & ML — all users */}
        {sectionHeader("ai","🤖 AI & ML ইঞ্জিন",<>
          {navItem("LSTM Sequence","🧠","lstm")}
          {navItem("Markov Chain","🔄","markov")}
          {navItem("Genetic Algorithm","🧬","genetic")}
          {navItem("Cluster & Outlier","📍","outlier2")}
          {navItem("Backtesting","🧪","backtest")}
          {navItem("Sliding Window","🔲","sliding")}
          {navItem("Multi-Model Consensus","🏆","consensus")}
          {navItem("Breakout Alerts","🔔","alerts")}
          {navItem("Performance","📊","performance")}
          {navItem("Predictions","🔮","predictions")}
        </>)}

        {/* Non-admin: Admin login button */}
        {user.role!=="admin"&&(
          <div className="mt-3 space-y-2">
            <div className="mx-1 rounded-xl px-3 py-2 flex items-center gap-2" style={{background:"rgba(124,58,237,0.08)",border:"1px solid rgba(124,58,237,0.2)"}}>
              <span className="text-purple-400 text-sm">👁️</span>
              <div>
                <div className="text-purple-300 text-[10px] font-black uppercase tracking-widest">View Only</div>
                <div className="text-zinc-700 text-[10px]">শুধু দেখার অনুমতি আছে</div>
              </div>
            </div>
            <button onClick={()=>{onAdminLogin();onClose();}}
              className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-semibold text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-all"
              style={{border:"1px solid rgba(220,38,38,0.2)"}}>
              <span>🛡️</span><span>Admin Mode চালু করুন</span>
            </button>
          </div>
        )}

        <div className="mt-3 space-y-0.5">
          {navItem("👥 Agent / KYC","👥","agents")}
          {navItem("Settings","⚙️","settings")}
          <SupportButton/>
        </div>
      </nav>

      {/* User footer */}
      <div className="p-3 flex-shrink-0" style={{borderTop:"1px solid rgba(220,38,38,0.15)"}}>
        <div className="flex items-center gap-3 px-2 py-2">
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-black text-white flex-shrink-0"
            style={{background:"linear-gradient(135deg,#dc2626,#7c3aed)"}}>{user.username[0]?.toUpperCase()}</div>
          <div className="flex-1 min-w-0">
            <div className="text-white text-sm font-semibold truncate">{user.username}</div>
            <div className="text-zinc-600 text-xs">{user.role==="admin"?"Admin Mode চালু":"Guest"}</div>
          </div>
          {user.role==="admin"&&(
            <button onClick={onLogout} title="Admin Mode বন্ধ করুন" className="text-zinc-600 hover:text-red-500 transition p-1" style={{flexShrink:0}}>
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
            </button>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <>
      {isOpen&&<div className="fixed inset-0 bg-black/70 z-40 lg:hidden" onClick={onClose}/>}
      <div className="hidden lg:flex flex-col w-64 flex-shrink-0" style={{background:"#0d0d0d",borderRight:"1px solid rgba(220,38,38,0.15)"}}>{content}</div>
      <div className={`fixed inset-y-0 left-0 w-72 z-50 transform transition-transform duration-200 lg:hidden ${isOpen?"translate-x-0":"-translate-x-full"}`} style={{background:"#0d0d0d"}}>{content}</div>
    </>
  );
}

// ─── Dashboard ────────────────────────────────────────────────────────────────
function ToolGrid({ onView }: { onView:(v:View)=>void }) {
  const TOOLS: {icon:string; label:string; view:View; color:string; group:string}[] = [
    // Analysis
    {icon:"🔬",label:"Deep Analysis",      view:"deep",          color:"#818cf8",group:"বিশ্লেষণ"},
    {icon:"⏹️",label:"3D Triplet & Pair",  view:"triplets",      color:"#34d399",group:"বিশ্লেষণ"},
    {icon:"💞",label:"Pairs Analysis",      view:"pairs",         color:"#f472b6",group:"বিশ্লেষণ"},
    {icon:"🌗",label:"High/Low & Odd/Even", view:"highlowmatrix", color:"#60a5fa",group:"বিশ্লেষণ"},
    {icon:"🔥",label:"Pattern Heatmap",     view:"heatmap",       color:"#fb923c",group:"বিশ্লেষণ"},
    {icon:"📅",label:"Calendar Correlation",view:"calendar",      color:"#a78bfa",group:"বিশ্লেষণ"},
    {icon:"📉",label:"Regression Trends",   view:"regression",    color:"#38bdf8",group:"বিশ্লেষণ"},
    {icon:"🪞",label:"Mirror Number",       view:"mirror",        color:"#e2e8f0",group:"বিশ্লেষণ"},
    {icon:"📊",label:"Benford's Law",       view:"benford",       color:"#fbbf24",group:"বিশ্লেষণ"},
    {icon:"🎲",label:"Permutation Filter",  view:"permutation",   color:"#c084fc",group:"বিশ্লেষণ"},
    {icon:"⏭️",label:"Skip-Draw",           view:"skipdraw",      color:"#f87171",group:"বিশ্লেষণ"},
    {icon:"🔢",label:"Neighbor Digits",     view:"neighbor",      color:"#6ee7b7",group:"বিশ্লেষণ"},
    {icon:"🔀",label:"Cross-Company",       view:"cross",         color:"#fdba74",group:"বিশ্লেষণ"},
    {icon:"📈",label:"Correlation",         view:"correlation",   color:"#67e8f9",group:"বিশ্লেষণ"},
    // AI & ML
    {icon:"🧠",label:"LSTM Sequence",       view:"lstm",          color:"#a78bfa",group:"AI & ML"},
    {icon:"🔄",label:"Markov Chain",        view:"markov",        color:"#34d399",group:"AI & ML"},
    {icon:"🧬",label:"Genetic Algorithm",   view:"genetic",       color:"#f472b6",group:"AI & ML"},
    {icon:"📍",label:"Cluster & Outlier",   view:"outlier2",      color:"#fb923c",group:"AI & ML"},
    {icon:"🧪",label:"Backtesting",         view:"backtest",      color:"#60a5fa",group:"AI & ML"},
    {icon:"🔲",label:"Sliding Window",      view:"sliding",       color:"#818cf8",group:"AI & ML"},
    {icon:"🏆",label:"Multi-Model Consensus",view:"consensus",    color:"#fbbf24",group:"AI & ML"},
    {icon:"🔔",label:"Breakout Alerts",     view:"alerts",        color:"#f87171",group:"AI & ML"},
    {icon:"📊",label:"Performance",         view:"performance",   color:"#67e8f9",group:"AI & ML"},
    {icon:"🔮",label:"Predictions",         view:"predictions",   color:"#c084fc",group:"AI & ML"},
  ];
  const grouped = {
    "বিশ্লেষণ": TOOLS.filter(t=>t.group==="বিশ্লেষণ"),
    "AI & ML":   TOOLS.filter(t=>t.group==="AI & ML"),
  };
  return (
    <div className="space-y-5 mt-6">
      {(Object.entries(grouped) as [string, typeof TOOLS][]).map(([grp, tools])=>(
        <div key={grp}>
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs font-black uppercase tracking-widest text-red-700">{grp==="AI & ML"?"🤖 AI & ML ইঞ্জিন":"📐 "+grp}</span>
            <div className="flex-1 h-px" style={{background:"rgba(220,38,38,0.15)"}}/>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-7 gap-2">
            {tools.map(t=>(
              <button key={t.view} onClick={()=>onView(t.view)}
                className="group flex flex-col items-center gap-2 p-3 rounded-xl transition-all hover:scale-105 active:scale-95"
                style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)"}}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl transition-all group-hover:scale-110"
                  style={{background:`${t.color}18`,border:`1px solid ${t.color}40`}}>
                  {t.icon}
                </div>
                <span className="text-xs text-center leading-tight font-medium" style={{color:"#94a3b8",lineHeight:"1.2"}}>{t.label}</span>
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Admin Picks Box ─────────────────────────────────────────────────────────
type AdminPicks = { date: string; draw: string; label: string; nums: string[] };
const DEFAULT_PICKS: AdminPicks = { date: "", draw: "", label: "আজকের কাঙ্খিত নাম্বার আসতে পারে", nums: ["", "", ""] };
const BOX_STYLES = [
  { bg: "rgba(34,197,94,0.15)",  border: "rgba(34,197,94,0.5)",  glow: "rgba(34,197,94,0.2)",  text: "#4ade80",  label: "সেট #১" },
  { bg: "rgba(16,185,129,0.15)", border: "rgba(16,185,129,0.5)", glow: "rgba(16,185,129,0.2)", text: "#34d399",  label: "সেট #২" },
  { bg: "rgba(239,68,68,0.18)",  border: "rgba(239,68,68,0.5)",  glow: "rgba(239,68,68,0.2)",  text: "#f87171",  label: "সেট #৩" },
];

function AdminPicksBox({ user }: { user: AuthUser }) {
  const isAdmin = user.role === "admin";
  const [picks, setPicks] = useState<AdminPicks>(DEFAULT_PICKS);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<AdminPicks>(DEFAULT_PICKS);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    const d = lsGetPicks();
    if (d) { setPicks(d); setDraft(d); }
  }, []);

  const hasContent = picks.nums.some(n => n.trim().length > 0) || picks.date || picks.draw;

  async function handleSave() {
    setSaving(true);
    try {
      lsSavePicks(draft);
      setPicks({ ...draft });
      setEditing(false);
      setMsg("✅ Saved");
      setTimeout(() => setMsg(""), 2000);
    } catch {
      setMsg("❌ সংরক্ষণ ব্যর্থ হয়েছে");
      setTimeout(() => setMsg(""), 3000);
    } finally { setSaving(false); }
  }

  function setNum(i: number, v: string) {
    const nums = [...draft.nums];
    nums[i] = v.replace(/\D/g, "").slice(0, 4);
    setDraft(d => ({ ...d, nums }));
  }

  return (
    <div className="rounded-2xl overflow-hidden"
      style={{ background: "linear-gradient(135deg,rgba(10,20,10,0.95),rgba(5,15,5,0.98))", border: "1px solid rgba(34,197,94,0.2)", boxShadow: "0 0 24px rgba(34,197,94,0.06)" }}>

      {/* Header row — compact */}
      <div className="flex items-center justify-between px-3 py-2" style={{borderBottom:"1px solid rgba(34,197,94,0.1)"}}>
        <div className="flex items-center gap-1.5 min-w-0 flex-1 overflow-hidden">
          <span className="text-sm flex-shrink-0">🎯</span>
          <span className="text-white font-black text-xs tracking-wide flex-shrink-0">Admin's Pick</span>
          {!editing && picks.date && <span className="text-green-600 text-[10px] font-bold flex-shrink-0">📅 {picks.date}</span>}
          {!editing && picks.label && <span className="text-slate-500 text-[10px] italic truncate">{picks.label}</span>}
        </div>
        <div className="flex items-center gap-1.5">
          {isAdmin && !editing && (
            <button onClick={() => { setDraft({ ...picks }); setEditing(true); }}
              className="flex items-center gap-1 text-[10px] font-bold px-2.5 py-1 rounded-lg transition"
              style={{ background: "rgba(34,197,94,0.12)", color: "#4ade80", border: "1px solid rgba(34,197,94,0.3)" }}>
              ✏️ Edit
            </button>
          )}
          {isAdmin && editing && <>
            <button onClick={() => setEditing(false)}
              className="text-[10px] px-2.5 py-1 rounded-lg font-bold"
              style={{ background: "rgba(100,116,139,0.2)", color: "#94a3b8", border: "1px solid rgba(100,116,139,0.3)" }}>
              বাতিল
            </button>
            <button onClick={handleSave} disabled={saving}
              className="text-[10px] px-3 py-1 rounded-lg font-bold transition"
              style={{ background: "rgba(34,197,94,0.2)", color: "#4ade80", border: "1px solid rgba(34,197,94,0.4)" }}>
              {saving ? "…" : "💾 Save"}
            </button>
          </>}
        </div>
      </div>

      {/* Edit fields */}
      {editing && (
        <div className="px-3 py-2 flex flex-wrap gap-2 items-center" style={{borderBottom:"1px solid rgba(34,197,94,0.08)"}}>
          <div className="flex items-center gap-1">
            <span className="text-green-600 text-[10px] font-bold">📅</span>
            <input type="date" value={draft.date}
              onChange={e => setDraft(d => ({ ...d, date: e.target.value }))}
              className="bg-slate-900 border border-green-900 rounded px-2 py-0.5 text-white text-[10px] focus:outline-none focus:border-green-500"/>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-green-600 text-[10px] font-bold">🎰</span>
            <input type="text" value={draft.draw} placeholder="Magnum, Wed"
              onChange={e => setDraft(d => ({ ...d, draw: e.target.value }))}
              className="bg-slate-900 border border-green-900 rounded px-2 py-0.5 text-white text-[10px] focus:outline-none focus:border-green-500 w-28"/>
          </div>
          <div className="flex items-center gap-1 flex-1 min-w-0">
            <span className="text-green-600 text-[10px] font-bold">📝</span>
            <input type="text" value={draft.label} placeholder="লেবেল"
              onChange={e => setDraft(d => ({ ...d, label: e.target.value }))}
              className="bg-slate-900 border border-green-900 rounded px-2 py-0.5 text-white text-[10px] focus:outline-none focus:border-green-500 flex-1 min-w-0"/>
          </div>
        </div>
      )}

      {/* 3 Number Boxes — compact horizontal */}
      <div className="px-2.5 py-2 flex gap-1.5">
        {BOX_STYLES.map((style, i) => (
          <div key={i} className="flex-1 rounded-xl flex items-center gap-2 px-3 py-2"
            style={{ background: style.bg, border: `1px solid ${style.border}`, boxShadow: `0 0 12px ${style.glow}` }}>
            <div className="text-[9px] font-black uppercase tracking-wider flex-shrink-0" style={{ color: `${style.text}99` }}>{style.label}</div>
            <div className="flex-1 text-center">
              {editing ? (
                <input
                  type="text" inputMode="numeric" maxLength={4}
                  value={draft.nums[i] ?? ""}
                  onChange={e => setNum(i, e.target.value)}
                  placeholder="0000"
                  className="w-full bg-transparent font-mono font-black text-xl tracking-[0.15em] text-center outline-none border-b"
                  style={{ color: style.text, borderColor: style.border, caretColor: style.text }}
                />
              ) : (
                <div className="font-mono font-black text-lg tracking-[0.12em]"
                  style={{ color: style.text, textShadow: `0 0 14px ${style.glow}` }}>
                  {picks.nums[i]?.trim() || <span className="text-slate-700 text-sm">—</span>}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {msg && <div className="px-3 pb-2 text-[10px] font-bold text-center" style={{ color: msg.startsWith("✅") ? "#4ade80" : "#f87171" }}>{msg}</div>}
    </div>
  );
}

function DashboardView({ results,loadingData,onView,user }: { results:LotteryResult[]; loadingData:boolean; onView:(v:View)=>void; user:AuthUser }) {
  const [copied, setCopied] = useState<string|null>(null);
  const [secretNum, setSecretNum] = useState<string>(()=>localStorage.getItem("secret_lucky_num")??"");
  const [secretLocked, setSecretLocked] = useState<boolean>(()=>localStorage.getItem("secret_lucky_locked")==="1");
  const [secretEditing, setSecretEditing] = useState(false);
  const isAdmin = user.role==="admin";
  function handleSecretLock() {
    if(!isAdmin) return;
    const next=!secretLocked;
    setSecretLocked(next);
    localStorage.setItem("secret_lucky_locked", next?"1":"0");
    localStorage.setItem("secret_lucky_num", secretNum);
  }
  function handleSecretChange(v:string){
    setSecretNum(v);
    localStorage.setItem("secret_lucky_num",v);
  }

  const latestByCompany = useMemo(()=>{
    const map: Partial<Record<CompanyId,LotteryResult>> = {};
    for (const id of COMPANY_IDS) map[id]=results.filter(r=>r.company===id).sort((a,b)=>b.date.localeCompare(a.date))[0];
    return map;
  },[results]);

  const top4 = useMemo(()=>{
    const freq: Record<string,number> = {};
    for (const r of results) for (const n of allNums(r))
      if (n && /^\d{4}$/.test(n)) freq[n]=(freq[n]??0)+1;
    return Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([num,count])=>({num,count}));
  },[results]);

  const top2 = useMemo(()=>pairFrequency(results).slice(0,5),[results]);
  const allDigits = useMemo(()=>digitFrequency(results).sort((a,b)=>b.count-a.count),[results]);
  const sortedAsc = useMemo(()=>[...allDigits].sort((a,b)=>a.count-b.count),[allDigits]);

  const totalDraws = useMemo(()=>new Set(results.map(r=>r.date+r.company)).size,[results]);
  const totalNums  = useMemo(()=>results.reduce((s,r)=>s+allNums(r).filter(n=>/^\d{4}$/.test(n)).length,0),[results]);
  const bestDigit  = allDigits[0];
  const bestPair   = top2[0];
  const maxCnt     = allDigits[0]?.count || 1;
  const hasData    = results.length > 0;

  // Advanced digit analytics
  const digitAnalytics = useMemo(()=>{
    if (!hasData) return [];
    const total = allDigits.reduce((s,d)=>s+d.count,0);
    const expected = total / 10;
    return allDigits.map((d,i)=>{
      const rank = i + 1;
      const pct = total > 0 ? Math.round((d.count/total)*1000)/10 : 0;
      const deviation = expected > 0 ? ((d.count - expected)/expected)*100 : 0;
      const isHot = rank <= 3;
      const isCold = rank >= 8;
      const isDrop = rank >= 9;
      const isPattern = Math.abs(deviation) < 8;
      const isRandom = Math.abs(deviation) > 20;
      const popularity = Math.round((d.count / maxCnt) * 100);
      return { ...d, rank, pct, deviation: Math.round(deviation), isHot, isCold, isDrop, isPattern, isRandom, popularity };
    });
  },[allDigits, hasData, maxCnt]);

  const aiSummary = useMemo(()=>{
    if (!hasData || results.length < 10) return null;
    const primaryId = COMPANY_IDS.reduce((best,id)=>
      results.filter(r=>r.company===id).length > results.filter(r=>r.company===best).length ? id : best
    , COMPANY_IDS[0]);
    const fil = results.filter(r=>r.company===primaryId).sort((a,b)=>b.date.localeCompare(a.date));
    if (fil.length < 10) return null;
    function topP(pf: Record<number,Record<string,number>>) {
      return [0,1,2,3].map(p=>Object.entries(pf[p]).sort((a,b)=>Number(b[1])-Number(a[1]))[0]?.[0]??"5").join("");
    }
    const posF30=buildPosFreq(fil.slice(0,30));
    const posF50=buildPosFreq(fil.slice(0,50));
    const posF90=buildPosFreq(fil.slice(0,Math.min(90,fil.length)));
    const pred30=topP(posF30), pred90=topP(posF90);
    const sorted2=[...fil].sort((a,b)=>a.date.localeCompare(b.date));
    const trans:Record<string,Record<string,number>>={};
    for (let i=1;i<sorted2.length;i++){
      const from=sorted2[i-1].first[0]??"0", to=sorted2[i].first[0]??"0";
      if(!trans[from])trans[from]={};
      trans[from][to]=(trans[from][to]??0)+1;
    }
    const lastFirst=fil[0]?.first??"0000";
    const markovFirst=Object.entries(trans[lastFirst[0]??"0"]??{}).sort((a,b)=>b[1]-a[1])[0]?.[0]??"5";
    const markovPred=markovFirst+pred30.slice(1);
    const lstmPred=topP(buildPosFreq(fil.slice(-30)));
    const geneticPred=topP(posF50);
    const hotF:Record<string,number>={};
    for (const r of fil.slice(0,30)) for (const n of prizeNums(r)) for (const c of n.split("")) if(/\d/.test(c)) hotF[c]=(hotF[c]??0)+1;
    const hotDig=Object.entries(hotF).sort((a,b)=>b[1]-a[1])[0]?.[0]??"7";
    const hotFreqPred=pred30.split("").map((d,i)=>i===0?hotDig:d).join("");
    const benfordExp:Record<string,number>={"1":30.1,"2":17.6,"3":12.5,"4":9.7,"5":7.9,"6":6.7,"7":5.8,"8":5.1,"9":4.6,"0":0};
    const benFirst=Object.entries(posF30[0]).sort((a,b)=>(benfordExp[b[0]]??0)-(benfordExp[a[0]]??0))[0]?.[0]??"1";
    const benPred=benFirst+pred30.slice(1);
    const allPreds=[pred30,pred90,markovPred,lstmPred,geneticPred,hotFreqPred,benPred];
    const votes:Record<string,number>={};
    allPreds.forEach(p=>{votes[p]=(votes[p]??0)+1;});
    const sortedVotes=Object.entries(votes).sort((a,b)=>b[1]-a[1]);
    const hitNumber=sortedVotes[0]?.[0]??pred30, hitModels=sortedVotes[0]?.[1]??1;
    const commonEntry=sortedVotes.find(([,c])=>c>=2);
    const commonNumber=commonEntry?.[0]??pred30, commonCount=commonEntry?.[1]??1;
    const skipStats:Array<{digit:string;ratio:number;alert:boolean}>=[];
    for (let d2=0;d2<10;d2++){
      const digit=String(d2), apps:number[]=[];
      for (let i=0;i<fil.length;i++) if(fil[i].first.includes(digit)) apps.push(i);
      if(apps.length<3) continue;
      const gaps:number[]=[]; for(let i=1;i<apps.length;i++) gaps.push(apps[i]-apps[i-1]);
      const avgSkip=gaps.reduce((a,b)=>a+b,0)/gaps.length;
      const currentSkip=(fil.length-1)-apps[apps.length-1];
      skipStats.push({digit,ratio:Math.round((currentSkip/avgSkip)*100)/100,alert:(currentSkip/avgSkip)>=1.5});
    }
    skipStats.sort((a,b)=>b.ratio-a.ratio);
    const overdueDigits=skipStats.filter(s=>s.alert).map(s=>s.digit);
    const hotNumber=skipStats.slice(0,4).map((s,i)=>
      s.alert?s.digit:(Object.entries(posF30[i]).sort((a,b)=>Number(b[1])-Number(a[1]))[0]?.[0]??"5")
    ).join("");
    const maxFit=[0,1,2,3].reduce((s,p)=>s+(Math.max(...Object.values(posF50[p]).map(Number))*10),0);
    const powerFit=geneticPred.split("").reduce((s,c,i)=>s+(posF50[i][c]??0)*10,0);
    const powerScore=maxFit>0?Math.round((powerFit/maxFit)*100):0;
    const allNums4D=fil.slice(0,50).flatMap(r=>prizeNums(r)).filter(n=>/^\d{4}$/.test(n));
    let hlH=0,hlL=0,oeO=0,oeE=0;
    const hlFreq:Record<string,number>={}, oeFreq2:Record<string,number>={};
    for (const n of allNums4D){
      const d=n.split("").map(Number);
      d.forEach(x=>{if(x>=5)hlH++;else hlL++;if(x%2===1)oeO++;else oeE++;});
      const hp=d.map(x=>x>=5?"H":"L").join(""), op=d.map(x=>x%2===0?"E":"O").join("");
      hlFreq[hp]=(hlFreq[hp]??0)+1; oeFreq2[op]=(oeFreq2[op]??0)+1;
    }
    const hlTot=(hlH+hlL)||1, oeTot=(oeO+oeE)||1;
    const highPct=Math.round((hlH/hlTot)*100), oddPct=Math.round((oeO/oeTot)*100);
    const topHLP=Object.entries(hlFreq).sort((a,b)=>b[1]-a[1])[0]?.[0]??"LLLL";
    const topOEP=Object.entries(oeFreq2).sort((a,b)=>b[1]-a[1])[0]?.[0]??"EOEO";
    const nextHL=topHLP.split("").map((hl,p)=>{
      const pd=Object.entries(posF30[p]).sort((a,b)=>Number(b[1])-Number(a[1]));
      return (pd.find(([d])=>hl==="H"?Number(d)>=5:Number(d)<5)?.[0])??(hl==="H"?"7":"2");
    }).join("");
    const highProbNums=sortedVotes.slice(0,3).map(([n,c])=>({num:n,models:c}));
    const fdFreq:Record<string,number>={};
    for (const r of fil) for (const n of prizeNums(r)){const d=n[0];if(d&&d!=="0")fdFreq[d]=(fdFreq[d]??0)+1;}
    const fdTot=Object.values(fdFreq).reduce((a,b)=>a+b,0)||1;
    const benAnomaly=Array.from({length:9},(_,i)=>{
      const digit=String(i+1); return {digit,diff:((fdFreq[digit]??0)/fdTot)*100-(benfordExp[digit]??0)};
    }).filter(d=>d.diff>5).map(d=>d.digit).slice(0,3);
    const outPts=fil.slice(-100).flatMap(r=>prizeNums(r)).filter(n=>/^\d{4}$/.test(n))
      .map(n=>({n,sum:n.split("").map(Number).reduce((a,b)=>a+b,0)}));
    const allSums=outPts.map(p=>p.sum);
    const mean2=allSums.reduce((a,b)=>a+b,0)/(allSums.length||1);
    const std2=Math.sqrt(allSums.reduce((a,b)=>a+(b-mean2)**2,0)/(allSums.length||1));
    const outlierNums=outPts.filter(p=>Math.abs(p.sum-mean2)>2*std2).map(p=>p.n).slice(0,6);
    const coldDigits=sortedAsc.slice(0,3).map(d=>d.digit);

    // ── Special Even / Odd Number Boxes (from topOEP pattern + posF30) ──
    const evenBox=topOEP.split("").map((oe,p)=>{
      const pd=Object.entries(posF30[p]).sort((a,b)=>Number(b[1])-Number(a[1]));
      return (pd.find(([d])=>oe==="E"?Number(d)%2===0:Number(d)%2===1)?.[0])??(oe==="E"?"2":"3");
    }).join("");
    const oddBox=topOEP.split("").map((oe,p)=>{
      const inv=oe==="E"?"O":"E";
      const pd=Object.entries(posF30[p]).sort((a,b)=>Number(b[1])-Number(a[1]));
      return (pd.find(([d])=>inv==="E"?Number(d)%2===0:Number(d)%2===1)?.[0])??(inv==="E"?"2":"3");
    }).join("");

    // ── Top Triplets (3D sequences from last 50 draws) ──
    const tripFreq:Record<string,number>={};
    for (const r of fil.slice(0,50)) for (const n of prizeNums(r)) if(n.length===4){
      const d=n.split("");
      [d[0]+d[1]+d[2],d[1]+d[2]+d[3],d[0]+d[1]+d[3],d[0]+d[2]+d[3]].forEach(t=>tripFreq[t]=(tripFreq[t]??0)+1);
    }
    const topTrips=Object.entries(tripFreq).sort((a,b)=>b[1]-a[1]).slice(0,4).map(([seq,count])=>({seq,count}));

    // ── LSTM prediction (last 30 draws reversed = forward window) ──
    const lstmSeqPred=topP(buildPosFreq([...fil].slice(0,30).reverse()));

    return {
      primaryId, hitNumber, hitModels, totalModels:allPreds.length,
      hotNumber, overdueDigits:overdueDigits.slice(0,4),
      powerfulNumber:geneticPred, powerScore,
      commonNumber, commonCount,
      highPct, lowPct:100-highPct, oddPct, evenPct:100-oddPct,
      topHLP, topOEP, nextHL, highProbNums,
      coldDigits, outlierNums, benAnomaly,
      evenBox, oddBox, topTrips, lstmSeqPred,
    };
  },[results, hasData, sortedAsc]);

  function copyResult(r: LotteryResult, id: string) {
    const text = `${COMPANIES[id as CompanyId]?.name ?? id} | ${r.date} | 1st: ${r.first} | 2nd: ${r.second} | 3rd: ${r.third}${r.special.length?` | Special: ${r.special.join(" ")}`:""}${r.consolation.length?` | Consolation: ${r.consolation.join(" ")}` : ""}`;
    navigator.clipboard.writeText(text).then(()=>{setCopied(id); setTimeout(()=>setCopied(null),2000);});
  }

  if (loadingData) return <div className="flex items-center justify-center h-64" style={{color:"#dc2626"}}>ডেটা লোড হচ্ছে…</div>;

  const rankStyle = (i:number) => {
    if(i===0) return {background:"linear-gradient(135deg,#d97706,#92400e)",border:"1px solid rgba(234,179,8,0.4)"};
    if(i===1) return {background:"linear-gradient(135deg,#475569,#1e293b)",border:"1px solid rgba(148,163,184,0.3)"};
    if(i===2) return {background:"linear-gradient(135deg,#92400e,#78350f)",border:"1px solid rgba(180,83,9,0.3)"};
    return {background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)"};
  };

  return (
    <div className="dashboard-home p-3 max-w-5xl mx-auto space-y-3">

      {/* ══ Top Section (Timer + Date + Mascot + Helpline) ══ */}
      <TopSection user={user} />

      {/* ══ 0. SECRET LUCKY NUMBER BOX ══ */}
      <div className={`rounded-2xl overflow-hidden${secretLocked&&secretNum?" lucky-vibrate":""}`} style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.08)",boxShadow:"0 0 30px rgba(124,58,237,0.08)"}}>
        <div className="flex items-center justify-between px-4 py-2.5" style={{borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
          <div className="flex items-center gap-2">
            <span className="text-base">{secretLocked?"🔒":"🔓"}</span>
            <span className="text-white font-bold text-sm">Your Lucky Number</span>
            <span className="text-zinc-600 text-xs">— শুধু আপনার জন্য</span>
          </div>
          {isAdmin && (
            <div className="flex items-center gap-1.5">
              {!secretEditing && !secretLocked && (
                <button onClick={()=>setSecretEditing(true)} className="text-[10px] font-bold px-2.5 py-1.5 rounded-xl" style={{background:"rgba(59,130,246,0.14)",color:"#60a5fa",border:"1px solid rgba(59,130,246,0.28)"}}>✏️ Edit</button>
              )}
              {secretEditing && (
                <>
                  <button onClick={()=>{setSecretEditing(false);setSecretNum(localStorage.getItem("secret_lucky_num")??"")}} className="text-[10px] font-bold px-2.5 py-1.5 rounded-xl" style={{background:"rgba(100,116,139,0.18)",color:"#94a3b8",border:"1px solid rgba(100,116,139,0.28)"}}>বাতিল</button>
                  <button onClick={()=>{localStorage.setItem("secret_lucky_num",secretNum);setSecretEditing(false)}} className="text-[10px] font-bold px-2.5 py-1.5 rounded-xl" style={{background:"rgba(34,197,94,0.16)",color:"#4ade80",border:"1px solid rgba(34,197,94,0.3)"}}>💾 Save</button>
                </>
              )}
              <button onClick={handleSecretLock} className="text-[10px] font-semibold px-2.5 py-1.5 rounded-xl transition-all active:scale-95" style={secretLocked ? {background:"rgba(34,197,94,0.15)",color:"#4ade80",border:"1px solid rgba(34,197,94,0.3)"} : {background:"rgba(220,38,38,0.15)",color:"#f87171",border:"1px solid rgba(220,38,38,0.3)"}}>{secretLocked ? "🔓 Unlock" : "🔒 Lock"}</button>
            </div>
          )}
        </div>
        <div className="relative px-4 py-4">
          <input
            type="text"
            value={secretNum}
            onChange={e=>handleSecretChange(e.target.value)}
            disabled={secretLocked || !secretEditing}
            placeholder="আপনার lucky number লিখুন…"
            className="w-full bg-transparent font-mono font-black text-3xl tracking-[0.3em] text-center text-white outline-none placeholder:text-zinc-800 placeholder:font-normal placeholder:text-base placeholder:tracking-normal transition-all"
            style={{caretColor:"#dc2626"}}
          />
          {secretLocked && (
            <div
              className="absolute inset-0 rounded-xl flex items-center justify-center"
              style={{backdropFilter:"blur(12px)",WebkitBackdropFilter:"blur(12px)",background:"rgba(10,10,15,0.55)",cursor:isAdmin?"pointer":"default"}}
              onClick={isAdmin ? handleSecretLock : undefined}
              title={isAdmin ? "Unlock করতে ক্লিক করুন" : ""}
            >
              <div className="flex flex-col items-center gap-1 select-none pointer-events-none">
                <span className="text-2xl">🔒</span>
                <span className="text-zinc-500 text-xs">{isAdmin ? "ট্যাপ করে Unlock করুন" : "শুধু Admin Unlock করতে পারবে"}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ══ Admin Picks ══ */}
      <AdminPicksBox user={user} />

      {/* ══ 1. COMPANY RESULT BOXES (TOP — most important) ══ */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <span className="text-yellow-500 text-lg">🏢</span>
          <p className="text-white font-black text-base">সর্বশেষ কোম্পানি রেজাল্ট</p>
          <span className="text-zinc-600 text-xs">— ক্লিক করে copy করুন</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
          {COMPANY_IDS.map(id=>{
            const c=COMPANIES[id]; const r=latestByCompany[id];
            const isCopied = copied===id;
            return (
              <div key={id} className="rounded-2xl p-4 transition-all" style={{background:"rgba(255,255,255,0.03)",border:`2px solid ${c.color}40`,boxShadow:`0 0 20px ${c.color}15`}}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{background:c.color,boxShadow:`0 0 8px ${c.color}`}}/>
                    <span className="font-black text-white text-sm">{c.short}</span>
                    <span className="text-zinc-600 text-xs">{c.name}</span>
                  </div>
                  {r&&(
                    <button onClick={()=>copyResult(r,id)} title="Copy result"
                      className="text-xs px-2 py-1 rounded-lg font-semibold transition"
                      style={{background:isCopied?"rgba(34,197,94,0.2)":"rgba(220,38,38,0.15)",color:isCopied?"#4ade80":"#f87171",border:`1px solid ${isCopied?"rgba(34,197,94,0.3)":"rgba(220,38,38,0.25)"}`}}>
                      {isCopied?"✓ Copied":"📋 Copy"}
                    </button>
                  )}
                </div>
                {r ? (
                  <>
                    <div className="text-zinc-600 text-[10px] mb-2">{r.date} {r.drawNo ? `· Draw ${r.drawNo}` : ""}</div>
                    <div className="grid grid-cols-3 gap-1.5 mb-2">
                      {[["1st",r.first,"#eab308"],["2nd",r.second,"#94a3b8"],["3rd",r.third,"#cd7c2f"]].map(([lbl,num,col])=>(
                        <div key={lbl} className="rounded-xl py-2 text-center" style={{background:`${col}18`,border:`1px solid ${col}35`}}>
                          <div className="font-mono font-black text-lg leading-none" style={{color:col}}>{num}</div>
                          <div className="text-[9px] mt-0.5" style={{color:`${col}90`}}>{lbl}</div>
                        </div>
                      ))}
                    </div>
                    {r.special.length>0&&(
                      <div className="text-[10px] text-zinc-700 truncate">
                        <span className="text-zinc-600">Sp:</span> {r.special.slice(0,5).join(" ")} {r.special.length>5?`+${r.special.length-5}`:""}
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-zinc-700 text-sm py-4 text-center">ডেটা নেই</div>
                )}
                <div className="mt-2 text-zinc-800 text-[10px] text-right">{results.filter(x=>x.company===id).length} draws saved</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ══ 2. SUMMARY STATS ══ */}
      {hasData && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            {label:"মোট ড্র",val:totalDraws,sub:"বিশ্লেষিত",grad:"linear-gradient(135deg,#7c3aed,#4c1d95)"},
            {label:"মোট নাম্বার",val:totalNums.toLocaleString(),sub:"৪-ডিজিট",grad:"linear-gradient(135deg,#dc2626,#7f1d1d)"},
            {label:"সেরা ডিজিট",val:bestDigit?.digit??"—",sub:`${bestDigit?.count??0} বার`,grad:"linear-gradient(135deg,#d97706,#92400e)"},
            {label:"সেরা পেয়ার",val:bestPair?.pair??"—",sub:`${bestPair?.count??0}x সর্বোচ্চ`,grad:"linear-gradient(135deg,#dc2626,#7c3aed)"},
          ].map(({label,val,sub,grad})=>(
            <div key={label} className="rounded-2xl p-4" style={{background:grad,boxShadow:"0 4px 20px rgba(0,0,0,0.4)"}}>
              <p className="text-white/60 text-xs font-medium mb-1">{label}</p>
              <p className="text-white font-black text-3xl leading-none font-mono">{val}</p>
              <p className="text-white/50 text-xs mt-1">{sub}</p>
            </div>
          ))}
        </div>
      )}

      {/* ══ 3. TOP NUMBERS ══ */}
      {hasData && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* 4-digit */}
          <div className="rounded-2xl p-4" style={{background:"rgba(124,58,237,0.1)",border:"1px solid rgba(124,58,237,0.3)"}}>
            <p className="text-violet-300 font-bold text-sm mb-0.5">🔢 Top ৪-ডিজিট সেট</p>
            <p className="text-violet-700 text-xs mb-3">সবচেয়ে বেশিবার আসা</p>
            {top4.length===0?<p className="text-zinc-700 text-xs">ডেটা নেই</p>:(
              <div className="space-y-2">
                {top4.map(({num,count},i)=>(
                  <div key={num} className="flex items-center gap-2 rounded-xl px-3 py-2" style={rankStyle(i)}>
                    <span className="text-white/50 text-xs w-4">#{i+1}</span>
                    <span className="font-mono font-black text-xl text-white tracking-widest flex-1">{num}</span>
                    <span className="text-white/50 text-xs">{count}x</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 2-digit */}
          <div className="rounded-2xl p-4" style={{background:"rgba(220,38,38,0.08)",border:"1px solid rgba(220,38,38,0.25)"}}>
            <p className="text-red-300 font-bold text-sm mb-0.5">🔗 Top ২-ডিজিট সেট</p>
            <p className="text-red-900 text-xs mb-3">৪টি সেরা পেয়ার</p>
            {top2.length===0?<p className="text-zinc-700 text-xs">ডেটা নেই</p>:(
              <div className="space-y-2">
                {top2.slice(0,4).map(({pair,count},i)=>(
                  <div key={pair} className="flex items-center gap-2 rounded-xl px-3 py-2" style={rankStyle(i)}>
                    <span className="text-white/50 text-xs w-4">#{i+1}</span>
                    <span className="font-mono font-black text-2xl text-white tracking-widest flex-1">{pair}</span>
                    <span className="text-white/50 text-xs">{count}x</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 1-digit */}
          <div className="rounded-2xl p-4" style={{background:"rgba(234,179,8,0.08)",border:"1px solid rgba(234,179,8,0.2)"}}>
            <p className="text-yellow-400 font-bold text-sm mb-0.5">🎯 Top ১-ডিজিট সেট</p>
            <p className="text-yellow-900 text-xs mb-3">৪টি সেরা ডিজিট</p>
            {allDigits.length===0?<p className="text-zinc-700 text-xs">ডেটা নেই</p>:(
              <div className="space-y-2">
                {allDigits.slice(0,4).map(({digit,count},i)=>(
                  <div key={digit} className="flex items-center gap-2 rounded-xl px-3 py-2" style={rankStyle(i)}>
                    <span className="text-white/50 text-xs w-4">#{i+1}</span>
                    <span className="font-mono font-black text-2xl text-white w-6 text-center">{digit}</span>
                    <span className="text-white/50 text-xs flex-1">{count}x</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ══ 4. ADVANCED DIGIT ANALYTICS ══ */}
      {hasData && (
        <div className="rounded-2xl p-5" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.06)"}}>
          <p className="text-white font-black text-base mb-0.5">📊 গভীর ডিজিট বিশ্লেষণ (০–৯)</p>
          <p className="text-zinc-700 text-xs mb-4">প্রতিটি ডিজিটের Hot/Cold/Drop/Pattern স্ট্যাটাস</p>
          <div className="space-y-2">
            {digitAnalytics.map(d=>{
              const tags: {label:string;color:string;bg:string}[] = [];
              if(d.isHot)     tags.push({label:"🔥 Hot",color:"#f97316",bg:"rgba(249,115,22,0.15)"});
              if(d.isCold)    tags.push({label:"❄️ Cold",color:"#60a5fa",bg:"rgba(96,165,250,0.12)"});
              if(d.isDrop)    tags.push({label:"⛔ Drop",color:"#f87171",bg:"rgba(248,113,113,0.12)"});
              if(d.isPattern) tags.push({label:"📐 Pattern",color:"#a78bfa",bg:"rgba(167,139,250,0.12)"});
              if(d.isRandom)  tags.push({label:"🎲 Random",color:"#6b7280",bg:"rgba(107,114,128,0.12)"});
              const barColor = d.isHot?"#dc2626":d.isCold?"#3b82f6":"#7c3aed";
              return (
                <div key={d.digit} className="flex items-center gap-3 rounded-xl px-3 py-2.5 transition" style={{background:"rgba(255,255,255,0.02)"}}>
                  <div className="w-8 h-8 rounded-full flex items-center justify-center font-black text-lg flex-shrink-0 text-white"
                    style={{background:d.isHot?"linear-gradient(135deg,#dc2626,#991b1b)":d.isCold?"linear-gradient(135deg,#1d4ed8,#1e3a8a)":"rgba(255,255,255,0.08)"}}>{d.digit}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1 mb-1">
                      {tags.map(t=>(
                        <span key={t.label} className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md" style={{color:t.color,background:t.bg}}>{t.label}</span>
                      ))}
                    </div>
                    <div className="h-2 rounded-full overflow-hidden" style={{background:"rgba(255,255,255,0.05)"}}>
                      <div className="h-full rounded-full transition-all" style={{width:`${d.popularity}%`,background:barColor}}/>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="text-white font-mono font-black text-sm">{d.count}x</div>
                    <div className="text-zinc-700 text-[10px]">{d.pct}%</div>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-3 pt-3 flex flex-wrap gap-3 text-xs" style={{borderTop:"1px solid rgba(255,255,255,0.05)"}}>
            <span className="text-zinc-700">🔥 Hot = শীর্ষ ৩ (বেশি আসে)</span>
            <span className="text-zinc-700">❄️ Cold = নিচের ৩ (কম আসে)</span>
            <span className="text-zinc-700">⛔ Drop = বাতিল হওয়ার সম্ভাবনা</span>
            <span className="text-zinc-700">📐 Pattern = নির্দিষ্ট pattern ধরে আছে</span>
            <span className="text-zinc-700">🎲 Random = এলোমেলো</span>
          </div>
        </div>
      )}

      {/* ══ 5. AI & ML INTELLIGENCE SUMMARY ══ */}
      {hasData && aiSummary && (
        <div className="space-y-4">
          {/* Header */}
          <div className="flex items-center gap-3 pt-2">
            <span className="text-2xl">🤖</span>
            <div className="flex-1">
              <p className="text-white font-black text-base">AI & ML ইন্টেলিজেন্স সামারি</p>
              <p className="text-zinc-600 text-xs">সব AI মডেলের বিশ্লেষণ থেকে Quick Summary — {COMPANIES[aiSummary.primaryId as CompanyId]?.name ?? aiSummary.primaryId} ডেটা ভিত্তিক</p>
            </div>
            <span className="text-[10px] font-semibold px-2.5 py-1 rounded-full" style={{background:"rgba(124,58,237,0.15)",color:"#a78bfa",border:"1px solid rgba(124,58,237,0.3)"}}>LIVE</span>
          </div>

          {/* Row 1: Hit / Hot / Powerful / Common */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {([
              {label:"🎯 HIT NUMBER",   sub:"Multi-Model Consensus", num:aiSummary.hitNumber,      info:`${aiSummary.hitModels}/${aiSummary.totalModels} মডেলে মিল`, color:"#ef4444", bg:"rgba(220,38,38,0.10)",  border:"rgba(220,38,38,0.35)"},
              {label:"🔥 HOT NUMBER",   sub:"Skip-Draw Overdue",     num:aiSummary.hotNumber,      info:`${aiSummary.overdueDigits.length} overdue digit`,         color:"#f97316", bg:"rgba(249,115,22,0.10)", border:"rgba(249,115,22,0.35)"},
              {label:"⚡ POWERFUL",     sub:"Genetic Algorithm",     num:aiSummary.powerfulNumber, info:`Fitness: ${aiSummary.powerScore}%`,                        color:"#a78bfa", bg:"rgba(124,58,237,0.10)", border:"rgba(124,58,237,0.35)"},
              {label:"🔗 COMMON",       sub:"Cross-Model Agreement", num:aiSummary.commonNumber,   info:`${aiSummary.commonCount} মডেলে একমত`,                     color:"#eab308", bg:"rgba(234,179,8,0.10)",  border:"rgba(234,179,8,0.30)"},
            ] as const).map(({label,sub,num,info,color,bg,border})=>(
              <div key={label} className="rounded-2xl p-4 text-center" style={{background:bg,border:`1px solid ${border}`}}>
                <div className="text-[11px] font-bold mb-0.5 tracking-wide" style={{color}}>{label}</div>
                <div className="text-zinc-600 text-[10px] mb-2">{sub}</div>
                <div className="font-mono font-black text-4xl tracking-widest leading-none mb-2" style={{color}}>{num}</div>
                <div className="text-zinc-500 text-[10px]">{info}</div>
                {label==="⚡ POWERFUL"&&(
                  <div className="mt-2 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{width:`${aiSummary.powerScore}%`,background:color}}/>
                  </div>
                )}
                {label==="🔥 HOT NUMBER"&&aiSummary.overdueDigits.length>0&&(
                  <div className="flex justify-center gap-1 mt-1.5">
                    {aiSummary.overdueDigits.map(d=>(
                      <span key={d} className="text-[10px] rounded px-1.5 py-0.5" style={{background:"rgba(249,115,22,0.2)",color:"#fdba74",border:"1px solid rgba(249,115,22,0.3)"}}>{d}</span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Row 2: High/Low & Odd/Even progress bars */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="rounded-2xl p-4" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.07)"}}>
              <div className="flex items-center justify-between mb-3">
                <p className="text-white font-bold text-sm">🌗 High / Low বিশ্লেষণ</p>
                <span className="text-[10px] text-zinc-600 bg-slate-800/60 px-2 py-0.5 rounded-full">H/L Matrix</span>
              </div>
              <div className="flex gap-4 mb-2">
                <div className="flex-1"><p className="text-[10px] text-slate-500 mb-0.5">High (5–9)</p><p className="font-black text-2xl text-red-400">{aiSummary.highPct}%</p></div>
                <div className="flex-1"><p className="text-[10px] text-slate-500 mb-0.5">Low (0–4)</p><p className="font-black text-2xl text-blue-400">{aiSummary.lowPct}%</p></div>
              </div>
              <div className="flex h-3.5 rounded-full overflow-hidden mb-2">
                <div className="bg-red-500" style={{width:`${aiSummary.highPct}%`}}/>
                <div className="bg-blue-500 flex-1"/>
              </div>
              <div className="flex justify-between text-[10px] text-zinc-600">
                <span>শীর্ষ Pattern: <span className="font-mono text-white">{aiSummary.topHLP}</span></span>
                <span>পরবর্তী সংখ্যা: <span className="font-mono text-green-400">{aiSummary.nextHL}</span></span>
              </div>
            </div>
            <div className="rounded-2xl p-4" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.07)"}}>
              <div className="flex items-center justify-between mb-3">
                <p className="text-white font-bold text-sm">🔢 Odd / Even বিশ্লেষণ</p>
                <span className="text-[10px] text-zinc-600 bg-slate-800/60 px-2 py-0.5 rounded-full">O/E Matrix</span>
              </div>
              <div className="flex gap-4 mb-2">
                <div className="flex-1"><p className="text-[10px] text-slate-500 mb-0.5">Odd (বিজোড়)</p><p className="font-black text-2xl text-purple-400">{aiSummary.oddPct}%</p></div>
                <div className="flex-1"><p className="text-[10px] text-slate-500 mb-0.5">Even (জোড়)</p><p className="font-black text-2xl text-green-400">{aiSummary.evenPct}%</p></div>
              </div>
              <div className="flex h-3.5 rounded-full overflow-hidden mb-2">
                <div className="bg-purple-500" style={{width:`${aiSummary.oddPct}%`}}/>
                <div className="bg-green-500 flex-1"/>
              </div>
              <div className="flex justify-between text-[10px] text-zinc-600">
                <span>শীর্ষ Pattern: <span className="font-mono text-white">{aiSummary.topOEP}</span></span>
                <span>Pattern ভিত্তিক সাজেশন চালু</span>
              </div>
            </div>
          </div>

          {/* Row 2b: Special Even/Odd Number Boxes */}
          <div className="rounded-2xl p-4" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.07)"}}>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-base">✨</span>
              <p className="text-white font-bold text-sm">বিশেষ জোড়/বিজোড় নাম্বার সেট</p>
              <span className="text-zinc-600 text-xs">— 3D Triplet + Odd/Even Pattern থেকে গণনা করা</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl p-4 text-center" style={{background:"linear-gradient(135deg,rgba(34,197,94,0.15),rgba(16,185,129,0.05))",border:"1px solid rgba(34,197,94,0.35)"}}>
                <div className="text-[10px] font-bold text-green-400 tracking-widest mb-1">🟢 EVEN SET (জোড়)</div>
                <div className="text-[10px] text-zinc-600 mb-2">Pattern: <span className="font-mono text-zinc-400">{aiSummary.topOEP}</span></div>
                <div className="font-mono font-black text-4xl text-green-300 tracking-[0.2em] leading-none">{aiSummary.evenBox}</div>
                <div className="text-green-700 text-[10px] mt-2">জোড় ডিজিট সর্বোচ্চ সম্ভাবনা</div>
              </div>
              <div className="rounded-xl p-4 text-center" style={{background:"linear-gradient(135deg,rgba(168,85,247,0.15),rgba(124,58,237,0.05))",border:"1px solid rgba(168,85,247,0.35)"}}>
                <div className="text-[10px] font-bold text-purple-400 tracking-widest mb-1">🟣 ODD SET (বিজোড়)</div>
                <div className="text-[10px] text-zinc-600 mb-2">Inverted Pattern</div>
                <div className="font-mono font-black text-4xl text-purple-300 tracking-[0.2em] leading-none">{aiSummary.oddBox}</div>
                <div className="text-purple-700 text-[10px] mt-2">বিজোড় ডিজিট সর্বোচ্চ সম্ভাবনা</div>
              </div>
            </div>
          </div>

          {/* Row 2c: Top 3D Triplets + LSTM */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="rounded-2xl p-4" style={{background:"rgba(234,179,8,0.06)",border:"1px solid rgba(234,179,8,0.22)"}}>
              <p className="text-yellow-400 font-bold text-sm mb-0.5">🔷 শীর্ষ ৩D ট্রিপলেট সিকোয়েন্স</p>
              <p className="text-zinc-700 text-[10px] mb-3">সাম্প্রতিক ৫০ ড্র থেকে সবচেয়ে বেশিবার আসা ৩-ডিজিট সিকোয়েন্স</p>
              <div className="grid grid-cols-2 gap-2">
                {aiSummary.topTrips.map(({seq,count},i)=>(
                  <div key={seq} className="rounded-xl px-3 py-2 flex items-center gap-2" style={{background:i===0?"rgba(234,179,8,0.15)":"rgba(255,255,255,0.03)",border:i===0?"1px solid rgba(234,179,8,0.35)":"1px solid rgba(255,255,255,0.06)"}}>
                    <span className="text-zinc-600 text-xs">#{i+1}</span>
                    <span className="font-mono font-black text-xl text-white tracking-widest flex-1">{seq}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-md" style={{background:"rgba(234,179,8,0.12)",color:"#fbbf24"}}>{count}x</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-2xl p-4" style={{background:"rgba(59,130,246,0.06)",border:"1px solid rgba(59,130,246,0.22)"}}>
              <p className="text-blue-400 font-bold text-sm mb-0.5">🧬 LSTM Sequence পূর্বাভাস</p>
              <p className="text-zinc-700 text-[10px] mb-3">সাম্প্রতিক ৩০ ড্রের Sequential analysis</p>
              <div className="flex items-center gap-4">
                <div className="rounded-2xl px-5 py-3 text-center" style={{background:"linear-gradient(135deg,rgba(59,130,246,0.25),rgba(37,99,235,0.1))",border:"1px solid rgba(59,130,246,0.4)"}}>
                  <div className="font-mono font-black text-4xl text-blue-200 tracking-[0.15em] leading-none">{aiSummary.lstmSeqPred}</div>
                  <div className="text-blue-600 text-[10px] mt-1.5">LSTM পূর্বাভাস</div>
                </div>
                <div className="flex-1 space-y-1.5">
                  <div className="text-[10px] text-zinc-600">Genetic: <span className="font-mono text-purple-300 font-bold">{aiSummary.powerfulNumber}</span></div>
                  <div className="text-[10px] text-zinc-600">Markov: <span className="font-mono text-orange-300 font-bold">{aiSummary.hotNumber}</span></div>
                  <div className="text-[10px] text-zinc-600">Consensus: <span className="font-mono text-yellow-300 font-bold">{aiSummary.hitNumber}</span></div>
                  <div className="text-[10px] text-zinc-600">Common: <span className="font-mono text-green-300 font-bold">{aiSummary.commonNumber}</span></div>
                </div>
              </div>
            </div>
          </div>

          {/* Row 3: High Probability | Low Probability */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="rounded-2xl p-4" style={{background:"rgba(34,197,94,0.05)",border:"1px solid rgba(34,197,94,0.22)"}}>
              <p className="text-green-400 font-bold text-sm mb-0.5">📈 পরবর্তী আসার সম্ভাবনা বেশি</p>
              <p className="text-zinc-700 text-[10px] mb-3">Consensus + Performance র্যাঙ্কিং</p>
              <div className="space-y-2">
                {aiSummary.highProbNums.map(({num,models},i)=>(
                  <div key={num} className="flex items-center gap-3 rounded-xl px-3 py-2" style={rankStyle(i)}>
                    <span className="text-white/40 text-xs w-4">#{i+1}</span>
                    <span className="font-mono font-black text-xl text-white tracking-widest flex-1">{num}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full" style={{background:"rgba(34,197,94,0.15)",color:"#4ade80",border:"1px solid rgba(34,197,94,0.3)"}}>{models} মডেল</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-2xl p-4" style={{background:"rgba(96,165,250,0.04)",border:"1px solid rgba(96,165,250,0.18)"}}>
              <p className="text-blue-400 font-bold text-sm mb-0.5">📉 পরবর্তী না আসার সম্ভাবনা</p>
              <p className="text-zinc-700 text-[10px] mb-3">Benford + Outlier + Cold Digits</p>
              <div className="space-y-3">
                {aiSummary.coldDigits.length>0&&(
                  <div>
                    <p className="text-[10px] text-zinc-600 mb-1.5">❄️ Cold Digits (কম আসে)</p>
                    <div className="flex gap-1.5">
                      {aiSummary.coldDigits.map(d=>(
                        <span key={d} className="w-9 h-9 rounded-xl flex items-center justify-center font-mono font-black text-lg" style={{background:"rgba(96,165,250,0.12)",color:"#93c5fd",border:"1px solid rgba(96,165,250,0.3)"}}>{d}</span>
                      ))}
                    </div>
                  </div>
                )}
                {aiSummary.benAnomaly.length>0&&(
                  <div>
                    <p className="text-[10px] text-zinc-600 mb-1.5">📊 Benford Anomaly (অতিরিক্ত আসা)</p>
                    <div className="flex gap-1.5 flex-wrap">
                      {aiSummary.benAnomaly.map(d=>(
                        <span key={d} className="px-2.5 py-1 rounded-lg font-mono text-sm font-bold" style={{background:"rgba(234,179,8,0.12)",color:"#fbbf24",border:"1px solid rgba(234,179,8,0.3)"}}>1st: {d}</span>
                      ))}
                    </div>
                  </div>
                )}
                {aiSummary.outlierNums.length>0&&(
                  <div>
                    <p className="text-[10px] text-zinc-600 mb-1.5">⚠️ Outliers (2σ+ বিচ্যুতি)</p>
                    <div className="flex flex-wrap gap-1.5">
                      {aiSummary.outlierNums.map(n=>(
                        <span key={n} className="font-mono text-xs rounded-lg px-2 py-0.5" style={{background:"rgba(248,113,113,0.1)",color:"#f87171",border:"1px solid rgba(248,113,113,0.25)"}}>{n}</span>
                      ))}
                    </div>
                  </div>
                )}
                {aiSummary.coldDigits.length===0&&aiSummary.benAnomaly.length===0&&aiSummary.outlierNums.length===0&&(
                  <p className="text-zinc-600 text-xs py-2">যথেষ্ট ডেটা জমা হলে anomaly দেখাবে</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {!hasData && (
        <div className="text-center py-16">
          <p className="text-5xl mb-3">📊</p>
          <p className="text-base font-bold text-white">এখনো কোনো ডেটা নেই</p>
          <p className="text-zinc-600 text-sm mt-1">Admin ড্র যোগ করলে এখানে দেখা যাবে</p>
        </div>
      )}

      {/* ── Quick Access: All Analysis & AI Tools ─────────────────────── */}
      <div className="mt-4 px-4 pb-6">
        <div className="rounded-2xl p-5" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(220,38,38,0.15)"}}>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-white font-black text-base">⚡ Quick Access</span>
            <span className="text-xs text-slate-600 ml-1">— সব টুল এক জায়গায়</span>
          </div>
          <ToolGrid onView={onView}/>
        </div>
      </div>
    </div>
  );
}

// ─── Company View ─────────────────────────────────────────────────────────────
function CompanyView({ companyId,results,loadingData,isAdmin,onAddResult,onUpdateResult,onResetDone }: {
  companyId:CompanyId; results:LotteryResult[]; loadingData:boolean;
  isAdmin:boolean; onAddResult:(r:any)=>Promise<void>; onUpdateResult?:(id:number,r:any)=>Promise<void>; onResetDone?:()=>void;
}) {
  const c=COMPANIES[companyId];
  const [showAdd,setShowAdd]=useState(false);
  const [form,setForm]=useState({date:"",drawNo:"",first:"",second:"",third:"",special:"",consolation:""});
  const [saving,setSaving]=useState(false); const [addErr,setAddErr]=useState("");

  // ── Edit modal state ──
  const [editRow,setEditRow]=useState<LotteryResult|null>(null);
  const [editForm,setEditForm]=useState({date:"",drawNo:"",first:"",second:"",third:"",special:"",consolation:""});
  const [editSaving,setEditSaving]=useState(false);
  const [editErr,setEditErr]=useState("");

  function openEdit(r:LotteryResult){
    setEditRow(r);
    setEditForm({date:r.date,drawNo:r.drawNo??"",first:r.first,second:r.second,third:r.third,
      special:r.special.join(" "),consolation:r.consolation.join(" ")});
    setEditErr("");
  }
  function closeEdit(){ setEditRow(null); setEditErr(""); }

  async function handleEditSave(e:React.FormEvent){
    e.preventDefault();
    if(!editRow||!onUpdateResult) return;
    setEditSaving(true); setEditErr("");
    try{
      await onUpdateResult(editRow.id,{
        date:editForm.date, drawNo:editForm.drawNo||null,
        first:editForm.first, second:editForm.second, third:editForm.third,
        special:editForm.special.split(/[\s,]+/).filter(Boolean),
        consolation:editForm.consolation.split(/[\s,]+/).filter(Boolean),
      });
      closeEdit();
    }catch(err:any){ setEditErr(err.message||"সংরক্ষণ ব্যর্থ হয়েছে"); }
    finally{ setEditSaving(false); }
  }

  // ── Reset modal state ──
  const [showReset,setShowReset]=useState(false);
  const [resetStep,setResetStep]=useState<1|2>(1); // step1=confirm, step2=password
  const [resetPw,setResetPw]=useState("");
  const [resetting,setResetting]=useState(false);
  const [resetErr,setResetErr]=useState("");
  const [resetDone,setResetDone]=useState(false);

  function openReset(){ setShowReset(true); setResetStep(1); setResetPw(""); setResetErr(""); setResetDone(false); }
  function closeReset(){ setShowReset(false); setResetPw(""); setResetErr(""); }

  async function handleReset(){
    if(!resetPw.trim()){setResetErr("পাসওয়ার্ড দিন"); return;}
    if(!(await verifyAdminPassword(resetPw))){setResetErr("ভুল Admin পাসওয়ার্ড"); return;}
    setResetting(true); setResetErr("");
    try{
      setResetDone(true);
      localAudit("company_reset", `${COMPANIES[companyId].name} data reset`);
      setTimeout(()=>{ closeReset(); onResetDone?.(); },1200);
    }catch(e:any){ setResetErr(e.message||"রিসেট ব্যর্থ হয়েছে"); }
    finally{setResetting(false);}
  }

  const companyResults=useMemo(()=>results.filter(r=>r.company===companyId).sort((a,b)=>b.date.localeCompare(a.date)),[results,companyId]);
  const latest=companyResults[0];

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault(); setSaving(true); setAddErr("");
    try {
      await onAddResult({company:companyId,date:form.date,drawNo:form.drawNo||null,first:form.first,second:form.second,third:form.third,
        special:form.special.split(/[\s,]+/).filter(Boolean),consolation:form.consolation.split(/[\s,]+/).filter(Boolean)});
      setForm({date:"",drawNo:"",first:"",second:"",third:"",special:"",consolation:""}); setShowAdd(false);
    } catch(err:any){setAddErr(err.message);}
    finally{setSaving(false);}
  }

  if(loadingData) return <div className="flex items-center justify-center h-64 text-slate-400">Loading…</div>;

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">

      {/* ── Reset Confirmation Modal ── */}
      {showReset&&(
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{background:"rgba(0,0,0,0.75)"}}>
          <div className="w-full max-w-sm rounded-2xl p-6 space-y-4" style={{background:"#111",border:"1px solid rgba(220,38,38,0.4)"}}>
            {resetDone ? (
              <div className="text-center py-4 space-y-2">
                <div className="text-4xl">✅</div>
                <div className="text-green-400 font-bold">সফলভাবে ডিলিট হয়েছে!</div>
                <div className="text-zinc-500 text-sm">{c.name}-এর সব ডেটা মুছে গেছে।</div>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{background:"rgba(220,38,38,0.15)",border:"1px solid rgba(220,38,38,0.3)"}}>
                    <span className="text-xl">🗑️</span>
                  </div>
                  <div>
                    <h3 className="text-white font-black text-sm">{c.name} ডেটা রিসেট</h3>
                    <p className="text-zinc-600 text-xs">এই কোম্পানির সব ড্র ডিলিট হবে</p>
                  </div>
                </div>

                {resetStep===1&&(
                  <div className="space-y-3">
                    <div className="rounded-xl p-3 text-xs space-y-1" style={{background:"rgba(220,38,38,0.08)",border:"1px solid rgba(220,38,38,0.2)"}}>
                      <p className="text-red-400 font-bold">⚠️ সতর্কতা</p>
                      <p className="text-zinc-500">{c.name}-এর <span className="text-white font-bold">{companyResults.length}টি ড্র</span> স্থায়ীভাবে মুছে যাবে। এই কাজ পূর্বাবস্থায় ফেরানো যাবে না।</p>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={closeReset} className="flex-1 rounded-lg py-2.5 text-sm font-semibold text-zinc-400 transition" style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.08)"}}>বাতিল করুন</button>
                      <button onClick={()=>setResetStep(2)} className="flex-1 rounded-lg py-2.5 text-sm font-bold text-white transition" style={{background:"rgba(220,38,38,0.25)",border:"1px solid rgba(220,38,38,0.4)"}}>হ্যাঁ, নিশ্চিত →</button>
                    </div>
                  </div>
                )}

                {resetStep===2&&(
                  <div className="space-y-3">
                    <div>
                      <label className="block text-zinc-500 text-xs mb-1.5">🔒 আপনার Admin পাসওয়ার্ড দিন</label>
                      <input
                        type="password" value={resetPw} onChange={e=>setResetPw(e.target.value)}
                        onKeyDown={e=>e.key==="Enter"&&handleReset()}
                        placeholder="পাসওয়ার্ড লিখুন…"
                        className="w-full rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none"
                        style={{background:"rgba(255,255,255,0.05)",border:`1px solid ${resetErr?"rgba(220,38,38,0.5)":"rgba(255,255,255,0.1)"}`}}
                        autoFocus
                      />
                      {resetErr&&<p className="text-red-400 text-xs mt-1.5">❌ {resetErr}</p>}
                    </div>
                    <div className="flex gap-2">
                      <button onClick={closeReset} className="flex-1 rounded-lg py-2.5 text-sm font-semibold text-zinc-400 transition" style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.08)"}}>বাতিল</button>
                      <button onClick={handleReset} disabled={resetting} className="flex-1 rounded-lg py-2.5 text-sm font-black text-white transition disabled:opacity-50" style={{background:"linear-gradient(135deg,#dc2626,#991b1b)",border:"1px solid rgba(220,38,38,0.5)"}}>
                        {resetting?"মুছছে…":"🗑️ ডিলিট করুন"}
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}

      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <span className="w-4 h-4 rounded-full" style={{background:c.color}}/>
          <h1 className="text-2xl font-bold text-white">{c.name}</h1>
          <span className="text-slate-500 text-sm">({companyResults.length} draws)</span>
        </div>
        <div className="flex items-center gap-2">
          {<button onClick={()=>setShowAdd(!showAdd)} className="bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-lg transition">{showAdd?"Cancel":"+ Add Result"}</button>}
          {isAdmin&&<button onClick={openReset} className="text-sm font-medium px-3 py-2 rounded-lg transition" style={{background:"rgba(220,38,38,0.12)",border:"1px solid rgba(220,38,38,0.3)",color:"#f87171"}} title="কোম্পানির সব ডেটা রিসেট করুন">🗑️ Reset</button>}
        </div>
      </div>

      {showAdd&&(
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
          <h2 className="text-white font-semibold mb-4">Add Draw Result</h2>
          {addErr&&<div className="mb-3 p-2 bg-red-900/30 border border-red-700 rounded text-red-300 text-sm">{addErr}</div>}
          <form onSubmit={handleAdd} className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {([["date","Date","2025-01-01"],["drawNo","Draw No.","Optional"],["first","1st Prize","0000"],["second","2nd Prize","0000"],["third","3rd Prize","0000"]] as const).map(([k,l,ph])=>(
              <div key={k}>
                <label className="block text-slate-400 text-xs mb-1">{l}</label>
                <input type={k==="date"?"date":"text"} value={(form as any)[k]} onChange={e=>setForm(f=>({...f,[k]:e.target.value}))}
                  className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
                  placeholder={ph} required={k!=="drawNo"}/>
              </div>
            ))}
            {([["special","Special (10 numbers, space separated)"],["consolation","Consolation (10 numbers)"]] as const).map(([k,l])=>(
              <div key={k} className="col-span-2 sm:col-span-3">
                <label className="block text-slate-400 text-xs mb-1">{l}</label>
                <input value={(form as any)[k]} onChange={e=>setForm(f=>({...f,[k]:e.target.value}))}
                  className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" placeholder="1234 5678 9012 …"/>
              </div>
            ))}
            <div className="col-span-2 sm:col-span-3">
              <button type="submit" disabled={saving} className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-medium text-sm px-6 py-2 rounded-lg transition">{saving?"Saving…":"Save Draw"}</button>
            </div>
          </form>
        </div>
      )}

      {latest&&(
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-6" style={{borderTop:`3px solid ${c.color}`}}>
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-white font-semibold">Latest Draw</h2>
            <span className="text-slate-400 text-sm bg-slate-700 px-3 py-1 rounded-full">{latest.date}</span>
          </div>
          <div className="flex justify-around mb-5">
            <PrizeBadge label="1st Prize" number={latest.first} size="lg"/>
            <PrizeBadge label="2nd Prize" number={latest.second} size="lg"/>
            <PrizeBadge label="3rd Prize" number={latest.third} size="lg"/>
          </div>
          {latest.special.length>0&&<>
            <p className="text-slate-500 text-xs uppercase tracking-wide font-medium mb-2">Special</p>
            <div className="flex flex-wrap gap-2 mb-3">{latest.special.map((n,i)=><span key={i} className="font-mono text-sm bg-slate-700 text-slate-200 px-2.5 py-1 rounded border border-slate-600">{n}</span>)}</div>
            <p className="text-slate-500 text-xs uppercase tracking-wide font-medium mb-2">Consolation</p>
            <div className="flex flex-wrap gap-2">{latest.consolation.map((n,i)=><span key={i} className="font-mono text-sm bg-slate-700 text-slate-300 px-2.5 py-1 rounded border border-slate-600">{n}</span>)}</div>
          </>}
        </div>
      )}

      <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
        <h2 className="text-white font-semibold mb-4">Digit Frequency</h2>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={digitFrequency(results,companyId)}>
            <XAxis dataKey="digit" tick={{fill:"#94a3b8",fontSize:12}} axisLine={false} tickLine={false}/>
            <YAxis tick={{fill:"#94a3b8",fontSize:11}} axisLine={false} tickLine={false}/>
            <Tooltip contentStyle={{background:"#1e293b",border:"1px solid #334155",borderRadius:8,color:"#fff"}}/>
            <Bar dataKey="count" fill={c.color} radius={[4,4,0,0]}/>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* ── Edit Modal ── */}
      {editRow&&(
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{background:"rgba(0,0,0,0.8)"}}>
          <div className="w-full max-w-md rounded-2xl overflow-hidden" style={{background:"#111",border:"1px solid rgba(99,102,241,0.4)"}}>
            <div className="px-5 py-4 flex items-center justify-between" style={{background:"rgba(99,102,241,0.1)",borderBottom:"1px solid rgba(99,102,241,0.2)"}}>
              <div>
                <div className="text-white font-black text-sm">✏️ Draw সম্পাদনা করুন</div>
                <div className="text-zinc-600 text-xs mt-0.5">{c.name} · ID #{editRow.id}</div>
              </div>
              <button onClick={closeEdit} className="text-zinc-500 hover:text-white transition text-xl font-bold">✕</button>
            </div>
            <form onSubmit={handleEditSave} className="p-5 space-y-3">
              {editErr&&<div className="p-2 rounded-lg text-red-300 text-xs" style={{background:"rgba(220,38,38,0.15)",border:"1px solid rgba(220,38,38,0.3)"}}>❌ {editErr}</div>}
              <div className="grid grid-cols-2 gap-3">
                {([["date","তারিখ","date"],["drawNo","Draw No. (optional)","text"]] as const).map(([k,l,t])=>(
                  <div key={k} className={k==="date"?"":""}>
                    <label className="block text-zinc-500 text-xs mb-1">{l}</label>
                    <input type={t} value={(editForm as any)[k]} onChange={e=>setEditForm(f=>({...f,[k]:e.target.value}))}
                      required={k==="date"}
                      className="w-full rounded-lg px-3 py-2 text-white text-sm focus:outline-none"
                      style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.1)"}}/>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-3 gap-3">
                {([["first","🥇 ১ম পুরস্কার"],["second","🥈 ২য় পুরস্কার"],["third","🥉 ৩য় পুরস্কার"]] as const).map(([k,l])=>(
                  <div key={k}>
                    <label className="block text-zinc-500 text-xs mb-1">{l}</label>
                    <input value={(editForm as any)[k]} onChange={e=>setEditForm(f=>({...f,[k]:e.target.value}))}
                      required maxLength={4} placeholder="0000"
                      className="w-full rounded-lg px-3 py-2 text-white font-mono font-black text-center text-base focus:outline-none"
                      style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.1)"}}/>
                  </div>
                ))}
              </div>
              <div>
                <label className="block text-zinc-500 text-xs mb-1">Special (space দিয়ে আলাদা করুন)</label>
                <input value={editForm.special} onChange={e=>setEditForm(f=>({...f,special:e.target.value}))}
                  placeholder="1234 5678 9012 …"
                  className="w-full rounded-lg px-3 py-2 text-white text-sm focus:outline-none"
                  style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.1)"}}/>
              </div>
              <div>
                <label className="block text-zinc-500 text-xs mb-1">Consolation (space দিয়ে আলাদা করুন)</label>
                <input value={editForm.consolation} onChange={e=>setEditForm(f=>({...f,consolation:e.target.value}))}
                  placeholder="1234 5678 9012 …"
                  className="w-full rounded-lg px-3 py-2 text-white text-sm focus:outline-none"
                  style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.1)"}}/>
              </div>
              <div className="flex gap-2 pt-1">
                <button type="button" onClick={closeEdit} className="flex-1 rounded-xl py-2.5 text-sm font-semibold text-zinc-400 transition" style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.08)"}}>বাতিল</button>
                <button type="submit" disabled={editSaving} className="flex-1 rounded-xl py-2.5 text-sm font-black text-white transition disabled:opacity-50" style={{background:"linear-gradient(135deg,rgba(99,102,241,0.8),rgba(79,70,229,0.8))",border:"1px solid rgba(99,102,241,0.5)"}}>
                  {editSaving?"সংরক্ষণ হচ্ছে…":"✅ সংরক্ষণ করুন"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-700 flex items-center justify-between">
          <h2 className="text-white font-semibold">Draw History</h2>
          <span className="text-zinc-600 text-xs">✏️ icon ক্লিক করে edit করুন</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="border-b border-slate-700 text-slate-500 text-xs uppercase tracking-wide">
              <th className="text-left px-5 py-3">Date</th>
              <th className="text-center px-3 py-3">1st</th>
              <th className="text-center px-3 py-3">2nd</th>
              <th className="text-center px-3 py-3">3rd</th>
              <th className="text-left px-3 py-3 hidden sm:table-cell">Special (first 5)</th>
              <th className="px-3 py-3 w-10"/>
            </tr></thead>
            <tbody>
              {companyResults.slice(0,50).map((r,i)=>(
                <tr key={r.id} className={`border-b border-slate-700/50 ${i%2===0?"bg-slate-800/30":""} hover:bg-slate-700/30 transition`}>
                  <td className="px-5 py-3 text-slate-400 text-sm">{r.date}</td>
                  <td className="px-3 py-3 text-center font-mono text-white font-semibold">{r.first}</td>
                  <td className="px-3 py-3 text-center font-mono text-slate-300">{r.second}</td>
                  <td className="px-3 py-3 text-center font-mono text-slate-300">{r.third}</td>
                  <td className="px-3 py-3 hidden sm:table-cell">
                    <div className="flex gap-1 flex-wrap">{r.special.slice(0,5).map((n,j)=><span key={j} className="font-mono text-xs text-slate-400 bg-slate-700/50 px-1.5 py-0.5 rounded">{n}</span>)}</div>
                  </td>
                  <td className="px-3 py-3 text-center">
                    <button onClick={()=>openEdit(r)} className="text-indigo-400 hover:text-indigo-300 transition text-base" title="এই row edit করুন">✏️</button>
                  </td>
                </tr>
              ))}
              {companyResults.length===0&&<tr><td colSpan={6} className="py-12 text-center text-slate-500">No draws found</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ─── Triplets View ────────────────────────────────────────────────────────────
function TripletsView({ results }: { results:LotteryResult[] }) {
  const [sel,setSel]=useState<CompanyId|"all">("all");
  const data=useMemo(()=>tripletFrequency(results,sel==="all"?undefined:sel),[results,sel]);
  return (
    <div className="p-6 max-w-4xl mx-auto space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-2xl font-bold text-white">3D Triplets Analysis</h1>
        <CompanySelector value={sel} onChange={setSel}/>
      </div>
      <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
        <h2 className="text-white font-semibold mb-4">Top 20 Triplets</h2>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={data.slice(0,20)} layout="vertical">
            <XAxis type="number" tick={{fill:"#94a3b8",fontSize:11}} axisLine={false} tickLine={false}/>
            <YAxis type="category" dataKey="triplet" width={40} tick={{fill:"#e2e8f0",fontSize:12,fontFamily:"monospace"}} axisLine={false} tickLine={false}/>
            <Tooltip contentStyle={{background:"#1e293b",border:"1px solid #334155",borderRadius:8,color:"#fff"}}/>
            <Bar dataKey="count" fill="#8b5cf6" radius={[0,4,4,0]}/>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden">
        <table className="w-full">
          <thead><tr className="border-b border-slate-700 text-slate-500 text-xs uppercase tracking-wide">
            <th className="text-left px-5 py-3">Rank</th><th className="text-left px-5 py-3">Triplet</th>
            <th className="text-left px-5 py-3">Count</th><th className="text-left px-5 py-3">Frequency</th>
          </tr></thead>
          <tbody>{data.slice(0,30).map((row,i)=>(
            <tr key={row.triplet} className="border-b border-slate-700/50 hover:bg-slate-700/30">
              <td className="px-5 py-2.5 text-slate-500 text-sm">#{i+1}</td>
              <td className="px-5 py-2.5 font-mono text-white font-bold text-lg">{row.triplet}</td>
              <td className="px-5 py-2.5 text-slate-300 text-sm">{row.count}</td>
              <td className="px-5 py-2.5 w-40"><div className="h-2 bg-slate-700 rounded-full overflow-hidden"><div className="h-full bg-purple-500 rounded-full" style={{width:`${(row.count/(data[0]?.count||1))*100}%`}}/></div></td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Pairs View ───────────────────────────────────────────────────────────────
function PairsView({ results }: { results:LotteryResult[] }) {
  const [sel,setSel]=useState<CompanyId|"all">("all");
  const data=useMemo(()=>pairFrequency(results,sel==="all"?undefined:sel),[results,sel]);
  return (
    <div className="p-6 max-w-4xl mx-auto space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-2xl font-bold text-white">Pairs Analysis</h1>
        <CompanySelector value={sel} onChange={setSel}/>
      </div>
      <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
        <h2 className="text-white font-semibold mb-4">Top 20 Digit Pairs</h2>
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={data.slice(0,20)} layout="vertical">
            <XAxis type="number" tick={{fill:"#94a3b8",fontSize:11}} axisLine={false} tickLine={false}/>
            <YAxis type="category" dataKey="pair" width={32} tick={{fill:"#e2e8f0",fontSize:12,fontFamily:"monospace"}} axisLine={false} tickLine={false}/>
            <Tooltip contentStyle={{background:"#1e293b",border:"1px solid #334155",borderRadius:8,color:"#fff"}}/>
            <Bar dataKey="count" fill="#ec4899" radius={[0,4,4,0]}/>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-6 gap-3">
        {data.slice(0,30).map((row,i)=>(
          <div key={row.pair} className="bg-slate-800 border border-slate-700 rounded-xl p-3 text-center hover:border-pink-500/50 transition">
            <div className="font-mono text-white font-bold text-xl">{row.pair}</div>
            <div className="text-slate-400 text-xs mt-1">×{row.count}</div>
            <div className="text-slate-600 text-xs">#{i+1}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Cross-Company View ───────────────────────────────────────────────────────
function CrossView({ results }: { results:LotteryResult[] }) {
  const matrix=useMemo(()=>crossCompanyMatrix(results),[results]);
  return (
    <div className="p-6 max-w-3xl mx-auto space-y-5">
      <h1 className="text-2xl font-bold text-white">Cross-Company Analysis</h1>
      <p className="text-slate-400 text-sm">Number overlap count between companies on same draw days</p>
      <div className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden">
        <table className="w-full text-center">
          <thead><tr className="border-b border-slate-700">
            <th className="px-4 py-3 text-slate-500 text-sm text-left">Company</th>
            {COMPANY_IDS.map(id=><th key={id} className="px-4 py-3"><span className="text-xs font-bold" style={{color:COMPANIES[id].color}}>{COMPANIES[id].short}</span></th>)}
          </tr></thead>
          <tbody>{COMPANY_IDS.map(row=>(
            <tr key={row} className="border-b border-slate-700/50">
              <td className="px-4 py-3 text-left">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{background:COMPANIES[row].color}}/>
                  <span className="text-white text-sm font-medium">{COMPANIES[row].name}</span>
                </div>
              </td>
              {COMPANY_IDS.map(col=>{
                const val=matrix[row][col];
                const max=Math.max(...COMPANY_IDS.flatMap(r=>COMPANY_IDS.map(c=>r!==c?matrix[r][c]:0)));
                const intensity=row===col?1:val/(max||1);
                return <td key={col} className="px-4 py-3">
                  {row===col?<span className="text-slate-600">—</span>:
                  <span className="text-white font-mono text-sm font-semibold px-2 py-1 rounded" style={{background:`rgba(59,130,246,${0.1+intensity*0.5})`}}>{val}</span>}
                </td>;
              })}
            </tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Correlation View ─────────────────────────────────────────────────────────
function CorrelationView({ results }: { results:LotteryResult[] }) {
  const chartData=useMemo(()=>{
    const byDate: Record<string,Record<CompanyId,number>>={};
    for (const r of results) {
      const c=r.company as CompanyId; if(!COMPANY_IDS.includes(c)) continue;
      if(!byDate[r.date]) byDate[r.date]={magnum:0,toto:0,damacai:0,singapore:0};
      byDate[r.date][c]=Number(r.first);
    }
    return Object.entries(byDate).sort(([a],[b])=>a.localeCompare(b)).slice(-30).map(([date,vals])=>({date:date.slice(5),...vals}));
  },[results]);
  const COLORS={magnum:"#ef4444",toto:"#3b82f6",damacai:"#22c55e",singapore:"#f59e0b"};
  return (
    <div className="p-6 max-w-4xl mx-auto space-y-5">
      <h1 className="text-2xl font-bold text-white">Correlation Analysis</h1>
      <p className="text-slate-400 text-sm">1st prize number trends across companies (last 30 draws)</p>
      <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
        <ResponsiveContainer width="100%" height={320}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b"/>
            <XAxis dataKey="date" tick={{fill:"#94a3b8",fontSize:10}} axisLine={false} tickLine={false} interval={4}/>
            <YAxis tick={{fill:"#94a3b8",fontSize:11}} axisLine={false} tickLine={false} domain={[0,9999]}/>
            <Tooltip contentStyle={{background:"#1e293b",border:"1px solid #334155",borderRadius:8,color:"#fff"}}/>
            <Legend wrapperStyle={{color:"#94a3b8"}}/>
            {COMPANY_IDS.map(id=><Line key={id} type="monotone" dataKey={id} name={COMPANIES[id].name} stroke={COLORS[id]} dot={false} strokeWidth={1.5}/>)}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

// ─── Predictions — Client-Side Computation ────────────────────────────────────
function computeLocalPredictions(results: LotteryResult[], company: CompanyId) {
  const filtered = results.filter(r => r.company === company)
    .sort((a,b) => b.date.localeCompare(a.date));
  if (filtered.length < 3) return null;

  const lastDraw = filtered[0]!;
  const drawsAnalyzed = filtered.length;

  // Digit frequency
  const digFreq = digitFrequency(results, company);
  const sorted = [...digFreq].sort((a,b) => b.count - a.count);
  const hotDigits = sorted.slice(0,5).map(x => x.digit);
  const coldDigits = [...sorted].reverse().slice(0,5).map(x => x.digit);

  // Position-wise frequency
  const posCounts: Record<number,Record<string,number>> = {0:{},1:{},2:{},3:{}};
  for (const r of filtered) {
    for (const num of [r.first, r.second, r.third]) {
      if (num && num.length === 4) {
        for (let i = 0; i < 4; i++) {
          const d = num[i]!;
          posCounts[i][d] = (posCounts[i][d] ?? 0) + 1;
        }
      }
    }
  }
  const total3 = filtered.length * 3 || 1;
  const positionProbability = [0,1,2,3].map(pos =>
    Object.entries(posCounts[pos]).sort((a,b)=>b[1]-a[1]).slice(0,5)
      .map(([digit,count]) => ({ digit, pct: Math.round(count/total3*100) }))
  );

  // Build prediction candidates
  const topByPos = [0,1,2,3].map(pos =>
    Object.entries(posCounts[pos]).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([d])=>d)
  );
  const candidates: Record<string,number> = {};
  const add = (num: string, score: number) => { if (/^\d{4}$/.test(num)) candidates[num]=(candidates[num]??0)+score; };

  // Method 1: top position digits
  for (const a of (topByPos[0]?.slice(0,3)??[])) for (const b of (topByPos[1]?.slice(0,3)??[])) for (const c of (topByPos[2]?.slice(0,3)??[])) for (const d of (topByPos[3]?.slice(0,3)??[])) {
    add(`${a}${b}${c}${d}`, 5);
  }
  // Method 2: hot digit combos
  const hot4 = hotDigits.slice(0,4);
  for (const a of hot4) for (const b of hot4) for (const c of hot4) for (const d of hot4) add(`${a}${b}${c}${d}`, 3);

  const recentNums = new Set(filtered.slice(0,10).flatMap(r=>[r.first,r.second,r.third]));
  const ranked = Object.entries(candidates).filter(([n])=>!recentNums.has(n)).sort((a,b)=>b[1]-a[1]).slice(0,5);
  const maxScore = ranked[0]?.[1] ?? 1;
  const models = ["Position+Hot","Hot Frequency","Markov","Statistical","Position"];
  const predictions = ranked.map(([number,score],i) => {
    const pct = Math.round(score/maxScore*100);
    return { number, confidence: pct>=70?"High":pct>=40?"Medium":"Low", confidencePct:pct, dominantModel:models[i]??"Position", type:"Statistical pattern analysis" };
  });

  const topTriplets = tripletFrequency(results, company).slice(0,8);
  const topPairs    = pairFrequency(results, company).slice(0,8);
  return { lastDraw, drawsAnalyzed, predictions, hotDigits, coldDigits, positionProbability, topTriplets, topPairs };
}

// ─── Predictions View ─────────────────────────────────────────────────────────
function PredictionsView({ results }: { results: LotteryResult[] }) {
  const [company,setCompany]=useState<CompanyId>("magnum");

  const data = useMemo(() => computeLocalPredictions(results, company), [results, company]);
  const loading = false;

  const CONF_STYLE: Record<string,string> = {
    High:"text-green-400 bg-green-900/20 border-green-700",
    Medium:"text-yellow-400 bg-yellow-900/20 border-yellow-700",
    Low:"text-red-400 bg-red-900/20 border-red-700",
  };

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-white">🔮 Predictions</h1>
          <p className="text-slate-400 text-xs mt-0.5">৩-স্তরের AI বিশ্লেষণ: Statistical + Markov Chain + Human Filter</p>
        </div>
        <select value={company} onChange={e=>setCompany(e.target.value as CompanyId)}
          className="bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500">
          {COMPANY_IDS.map(id=><option key={id} value={id}>{COMPANIES[id].name}</option>)}
        </select>
      </div>

      <div className="bg-amber-900/20 border border-amber-700/30 rounded-xl p-3 text-amber-300 text-xs">
        ⚠️ প্যাটার্ন-ভিত্তিক পরিসংখ্যান বিশ্লেষণ মাত্র — লটারির ফলাফল এলোমেলো হয়।
      </div>

      {loading && <div className="text-center text-slate-400 py-16 text-sm">বিশ্লেষণ চলছে…</div>}

      {!loading && data && <>
        {/* Last draw info */}
        {data.lastDraw && (
          <div className="bg-slate-800/60 border border-slate-700 rounded-xl px-4 py-3 flex items-center gap-3 text-sm">
            <span className="text-slate-500">শেষ ড্র ({data.lastDraw.date}):</span>
            <span className="font-mono text-white font-bold text-lg">{data.lastDraw.first}</span>
            <span className="text-slate-500 text-xs ml-auto">{data.drawsAnalyzed} ড্র বিশ্লেষণ করা হয়েছে</span>
          </div>
        )}

        {/* ─── Top 5 Predictions Table ─── */}
        <div className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-700 bg-slate-800/80">
            <h2 className="text-white font-semibold">পরবর্তী সম্ভাব্য সংখ্যা — Top 5 Predictions</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700 text-slate-500 text-xs uppercase tracking-wide">
                  <th className="px-4 py-3 text-left">#</th>
                  <th className="px-4 py-3 text-left">৪-ডিজিট কোড</th>
                  <th className="px-4 py-3 text-left">নির্ভুলতা</th>
                  <th className="px-4 py-3 text-left">মূল মডেল</th>
                  <th className="px-4 py-3 text-left">ধরন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                {data.predictions?.map((p:any, i:number) => (
                  <tr key={i} className={`hover:bg-slate-700/30 transition ${i===0?"bg-blue-900/10":""}`}>
                    <td className="px-4 py-4">
                      <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${i===0?"bg-blue-600 text-white":i===1?"bg-slate-600 text-white":"bg-slate-700 text-slate-400"}`}>{i+1}</span>
                    </td>
                    <td className="px-4 py-4">
                      <div className="font-mono font-black text-2xl text-white tracking-widest">{p.number}</div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex flex-col gap-1">
                        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border w-fit ${CONF_STYLE[p.confidence]||"text-slate-400 border-slate-600"}`}>
                          {p.confidence} · {p.confidencePct}%
                        </span>
                        <div className="w-24 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                          <div className={`h-full rounded-full ${p.confidence==="High"?"bg-green-500":p.confidence==="Medium"?"bg-yellow-500":"bg-red-500"}`}
                            style={{width:`${p.confidencePct}%`}}/>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <span className="text-blue-300 text-xs font-medium bg-blue-900/20 border border-blue-800/40 px-2 py-1 rounded-lg">{p.dominantModel}</span>
                    </td>
                    <td className="px-4 py-4 text-slate-300 text-xs max-w-[160px]">{p.type}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* ─── Hot & Cold Digits ─── */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4">
            <p className="text-orange-400 text-xs font-semibold uppercase tracking-wide mb-3">🔥 Hot Digits (বেশি আসে)</p>
            <div className="flex gap-2 flex-wrap">
              {data.hotDigits?.map((d:string,i:number)=>(
                <div key={d} className="flex flex-col items-center">
                  <span className="w-10 h-10 rounded-xl bg-orange-500/20 border border-orange-600 flex items-center justify-center text-orange-300 font-black font-mono text-lg">{d}</span>
                  <span className="text-orange-600 text-xs mt-0.5">#{i+1}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4">
            <p className="text-blue-400 text-xs font-semibold uppercase tracking-wide mb-3">❄️ Cold Digits (কম আসে)</p>
            <div className="flex gap-2 flex-wrap">
              {data.coldDigits?.map((d:string,i:number)=>(
                <div key={d} className="flex flex-col items-center">
                  <span className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-600 flex items-center justify-center text-blue-300 font-black font-mono text-lg">{d}</span>
                  <span className="text-blue-600 text-xs mt-0.5">#{i+1}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ─── Position-wise Probability ─── */}
        {data.positionProbability && (
          <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
            <h2 className="text-white font-semibold mb-4">পজিশন ভিত্তিক সম্ভাবনা (Position-wise Probability)</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {["১ম","২য়","৩য়","৪র্থ"].map((label,pos)=>(
                <div key={pos}>
                  <p className="text-slate-500 text-xs font-semibold uppercase mb-2">{label} ডিজিট</p>
                  <div className="space-y-1.5">
                    {data.positionProbability[pos]?.map((item:any)=>(
                      <div key={item.digit} className="flex items-center gap-2">
                        <span className="font-mono text-white font-bold w-4 text-center">{item.digit}</span>
                        <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                          <div className="h-full bg-blue-500 rounded-full" style={{width:`${Math.min(item.pct*2,100)}%`}}/>
                        </div>
                        <span className="text-slate-400 text-xs w-8 text-right">{item.pct}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ─── Top Triplets & Pairs ─── */}
        <div className="grid grid-cols-2 gap-4">
          {data.topTriplets?.length>0 && (
            <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4">
              <h2 className="text-white font-semibold text-sm mb-3">🔢 Top Triplets</h2>
              <div className="flex flex-wrap gap-2">
                {data.topTriplets.map((t:any)=>(
                  <div key={t.triplet} className="bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-center">
                    <div className="font-mono text-white font-bold">{t.triplet}</div>
                    <div className="text-slate-400 text-xs">×{t.count}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {data.topPairs?.length>0 && (
            <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4">
              <h2 className="text-white font-semibold text-sm mb-3">🔗 Top Pairs</h2>
              <div className="flex flex-wrap gap-2">
                {data.topPairs.map((t:any)=>(
                  <div key={t.pair} className="bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-center">
                    <div className="font-mono text-white font-bold">{t.pair}</div>
                    <div className="text-slate-400 text-xs">×{t.count}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </>}
    </div>
  );
}

// ─── Deep Thesis Engine ───────────────────────────────────────────────────────
function DeepAnalysisView({ results }: { results: LotteryResult[] }) {
  const [tab, setTab] = useState<"hotzone"|"cluster"|"backtest"|"predlog">("hotzone");
  const [company, setCompany] = useState<CompanyId>("magnum");
  const [btDate, setBtDate] = useState("");
  const [btResult, setBtResult] = useState<any>(null);
  const [hitLog, setHitLog] = useState<Record<string,boolean>>(() => {
    try { return JSON.parse(localStorage.getItem("4d_hits") ?? "{}"); } catch { return {}; }
  });

  const filtered = results.filter(r => r.company === company);
  const prizeNums = (r: LotteryResult) => [r.first, r.second, r.third];
  const allNums = (r: LotteryResult) => [r.first, r.second, r.third, ...r.special, ...r.consolation];

  // ── Digit frequency per position ─────────────────────────────────────────────
  const posFreq: Record<number, Record<string,number>> = {0:{},1:{},2:{},3:{}};
  for (let i = 0; i < 10; i++) { posFreq[0][i]=0; posFreq[1][i]=0; posFreq[2][i]=0; posFreq[3][i]=0; }
  for (const r of filtered) for (const num of prizeNums(r)) if (num.length===4) num.split("").forEach((d,i)=>{ posFreq[i][d]=(posFreq[i][d]??0)+1; });

  const digitFreq: Record<string,number> = {};
  for (let i=0;i<10;i++) digitFreq[String(i)]=0;
  for (const r of filtered) for (const n of allNums(r)) for (const d of n.split("")) if (/\d/.test(d)) digitFreq[d]++;
  const maxFreq = Math.max(...Object.values(digitFreq)) || 1;
  const sortedDigits = Object.entries(digitFreq).sort((a,b)=>b[1]-a[1]);

  // ── Cluster analysis ─────────────────────────────────────────────────────────
  function classify(num: string): string {
    const d = num.split("").map(Number);
    if (d.every(x=>x===d[0])) return "Mirror (1111)";
    if (d.includes(0)) return "Zero Family";
    if ([1,2,3,4,5,6,7,8,9].some((_,i,a)=>i>0&&d[i]-d[i-1]===1)) return "Serial Family";
    const evens = d.filter(x=>x%2===0).length;
    if (evens>=3) return "Even Heavy";
    if (evens<=1) return "Odd Heavy";
    const sum = d.reduce((a,b)=>a+b,0);
    if (sum>=20) return "High Sum";
    if (sum<=10) return "Low Sum";
    return "Balanced";
  }
  const clusterCount: Record<string,number> = {};
  for (const r of filtered) for (const n of prizeNums(r)) { const c=classify(n); clusterCount[c]=(clusterCount[c]??0)+1; }
  const clusterTotal = Object.values(clusterCount).reduce((a,b)=>a+b,0)||1;
  const clusters = Object.entries(clusterCount).sort((a,b)=>b[1]-a[1]);

  // ── Prediction Log: top 10 with scores ──────────────────────────────────────
  const pairFreq: Record<string,number> = {};
  const tripFreq: Record<string,number> = {};
  for (const r of filtered) for (const num of prizeNums(r)) if (num.length===4) {
    const d = num.split("");
    [d[0]+d[1],d[1]+d[2],d[2]+d[3],d[0]+d[2],d[1]+d[3],d[0]+d[3]].forEach(p=>pairFreq[p]=(pairFreq[p]??0)+1);
    [d[0]+d[1]+d[2],d[0]+d[1]+d[3],d[0]+d[2]+d[3],d[1]+d[2]+d[3]].forEach(t=>tripFreq[t]=(tripFreq[t]??0)+1);
  }
  const bestPos = [0,1,2,3].map(p=>Object.entries(posFreq[p]).sort((a,b)=>b[1]-a[1]).map(([d])=>d));

  function scoreNum(num: string): number {
    if (!/^\d{4}$/.test(num)) return 0;
    const d = num.split("");
    let s = 0;
    d.forEach((c,i) => s += (posFreq[i][c]??0)*50);
    [d[0]+d[1]+d[2],d[0]+d[1]+d[3],d[0]+d[2]+d[3],d[1]+d[2]+d[3]].forEach(t=>s+=(tripFreq[t]??0)*20);
    [d[0]+d[1],d[1]+d[2],d[2]+d[3]].forEach(p=>s+=(pairFreq[p]??0)*10);
    return s;
  }

  const candidates = new Set<string>();
  for (let i=0;i<4;i++) for (let j=0;j<5;j++) { const d=[...bestPos[0]]; d[i]=sortedDigits[j][0]; candidates.add([bestPos[0][0],bestPos[1][0],bestPos[2][0],bestPos[3][0]].map((_,p)=>p===i?sortedDigits[j][0]:bestPos[p][0]).join("")); }
  Object.keys(tripFreq).sort((a,b)=>tripFreq[b]-tripFreq[a]).slice(0,5).forEach(t=>{ candidates.add(t+bestPos[3][0]); candidates.add(bestPos[0][0]+t); });
  Object.keys(pairFreq).sort((a,b)=>pairFreq[b]-pairFreq[a]).slice(0,3).forEach(p=>{ candidates.add(p+bestPos[2][0]+bestPos[3][0]); candidates.add(bestPos[0][0]+bestPos[1][0]+p); });

  const top10 = Array.from(candidates).filter(n=>/^\d{4}$/.test(n)).map(n=>({ num:n, score:scoreNum(n) })).sort((a,b)=>b.score-a.score).slice(0,10);
  const maxS = top10[0]?.score||1;

  // ── Back-test ────────────────────────────────────────────────────────────────
  function runBacktest() {
    if (!btDate) return;
    const idx = filtered.findIndex(r=>r.date===btDate);
    if (idx<0||idx>=filtered.length-5) { setBtResult({error:"Date not found or not enough prior data."}); return; }
    const prior = filtered.slice(idx+1);
    const actual = filtered[idx];
    const pp: Record<number,Record<string,number>> = {0:{},1:{},2:{},3:{}};
    for (let i=0;i<10;i++){pp[0][i]=0;pp[1][i]=0;pp[2][i]=0;pp[3][i]=0;}
    for (const r of prior.slice(0,60)) for (const num of prizeNums(r)) if(num.length===4) num.split("").forEach((d,i)=>{ pp[i][d]=(pp[i][d]??0)+1; });
    const predicted = [0,1,2,3].map(p=>Object.entries(pp[p]).sort((a,b)=>b[1]-a[1])[0]?.[0]??"0").join("");
    const actualFirst = actual.first;
    const matchDigits = predicted.split("").filter((d,i)=>d===actualFirst[i]).length;
    setBtResult({ predicted, actual: actualFirst, date: btDate, matchDigits, usedDraws: prior.slice(0,60).length });
  }

  function markHit(num: string) {
    const updated = {...hitLog, [num]: true};
    setHitLog(updated);
    localStorage.setItem("4d_hits", JSON.stringify(updated));
  }

  const TABS = [
    {id:"hotzone",label:"🔥 Hot Zone"},
    {id:"cluster",label:"🗂 Cluster"},
    {id:"backtest",label:"🧪 Back-Test"},
    {id:"predlog",label:"📋 Prediction Log"},
  ] as const;

  const compColor = COMPANIES[company].color;

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-white">🧠 Deep Thesis Engine</h1>
          <p className="text-slate-400 text-xs mt-0.5">Ensemble Learning — Statistical + Cluster + Back-Test + Prediction Log</p>
        </div>
        <select value={company} onChange={e=>setCompany(e.target.value as CompanyId)}
          className="bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500">
          {COMPANY_IDS.map(id=><option key={id} value={id}>{COMPANIES[id].name}</option>)}
        </select>
      </div>

      {/* Tab bar */}
      <div className="flex gap-1 bg-slate-800/60 border border-slate-700 rounded-xl p-1 overflow-x-auto">
        {TABS.map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)}
            className={`flex-1 min-w-fit px-3 py-2 rounded-lg text-xs font-semibold transition whitespace-nowrap ${tab===t.id?"bg-blue-600 text-white shadow":"text-slate-400 hover:text-white"}`}>
            {t.label}
          </button>
        ))}
      </div>

      {filtered.length<5 && <div className="text-center text-slate-400 py-8 text-sm">এই company-র জন্য যথেষ্ট data নেই।</div>}

      {filtered.length>=5 && <>

        {/* ── HOT ZONE ── */}
        {tab==="hotzone" && (
          <div className="space-y-5">
            {/* Heat Map */}
            <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
              <h2 className="text-white font-semibold mb-4">🌡️ Digit Heat Map (0–9)</h2>
              <div className="grid grid-cols-5 md:grid-cols-10 gap-2">
                {sortedDigits.map(([digit, count], i)=>{
                  const intensity = count/maxFreq;
                  const bg = intensity>0.8?"bg-red-600":intensity>0.6?"bg-orange-500":intensity>0.4?"bg-yellow-500":intensity>0.2?"bg-blue-600":"bg-slate-700";
                  const label = intensity>0.8?"🔥":intensity>0.6?"♨️":intensity>0.4?"🌡️":intensity>0.2?"❄️":"🧊";
                  return (
                    <div key={digit} className={`${bg} rounded-xl p-3 text-center border border-white/10`}>
                      <div className="font-mono font-black text-white text-2xl">{digit}</div>
                      <div className="text-white/70 text-xs mt-1">×{count}</div>
                      <div className="text-base mt-0.5">{label}</div>
                      <div className="text-white/60 text-xs">#{i+1}</div>
                    </div>
                  );
                })}
              </div>
              <div className="flex gap-4 mt-4 text-xs text-slate-400 flex-wrap">
                {[["bg-red-600","🔥","Very Hot (>80%)"],["bg-orange-500","♨️","Hot (>60%)"],["bg-yellow-500","🌡️","Warm (>40%)"],["bg-blue-600","❄️","Cool (>20%)"],["bg-slate-700","🧊","Cold"]].map(([cls,ic,l])=>(
                  <div key={l} className="flex items-center gap-1.5"><span className={`w-3 h-3 rounded ${cls}`}/>{ic} {l}</div>
                ))}
              </div>
            </div>

            {/* Position-wise heat */}
            <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
              <h2 className="text-white font-semibold mb-4">📍 Position-wise Hot Digits</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {["১ম","২য়","৩য়","৪র্থ"].map((lbl,pos)=>{
                  const sorted = Object.entries(posFreq[pos]).sort((a,b)=>b[1]-a[1]).slice(0,5);
                  const mx = sorted[0]?.[1]||1;
                  return (
                    <div key={pos} className="bg-slate-700/40 rounded-xl p-3">
                      <p className="text-slate-400 text-xs font-semibold mb-3 uppercase">{lbl} ডিজিট</p>
                      {sorted.map(([d,c])=>(
                        <div key={d} className="flex items-center gap-2 mb-1.5">
                          <span className="font-mono text-white font-bold w-4">{d}</span>
                          <div className="flex-1 h-2 bg-slate-600 rounded-full overflow-hidden">
                            <div className="h-full rounded-full" style={{width:`${(c/mx)*100}%`, background:compColor}}/>
                          </div>
                          <span className="text-slate-400 text-xs w-6 text-right">{c}</span>
                        </div>
                      ))}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Top pairs */}
            <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
              <h2 className="text-white font-semibold mb-3">🔗 Top 3 Pairs</h2>
              <div className="flex gap-3 flex-wrap">
                {Object.entries(pairFreq).sort((a,b)=>b[1]-a[1]).slice(0,3).map(([pair,cnt])=>(
                  <div key={pair} className="bg-slate-700 border border-slate-600 rounded-xl px-5 py-3 text-center">
                    <div className="font-mono text-white font-black text-2xl">{pair}</div>
                    <div className="text-slate-400 text-xs mt-1">×{cnt} times</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── CLUSTER ── */}
        {tab==="cluster" && (
          <div className="space-y-4">
            <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
              <h2 className="text-white font-semibold mb-1">🗂 Number Family Clusters</h2>
              <p className="text-slate-500 text-xs mb-5">১০,০০০ সম্ভাব্য সংখ্যাকে পরিবারে ভাগ করে কোন পরিবার এখন সবচেয়ে সক্রিয় তা দেখায়।</p>
              <div className="space-y-3">
                {clusters.map(([name,count])=>{
                  const pct = Math.round((count/clusterTotal)*100);
                  return (
                    <div key={name} className="bg-slate-700/40 rounded-xl p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-white font-medium text-sm">{name}</span>
                        <span className="text-slate-300 text-sm font-bold">{pct}%</span>
                      </div>
                      <div className="w-full h-3 bg-slate-600 rounded-full overflow-hidden">
                        <div className="h-full rounded-full transition-all duration-500" style={{width:`${pct}%`, background:compColor}}/>
                      </div>
                      <div className="text-slate-300 text-xs mt-1">{count} numbers in last {filtered.length} draws</div>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="bg-blue-900/20 border border-blue-700/30 rounded-xl p-4 text-blue-300 text-sm">
              💡 <strong>টিপস:</strong> যে পরিবারের % সবচেয়ে বেশি, সেই ধরনের সংখ্যায় focus করুন।
            </div>
          </div>
        )}

        {/* ── BACK-TEST ── */}
        {tab==="backtest" && (
          <div className="space-y-4">
            <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
              <h2 className="text-white font-semibold mb-1">🧪 Back-Testing Lab</h2>
              <p className="text-slate-500 text-xs mb-5">যেকোনো পুরনো তারিখ দিন — অ্যাপ সেইদিনের আগের data দিয়ে prediction করবে এবং actual result-এর সাথে মেলাবে।</p>
              <div className="flex gap-3 items-end flex-wrap">
                <div className="flex-1 min-w-[160px]">
                  <label className="block text-slate-400 text-xs mb-1.5">তারিখ বেছে নিন</label>
                  <input type="date" value={btDate} onChange={e=>setBtDate(e.target.value)}
                    className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500"/>
                </div>
                <button onClick={runBacktest}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-5 py-2.5 rounded-lg text-sm transition">
                  Test করুন
                </button>
              </div>
              {btResult&&(
                <div className={`mt-5 rounded-xl p-5 border ${btResult.error?"bg-red-900/20 border-red-700":"bg-slate-700/50 border-slate-600"}`}>
                  {btResult.error ? <p className="text-red-300 text-sm">{btResult.error}</p> : (
                    <div className="space-y-3">
                      <div className="flex gap-8 flex-wrap">
                        <div>
                          <div className="text-slate-400 text-xs mb-1">আমাদের Prediction</div>
                          <div className="font-mono text-white font-black text-3xl tracking-widest">{btResult.predicted}</div>
                        </div>
                        <div>
                          <div className="text-slate-400 text-xs mb-1">Actual Result ({btResult.date})</div>
                          <div className="font-mono text-white font-black text-3xl tracking-widest">{btResult.actual}</div>
                        </div>
                      </div>
                      <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold ${btResult.matchDigits>=3?"bg-green-900/40 text-green-300 border border-green-700":btResult.matchDigits>=2?"bg-yellow-900/40 text-yellow-300 border border-yellow-700":"bg-red-900/40 text-red-300 border border-red-700"}`}>
                        {btResult.matchDigits===4?"🎯 সম্পূর্ণ মিলেছে!":btResult.matchDigits>=2?`✅ ${btResult.matchDigits}/4 ডিজিট মিলেছে`:`❌ ${btResult.matchDigits}/4 ডিজিট মিলেছে`}
                      </div>
                      <p className="text-slate-500 text-xs">{btResult.usedDraws} টি আগের draw ব্যবহার করে prediction করা হয়েছে।</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── PREDICTION LOG ── */}
        {tab==="predlog" && (
          <div className="space-y-4">
            <div className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-700">
                <h2 className="text-white font-semibold">📋 Prediction Log — Top 10</h2>
                <p className="text-slate-500 text-xs mt-0.5">Ensemble scoring: Position + Triplet + Pair frequency। "Hit" বাটন চাপুন যদি সংখ্যাটি মেলে।</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-700 text-slate-500 text-xs uppercase tracking-wide">
                      <th className="px-4 py-3 text-left">#</th>
                      <th className="px-4 py-3 text-left">সংখ্যা</th>
                      <th className="px-4 py-3 text-left">Score</th>
                      <th className="px-4 py-3 text-left">Odds</th>
                      <th className="px-4 py-3 text-left">Cluster</th>
                      <th className="px-4 py-3 text-left">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/50">
                    {top10.map(({num, score}, i)=>{
                      const pct = Math.round((score/maxS)*95);
                      const odds = (10000/Math.max(pct,1)).toFixed(0);
                      const hit = hitLog[num];
                      return (
                        <tr key={num} className={`hover:bg-slate-700/30 transition ${i===0?"bg-blue-900/10":""}`}>
                          <td className="px-4 py-3">
                            <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${i===0?"bg-blue-600 text-white":i<3?"bg-slate-600 text-white":"bg-slate-700 text-slate-400"}`}>{i+1}</span>
                          </td>
                          <td className="px-4 py-3 font-mono font-black text-xl text-white tracking-widest">{num}</td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <div className="w-16 h-2 bg-slate-600 rounded-full overflow-hidden">
                                <div className="h-full rounded-full bg-blue-500" style={{width:`${pct}%`}}/>
                              </div>
                              <span className="text-slate-300 text-xs">{pct}%</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-slate-400 text-xs">1:{odds}</td>
                          <td className="px-4 py-3 text-slate-400 text-xs">{classify(num)}</td>
                          <td className="px-4 py-3">
                            {hit
                              ? <span className="text-green-400 text-xs font-semibold bg-green-900/30 border border-green-700 px-2 py-1 rounded-lg">✅ Hit!</span>
                              : <button onClick={()=>markHit(num)} className="text-xs bg-slate-700 hover:bg-green-800 border border-slate-600 hover:border-green-600 text-slate-300 hover:text-green-300 px-2 py-1 rounded-lg transition">Mark Hit</button>
                            }
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="bg-amber-900/20 border border-amber-700/30 rounded-xl p-3 text-amber-300 text-xs">
              ⚠️ Odds হলো গাণিতিক সম্ভাবনা, বাস্তব জয়ের নিশ্চয়তা নয়।
            </div>
          </div>
        )}
      </>}
    </div>
  );
}

// ─── Admin Users View ─────────────────────────────────────────────────────────
function UsersView({ currentUserId }: { currentUserId:number }) {
  const [users,setUsers]=useState<ManagedUser[]>([]); const [loading,setLoading]=useState(true);
  const [showAdd,setShowAdd]=useState(false);
  const [form,setForm]=useState({username:"",password:"",confirm:"",role:"user"});
  const [showPw,setShowPw]=useState(false);
  const [saving,setSaving]=useState(false); const [err,setErr]=useState("");
  const [copied,setCopied]=useState(false);
  const [inviteInfo,setInviteInfo]=useState<{link:string;expiresAt:string}|null>(null);
  const [generating,setGenerating]=useState(false);
  const [confirmDelete,setConfirmDelete]=useState<ManagedUser|null>(null);
  const [actionLoading,setActionLoading]=useState<number|null>(null);

  const loadUsers=useCallback(async()=>{
    setLoading(true);
    try{setUsers(await api.get("/auth/users"));}catch{}finally{setLoading(false);}
  },[]);
  useEffect(()=>{loadUsers();},[loadUsers]);

  // ── Password strength ──────────────────────────────────────────────────────
  function pwStrength(pw:string):{level:0|1|2|3;label:string;color:string;bar:string}{
    if(!pw) return {level:0,label:"",color:"",bar:"w-0"};
    let score=0;
    if(pw.length>=8) score++;
    if(pw.length>=12) score++;
    if(/[A-Z]/.test(pw)&&/[a-z]/.test(pw)) score++;
    if(/\d/.test(pw)) score++;
    if(/[^A-Za-z0-9]/.test(pw)) score++;
    if(score<=1) return {level:1,label:"দুর্বল ❌",color:"#ef4444",bar:"w-1/4"};
    if(score<=3) return {level:2,label:"মাঝারি ⚠️",color:"#f59e0b",bar:"w-2/4"};
    return {level:3,label:"শক্তিশালী ✅",color:"#22c55e",bar:"w-full"};
  }
  const strength=pwStrength(form.password);

  // ── Auto-generate strong password ─────────────────────────────────────────
  function generatePw(){
    const upper="ABCDEFGHJKLMNPQRSTUVWXYZ";
    const lower="abcdefghjkmnpqrstuvwxyz";
    const digits="23456789";
    const special="@#$!";
    const pool=upper+lower+digits+special;
    let pw=upper[Math.floor(Math.random()*upper.length)]+lower[Math.floor(Math.random()*lower.length)]+digits[Math.floor(Math.random()*digits.length)]+special[Math.floor(Math.random()*special.length)];
    for(let i=4;i<12;i++) pw+=pool[Math.floor(Math.random()*pool.length)];
    pw=pw.split("").sort(()=>Math.random()-0.5).join("");
    setForm(f=>({...f,password:pw,confirm:pw}));
    setShowPw(true);
  }

  // ── Username validation ────────────────────────────────────────────────────
  function usernameError(u:string):string{
    if(!u) return "";
    if(u.length<3) return "কমপক্ষে ৩ অক্ষর লিখুন";
    if(/\s/.test(u)) return "স্পেস ব্যবহার করা যাবে না";
    if(!/^[A-Za-z0-9_\-.]+$/.test(u)) return "শুধু A-Z, 0-9, _ . - ব্যবহার করুন";
    return "";
  }
  const unameErr=usernameError(form.username);
  const pwMismatch=form.confirm&&form.password!==form.confirm;
  const canSubmit=!unameErr&&form.username.length>=3&&form.password.length>=6&&!pwMismatch&&strength.level>=1;

  async function handleAdd(e:React.FormEvent){
    e.preventDefault();
    if(!canSubmit) return;
    if(strength.level===1){const ok=confirm("পাসওয়ার্ড দুর্বল। তবুও কি তৈরি করবেন?");if(!ok)return;}
    setSaving(true); setErr("");
    try{
      await api.post("/auth/users",{username:form.username,password:form.password,role:form.role});
      setForm({username:"",password:"",confirm:"",role:"user"});
      setShowPw(false); setShowAdd(false); await loadUsers();
    }catch(ex:any){setErr(ex.message);}finally{setSaving(false);}
  }

  async function handleSuspend(u:ManagedUser){
    setActionLoading(u.id);
    try{await api.patch(`/auth/users/${u.id}`,{isActive:!u.isActive});await loadUsers();}
    catch(ex:any){alert(ex.message);}finally{setActionLoading(null);}
  }
  async function handleRoleToggle(u:ManagedUser){
    setActionLoading(u.id);
    try{await api.patch(`/auth/users/${u.id}`,{role: u.role==="admin"?"user":"admin"});await loadUsers();}
    catch(ex:any){alert(ex.message);}finally{setActionLoading(null);}
  }
  async function handleRemove(u:ManagedUser){
    setActionLoading(u.id);
    try{await api.del(`/auth/users/${u.id}`);setConfirmDelete(null);await loadUsers();}
    catch(ex:any){alert(ex.message);}finally{setActionLoading(null);}
  }
  async function generateInvite(){
    setGenerating(true);
    try{
      const{token,expiresAt}=await api.post("/auth/invite",{});
      const base=window.location.origin+window.location.pathname;
      setInviteInfo({link:`${base}#invite/${token}`,expiresAt});
    }
    catch(ex:any){alert(ex.message);}finally{setGenerating(false);}
  }
  function copyLink(txt:string){navigator.clipboard.writeText(txt);setCopied(true);setTimeout(()=>setCopied(false),2000);}

  function fmtExpiry(iso:string){
    const ms=new Date(iso).getTime()-Date.now();
    if(ms<=0) return "মেয়াদ শেষ";
    const h=Math.floor(ms/3600000); const m=Math.floor((ms%3600000)/60000);
    return `${h} ঘণ্টা ${m} মিনিট বাকি`;
  }

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-4">

      {/* Delete confirm modal */}
      {confirmDelete&&(
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-red-700/60 rounded-2xl p-6 max-w-sm w-full shadow-2xl">
            <div className="text-4xl mb-3 text-center">⚠️</div>
            <h3 className="text-white font-bold text-lg text-center mb-1">ইউজার মুছে ফেলবেন?</h3>
            <p className="text-slate-400 text-sm text-center mb-1">
              <span className="text-white font-bold">@{confirmDelete.username}</span> চিরতরে মুছে যাবে।
            </p>
            <p className="text-red-400 text-xs text-center mb-5">এটি আর ফেরানো যাবে না। তার active session এখনই বন্ধ হয়ে যাবে।</p>
            <div className="flex gap-3">
              <button onClick={()=>setConfirmDelete(null)} className="flex-1 bg-slate-700 hover:bg-slate-600 text-white text-sm font-medium py-2.5 rounded-xl transition">বাতিল</button>
              <button onClick={()=>handleRemove(confirmDelete)} disabled={actionLoading===confirmDelete.id}
                className="flex-1 bg-red-700 hover:bg-red-600 disabled:opacity-50 text-white text-sm font-bold py-2.5 rounded-xl transition">
                {actionLoading===confirmDelete.id?"মুছছে…":"হ্যাঁ, মুছে দিন"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-white">👥 ইউজার ম্যানেজমেন্ট</h1>
          <p className="text-slate-500 text-xs mt-0.5">Admin-only · নিরাপদ JWT · Single-device session</p>
        </div>
        <div className="flex gap-2">
          <button onClick={generateInvite} disabled={generating}
            className="bg-purple-700 hover:bg-purple-600 disabled:opacity-50 text-white text-xs font-medium px-3 py-2 rounded-xl transition flex items-center gap-1.5">
            {generating?<><span className="animate-spin">⏳</span> তৈরি হচ্ছে…</>:<>🔗 ইনভাইট লিংক</>}
          </button>
          <button onClick={()=>{setShowAdd(!showAdd);setErr("");}}
            className={`text-xs font-bold px-4 py-2 rounded-xl transition ${showAdd?"bg-slate-700 text-slate-300 hover:bg-slate-600":"bg-blue-600 hover:bg-blue-500 text-white"}`}>
            {showAdd?"✕ বাতিল":"＋ নতুন ইউজার"}
          </button>
        </div>
      </div>

      {/* Invite link panel */}
      {inviteInfo&&(
        <div className="bg-purple-900/20 border border-purple-600/40 rounded-2xl p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="text-purple-300 text-sm font-bold">🔗 ইনভাইট লিংক তৈরি হয়েছে</p>
            <button onClick={()=>setInviteInfo(null)} className="text-slate-500 hover:text-slate-300 text-xl leading-none">✕</button>
          </div>
          <div className="flex gap-2 mb-2">
            <input value={inviteInfo.link} readOnly className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-slate-300 text-xs font-mono focus:outline-none select-all"/>
            <button onClick={()=>copyLink(inviteInfo.link)} className={`text-white text-xs font-bold px-4 py-2 rounded-xl transition whitespace-nowrap ${copied?"bg-green-700":"bg-purple-700 hover:bg-purple-600"}`}>
              {copied?"✅ Copied!":"📋 কপি"}
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs mt-2">
            <div className="bg-amber-900/20 border border-amber-700/30 rounded-lg px-3 py-2">
              <div className="text-amber-400 font-semibold">⏱️ {fmtExpiry(inviteInfo.expiresAt)}</div>
              <div className="text-slate-600 mt-0.5">মেয়াদ শেষ: {new Date(inviteInfo.expiresAt).toLocaleTimeString("bn-BD")}</div>
            </div>
            <div className="bg-blue-900/20 border border-blue-700/30 rounded-lg px-3 py-2">
              <div className="text-blue-400 font-semibold">🔒 একবারই ব্যবহার হবে</div>
              <div className="text-slate-600 mt-0.5">Register করলেই link বাতিল</div>
            </div>
          </div>
        </div>
      )}

      {/* Add user form */}
      {showAdd&&(
        <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-5">
          <h2 className="text-white font-bold mb-1">➕ নতুন ইউজার তৈরি করুন</h2>
          <p className="text-slate-500 text-xs mb-4">সব তথ্য সঠিকভাবে পূরণ করুন। পাসওয়ার্ড কমপক্ষে ৬ অক্ষর হতে হবে।</p>
          {err&&(
            <div className="mb-4 p-3 bg-red-900/30 border border-red-700/60 rounded-xl flex items-start gap-2">
              <span className="text-red-400 text-lg">⚠️</span>
              <span className="text-red-300 text-sm">{err}</span>
            </div>
          )}
          <form onSubmit={handleAdd} className="space-y-4">

            {/* Username */}
            <div>
              <label className="block text-slate-300 text-xs font-semibold mb-1.5">👤 ইউজারনেম</label>
              <input type="text" value={form.username} onChange={e=>setForm(f=>({...f,username:e.target.value}))}
                className={`w-full bg-slate-900 border rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none transition ${unameErr?"border-red-600 focus:border-red-500":"border-slate-600 focus:border-blue-500"}`}
                placeholder="যেমন: Rahman_01" required autoComplete="off"/>
              {unameErr&&<p className="text-red-400 text-xs mt-1">⚠️ {unameErr}</p>}
              {!unameErr&&form.username.length>=3&&<p className="text-green-500 text-xs mt-1">✅ ঠিক আছে</p>}
              <p className="text-slate-600 text-[10px] mt-1">A-Z, 0-9, _ . - ব্যবহার করুন। স্পেস দেওয়া যাবে না।</p>
            </div>

            {/* Password */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-slate-300 text-xs font-semibold">🔑 পাসওয়ার্ড</label>
                <button type="button" onClick={generatePw}
                  className="text-[10px] font-bold px-2.5 py-1 rounded-lg bg-emerald-900/30 text-emerald-400 hover:bg-emerald-900/50 border border-emerald-700/40 transition">
                  ⚡ অটো তৈরি করুন
                </button>
              </div>
              <div className="relative">
                <input type={showPw?"text":"password"} value={form.password}
                  onChange={e=>setForm(f=>({...f,password:e.target.value}))}
                  className="w-full bg-slate-900 border border-slate-600 focus:border-blue-500 rounded-xl px-4 py-2.5 pr-20 text-white text-sm font-mono focus:outline-none transition"
                  placeholder="কমপক্ষে ৮ অক্ষর" required/>
                <button type="button" onClick={()=>setShowPw(v=>!v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 text-xs font-bold transition select-none">
                  {showPw?"🙈 লুকান":"👁️ দেখুন"}
                </button>
              </div>
              {form.password&&(
                <div className="mt-2">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] text-slate-500">পাসওয়ার্ডের শক্তি:</span>
                    <span className="text-[10px] font-bold" style={{color:strength.color}}>{strength.label}</span>
                  </div>
                  <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                    <div className={`h-full rounded-full transition-all duration-300 ${strength.bar}`} style={{background:strength.color}}/>
                  </div>
                  {strength.level===1&&<p className="text-amber-500 text-[10px] mt-1">💡 বড় হাতের অক্ষর, সংখ্যা ও চিহ্ন যোগ করুন</p>}
                  {strength.level===3&&<p className="text-green-500 text-[10px] mt-1">✅ চমৎকার পাসওয়ার্ড!</p>}
                </div>
              )}
            </div>

            {/* Confirm password */}
            <div>
              <label className="block text-slate-300 text-xs font-semibold mb-1.5">🔄 পাসওয়ার্ড নিশ্চিত করুন</label>
              <input type={showPw?"text":"password"} value={form.confirm}
                onChange={e=>setForm(f=>({...f,confirm:e.target.value}))}
                className={`w-full bg-slate-900 border rounded-xl px-4 py-2.5 text-white text-sm font-mono focus:outline-none transition ${pwMismatch?"border-red-600":"border-slate-600 focus:border-blue-500"}`}
                placeholder="একই পাসওয়ার্ড আবার লিখুন"/>
              {pwMismatch&&<p className="text-red-400 text-xs mt-1">⚠️ পাসওয়ার্ড মিলছে না</p>}
              {form.confirm&&!pwMismatch&&<p className="text-green-500 text-xs mt-1">✅ মিলেছে</p>}
            </div>

            {/* Role */}
            <div>
              <label className="block text-slate-300 text-xs font-semibold mb-1.5">🎭 ভূমিকা (Role)</label>
              <div className="grid grid-cols-2 gap-2">
                {([["user","👤 User","শুধু Master Sheet দেখবে"],["admin","⭐ Admin","সব কিছু দেখবে ও নিয়ন্ত্রণ করবে"]] as const).map(([v,label,desc])=>(
                  <button type="button" key={v} onClick={()=>setForm(f=>({...f,role:v}))}
                    className={`rounded-xl p-3 text-left border transition ${form.role===v?"border-blue-500 bg-blue-900/20":"border-slate-700 bg-slate-900/40 hover:border-slate-500"}`}>
                    <div className={`text-sm font-bold ${form.role===v?"text-blue-300":"text-slate-300"}`}>{label}</div>
                    <div className="text-[10px] text-slate-500 mt-0.5">{desc}</div>
                  </button>
                ))}
              </div>
            </div>

            <button type="submit" disabled={saving||!canSubmit}
              className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold py-3 rounded-xl transition text-sm">
              {saving?"⏳ তৈরি হচ্ছে…":"✅ ইউজার তৈরি করুন"}
            </button>
          </form>
        </div>
      )}

      {/* Security info */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {[["🔒","JWT ৪৮ ঘণ্টায় expire"],["📱","Single-device login"],["🚫","Open registration বন্ধ"],["🛡️","Suspend করলে session বাতিল"]].map(([i,t])=>(
          <div key={t} className="flex items-center gap-2 bg-slate-800/40 border border-slate-700/30 rounded-xl px-3 py-2">
            <span className="text-base">{i}</span><span className="text-xs text-slate-500">{t}</span>
          </div>
        ))}
      </div>

      {/* User list */}
      {loading?<div className="text-center text-slate-400 py-8">⏳ ইউজার লোড হচ্ছে…</div>:(
        <div className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden">
          <div className="px-5 py-3 border-b border-slate-700 flex items-center justify-between">
            <span className="text-slate-400 text-xs font-semibold uppercase tracking-wide">মোট ইউজার: {users.length} জন</span>
            <button onClick={loadUsers} className="text-slate-600 hover:text-slate-400 text-xs transition">🔄 রিফ্রেশ</button>
          </div>
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-700 text-slate-500 text-xs uppercase tracking-wide bg-slate-800/80">
              <th className="text-left px-5 py-3">ইউজার</th>
              <th className="text-left px-5 py-3">Role</th>
              <th className="text-left px-5 py-3">অবস্থা</th>
              <th className="text-left px-5 py-3 hidden sm:table-cell">শেষ Login</th>
              <th className="text-right px-5 py-3">নিয়ন্ত্রণ</th>
            </tr></thead>
            <tbody>{users.map(u=>(
              <tr key={u.id} className="border-b border-slate-700/50 hover:bg-slate-700/20 transition-colors">
                <td className="px-5 py-3">
                  <div className="flex items-center gap-2.5">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white ${u.role==="admin"?"bg-orange-700":"bg-slate-600"}`}>{u.username[0]?.toUpperCase()}</div>
                    <div>
                      <div className="text-white font-semibold text-sm">{u.username}{u.id===currentUserId&&<span className="ml-2 text-[10px] text-blue-400 bg-blue-900/30 px-1.5 py-0.5 rounded-full">আপনি</span>}</div>
                      <div className="text-slate-600 text-[10px]">ID #{u.id}</div>
                    </div>
                  </div>
                </td>
                <td className="px-5 py-3">
                  <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${u.role==="admin"?"bg-orange-900/30 text-orange-300 border border-orange-700/50":"bg-slate-700 text-slate-300 border border-slate-600"}`}>
                    {u.role==="admin"?"⭐ admin":"👤 user"}
                  </span>
                </td>
                <td className="px-5 py-3">
                  <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${u.isActive?"bg-green-900/30 text-green-300 border border-green-700/50":"bg-red-900/30 text-red-300 border border-red-700/50"}`}>
                    {u.isActive?"🟢 Active":"🔴 Suspended"}
                  </span>
                </td>
                <td className="px-5 py-3 text-slate-500 text-xs hidden sm:table-cell">{u.lastLogin?new Date(u.lastLogin).toLocaleString("bn-BD"):"কখনো না"}</td>
                <td className="px-5 py-3">
                  {u.id!==currentUserId?(
                    <div className="flex items-center justify-end gap-1.5 flex-wrap">
                      <button onClick={()=>handleRoleToggle(u)} disabled={actionLoading===u.id}
                        className={`text-[11px] font-bold px-2.5 py-1.5 rounded-lg transition border disabled:opacity-40 ${u.role==="admin"
                          ?"bg-orange-900/20 text-orange-400 hover:bg-orange-900/40 border-orange-700/50"
                          :"bg-purple-900/20 text-purple-300 hover:bg-purple-900/40 border-purple-600/50"}`}>
                        {actionLoading===u.id?"…":u.role==="admin"?"👤 Demote":"⭐ Admin"}
                      </button>
                      <button onClick={()=>handleSuspend(u)} disabled={actionLoading===u.id}
                        className={`text-[11px] font-bold px-2.5 py-1.5 rounded-lg transition border disabled:opacity-40 ${u.isActive
                          ?"bg-amber-900/20 text-amber-400 hover:bg-amber-900/40 border-amber-700/50"
                          :"bg-green-900/20 text-green-400 hover:bg-green-900/40 border-green-700/50"}`}>
                        {actionLoading===u.id?"…":u.isActive?"⏸ Suspend":"▶ Unsuspend"}
                      </button>
                      <button onClick={()=>setConfirmDelete(u)} disabled={actionLoading===u.id}
                        className="text-[11px] font-bold px-2.5 py-1.5 rounded-lg transition border bg-red-900/20 text-red-400 hover:bg-red-900/40 border-red-700/50 disabled:opacity-40">
                        🗑️
                      </button>
                    </div>
                  ):(
                    <span className="text-slate-700 text-xs text-right block">—</span>
                  )}
                </td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── Settings View ────────────────────────────────────────────────────────────
function SettingsView({ user }: { user: AuthUser }) {
  const [curr,setCurr]=useState(""); const [newPw,setNewPw]=useState(""); const [conf,setConf]=useState("");
  const [saving,setSaving]=useState(false); const [msg,setMsg]=useState(""); const [err,setErr]=useState("");

  const [emailVal,setEmailVal]=useState(""); const [emailSaving,setEmailSaving]=useState(false);
  const [emailMsg,setEmailMsg]=useState(""); const [emailErr,setEmailErr]=useState("");

  const [admLoading,setAdmLoading]=useState(false);
  const [admMsg,setAdmMsg]=useState("");
  const [statFreq,setStatFreq]=useState(40);
  const [markov,setMarkov]=useState(40);
  const [humanFilter,setHumanFilter]=useState(20);
  const [dataWindow,setDataWindow]=useState<30|60|90|180>(90);
  const [singleDevice,setSingleDevice]=useState(true);
  const [specialDraw,setSpecialDraw]=useState(false);
  const [blockVpn,setBlockVpn]=useState(false);
  const [openaiKey,setOpenaiKey]=useState("");
  const [showKey,setShowKey]=useState(false);
  const [logs,setLogs]=useState<Array<{ts:number;level:string;msg:string}>>([]);
  const [logsLoading,setLogsLoading]=useState(false);
  const [restartPending,setRestartPending]=useState(false);
  const [restarting,setRestarting]=useState(false);
  const [ocrRemap,setOcrRemap]=useState("{}");
  const [inviteTtl,setInviteTtl]=useState(24);
  const [exportLoading,setExportLoading]=useState(false);
  const [importLoading,setImportLoading]=useState(false);
  const [importMsg,setImportMsg]=useState("");
  const [auditLogs,setAuditLogs]=useState<Array<{id:number;username:string|null;action:string;ip:string|null;success:boolean;detail:string|null;createdAt:string}>>([]);
  const [auditLoading,setAuditLoading]=useState(false);
  const [emailBackupLoading,setEmailBackupLoading]=useState(false);
  const [emailBackupMsg,setEmailBackupMsg]=useState("");
  const [supportUrl,setSupportUrl]=useState("");
  const [secAlertsEnabled,setSecAlertsEnabled]=useState(true);
  const [alertEmail,setAlertEmail]=useState("");
  const [alertMinSeverity,setAlertMinSeverity]=useState("medium");
  const [testAlertLoading,setTestAlertLoading]=useState(false);
  const [testAlertMsg,setTestAlertMsg]=useState("");
  const [recoveryEmail,setRecoveryEmail]=useState("");
  const [recoverySaving,setRecoverySaving]=useState(false);
  const [recoveryMsg,setRecoveryMsg]=useState("");

  useEffect(()=>{
    (async()=>{
      try{ const p=await api.get("/auth/me"); setEmailVal(p.email??""); }catch{}
    })();
  },[]);

  useEffect(()=>{
    if(user.role!=="admin") return;
    (async()=>{
      setAdmLoading(true);
      try{
        const d=await api.get("/admin/settings");
        const w=d.algo_weights??{};
        setStatFreq(w.statFreq??40); setMarkov(w.markov??40); setHumanFilter(w.humanFilter??20);
        setDataWindow((d.data_window??90) as 30|60|90|180);
        setSingleDevice(d.single_device_login??true);
        setSpecialDraw(d.special_draw_mode??false);
        setBlockVpn(d.block_vpn_proxy??false);
        if(d.openai_set) setOpenaiKey("__SET__");
        setOcrRemap(typeof d.ocr_remap==="object"?JSON.stringify(d.ocr_remap,null,2):String(d.ocr_remap??"{}"));
        setInviteTtl(d.invite_ttl_hours??720);
        setSupportUrl(d.support_url??"");
        setSecAlertsEnabled(d.security_alerts_enabled!==false);
        setAlertEmail(d.alert_email??"");
        setAlertMinSeverity(d.security_alert_min_severity??"medium");
        setRecoveryEmail(d.recovery_email??"");
      }catch{}
      finally{setAdmLoading(false);}
    })();
  },[user.role]);

  async function saveSettings(patch:Record<string,unknown>){
    try{
      await api.post("/admin/settings",patch);
      setAdmMsg("✅ Saved"); setTimeout(()=>setAdmMsg(""),2000);
    }catch(e:any){ setAdmMsg(`❌ ${e.message}`); setTimeout(()=>setAdmMsg(""),3000); }
  }

  async function fetchLogs(){
    setLogsLoading(true);
    try{const d=await api.get("/admin/logs"); setLogs(d.logs??[]);}catch{}
    finally{setLogsLoading(false);}
  }

  async function handleRestart(){
    setRestarting(true);
    try{await api.post("/admin/restart",{});}catch{}
    setTimeout(()=>{setRestarting(false);setRestartPending(false);},4000);
  }

  async function handleExport(fmt:"json"|"csv"){
    setExportLoading(true);
    try{
      const d=await api.get(`/admin/export?format=${fmt}`);
      const blob=fmt==="csv"
        ?new Blob([d.csvContent],{type:"text/csv"})
        :new Blob([JSON.stringify({version:d.version,exportedAt:d.exportedAt,rows:d.rows},null,2)],{type:"application/json"});
      const url=URL.createObjectURL(blob);
      const a=document.createElement("a"); a.href=url; a.download=d.filename; a.click();
      URL.revokeObjectURL(url);
      setAdmMsg(`✅ Exported ${d.totalRows} draws`); setTimeout(()=>setAdmMsg(""),2500);
    }catch(e:any){setAdmMsg(`❌ Export failed: ${e.message}`);}
    finally{setExportLoading(false);}
  }

  async function handleImport(file:File){
    setImportLoading(true); setImportMsg("");
    try{
      const text=await file.text(); const json=JSON.parse(text);
      const rows=json.rows??(Array.isArray(json)?json:[]);
      if(!rows.length){setImportMsg("❌ No rows found in file.");return;}
      const result=await api.post("/admin/import",{rows});
      setImportMsg(`✅ Imported ${result.inserted} rows (${result.skipped} skipped / duplicate)`);
    }catch(e:any){setImportMsg(`❌ ${e.message}`);}
    finally{setImportLoading(false);}
  }

  async function handleChange(e:React.FormEvent){
    e.preventDefault(); if(newPw!==conf){setErr("Passwords do not match");return;}
    setSaving(true); setErr(""); setMsg("");
    try{await api.post("/auth/change-password",{currentPassword:curr,newPassword:newPw});setMsg("Password changed!");setCurr("");setNewPw("");setConf("");}
    catch(ex:any){setErr(ex.message);}finally{setSaving(false);}
  }

  async function fetchAuditLogs(){
    setAuditLoading(true);
    try{const d=await api.get("/admin/audit-logs?limit=100"); setAuditLogs(d.logs??[]);}catch{}
    finally{setAuditLoading(false);}
  }

  async function handleEmailBackup(){
    setEmailBackupLoading(true); setEmailBackupMsg("");
    try{
      const d=await api.post("/admin/email-backup",{});
      setEmailBackupMsg(`✅ ${d.message}`);
    }catch(e:any){setEmailBackupMsg(`❌ ${e.message}`);}
    finally{setEmailBackupLoading(false);}
  }

  async function handleEmailSave(e:React.FormEvent){
    e.preventDefault(); setEmailSaving(true); setEmailErr(""); setEmailMsg("");
    try{
      await api.patch("/auth/profile",{email:emailVal});
      setEmailMsg("✅ Recovery email saved!");
      setTimeout(()=>setEmailMsg(""),3000);
    }catch(ex:any){setEmailErr(ex.message);}finally{setEmailSaving(false);}
  }

  const wTotal=statFreq+markov+humanFilter;

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-5">
      <h1 className="text-2xl font-bold text-white">⚙️ Settings</h1>
      {admMsg&&<div className={`p-3 rounded-lg border text-sm ${admMsg.startsWith("✅")?"bg-green-900/30 border-green-700 text-green-300":"bg-red-900/30 border-red-700 text-red-300"}`}>{admMsg}</div>}

      {/* Change Password */}
      <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
        <div className="flex items-center gap-3 mb-5 pb-5 border-b border-slate-700">
          <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-xl">{user.username[0]?.toUpperCase()}</div>
          <div><div className="text-white font-semibold">{user.username}</div><div className="text-slate-400 text-sm capitalize">{user.role}</div></div>
        </div>
        <h2 className="text-white font-semibold mb-4">🔑 Change Password</h2>
        {msg&&<div className="mb-3 p-3 bg-green-900/30 border border-green-700 rounded-lg text-green-300 text-sm">✅ {msg}</div>}
        {err&&<div className="mb-3 p-3 bg-red-900/30 border border-red-700 rounded-lg text-red-300 text-sm">{err}</div>}
        <form onSubmit={handleChange} className="space-y-3">
          {([["curr","Current Password",curr,setCurr],["new","New Password (min 6 chars)",newPw,setNewPw],["conf","Confirm New Password",conf,setConf]] as const).map(([k,l,v,sv])=>(
            <div key={k}><label className="block text-slate-400 text-xs mb-1">{l}</label>
              <input type="password" value={v} onChange={e=>(sv as any)(e.target.value)} className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500" required/></div>
          ))}
          <button type="submit" disabled={saving} className="w-full bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-medium text-sm py-2.5 rounded-lg transition mt-2">{saving?"Changing…":"Change Password"}</button>
        </form>
      </div>

      {/* Recovery Email */}
      <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
        <h2 className="text-white font-semibold mb-1">📧 Recovery Email</h2>
        <p className="text-slate-500 text-xs mb-4">Link an email address to your account for account recovery and ownership verification.</p>
        {emailMsg&&<div className="mb-3 p-3 bg-green-900/30 border border-green-700 rounded-lg text-green-300 text-sm">{emailMsg}</div>}
        {emailErr&&<div className="mb-3 p-3 bg-red-900/30 border border-red-700 rounded-lg text-red-300 text-sm">❌ {emailErr}</div>}
        <form onSubmit={handleEmailSave} className="space-y-3">
          <div>
            <label className="block text-slate-400 text-xs mb-1">Email Address</label>
            <input
              type="email"
              value={emailVal}
              onChange={e=>setEmailVal(e.target.value)}
              placeholder="e.g. yourname@gmail.com"
              className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500 placeholder:text-slate-600"
            />
          </div>
          <button type="submit" disabled={emailSaving} className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-medium text-sm py-2.5 rounded-lg transition">
            {emailSaving?"Saving…":"Save Recovery Email"}
          </button>
        </form>
      </div>

      {user.role==="admin"&&(admLoading?(
        <div className="text-slate-500 text-sm text-center py-8 animate-pulse">Loading admin controls…</div>
      ):(<>

        {/* Engine Tuning */}
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
          <h2 className="text-white font-semibold mb-1">🧠 ইঞ্জিন টিউনিং — Algorithm Weightage</h2>
          <p className="text-slate-500 text-xs mb-4">Adjusts the consensus aggregator weights. Auto-normalised to 100% on save. Takes effect on next prediction request.</p>
          <div className="space-y-4">
            {([
              ["LSTM / Stat Frequency","Position-based digit frequency analysis (Layer A)",statFreq,setStatFreq],
              ["Markov Chain Predictor","Sequence transition matrix predictor (Layer B)",markov,setMarkov],
              ["Math & Pattern Filters","Human pattern penalty & pair/triplet scoring (Layer C)",humanFilter,setHumanFilter],
            ] as [string,string,number,(v:number)=>void][]).map(([lbl,desc,val,setter])=>(
              <div key={lbl}>
                <div className="flex justify-between items-center mb-0.5">
                  <span className="text-slate-200 text-sm font-medium">{lbl}</span>
                  <span className={`text-sm font-mono font-bold ${wTotal===100?"text-blue-400":"text-yellow-400"}`}>{val}%</span>
                </div>
                <p className="text-slate-600 text-xs mb-2">{desc}</p>
                <input type="range" min={5} max={90} value={val} onChange={e=>setter(Number(e.target.value))} className="w-full accent-blue-500 cursor-pointer h-1"/>
              </div>
            ))}
            <div className={`text-xs font-mono text-right ${wTotal===100?"text-green-400":"text-yellow-400"}`}>
              Total: <strong>{wTotal}%</strong>{wTotal!==100&&` — will be normalised to 100% on save`}
            </div>
          </div>
          <button type="button" onClick={()=>{
            const t=statFreq+markov+humanFilter||100;
            const sf=Math.round(statFreq/t*100); const mk=Math.round(markov/t*100); const hf=100-sf-mk;
            setStatFreq(sf); setMarkov(mk); setHumanFilter(hf);
            saveSettings({algo_weights:{statFreq:sf,markov:mk,humanFilter:hf}});
          }} className="mt-4 w-full bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium py-2 rounded-lg transition">Save Engine Weights</button>
        </div>

        {/* Data Window */}
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
          <h2 className="text-white font-semibold mb-1">📊 ডাটা উইন্ডো কনফিগারেশন — Sliding Window Selector</h2>
          <p className="text-slate-500 text-xs mb-3">Number of historical draws the prediction models analyse per request.</p>
          <select value={dataWindow} onChange={e=>{const v=Number(e.target.value) as 30|60|90|180; setDataWindow(v); saveSettings({data_window:v});}}
            className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500">
            {([30,60,90,180] as const).map(n=><option key={n} value={n}>Last {n} Draws</option>)}
          </select>
        </div>

        {/* System Switches */}
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
          <h2 className="text-white font-semibold mb-1">🔒 সিস্টেম সুইচ — Global Toggles</h2>
          <p className="text-slate-500 text-xs mb-4">Backend-enforced switches. Changes are persisted instantly.</p>
          <div className="space-y-5">
            {([
              {label:"Enforce Single-Device Login",desc:"One active session per account. New login invalidates the previous device immediately.",val:singleDevice,set:(v:boolean)=>{setSingleDevice(v);saveSettings({single_device_login:v});}},
              {label:"Special Draw Optimization Mode",desc:"Weighs historical Tuesday special draws 30% more heavily in the prediction scoring aggregator.",val:specialDraw,set:(v:boolean)=>{setSpecialDraw(v);saveSettings({special_draw_mode:v});}},
              {label:"Block VPN / Proxy Connections",desc:"Rejects requests with proxy signal headers (Via, Proxy-Connection, multi-hop X-Forwarded-For).",val:blockVpn,set:(v:boolean)=>{setBlockVpn(v);saveSettings({block_vpn_proxy:v});}},
            ]).map(({label,desc,val,set})=>(
              <div key={label} className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="text-slate-200 text-sm font-medium">{label}</div>
                  <div className="text-slate-500 text-xs mt-0.5">{desc}</div>
                </div>
                <button type="button" onClick={()=>set(!val)}
                  className={`flex-shrink-0 relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${val?"bg-blue-600":"bg-slate-600"}`}>
                  <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${val?"translate-x-6":"translate-x-1"}`}/>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* API Key Manager */}
        <div className="bg-slate-800 border border-amber-900/50 rounded-2xl p-5">
          <h2 className="text-white font-semibold mb-1">🔐 এপিআই ও সিক্রেট কি ম্যানেজার</h2>
          <p className="text-slate-500 text-xs mb-2">Keys are AES-256-GCM encrypted before storage. Leave blank to keep current value.</p>
          <div className="mb-3 p-2 bg-amber-900/20 border border-amber-800/40 rounded-lg text-amber-400 text-xs">⚠️ Handle with care — updates take effect immediately without a restart.</div>
          <div>
            <label className="block text-slate-400 text-xs mb-1">OpenAI API Key (OCR endpoint)</label>
            <div className="flex gap-2">
              <input type={showKey?"text":"password"} value={openaiKey==="__SET__"?"":openaiKey}
                placeholder={openaiKey==="__SET__"?"●●●● Currently set — paste new key to replace":"sk-…"}
                onChange={e=>setOpenaiKey(e.target.value)}
                className="flex-1 bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm font-mono focus:outline-none focus:border-blue-500"/>
              <button type="button" onClick={()=>setShowKey(!showKey)}
                className="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-slate-300 text-xs rounded-lg transition">{showKey?"Hide":"Show"}</button>
            </div>
          </div>
          <button type="button" onClick={async()=>{
            if(!openaiKey||openaiKey==="__SET__") return;
            await saveSettings({api_key_openai:openaiKey});
            setOpenaiKey("__SET__");
          }} disabled={!openaiKey||openaiKey==="__SET__"}
            className="mt-3 w-full bg-amber-700 hover:bg-amber-600 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-medium py-2 rounded-lg transition">
            Update &amp; Encrypt API Key
          </button>
        </div>

        {/* Logs & Restart */}
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
          <div className="flex items-start justify-between gap-3 mb-3">
            <div>
              <h2 className="text-white font-semibold">🖥 সার্ভার লগ ও রিস্টার্ট</h2>
              <p className="text-slate-500 text-xs mt-0.5">Live backend log buffer (last 150 entries). Soft reset flushes memory &amp; restarts the Node.js process — the workflow manager brings it back automatically.</p>
            </div>
            <div className="flex gap-2 flex-shrink-0">
              <button type="button" onClick={fetchLogs} disabled={logsLoading}
                className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 text-xs rounded-lg transition">{logsLoading?"…":"↻ Refresh"}</button>
              {!restartPending?(
                <button type="button" onClick={()=>setRestartPending(true)}
                  className="px-3 py-1.5 bg-red-900/40 hover:bg-red-800/50 border border-red-700/50 text-red-300 text-xs rounded-lg transition">Soft Reset</button>
              ):(
                <div className="flex gap-1">
                  <button type="button" onClick={handleRestart} disabled={restarting}
                    className="px-3 py-1.5 bg-red-700 hover:bg-red-600 disabled:opacity-60 text-white text-xs rounded-lg transition">{restarting?"Restarting…":"Confirm Reset"}</button>
                  <button type="button" onClick={()=>setRestartPending(false)}
                    className="px-3 py-1.5 bg-slate-700 text-slate-400 text-xs rounded-lg">Cancel</button>
                </div>
              )}
            </div>
          </div>
          <div className="bg-slate-950 border border-slate-700 rounded-lg h-60 overflow-y-auto p-3 font-mono text-xs">
            {logs.length===0?(
              <span className="text-slate-600">No entries captured yet — click ↻ Refresh to load.</span>
            ):logs.map((l,i)=>(
              <div key={i} className="mb-0.5 leading-5">
                <span className="text-slate-600">{new Date(l.ts).toLocaleTimeString()}</span>
                <span className={`mx-1.5 font-bold ${l.level==="ERROR"||l.level==="FATAL"?"text-red-500":l.level==="WARN"?"text-yellow-500":"text-blue-500"}`}>[{l.level}]</span>
                <span className={l.level==="ERROR"||l.level==="FATAL"?"text-red-300":l.level==="WARN"?"text-yellow-300":"text-slate-400"}>{l.msg}</span>
              </div>
            ))}
          </div>
        </div>

        {/* OCR Digit Remapping */}
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
          <h2 className="text-white font-semibold mb-1">🔤 OCR Digit Remapping</h2>
          <p className="text-slate-500 text-xs mb-3">JSON map applied after every OCR scan to auto-correct common misreads. Example: <code className="bg-slate-900 px-1 rounded text-slate-300">{`{"O":"0","I":"1","S":"5"}`}</code></p>
          <textarea value={ocrRemap} onChange={e=>setOcrRemap(e.target.value)} rows={4}
            className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2.5 text-white text-xs font-mono resize-none focus:outline-none focus:border-blue-500"/>
          <button type="button" onClick={()=>{
            try{const v=JSON.parse(ocrRemap); saveSettings({ocr_remap:v});}
            catch{setAdmMsg("❌ Invalid JSON — check the remap map format"); setTimeout(()=>setAdmMsg(""),3000);}
          }} className="mt-2 w-full bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium py-2 rounded-lg transition">Save OCR Remap</button>
        </div>

        {/* Invite Auto-Expiry */}
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
          <h2 className="text-white font-semibold mb-1">⏱ Invite Link মেয়াদ (TTL)</h2>
          <p className="text-slate-500 text-xs mb-3">
            নতুন invite link কত ঘণ্টা পর expire হবে।
            <span className="text-green-400 font-semibold"> 0 = কখনো Expire নয়।</span>
            {" "}বর্তমান: <strong className="text-white">{inviteTtl===0?"♾ কখনো Expire নয়":`${inviteTtl} ঘণ্টা`}</strong>
          </p>
          <div className="flex gap-2 items-center flex-wrap">
            {/* Quick presets */}
            {[{label:"১ দিন",h:24},{label:"৭ দিন",h:168},{label:"৩০ দিন",h:720},{label:"১ বছর",h:8760},{label:"♾ কখনো না",h:0}].map(({label,h})=>(
              <button key={h} type="button"
                onClick={()=>setInviteTtl(h)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition border ${inviteTtl===h?"bg-blue-600 border-blue-500 text-white":"bg-slate-700 border-slate-600 text-slate-300 hover:border-blue-500 hover:text-white"}`}>
                {label}
              </button>
            ))}
          </div>
          <div className="flex gap-2 items-center mt-3">
            <input type="number" min={0} max={8760} value={inviteTtl}
              onChange={e=>setInviteTtl(Math.max(0,Math.min(8760,Number(e.target.value))))}
              className="w-28 bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"/>
            <span className="text-slate-500 text-sm">ঘণ্টা {inviteTtl===0&&<span className="text-green-400">(= কখনো Expire নয়)</span>}</span>
            <button type="button" onClick={()=>saveSettings({invite_ttl_hours:inviteTtl})}
              className="ml-auto px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition">Save</button>
          </div>
        </div>

        {/* Backup & Restore */}
        <div className="bg-slate-800 border border-emerald-900/50 rounded-2xl p-5">
          <h2 className="text-white font-semibold mb-1">💾 Backup &amp; Restore</h2>
          <p className="text-slate-500 text-xs mb-4">Full export of all 4D draw data from the database. Recommended: weekly backup. On import, duplicate draws (same company + date) are silently skipped — no data is overwritten.</p>
          <div className="grid grid-cols-2 gap-2 mb-4">
            <button type="button" onClick={()=>handleExport("json")} disabled={exportLoading}
              className="flex items-center justify-center gap-2 py-2.5 bg-emerald-700 hover:bg-emerald-600 disabled:opacity-50 text-white text-sm font-medium rounded-lg transition">
              {exportLoading?"Exporting…":"⬇ Export JSON"}
            </button>
            <button type="button" onClick={()=>handleExport("csv")} disabled={exportLoading}
              className="flex items-center justify-center gap-2 py-2.5 bg-teal-700 hover:bg-teal-600 disabled:opacity-50 text-white text-sm font-medium rounded-lg transition">
              {exportLoading?"Exporting…":"⬇ Export CSV"}
            </button>
          </div>
          <div>
            <label className="block text-slate-400 text-xs mb-1.5">Restore from JSON backup file</label>
            <input type="file" accept=".json" disabled={importLoading} onChange={async e=>{
              const file=e.target.files?.[0]; if(!file) return;
              await handleImport(file); e.target.value="";
            }} className="w-full text-sm text-slate-400 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-blue-700 file:text-white file:cursor-pointer hover:file:bg-blue-600 disabled:opacity-50"/>
            {importMsg&&<div className={`mt-2 text-xs p-2 rounded-lg ${importMsg.startsWith("✅")?"bg-green-900/30 text-green-300":"bg-red-900/30 text-red-300"}`}>{importMsg}</div>}
          </div>
        </div>

        {/* Help & Support URL */}
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
          <h2 className="text-white font-semibold mb-1">💬 Help &amp; Support Link</h2>
          <p className="text-slate-500 text-xs mb-3">Paste your WhatsApp Business or Facebook page URL. A "Help &amp; Support" button will appear in the sidebar for all users.</p>
          <div className="flex gap-2">
            <input type="url" value={supportUrl} onChange={e=>setSupportUrl(e.target.value)}
              placeholder="https://wa.me/601234567890 or https://fb.com/yourpage"
              className="flex-1 bg-slate-900 border border-slate-600 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500 placeholder:text-slate-600"/>
            <button type="button" onClick={()=>saveSettings({support_url:supportUrl})}
              className="px-5 py-2 bg-green-700 hover:bg-green-600 text-white text-sm font-medium rounded-lg transition whitespace-nowrap">Save</button>
          </div>
        </div>

        {/* Recovery Email */}
        <div className="bg-slate-800 border border-violet-900/40 rounded-2xl p-5 space-y-4">
          <div className="flex items-center gap-2">
            <span className="text-xl">🛟</span>
            <div>
              <h2 className="text-white font-semibold">Recovery Email (২য় জিমেল)</h2>
              <p className="text-slate-500 text-xs mt-0.5">Backup email যেখানে সকল alert ও data backup copy যাবে। মূল Gmail হারিয়ে গেলেও এই email থেকে সব পাবেন।</p>
            </div>
          </div>

          <div>
            <label className="block text-slate-400 text-xs mb-1.5">Recovery Gmail Address</label>
            <div className="flex gap-2">
              <input
                type="email"
                value={recoveryEmail}
                onChange={e=>setRecoveryEmail(e.target.value)}
                placeholder="your.backup@gmail.com"
                className="flex-1 bg-slate-900 border border-slate-600 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-violet-500 placeholder:text-slate-600"
              />
              <button
                type="button"
                disabled={recoverySaving}
                onClick={async()=>{
                  setRecoverySaving(true); setRecoveryMsg("");
                  try{
                    await saveSettings({recovery_email:recoveryEmail});
                    setRecoveryMsg("✅ Recovery email সেভ হয়েছে");
                  }catch{setRecoveryMsg("❌ সেভ ব্যর্থ হয়েছে");}
                  finally{setRecoverySaving(false);setTimeout(()=>setRecoveryMsg(""),4000);}
                }}
                className="px-4 py-2 bg-violet-700 hover:bg-violet-600 disabled:opacity-50 text-white text-sm font-medium rounded-lg transition whitespace-nowrap"
              >{recoverySaving?"Saving…":"Save"}</button>
            </div>
            {recoveryMsg&&<div className={`mt-2 text-xs px-3 py-2 rounded-lg ${recoveryMsg.startsWith("✅")?"bg-green-900/30 text-green-400 border border-green-800":"bg-red-900/30 text-red-400 border border-red-800"}`}>{recoveryMsg}</div>}
          </div>

          {recoveryEmail&&(
            <div className="bg-slate-900/60 rounded-xl p-3.5 text-xs text-slate-500 space-y-1.5">
              <div className="text-slate-400 font-medium">✅ <span className="text-violet-400 font-mono">{recoveryEmail}</span> সক্রিয়</div>
              <div>• সব <span className="text-slate-400">Security Alerts</span> এই email-এ copy যাবে</div>
              <div>• <span className="text-slate-400">Email Backup</span> পাঠালে এই email-এও backup যাবে</div>
              <div>• মূল Gmail (<span className="text-slate-400">mycbc34@gmail.com</span>) হারিয়ে গেলেও এই email থেকে সব data পাবেন</div>
            </div>
          )}

          {!recoveryEmail&&(
            <div className="bg-yellow-900/10 border border-yellow-900/30 rounded-xl p-3.5 text-xs text-yellow-700">
              ⚠️ Recovery email সেট করা নেই — মূল Gmail হারালে data recovery কঠিন হয়ে যাবে
            </div>
          )}
        </div>

        {/* Email Backup */}
        <div className="bg-slate-800 border border-blue-900/40 rounded-2xl p-5">
          <h2 className="text-white font-semibold mb-1">📨 Email Backup</h2>
          <p className="text-slate-500 text-xs mb-3">Email backup এই offline build-এ ইচ্ছাকৃতভাবে বন্ধ। কোনো Replit, Gmail password, SMS/OTP বা paid backend ব্যবহার করা হচ্ছে না। Local backup ব্যবহার করুন।</p>
          {emailBackupMsg&&<div className={`mb-3 p-3 rounded-lg text-sm ${emailBackupMsg.startsWith("✅")?"bg-green-900/30 border border-green-700 text-green-300":"bg-red-900/30 border border-red-700 text-red-300"}`}>{emailBackupMsg}</div>}
          <button type="button" onClick={handleEmailBackup} disabled={emailBackupLoading}
            className="w-full bg-blue-700 hover:bg-blue-600 disabled:opacity-50 text-white text-sm font-medium py-2.5 rounded-lg transition">
            {emailBackupLoading?"Sending backup…":"📤 Send Backup Email Now"}
          </button>
        </div>

        {/* Security Alert Notifications */}
        <div className="bg-slate-800 border border-orange-900/40 rounded-2xl p-5 space-y-4">
          <div className="flex items-center gap-2">
            <span className="text-xl">🔔</span>
            <div>
              <h2 className="text-white font-semibold">Security Alert Notifications</h2>
              <p className="text-slate-500 text-xs mt-0.5">Brute force, failed logins এবং সন্দেহজনক activity-র জন্য email ও in-app alerts।</p>
            </div>
          </div>

          {/* Enable toggle */}
          <div className="flex items-center justify-between">
            <div>
              <div className="text-slate-300 text-sm font-medium">Security Alerts চালু</div>
              <div className="text-slate-500 text-xs">সন্দেহজনক activity detect হলে in-app bell + email পাঠাবে</div>
            </div>
            <button type="button" onClick={()=>{setSecAlertsEnabled(v=>!v);saveSettings({security_alerts_enabled:!secAlertsEnabled});}}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${secAlertsEnabled?"bg-orange-600":"bg-slate-600"}`}>
              <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${secAlertsEnabled?"translate-x-6":"translate-x-1"}`}/>
            </button>
          </div>

          {/* Alert email */}
          <div>
            <label className="block text-slate-400 text-xs mb-1.5">Alert Email <span className="text-slate-600">(ফাঁকা রাখলে mycbc34@gmail.com ব্যবহার হবে)</span></label>
            <div className="flex gap-2">
              <input type="email" value={alertEmail} onChange={e=>setAlertEmail(e.target.value)}
                placeholder="your@email.com"
                className="flex-1 bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-orange-500 placeholder:text-slate-600"/>
              <button type="button" onClick={()=>saveSettings({alert_email:alertEmail})}
                className="px-4 py-2 bg-orange-700 hover:bg-orange-600 text-white text-sm font-medium rounded-lg transition whitespace-nowrap">Save</button>
            </div>
          </div>

          {/* Min severity */}
          <div>
            <label className="block text-slate-400 text-xs mb-1.5">Minimum Severity (email alert)</label>
            <select value={alertMinSeverity} onChange={e=>{setAlertMinSeverity(e.target.value);saveSettings({security_alert_min_severity:e.target.value});}}
              className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-orange-500">
              <option value="critical">🔴 Critical only</option>
              <option value="high">🟠 High &amp; above</option>
              <option value="medium">🟡 Medium &amp; above</option>
              <option value="info">🔵 All (info &amp; above)</option>
            </select>
          </div>

          {/* Test alert */}
          {testAlertMsg&&<div className={`p-3 rounded-lg text-sm ${testAlertMsg.startsWith("✅")?"bg-green-900/30 border border-green-700 text-green-300":"bg-red-900/30 border border-red-700 text-red-300"}`}>{testAlertMsg}</div>}
          <button type="button" disabled={testAlertLoading} onClick={async()=>{
            setTestAlertLoading(true);setTestAlertMsg("");
            try{const r=await api.post("/admin/security-alerts/test",{});setTestAlertMsg(`✅ ${r.message}`);}
            catch(e:any){setTestAlertMsg(`❌ ${e?.message||"ব্যর্থ হয়েছে"}`);} finally{setTestAlertLoading(false);}
          }} className="w-full bg-orange-900/30 hover:bg-orange-800/40 border border-orange-800/50 text-orange-300 text-sm font-medium py-2.5 rounded-lg transition disabled:opacity-50">
            {testAlertLoading?"পাঠানো হচ্ছে…":"🔔 পরীক্ষামূলক Alert পাঠান"}
          </button>

          {/* Brute force info */}
          <div className="bg-slate-900/60 rounded-xl p-3.5 text-xs text-slate-500 space-y-1">
            <div className="text-slate-400 font-medium mb-1.5">কখন alert আসবে?</div>
            <div>🔴 <span className="text-slate-400">Brute Force:</span> ১০ মিনিটে ৩+ ভুল login চেষ্টা</div>
            <div>🟠 <span className="text-slate-400">Suspended Login:</span> suspended account-এ login চেষ্টা</div>
            <div>🟡 <span className="text-slate-400">Failed Login:</span> প্রতিটি ব্যর্থ login</div>
            <div>🔵 <span className="text-slate-400">New Login:</span> যেকোনো সফল login</div>
          </div>
        </div>

        {/* Security Audit Logs */}
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-white font-semibold">🛡️ Security Audit Log</h2>
              <p className="text-slate-500 text-xs mt-0.5">Login attempts with IP address and timestamp. Last 100 entries.</p>
            </div>
            <button type="button" onClick={fetchAuditLogs} disabled={auditLoading}
              className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 text-xs rounded-lg transition flex-shrink-0">{auditLoading?"…":"↻ Load"}</button>
          </div>
          <div className="bg-slate-950 border border-slate-700 rounded-lg h-64 overflow-y-auto">
            {auditLogs.length===0?(
              <div className="flex items-center justify-center h-full text-slate-600 text-xs">Click ↻ Load to fetch audit log</div>
            ):(
              <table className="w-full text-xs">
                <thead className="sticky top-0 bg-slate-900 border-b border-slate-700">
                  <tr>
                    {["Time","User","IP","Result","Detail"].map(h=><th key={h} className="text-left py-2 px-3 text-slate-500 font-medium">{h}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {auditLogs.map(l=>(
                    <tr key={l.id} className={`border-b border-slate-800/50 ${l.success?"":"bg-red-900/5"}`}>
                      <td className="py-1.5 px-3 text-slate-500 whitespace-nowrap font-mono">{new Date(l.createdAt).toLocaleString()}</td>
                      <td className="py-1.5 px-3 text-slate-300 font-medium">{l.username??"-"}</td>
                      <td className="py-1.5 px-3 text-slate-500 font-mono">{l.ip??"-"}</td>
                      <td className="py-1.5 px-3"><span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${l.success?"bg-green-900/40 text-green-400":"bg-red-900/40 text-red-400"}`}>{l.success?"✓ OK":"✗ FAIL"}</span></td>
                      <td className="py-1.5 px-3 text-slate-500">{l.detail??""}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

      </>))}

      {/* ── PWA Install Guide ── */}
      <div className="rounded-2xl p-5 space-y-4" style={{background:"linear-gradient(135deg,rgba(124,58,237,0.08),rgba(0,0,0,0))",border:"1px solid rgba(124,58,237,0.25)"}}>
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xl">📱</span>
          <h2 className="text-white font-bold">ফোনে App Install করুন</h2>
          <span className="text-[10px] font-black px-2 py-0.5 rounded-full" style={{background:"rgba(124,58,237,0.2)",color:"#c4b5fd",border:"1px solid rgba(124,58,237,0.3)"}}>PWA</span>
        </div>
        <p className="text-zinc-500 text-xs">4D HOSPITAL একটি PWA (Progressive Web App) — আলাদা APK ছাড়াই ফোনে App-এর মতো install করা যাবে।</p>

        {/* Android */}
        <div className="rounded-xl p-4 space-y-2" style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)"}}>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-base">🤖</span>
            <span className="text-green-400 font-bold text-sm">Android (Chrome)</span>
          </div>
          {[
            ["①","Chrome browser-এ app-এর URL খুলুন"],
            ["②","ডানে উপরের ⋮ মেনুতে tap করুন"],
            ["③",'"Add to Home Screen" বা "Install App" select করুন'],
            ["④","Install বা Add বাটনে tap করুন — App icon চলে আসবে Home Screen-এ"],
          ].map(([num,txt])=>(
            <div key={num} className="flex items-start gap-2.5">
              <span className="text-purple-400 font-black text-xs w-5 flex-shrink-0 mt-0.5">{num}</span>
              <span className="text-zinc-400 text-xs">{txt}</span>
            </div>
          ))}
        </div>

        {/* iOS */}
        <div className="rounded-xl p-4 space-y-2" style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)"}}>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-base">🍎</span>
            <span className="text-blue-400 font-bold text-sm">iPhone / iPad (Safari)</span>
          </div>
          {[
            ["①","Safari browser-এ app-এর URL খুলুন (Chrome-এ কাজ করবে না)"],
            ["②","নিচের Share আইকনে ( ⎙ ) tap করুন"],
            ["③",'"Add to Home Screen" অপশনটি select করুন'],
            ["④","নামটি রাখুন এবং Add tap করুন — Home Screen-এ icon দেখাবে"],
          ].map(([num,txt])=>(
            <div key={num} className="flex items-start gap-2.5">
              <span className="text-blue-400 font-black text-xs w-5 flex-shrink-0 mt-0.5">{num}</span>
              <span className="text-zinc-400 text-xs">{txt}</span>
            </div>
          ))}
        </div>

        <div className="rounded-lg px-3 py-2 text-xs text-zinc-600" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.04)"}}>
          💡 Install করার পরে app টি offline-ও কিছুটা কাজ করবে। সব ডেটা আপনার ফোনেই সুরক্ষিত থাকবে।
        </div>
      </div>

    </div>
  );
}

// ─── Research Cycle / Leakage-Safe Validation ────────────────────────────────
function ResearchCycleView({ results, companyId, onApplyBatch }: { results:LotteryResult[]; companyId:CompanyId; onApplyBatch:(cycle:ResearchCycle)=>Promise<void> }) {
  const [cycles,setCycles]=useState<ResearchCycle[]>(()=>loadResearchCycles());
  const [batchSize,setBatchSize]=useState(23), [candidateLimit,setCandidateLimit]=useState(100);
  const [actualText,setActualText]=useState(''), [actualDate,setActualDate]=useState(()=>new Date().toISOString().slice(0,10)), [message,setMessage]=useState('');
  const [selectedId,setSelectedId]=useState(''), [tab,setTab]=useState<'cycle'|'catalog'>('cycle');
  const selected=cycles.find(c=>c.id===selectedId) || cycles.find(c=>c.company===companyId);
  const companyRows=useMemo(()=>results.filter(r=>r.company===companyId),[results,companyId]);
  const currentFingerprint=useMemo(()=>fingerprintDraws(companyRows),[companyRows]);
  const summary=useMemo(()=>cycleSummary(cycles),[cycles]);
  const persist=(next:ResearchCycle[])=>{setCycles(next);saveResearchCycles(next);};
  function lock(){try{const c=createLockedCycle(companyId,companyRows,batchSize,candidateLimit);persist([c,...cycles]);setSelectedId(c.id);setMessage(`🔒 ${c.id} locked হয়েছে। Prediction snapshot এখন immutable historical baseline হিসেবে রাখা হলো।`);}catch(e:any){setMessage(`❌ ${e?.message||'Lock করা যায়নি'}`)}}
  function validate(){if(!selected){setMessage('আগে একটি LOCKED cycle নির্বাচন করুন।');return;}if(selected.status!=='LOCKED'){setMessage('এই cycle ইতিমধ্যে validated।');return;}if(currentFingerprint!==selected.datasetFingerprint){setMessage('🛑 Lock-এর পরে dataset বদলে গেছে। Leakage-safe validation-এর জন্য নতুন cycle তৈরি করুন।');return;}try{const raw=actualText.split(/[\n,;\s]+/).map(x=>x.trim()).filter(Boolean);const v=validateLockedCycle(selected,raw,actualDate);persist(cycles.map(c=>c.id===v.id?v:c));setSelectedId(v.id);setMessage(`✅ Validation complete — ${v.validationFinal?.exactMatches.length||0} exact candidate match.`);}catch(e:any){setMessage(`❌ ${e?.message||'Validation ব্যর্থ'}`)}}
  async function apply(){if(!selected||selected.status!=='VALIDATED'){setMessage('প্রথমে actual batch validate করুন।');return;}if(currentFingerprint!==selected.datasetFingerprint){setMessage('🛑 Dataset ইতিমধ্যে বদলেছে; duplicate/leakage এড়াতে apply বন্ধ।');return;}try{const v=markCycleApplied(selected);await onApplyBatch(v);persist(cycles.map(c=>c.id===v.id?v:c));setSelectedId(v.id);setMessage('✅ Actual batch dataset-এ যোগ হয়েছে। এখন নতুন cycle lock করুন।');}catch(e:any){setMessage(`❌ ${e?.message||'Apply ব্যর্থ'}`)}}
  return <ViewShell title="Research Cycle — Lock → Actual → Validate" subtitle="Prediction leakage বন্ধ রেখে pre-data analysis snapshot, actual trace, এবং cumulative method performance" icon="🧪">
    <div className="flex gap-2 mb-4"><button onClick={()=>setTab('cycle')} className={`px-4 py-2 rounded-xl text-sm font-bold ${tab==='cycle'?'bg-red-600 text-white':'bg-white/5 text-slate-400'}`}>🔒 Research Cycle</button><button onClick={()=>setTab('catalog')} className={`px-4 py-2 rounded-xl text-sm font-bold ${tab==='catalog'?'bg-purple-600 text-white':'bg-white/5 text-slate-400'}`}>📚 107 Analysis Catalog · 28 Active Signals</button></div>
    {tab==='catalog'?<div className="space-y-3"><div className="grid grid-cols-2 md:grid-cols-5 gap-2">{(['descriptive','structural','statistical','predictive','validation'] as const).map(k=><div key={k} className="rounded-xl p-3 bg-white/5 border border-white/10"><div className="text-white font-bold text-sm">{k}</div><div className="text-slate-500 text-xs">{ANALYSIS_CATALOG.filter(x=>x.category===k).length} options</div></div>)}</div><div className="overflow-auto rounded-2xl border border-white/10"><table className="w-full text-sm"><thead><tr className="text-slate-500 bg-white/5"><th className="text-left p-3">#</th><th className="text-left p-3">Division</th><th className="text-left p-3">Analysis Option</th><th className="text-left p-3">Purpose</th><th className="text-left p-3">Implementation</th><th className="text-left p-3">Engine Link</th></tr></thead><tbody>{ANALYSIS_CATALOG.map(x=><tr key={x.id} className="border-t border-white/5"><td className="p-3 text-slate-500">{x.id}</td><td className="p-3 text-purple-300 whitespace-nowrap">{x.division}</td><td className="p-3 text-white font-medium">{x.name}</td><td className="p-3 text-slate-400">{x.purpose}</td><td className="p-3 whitespace-nowrap">{x.implementation==='active-signal'?<span className="text-green-300 text-xs font-bold">ACTIVE SIGNAL</span>:x.implementation==='advanced-metric'?<span className="text-cyan-300 text-xs font-bold">ADVANCED METRIC</span>:x.implementation==='validation'?<span className="text-yellow-300 text-xs font-bold">VALIDATION</span>:<span className="text-slate-500 text-xs">CATALOG / RESEARCH</span>}</td><td className="p-3 text-xs text-slate-400">{x.signalKeys.length?x.signalKeys.map(k=>ACTIVE_SIGNAL_CATALOG.find(s=>s.key===k)?.label??k).join(' · '):'—'}</td></tr>)}</tbody></table></div></div>:<>
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-4">{[['Company',COMPANIES[companyId].name],['Training rows',String(companyRows.length)],['Cycles',String(summary.totalCycles)],['Validated',String(summary.validated)],['Applied',String(summary.applied)]].map(([a,b])=><div key={a} className="rounded-2xl p-4 bg-white/5 border border-white/10"><div className="text-slate-500 text-xs">{a}</div><div className="text-white font-black text-2xl mt-1">{b}</div></div>)}</div>
      <div className="rounded-2xl p-4 bg-gradient-to-br from-red-500/10 to-purple-500/10 border border-red-500/20 mb-4"><div className="text-white font-black text-lg mb-1">A. Prediction Snapshot</div><div className="text-slate-400 text-sm mb-3">শুধু current dataset দিয়ে analysis হবে; lock হওয়ার পরে actual batch analysis-এ ঢুকবে না।</div><div className="grid grid-cols-2 md:grid-cols-4 gap-3"><label className="text-xs text-slate-400">Next batch size<input type="number" min={1} max={1000} value={batchSize} onChange={e=>setBatchSize(Math.max(1,Number(e.target.value)||1))} className="mt-1 w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"/></label><label className="text-xs text-slate-400">Candidate pool<input type="number" min={20} max={250} value={candidateLimit} onChange={e=>setCandidateLimit(Math.max(20,Math.min(250,Number(e.target.value)||100)))} className="mt-1 w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"/></label><div className="col-span-2 flex items-end"><button onClick={lock} disabled={companyRows.length<10} className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white font-black">🔒 LOCK NEW PREDICTION</button></div></div></div>
      {message&&<div className="mb-4 rounded-xl p-3 bg-white/5 border border-white/10 text-sm text-slate-200">{message}</div>}
      <div className="grid lg:grid-cols-3 gap-4"><div className="rounded-2xl p-4 bg-white/5 border border-white/10"><div className="text-white font-bold mb-3">Cycle History</div><div className="space-y-2 max-h-[520px] overflow-auto">{cycles.filter(c=>c.company===companyId).map(c=><button key={c.id} onClick={()=>setSelectedId(c.id)} className={`w-full text-left p-3 rounded-xl border ${selected?.id===c.id?'border-red-500/60 bg-red-500/10':'border-white/10 bg-black/10'}`}><div className="flex justify-between"><span className="text-white font-bold text-xs">{c.id}</span><span className="text-[10px] font-black text-slate-300">{c.status}</span></div><div className="text-slate-500 text-xs mt-1">Train {c.trainingCount} · Batch {c.batchSize}</div></button>)}</div></div>
      <div className="lg:col-span-2 space-y-4">{!selected?<div className="rounded-2xl p-8 bg-white/5 border border-white/10 text-center text-slate-500">প্রথমে LOCK NEW PREDICTION চাপুন।</div>:<>
        <div className="rounded-2xl p-4 bg-white/5 border border-white/10"><div className="flex justify-between mb-3"><div><div className="text-white font-black">Analysis Final Result</div><div className="text-slate-500 text-xs">Locked snapshot · fingerprint {selected.datasetFingerprint}</div></div><span className="text-xs font-black text-yellow-300">{selected.status}</span></div><div className="grid grid-cols-2 md:grid-cols-5 gap-2">{selected.analysisFinal.top.map(c=><div key={c.num} className="rounded-xl p-3 bg-black/20 border border-white/10"><div className="font-mono text-white font-black text-lg">{c.num}</div><div className="text-[10px] text-slate-500">Rank #{c.rank} · {c.signalsAgreed} signals</div><div className="text-[10px] text-purple-300 mt-1">{c.methods.slice(0,2).map(m=>m.label).join(' · ')||'ensemble'}</div></div>)}</div><div className="mt-3 text-xs text-slate-500">Walk-forward exact-4D rate: {selected.analysisFinal.backtest.exact4DRate}% · tests: {selected.analysisFinal.backtest.total} · confidence is a descriptive index, not a winning probability.</div></div>
        <div className="rounded-2xl p-4 bg-white/5 border border-white/10"><div className="text-white font-black mb-1">B. Actual Batch Entry</div><div className="text-slate-500 text-xs mb-3">Actual numbers dataset-এ যোগ হওয়ার আগে এখানে দিন। প্রতি line-এ একটি 4-digit number; comma/space-ও গ্রহণ করা হয়।</div><label className="block text-xs text-slate-400 mb-2">Actual batch date<input type="date" value={actualDate} onChange={e=>setActualDate(e.target.value)} className="mt-1 w-full md:w-64 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"/></label><textarea value={actualText} onChange={e=>setActualText(e.target.value)} placeholder={'1234\n5607\n...'} className="w-full min-h-[140px] bg-slate-950 border border-slate-700 rounded-xl p-3 text-white font-mono"/><div className="flex gap-2 mt-3"><button onClick={validate} className="px-4 py-2.5 rounded-xl bg-green-600 text-white font-black">🔎 VALIDATE & TRACE</button>{selected.status==='VALIDATED'&&<button onClick={apply} className="px-4 py-2.5 rounded-xl bg-blue-600 text-white font-black">➕ APPLY TO DATASET</button>}</div></div>
        {selected.validationFinal&&<div className="rounded-2xl p-4 bg-white/5 border border-white/10"><div className="text-white font-black mb-1">Validation Final Result</div><div className="text-slate-500 text-xs mb-3">Actual-vs-locked comparison · {selected.validationFinal.totalActual} actual numbers</div><div className="grid grid-cols-3 gap-2 mb-4"><div className="rounded-xl p-3 bg-green-500/10"><div className="text-green-300 text-xs">Exact predicted</div><div className="text-white font-black text-2xl">{selected.validationFinal.exactMatches.length}</div></div><div className="rounded-xl p-3 bg-red-500/10"><div className="text-red-300 text-xs">Unmatched</div><div className="text-white font-black text-2xl">{selected.validationFinal.unmatched.length}</div></div><div className="rounded-xl p-3 bg-purple-500/10"><div className="text-purple-300 text-xs">Coverage</div><div className="text-white font-black text-2xl">{selected.validationFinal.totalActual?Math.round(selected.validationFinal.exactMatches.length/selected.validationFinal.totalActual*100):0}%</div></div></div><div className="space-y-2 max-h-[420px] overflow-auto">{selected.validationFinal.trace.map((t,i)=><div key={`${t.num}-${i}`} className="rounded-xl p-3 bg-black/20 border border-white/10"><div className="flex justify-between"><span className="font-mono text-white font-black">{t.num}</span><span className={`text-xs font-black ${t.predicted?'text-green-300':'text-red-300'}`}>{t.predicted?`PREDICTED · Rank #${t.rank}`:'NOT IN LOCKED POOL'}</span></div>{t.methods.length>0&&<div className="text-xs text-slate-400 mt-1">Methods: {t.methods.join(' · ')}</div>}{t.evidence.length>0&&<div className="text-[10px] text-slate-500 mt-1">{t.evidence.join(' | ')}</div>}</div>)}</div></div>}
      </>}</div></div>
      {summary.methods.length>0&&<div className="rounded-2xl p-4 bg-white/5 border border-white/10 mt-4"><div className="text-white font-black mb-1">Historical Method Performance</div><div className="text-slate-500 text-xs mb-3">Validated cycles-এর actual coverage; এটি winner ranking নয়।</div><div className="overflow-auto"><table className="w-full text-sm"><thead><tr className="text-slate-500"><th className="text-left p-2">Method</th><th className="text-right p-2">Cycles</th><th className="text-right p-2">Hits</th><th className="text-right p-2">Coverage</th><th className="text-right p-2">Mean cycle rate</th></tr></thead><tbody>{summary.methods.slice(0,27).map(m=><tr key={m.key} className="border-t border-white/5"><td className="p-2 text-white">{m.label}</td><td className="p-2 text-right text-slate-400">{m.cycles}</td><td className="p-2 text-right text-slate-300">{m.hits}</td><td className="p-2 text-right text-green-300">{Math.round(m.rate*100)}%</td><td className="p-2 text-right text-purple-300">{Math.round(m.stability*100)}%</td></tr>)}</tbody></table></div></div>}
    </>}</ViewShell>;
}

// ─── Shared helpers ───────────────────────────────────────────────────────────
function ViewShell({ title, subtitle, icon, children }: { title:string; subtitle:string; icon:string; children:React.ReactNode }) {
  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-white">{icon} {title}</h1>
        <p className="text-slate-400 text-xs mt-0.5">{subtitle}</p>
      </div>
      {children}
    </div>
  );
}
function Card({ children, className="" }: { children:React.ReactNode; className?:string }) {
  return <div className={`bg-slate-800 border border-slate-700 rounded-2xl p-5 ${className}`}>{children}</div>;
}
function CompanyPicker({ value, onChange }: { value:CompanyId; onChange:(c:CompanyId)=>void }) {
  return (
    <select value={value} onChange={e=>onChange(e.target.value as CompanyId)}
      className="bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500">
      {COMPANY_IDS.map(id=><option key={id} value={id}>{COMPANIES[id].name}</option>)}
    </select>
  );
}
function prizeNums(r: LotteryResult) { return [r.first, r.second, r.third]; }
function noData() { return <div className="text-center text-slate-500 py-12 text-sm">এই company-র জন্য যথেষ্ট data নেই।</div>; }

function buildPosFreq(filtered: LotteryResult[]) {
  const pos: Record<number, Record<string,number>> = {0:{},1:{},2:{},3:{}};
  for (let i=0;i<10;i++) { pos[0][i]=0; pos[1][i]=0; pos[2][i]=0; pos[3][i]=0; }
  for (const r of filtered) for (const n of prizeNums(r)) if (n.length===4) n.split("").forEach((d,i)=>{pos[i][d]=(pos[i][d]??0)+1;});
  return pos;
}
// Standard 4D mirror mapping: [0↔5, 1↔6, 2↔7, 3↔8, 4↔9]
const DIGIT_MIRROR: Record<string,string> = {"0":"5","1":"6","2":"7","3":"8","4":"9","5":"0","6":"1","7":"2","8":"3","9":"4"};
function mirrorNum(n: string) { return n.split("").map(d => DIGIT_MIRROR[d] ?? d).join(""); }
function perms4(num: string): string[] {
  const d = num.split(""); const res: string[] = []; const seen = new Set<string>();
  const gen = (arr: string[], cur: string[]) => {
    if (cur.length === 4) { const s = cur.join(""); if (!seen.has(s)) { seen.add(s); res.push(s); } return; }
    const usedAtPos = new Set<string>();
    for (let i = 0; i < arr.length; i++) {
      if (usedAtPos.has(arr[i])) continue;
      usedAtPos.add(arr[i]);
      gen([...arr.slice(0,i), ...arr.slice(i+1)], [...cur, arr[i]]);
    }
  };
  gen(d, []); return res;
}

// ─── Scan / OCR View ──────────────────────────────────────────────────────────
type OcrItem = {
  id: number;
  imgSrc: string;
  status: "pending"|"scanning"|"done"|"error";
  errMsg: string;
  date: string; drawNo: string;
  first: string; second: string; third: string;
  special: string; consolation: string;
  saved: boolean;
};

function OcrCard({ item, company, onUpdate, onSave }: {
  item: OcrItem; company: CompanyId;
  onUpdate: (patch: Partial<OcrItem>) => void;
  onSave: () => Promise<void>;
}) {
  const ic = "w-full bg-slate-950 border border-slate-700 text-white font-mono rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500";
  const spCnt = item.special.trim()     ? item.special.trim().split(/[\s,]+/).filter(Boolean).length     : 0;
  const cnCnt = item.consolation.trim() ? item.consolation.trim().split(/[\s,]+/).filter(Boolean).length : 0;

  return (
    <div className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden">
      {/* top: thumbnail + status */}
      <div className="flex gap-3 p-4 border-b border-slate-700">
        <img src={item.imgSrc} alt="" className="w-24 h-20 object-cover rounded-xl border border-slate-600 flex-shrink-0"/>
        <div className="flex-1 min-w-0">
          {item.status==="scanning" && <div className="flex items-center gap-2 text-blue-400 text-sm font-medium"><span className="animate-spin">⏳</span> OCR চলছে…</div>}
          {item.status==="error"    && <div className="text-red-400 text-sm">❌ {item.errMsg}</div>}
          {item.status==="done"     && <div className="text-green-400 text-sm font-medium">✅ OCR সম্পন্ন — নিচে edit করুন</div>}
          {item.status==="pending"  && <div className="text-slate-500 text-sm">⏸ অপেক্ষায় আছে…</div>}
          {item.saved && <div className="mt-2 text-green-400 text-xs font-semibold bg-green-900/20 border border-green-700 rounded-lg px-2 py-1 inline-block">💾 Saved!</div>}
        </div>
      </div>

      {/* form fields */}
      {(item.status==="done"||item.status==="error") && (
        <div className="p-4 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-400 text-xs block mb-1">তারিখ *</label>
              <input type="date" className={ic} value={item.date} onChange={e=>onUpdate({date:e.target.value})}/>
            </div>
            <div>
              <label className="text-slate-400 text-xs block mb-1">ড্র নম্বর</label>
              <input className={ic} placeholder="যেমন: 6131/26" value={item.drawNo} onChange={e=>onUpdate({drawNo:e.target.value})}/>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {(["first","second","third"] as const).map((k,i)=>(
              <div key={k}>
                <label className="text-slate-400 text-xs block mb-1">{i===0?"১ম পুরস্কার":i===1?"২য় পুরস্কার":"৩য় পুরস্কার"} *</label>
                <input className={ic+" text-center font-black tracking-widest text-base"} maxLength={4} placeholder="৪ ডিজিট" value={item[k]} onChange={e=>onUpdate({[k]:e.target.value})}/>
              </div>
            ))}
          </div>
          <div>
            <label className="text-slate-400 text-xs block mb-1">🔵 স্পেশাল নাম্বার ({spCnt} নাম্বার পার্স হয়েছে)</label>
            <textarea rows={3} className={ic+" resize-none"} placeholder="1234 5678 9012 …" value={item.special} onChange={e=>onUpdate({special:e.target.value})}/>
          </div>
          <div>
            <label className="text-slate-400 text-xs block mb-1">🟡 কনসোলেশন নাম্বার ({cnCnt} নাম্বার পার্স হয়েছে)</label>
            <textarea rows={3} className={ic+" resize-none"} placeholder="1111 2222 3333 …" value={item.consolation} onChange={e=>onUpdate({consolation:e.target.value})}/>
          </div>
          {!item.saved
            ? <button onClick={onSave} disabled={!item.first||!item.second||!item.third||!item.date}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white font-semibold py-2.5 rounded-xl transition">
                💾 এই Result Save করুন
              </button>
            : <div className="text-center py-2 text-green-400 font-semibold text-sm bg-green-900/20 border border-green-700 rounded-xl">✅ সফলভাবে Saved!</div>
          }
        </div>
      )}
    </div>
  );
}

// ─── Live Results Import View ─────────────────────────────────────────────────
const LIVE_COMPANIES: { id: CompanyId; name: string; url: string; hint: string }[] = [
  { id: "magnum",    name: "Magnum 4D",       url: "https://www.magnum4d.my/en/results",           hint: "Magnum official site → copy all numbers from result page" },
  { id: "toto",      name: "Sports Toto",     url: "https://www.sportstoto.com.my/",               hint: "Sports Toto official site → copy result table" },
  { id: "damacai",   name: "Da Ma Cai",       url: "https://www.damacai.com.my/home",             hint: "Da Ma Cai official site → copy 4-digit numbers" },
  { id: "singapore", name: "Singapore Pools", url: "https://www.singaporepools.com.sg/en/product/Pages/4d_results.aspx", hint: "Singapore Pools official site → copy 4D result" },
];

function LiveResultsView({ onAddResult }: { onAddResult:(r:any)=>Promise<void> }) {
  const [company, setCompany]         = useState<CompanyId>("magnum");
  const [date, setDate]               = useState(new Date().toISOString().slice(0,10));
  const [drawNo, setDrawNo]           = useState("");
  const [pasteText, setPasteText]     = useState("");
  const [parsed, setParsed]           = useState<{first:string;second:string;third:string;special:string[];consolation:string[]}|null>(null);
  const [parseError, setParseError]   = useState("");
  const [saving, setSaving]           = useState(false);
  const [saved, setSaved]             = useState(false);
  const [editFirst, setEditFirst]     = useState("");
  const [editSecond, setEditSecond]   = useState("");
  const [editThird, setEditThird]     = useState("");
  const [editSpecial, setEditSpecial] = useState("");
  const [editCons, setEditCons]       = useState("");
  const [showEdit, setShowEdit]       = useState(false);

  const selCompany = LIVE_COMPANIES.find(c=>c.id===company)!;

  function extractNumbers(text: string): string[] {
    const all: string[] = [];
    // Match 4-digit numbers (may be separated by spaces, commas, newlines, etc.)
    const matches = text.matchAll(/\b(\d{4})\b/g);
    for (const m of matches) all.push(m[1]);
    return all;
  }

  function parsePaste() {
    setParseError("");
    setParsed(null);
    setShowEdit(false);
    const nums = extractNumbers(pasteText);
    if (nums.length < 3) {
      setParseError(`ন্যূনতম ৩টি ৪-ডিজিট নাম্বার প্রয়োজন। পেস্ট করা টেক্সট থেকে মাত্র ${nums.length}টি পাওয়া গেছে।`);
      return;
    }
    const first   = nums[0];
    const second  = nums[1];
    const third   = nums[2];
    const special     = nums.slice(3, 13);
    const consolation = nums.slice(13, 23);
    const result = { first, second, third, special, consolation };
    setParsed(result);
    setEditFirst(first);
    setEditSecond(second);
    setEditThird(third);
    setEditSpecial(special.join(" "));
    setEditCons(consolation.join(" "));
  }

  async function doSave() {
    const src = showEdit
      ? { first:editFirst, second:editSecond, third:editThird,
          special: editSpecial.trim() ? editSpecial.trim().split(/[\s,]+/).filter(Boolean) : [],
          consolation: editCons.trim() ? editCons.trim().split(/[\s,]+/).filter(Boolean) : [] }
      : parsed!;
    if (!src.first || !src.second || !src.third) {
      setParseError("১ম, ২য়, ৩য় পুরস্কার আবশ্যক।"); return;
    }
    setSaving(true); setParseError("");
    try {
      await onAddResult({ company, date, drawNo: drawNo||null, ...src });
      setSaved(true);
      setPasteText(""); setParsed(null); setShowEdit(false); setDrawNo("");
      setTimeout(()=>setSaved(false), 4000);
    } catch(ex:any) { setParseError(ex.message); }
    finally { setSaving(false); }
  }

  const ic = "w-full bg-slate-950 border border-slate-700 text-white font-mono rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-purple-500 placeholder:text-slate-600";
  const sp  = parsed?.special.length     ?? 0;
  const cn  = parsed?.consolation.length ?? 0;

  return (
    <div className="p-4 max-w-3xl mx-auto space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-white">🌐 4D Result Import</h1>
        <p className="text-slate-400 text-xs mt-0.5">4D result source থেকে result copy করুন → এখানে paste করুন → auto-parse করে DB-তে save করুন</p>
      </div>

      {/* Company quick-links */}
      <div className="rounded-2xl border border-slate-700/60 bg-slate-900/70 p-4 space-y-3">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Step 1 — Official Site খুলুন</p>
        <div className="grid grid-cols-2 gap-2">
          {LIVE_COMPANIES.map(c=>(
            <a
              key={c.id}
              href={c.url}
              target="_blank"
              rel="noopener noreferrer"
              onClick={()=>setCompany(c.id)}
              className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border text-sm font-semibold transition-all ${company===c.id ? "border-purple-500 bg-purple-600/20 text-white" : "border-slate-700 bg-slate-800/60 text-slate-300 hover:border-purple-500/60 hover:text-white"}`}
            >
              <span className="text-lg">{c.id==="magnum"?"🔵":c.id==="toto"?"🟡":c.id==="damacai"?"🟢":"🔴"}</span>
              <span className="flex-1">{c.name}</span>
              <span className="text-purple-400 text-xs">↗</span>
            </a>
          ))}
        </div>
        <p className="text-xs text-slate-500 italic">{selCompany.hint}</p>
      </div>

      {/* Paste area */}
      <div className="rounded-2xl border border-slate-700/60 bg-slate-900/70 p-4 space-y-3">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Step 2 — Result Paste করুন</p>
        <textarea
          value={pasteText}
          onChange={e=>{ setPasteText(e.target.value); setParsed(null); setParseError(""); }}
          rows={7}
          placeholder={"Official site থেকে result page-এর সব text copy করে এখানে paste করুন (Ctrl+A → Ctrl+C → এখানে Ctrl+V)\n\nউদাহরণ:\n1st Prize: 1234\n2nd Prize: 5678\n3rd Prize: 9012\nSpecial: 3456 7890 1234 5678 ..."}
          className="w-full bg-slate-950 border border-slate-700 text-white font-mono rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-purple-500 placeholder:text-slate-500 resize-none"
        />
        <div className="flex gap-2 items-center">
          <button
            onClick={parsePaste}
            disabled={!pasteText.trim()}
            className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-sm disabled:opacity-40 transition"
          >🔍 Auto-Parse</button>
          <span className="text-xs text-slate-500">{extractNumbers(pasteText).length} টি ৪-ডিজিট নাম্বার পাওয়া গেছে</span>
        </div>
        {parseError && <p className="text-red-400 text-xs bg-red-900/20 border border-red-700/40 rounded-xl px-3 py-2">{parseError}</p>}
      </div>

      {/* Parsed preview */}
      {parsed && (
        <div className="rounded-2xl border border-green-700/50 bg-green-900/10 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-xs font-semibold text-green-400 uppercase tracking-wider">Step 3 — Result Preview ও Save</p>
            <button onClick={()=>setShowEdit(v=>!v)} className="text-xs text-purple-400 hover:text-purple-300 underline">{showEdit?"← Auto-detected values দেখুন":"✏️ Edit করুন"}</button>
          </div>

          {!showEdit ? (
            <div className="space-y-2">
              <div className="grid grid-cols-3 gap-2 text-center">
                {[["🥇 1st","text-yellow-400",parsed.first],["🥈 2nd","text-slate-300",parsed.second],["🥉 3rd","text-orange-400",parsed.third]].map(([label,cls,val])=>(
                  <div key={label as string} className="bg-slate-950/70 rounded-xl py-3 border border-slate-700">
                    <p className="text-xs text-slate-500 mb-1">{label as string}</p>
                    <p className={`text-2xl font-black font-mono ${cls as string}`}>{val as string}</p>
                  </div>
                ))}
              </div>
              {parsed.special.length>0 && (
                <div className="bg-slate-950/70 rounded-xl p-3 border border-slate-700">
                  <p className="text-xs text-slate-500 mb-2">🌟 Special ({sp}/10)</p>
                  <div className="flex flex-wrap gap-1.5">
                    {parsed.special.map((n,i)=><span key={i} className="font-mono text-sm bg-blue-900/40 text-blue-300 border border-blue-700/40 rounded-lg px-2 py-0.5">{n}</span>)}
                  </div>
                </div>
              )}
              {parsed.consolation.length>0 && (
                <div className="bg-slate-950/70 rounded-xl p-3 border border-slate-700">
                  <p className="text-xs text-slate-500 mb-2">🎫 Consolation ({cn}/10)</p>
                  <div className="flex flex-wrap gap-1.5">
                    {parsed.consolation.map((n,i)=><span key={i} className="font-mono text-sm bg-slate-700/60 text-slate-300 border border-slate-600/40 rounded-lg px-2 py-0.5">{n}</span>)}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-2">
              <div className="grid grid-cols-3 gap-2">
                {[["🥇 1st Prize",editFirst,setEditFirst],["🥈 2nd Prize",editSecond,setEditSecond],["🥉 3rd Prize",editThird,setEditThird]].map(([lbl,val,fn])=>(
                  <div key={lbl as string}>
                    <label className="text-xs text-slate-400 mb-1 block">{lbl as string}</label>
                    <input value={val as string} onChange={e=>(fn as any)(e.target.value)} maxLength={4} placeholder="0000" className={ic}/>
                  </div>
                ))}
              </div>
              <div>
                <label className="text-xs text-slate-400 mb-1 block">🌟 Special (space-separated, max 10)</label>
                <input value={editSpecial} onChange={e=>setEditSpecial(e.target.value)} placeholder="1234 5678 9012 ..." className={ic}/>
              </div>
              <div>
                <label className="text-xs text-slate-400 mb-1 block">🎫 Consolation (space-separated, max 10)</label>
                <input value={editCons} onChange={e=>setEditCons(e.target.value)} placeholder="1234 5678 9012 ..." className={ic}/>
              </div>
            </div>
          )}

          {/* Meta fields */}
          <div className="grid grid-cols-3 gap-2 pt-1">
            <div>
              <label className="text-xs text-slate-400 mb-1 block">কোম্পানি</label>
              <select value={company} onChange={e=>setCompany(e.target.value as CompanyId)} className={ic}>
                {LIVE_COMPANIES.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-400 mb-1 block">তারিখ</label>
              <input type="date" value={date} onChange={e=>setDate(e.target.value)} className={ic}/>
            </div>
            <div>
              <label className="text-xs text-slate-400 mb-1 block">Draw No (optional)</label>
              <input value={drawNo} onChange={e=>setDrawNo(e.target.value)} placeholder="e.g. 5012" className={ic}/>
            </div>
          </div>

          <button
            onClick={doSave}
            disabled={saving}
            className="w-full py-3 rounded-xl font-bold text-white text-sm transition-all bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 disabled:opacity-50"
          >{saving ? "⏳ Saving..." : "💾 Database-এ Save করুন"}</button>
          {saved && <p className="text-center text-green-400 text-sm font-semibold animate-pulse">✅ সফলভাবে save হয়েছে!</p>}
        </div>
      )}

      {/* Instructions */}
      <div className="rounded-2xl border border-slate-700/40 bg-slate-900/40 p-4 space-y-2">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">📖 ব্যবহার নির্দেশিকা</p>
        <ol className="text-xs text-slate-400 space-y-1.5 list-decimal list-inside">
          <li><span className="text-white">উপরের যেকোনো কোম্পানি লিংকে ক্লিক করুন</span> — official site নতুন tab-এ খুলবে</li>
          <li>Result page-এ গিয়ে <span className="text-white font-mono">Ctrl+A</span> → <span className="text-white font-mono">Ctrl+C</span> দিয়ে সব text copy করুন</li>
          <li>এই page-এ এসে Paste এলাকায় <span className="text-white font-mono">Ctrl+V</span> দিন</li>
          <li><span className="text-white">🔍 Auto-Parse</span> বাটন চাপুন — সব ৪-ডিজিট নাম্বার automatically বের হবে</li>
          <li>Preview দেখুন, প্রয়োজনে <span className="text-white">✏️ Edit</span> করুন</li>
          <li>কোম্পানি ও তারিখ সঠিক আছে কিনা দেখুন → <span className="text-white">💾 Save</span> করুন</li>
        </ol>
        <p className="text-xs text-slate-500 italic mt-2">💡 Tip: যে কোম্পানির result দেখতে ক্লিক করবেন, সেই কোম্পানি automatically select হবে</p>
      </div>
    </div>
  );
}

// ─── Quick Paste helper ───────────────────────────────────────────────────────
function parseNumbers(raw: string): string[] {
  return (raw.match(/\b\d{4}\b/g) ?? []);
}

function ScanView({ onAddResult }: { onAddResult:(r:any)=>Promise<void> }) {
  const today = new Date().toISOString().slice(0,10);

  // ── Quick Paste state ──
  const [qCompany, setQCompany] = useState<CompanyId>("magnum");
  const [qDate,    setQDate]    = useState(today);
  const [qDrawNo,  setQDrawNo]  = useState("");
  const [qRaw,     setQRaw]     = useState("");
  const [qSaving,  setQSaving]  = useState(false);
  const [qSaved,   setQSaved]   = useState(false);
  const [qErr,     setQErr]     = useState("");

  // ── Manual entry state ──
  const [tab,         setTab]         = useState<"paste"|"manual">("paste");
  const [mCompany,    setMCompany]    = useState<CompanyId>("magnum");
  const [mDate,       setMDate]       = useState(today);
  const [mDrawNo,     setMDrawNo]     = useState("");
  const [mFirst,      setMFirst]      = useState("");
  const [mSecond,     setMSecond]     = useState("");
  const [mThird,      setMThird]      = useState("");
  const [mSpecial,    setMSpecial]    = useState("");
  const [mCons,       setMCons]       = useState("");
  const [mSaving,     setMSaving]     = useState(false);
  const [mSaved,      setMSaved]      = useState(false);
  const [mErr,        setMErr]        = useState("");

  const ic = "w-full bg-slate-950 border border-slate-700 text-white font-mono rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-blue-500 placeholder:text-slate-600";

  // ── Parse Quick Paste preview ──
  const nums    = parseNumbers(qRaw);
  const qFirst  = nums[0]  ?? "";
  const qSecond = nums[1]  ?? "";
  const qThird  = nums[2]  ?? "";
  const qSp     = nums.slice(3, 13);
  const qCn     = nums.slice(13, 23);
  const qReady  = !!qFirst && !!qSecond && !!qThird;

  async function saveQuick() {
    if (!qReady) { setQErr("কমপক্ষে ৩টি ৪-ডিজিট নাম্বার paste করুন (১ম, ২য়, ৩য় পুরস্কারের জন্য)।"); return; }
    setQSaving(true); setQErr("");
    try {
      await onAddResult({ company:qCompany, date:qDate, drawNo:qDrawNo||null, first:qFirst, second:qSecond, third:qThird, special:qSp, consolation:qCn });
      setQSaved(true); setQRaw(""); setQDrawNo("");
      setTimeout(()=>setQSaved(false), 4000);
    } catch(ex:any) { setQErr(ex.message); }
    finally { setQSaving(false); }
  }

  async function saveManual() {
    if (!mFirst||!mSecond||!mThird||!mDate) { setMErr("তারিখ, ১ম, ২য়, ৩য় পুরস্কার আবশ্যক।"); return; }
    setMSaving(true); setMErr("");
    try {
      const special     = mSpecial.trim() ? mSpecial.trim().split(/[\s,]+/).filter(Boolean) : [];
      const consolation = mCons.trim()    ? mCons.trim().split(/[\s,]+/).filter(Boolean)    : [];
      await onAddResult({ company:mCompany, date:mDate, drawNo:mDrawNo||null, first:mFirst, second:mSecond, third:mThird, special, consolation });
      setMSaved(true);
      setMFirst(""); setMSecond(""); setMThird(""); setMDrawNo(""); setMSpecial(""); setMCons("");
      setTimeout(()=>setMSaved(false), 3000);
    } catch(ex:any) { setMErr(ex.message); }
    finally { setMSaving(false); }
  }

  return (
    <div className="p-4 max-w-2xl mx-auto space-y-5">

      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">➕ রেজাল্ট যোগ করুন</h1>
        <p className="text-slate-400 text-xs mt-0.5">নাম্বার copy করে paste করুন — auto-detect হবে</p>
      </div>

      {/* Tab switcher */}
      <div className="flex gap-2">
        {(["paste","manual"] as const).map(t=>(
          <button key={t} onClick={()=>setTab(t)}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition ${tab===t?"bg-green-600 text-white":"bg-slate-800 text-slate-400 hover:text-white"}`}>
            {t==="paste" ? "📋 Quick Paste" : "✏️ Manual Entry"}
          </button>
        ))}
      </div>

      {/* ── QUICK PASTE TAB ── */}
      {tab==="paste" && (
        <div className="space-y-4">
          {/* Info banner */}
          <div className="bg-blue-900/20 border border-blue-700/40 rounded-xl p-3 text-blue-300 text-xs leading-relaxed">
            <p className="font-semibold mb-1">📋 কিভাবে ব্যবহার করবেন:</p>
            <p>১. 4D result source থেকে সব নাম্বার <strong>copy</strong> করুন</p>
            <p>২. নিচের box-এ <strong>paste</strong> করুন</p>
            <p>৩. Auto-detect হবে → <strong>Save</strong> চাপুন</p>
            <p className="mt-1 text-blue-400/60">প্রথম ৩টি = 1st/2nd/3rd · পরের ১০টি = Special · শেষ ১০টি = Consolation</p>
          </div>

          {/* Company + Date */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-400 text-xs block mb-1">Company *</label>
              <CompanyPicker value={qCompany} onChange={setQCompany}/>
            </div>
            <div>
              <label className="text-slate-400 text-xs block mb-1">তারিখ *</label>
              <input type="date" className={ic} value={qDate} onChange={e=>setQDate(e.target.value)}/>
            </div>
          </div>

          <div>
            <label className="text-slate-400 text-xs block mb-1">ড্র নম্বর (optional)</label>
            <input className={ic} placeholder="যেমন: 3430/2026" value={qDrawNo} onChange={e=>setQDrawNo(e.target.value)}/>
          </div>

          {/* Big paste area */}
          <div>
            <label className="text-slate-400 text-xs block mb-1">এখানে নাম্বার Paste করুন ↓</label>
            <textarea rows={6}
              className="w-full bg-slate-950 border-2 border-dashed border-green-700/50 hover:border-green-500/70 focus:border-green-500 text-white font-mono rounded-2xl px-4 py-3 text-sm focus:outline-none placeholder:text-slate-600 resize-none transition"
              placeholder={"যেকোনো format-এ paste করুন:\n\n1234  5678  9012\n3456 7890 2345\n...\n\n৪-ডিজিটের নাম্বার auto-detect হবে"}
              value={qRaw} onChange={e=>{setQRaw(e.target.value); setQErr(""); setQSaved(false);}}
            />
            <p className="text-slate-300 text-xs mt-1">{nums.length} টি ৪-ডিজিট নাম্বার detect হয়েছে</p>
          </div>

          {/* Live Preview */}
          {nums.length>0 && (
            <div className="bg-slate-800 border border-slate-700 rounded-2xl p-4 space-y-3">
              <p className="text-slate-300 text-xs font-semibold">🔍 Auto-Detected Preview</p>
              <div className="grid grid-cols-3 gap-2 text-center">
                {[["🥇 1st", qFirst, "text-yellow-400 border-yellow-700/50"],["🥈 2nd", qSecond, "text-slate-300 border-slate-600"],["🥉 3rd", qThird, "text-orange-400 border-orange-800/50"]].map(([label,val,cls])=>(
                  <div key={label as string} className={`bg-slate-900 border rounded-xl py-2 px-1 ${cls}`}>
                    <div className="text-[10px] text-slate-500 mb-1">{label}</div>
                    <div className={`font-black text-xl tracking-widest ${val?"":"text-slate-700"}`}>{(val as string)||"----"}</div>
                  </div>
                ))}
              </div>
              {qSp.length>0 && (
                <div>
                  <p className="text-slate-500 text-[10px] mb-1">Special ({qSp.length})</p>
                  <div className="flex flex-wrap gap-1.5">
                    {qSp.map((n,i)=><span key={i} className="bg-purple-900/40 border border-purple-700/30 text-purple-300 font-mono text-xs px-2 py-0.5 rounded-lg">{n}</span>)}
                  </div>
                </div>
              )}
              {qCn.length>0 && (
                <div>
                  <p className="text-slate-500 text-[10px] mb-1">Consolation ({qCn.length})</p>
                  <div className="flex flex-wrap gap-1.5">
                    {qCn.map((n,i)=><span key={i} className="bg-blue-900/40 border border-blue-700/30 text-blue-300 font-mono text-xs px-2 py-0.5 rounded-lg">{n}</span>)}
                  </div>
                </div>
              )}
            </div>
          )}

          {qErr&&<div className="p-3 bg-red-900/30 border border-red-700 rounded-xl text-red-300 text-sm">{qErr}</div>}
          {qSaved&&<div className="p-3 bg-green-900/30 border border-green-700 rounded-xl text-green-300 text-sm font-semibold text-center">✅ সফলভাবে Save হয়েছে!</div>}

          <button onClick={saveQuick} disabled={qSaving||!qReady}
            className="w-full bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-500 hover:to-teal-500 disabled:opacity-40 text-white font-black py-4 rounded-2xl transition text-base shadow-lg shadow-green-900/30">
            {qSaving ? "সংরক্ষণ হচ্ছে…" : qReady ? `💾 Save করুন (${COMPANIES[qCompany].name} · ${qDate})` : "⬆️ উপরে নাম্বার paste করুন"}
          </button>
        </div>
      )}

      {/* ── MANUAL ENTRY TAB ── */}
      {tab==="manual" && (
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5 space-y-4">
          {mSaved&&<div className="p-3 bg-green-900/30 border border-green-700 rounded-xl text-green-300 text-sm font-semibold text-center">✅ সফলভাবে Save হয়েছে!</div>}
          {mErr&&<div className="p-3 bg-red-900/30 border border-red-700 rounded-xl text-red-300 text-sm">{mErr}</div>}
          <div><label className="text-slate-400 text-xs block mb-1">Company *</label><CompanyPicker value={mCompany} onChange={setMCompany}/></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-slate-400 text-xs block mb-1">তারিখ *</label><input type="date" className={ic} value={mDate} onChange={e=>setMDate(e.target.value)}/></div>
            <div><label className="text-slate-400 text-xs block mb-1">ড্র নম্বর</label><input className={ic} placeholder="3430/2026" value={mDrawNo} onChange={e=>setMDrawNo(e.target.value)}/></div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {([["১ম",mFirst,setMFirst],["২য়",mSecond,setMSecond],["৩য়",mThird,setMThird]] as const).map(([label,val,set])=>(
              <div key={label}>
                <label className="text-slate-400 text-xs block mb-1">{label} পুরস্কার *</label>
                <input className={ic+" text-center font-black tracking-widest text-lg"} maxLength={4} placeholder="৪ ডিজিট" value={val} onChange={e=>(set as any)(e.target.value)}/>
              </div>
            ))}
          </div>
          <div>
            <label className="text-slate-400 text-xs block mb-1">স্পেশাল <span className="text-slate-500">(স্পেস বা কমা)</span></label>
            <textarea rows={2} className={ic+" resize-none"} placeholder="1234 5678 9012 …" value={mSpecial} onChange={e=>setMSpecial(e.target.value)}/>
          </div>
          <div>
            <label className="text-slate-400 text-xs block mb-1">কনসোলেশন <span className="text-slate-500">(স্পেস বা কমা)</span></label>
            <textarea rows={2} className={ic+" resize-none"} placeholder="1111 2222 3333 …" value={mCons} onChange={e=>setMCons(e.target.value)}/>
          </div>
          <button onClick={saveManual} disabled={mSaving||!mFirst||!mSecond||!mThird||!mDate}
            className="w-full bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-500 hover:to-teal-500 disabled:opacity-40 text-white font-bold py-3.5 rounded-xl transition text-base">
            {mSaving?"সংরক্ষণ হচ্ছে…":"💾 সংরক্ষণ করুন"}
          </button>
        </div>
      )}
    </div>
  );
}


// ─── Screenshot OCR Import ───────────────────────────────────────────────────
declare global { interface Window { Tesseract?: any } }

async function loadTesseract(): Promise<any> {
  if (window.Tesseract) return window.Tesseract;
  await new Promise<void>((resolve,reject)=>{
    const existing=document.querySelector('script[data-cbc-tesseract]');
    if(existing){ existing.addEventListener('load',()=>resolve()); existing.addEventListener('error',()=>reject(new Error('OCR library load failed'))); return; }
    const script=document.createElement('script');
    script.src='https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';
    script.async=true; script.dataset.cbcTesseract='1';
    script.onload=()=>resolve(); script.onerror=()=>reject(new Error('OCR library load failed'));
    document.head.appendChild(script);
  });
  if(!window.Tesseract) throw new Error('OCR library পাওয়া যায়নি');
  return window.Tesseract;
}

function ScreenshotOCRView({ onAddResult }: { onAddResult:(r:any)=>Promise<void> }) {
  const today=new Date().toISOString().slice(0,10);
  const [company,setCompany]=useState<CompanyId>('magnum');
  const [date,setDate]=useState(today);
  const [drawNo,setDrawNo]=useState('');
  const [file,setFile]=useState<File|null>(null);
  const [preview,setPreview]=useState('');
  const [ocrText,setOcrText]=useState('');
  const [numbers,setNumbers]=useState<string[]>([]);
  const [busy,setBusy]=useState(false);
  const [saved,setSaved]=useState(false);
  const [err,setErr]=useState('');

  function pickFile(f:File|null){
    setFile(f); setErr(''); setSaved(false); setOcrText(''); setNumbers([]);
    if(f){ const u=URL.createObjectURL(f); setPreview(u); }
    else setPreview('');
  }
  async function runOCR(){
    if(!file){setErr('আগে একটি screenshot/photo নির্বাচন করুন।');return;}
    setBusy(true); setErr(''); setSaved(false);
    try{
      const T=await loadTesseract();
      const worker=await T.createWorker('eng');
      const { data }=await worker.recognize(file);
      await worker.terminate();
      const text=String(data?.text??'');
      const found=(text.match(/\b\d{4}\b/g)??[]).map((x:string)=>x.padStart(4,'0'));
      setOcrText(text); setNumbers(found);
      if(!found.length) setErr('Screenshot থেকে ৪-ডিজিটের নাম্বার পাওয়া যায়নি। ছবি পরিষ্কার করে আবার চেষ্টা করুন।');
    }catch(e:any){setErr(`OCR ব্যর্থ: ${e?.message??e}`);}
    finally{setBusy(false);}
  }
  const [first,setFirst]=useState('');
  const [second,setSecond]=useState('');
  const [third,setThird]=useState('');
  const [specialText,setSpecialText]=useState('');
  const [consolationText,setConsolationText]=useState('');
  useEffect(()=>{
    setFirst(numbers[0]??''); setSecond(numbers[1]??''); setThird(numbers[2]??'');
    setSpecialText(numbers.slice(3,13).join(' ')); setConsolationText(numbers.slice(13,23).join(' '));
  },[numbers]);
  const special=specialText.trim().split(/[\s,]+/).filter(x=>/^\d{4}$/.test(x));
  const consolation=consolationText.trim().split(/[\s,]+/).filter(x=>/^\d{4}$/.test(x));
  async function ocrAndSave(){
    if(!file){setErr('আগে একটি screenshot/photo নির্বাচন করুন।');return;}
    await runOCR();
    // OCR state updates asynchronously, so the user gets a preview first; Save remains one tap away.
  }
  async function save(){
    if(!date||!first||!second||!third){setErr('তারিখ এবং অন্তত ৩টি ৪-ডিজিট নাম্বার প্রয়োজন।');return;}
    setBusy(true);setErr('');
    try{
      await onAddResult({company,date,drawNo:drawNo||null,first,second,third,special,consolation});
      setSaved(true);
    }catch(e:any){setErr(e?.message??'সংরক্ষণ ব্যর্থ');}
    finally{setBusy(false);}
  }
  return <ViewShell title="Screenshot OCR Data Entry" subtitle="Screenshot বসান → একবার চাপুন → ৪-ডিজিট নাম্বার বের করে Save করুন" icon="📷">
    <Card>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
        <div><label className="text-slate-400 text-xs block mb-1">Company</label><CompanyPicker value={company} onChange={setCompany}/></div>
        <div><label className="text-slate-400 text-xs block mb-1">তারিখ</label><input type="date" value={date} onChange={e=>setDate(e.target.value)} className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white text-sm"/></div>
        <div><label className="text-slate-400 text-xs block mb-1">ড্র নম্বর</label><input value={drawNo} onChange={e=>setDrawNo(e.target.value)} placeholder="optional" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white text-sm"/></div>
      </div>
      <input type="file" accept="image/*" onChange={e=>pickFile(e.target.files?.[0]??null)} className="w-full text-sm text-slate-400 file:mr-3 file:rounded-xl file:border-0 file:bg-blue-600 file:text-white file:px-4 file:py-2 file:font-bold"/>
      {preview&&<img src={preview} alt="Screenshot preview" className="mt-4 max-h-72 w-full object-contain rounded-xl border border-slate-700 bg-black"/>}
      <div className="flex gap-2 mt-4">
        <button onClick={runOCR} disabled={busy||!file} className="flex-1 bg-purple-600 disabled:opacity-40 text-white font-bold py-3 rounded-xl">{busy?'⏳ OCR চলছে…':'🔎 Screenshot থেকে পড়ুন'}</button>
        <button onClick={save} disabled={busy||!first||!second||!third} className="flex-1 bg-green-600 disabled:opacity-40 text-white font-bold py-3 rounded-xl">💾 Save Data</button>
      </div>
      {numbers.length>0&&<div className="mt-4 space-y-3">
        <div className="rounded-xl border border-yellow-700/30 bg-yellow-900/10 p-3"><p className="text-yellow-300 text-xs font-bold mb-2">⚠️ OCR-এর ফল Save করার আগে যাচাই/সংশোধন করুন</p><div className="grid grid-cols-3 gap-2">{[["১ম",first,setFirst],["২য়",second,setSecond],["৩য়",third,setThird]].map(([l,n,setter])=><div key={String(l)}><div className="text-slate-500 text-[10px] mb-1">{l}</div><input maxLength={4} inputMode="numeric" value={String(n)} onChange={e=>(setter as any)(e.target.value.replace(/\D/g,'').slice(0,4))} className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-center text-yellow-400 font-black font-mono text-xl tracking-widest"/></div>)}</div><div className="mt-3"><label className="text-slate-500 text-xs">Special — space/comma দিয়ে আলাদা করুন</label><textarea value={specialText} onChange={e=>setSpecialText(e.target.value)} className="w-full mt-1 bg-slate-950 border border-slate-700 rounded-xl p-3 text-white font-mono text-xs"/></div><div className="mt-3"><label className="text-slate-500 text-xs">Consolation — space/comma দিয়ে আলাদা করুন</label><textarea value={consolationText} onChange={e=>setConsolationText(e.target.value)} className="w-full mt-1 bg-slate-950 border border-slate-700 rounded-xl p-3 text-white font-mono text-xs"/></div></div>
        <details className="text-xs text-slate-500"><summary>OCR text দেখুন</summary><pre className="mt-2 whitespace-pre-wrap bg-slate-950 rounded-xl p-3 text-slate-400">{ocrText}</pre></details>
      </div>}
      {saved&&<div className="mt-3 p-3 rounded-xl bg-green-900/30 border border-green-700/40 text-green-300 text-sm font-bold">✅ Data এই ডিভাইসে company অনুযায়ী Save হয়েছে।</div>}
      {err&&<div className="mt-3 p-3 rounded-xl bg-red-900/30 border border-red-700/40 text-red-300 text-sm">{err}</div>}
      <p className="text-slate-600 text-[10px] mt-3">প্রথম OCR চালাতে internet লাগতে পারে, কারণ OCR engine প্রথমবার CDN থেকে লোড হয়।</p>
    </Card>
  </ViewShell>;
}

// ─── Data Vault / History — unified local information store ──────────────────
function backupChecksum(text:string){
  let h1=0x811c9dc5,h2=0x9e3779b9;
  for(let i=0;i<text.length;i++){const c=text.charCodeAt(i); h1=Math.imul(h1^c,16777619); h2=Math.imul(h2^c,2246822519);}
  return (h1>>>0).toString(16).padStart(8,"0")+(h2>>>0).toString(16).padStart(8,"0");
}

function DataVaultView({results,onUpdateResult,onDeleteResult,onClearAll,onRestore}:{results:LotteryResult[];onUpdateResult:(id:number,r:any)=>Promise<void>;onDeleteResult:(id:number)=>void;onClearAll:()=>void;onRestore:(rows:LotteryResult[])=>void}){
  const [company,setCompany]=useState<CompanyId|"all">("all");
  const [q,setQ]=useState("");
  const [editing,setEditing]=useState<LotteryResult|null>(null);
  const [draft,setDraft]=useState<any>(null);
  const [migrationOpen,setMigrationOpen]=useState(false);
  const [migrationText,setMigrationText]=useState("");
  const [migrationMsg,setMigrationMsg]=useState("");
  const [showConflicts,setShowConflicts]=useState(false);
  const filtered=useMemo(()=>results.filter(r=>(company==="all"||r.company===company)&&(!q.trim()||[r.date,r.drawNo,r.first,r.second,r.third,r.special.join(" ") ,r.consolation.join(" ")].join(" ").toLowerCase().includes(q.toLowerCase()))).sort((a,b)=>b.date.localeCompare(a.date)),[results,company,q]);
  const all4=filtered.flatMap(r=>[r.first,r.second,r.third,...r.special,...r.consolation]).filter(n=>/^\d{4}$/.test(n));
  const digitCount=Array.from({length:10},(_,d)=>({d:String(d),n:all4.reduce((s,x)=>s+(x.match(new RegExp(String(d),"g"))||[]).length,0)}));
  const hot=[...digitCount].sort((a,b)=>b.n-a.n).slice(0,5);
  function startEdit(r:LotteryResult){setEditing(r);setDraft({date:r.date,drawNo:r.drawNo??"",first:r.first,second:r.second,third:r.third,special:r.special.join(" "),consolation:r.consolation.join(" ")});}
  async function saveEdit(){if(!editing||!draft)return; try{await onUpdateResult(editing.id,{...draft,special:String(draft.special).split(/[\s,]+/).filter(Boolean),consolation:String(draft.consolation).split(/[\s,]+/).filter(Boolean)});setEditing(null);}catch(e:any){alert(e?.message||'Save ব্যর্থ হয়েছে।');}}
  async function exportVault(){
    const stamp=new Date().toISOString().replace(/[:.]/g,"-");
    const fileName=`4d-hospital-backup-${stamp}.json`;
    const backupObject:any={
      app:"4D HOSPITAL",
      version:3,
      exportedAt:new Date().toISOString(),
      results,
      agents:jsonLs<any[]>(LS_AGENTS,[]),
      settings:jsonLs<any>(LS_SETTINGS,defaultSettings()),
      preferences:{
        theme:localStorage.getItem(LS_THEME)||"#22c55e",
        language:localStorage.getItem(LS_LANGUAGE)||"bn",
        compact:localStorage.getItem(LS_COMPACT)==="1",
        luckyNumber:localStorage.getItem("secret_lucky_num")||"",
        luckyLocked:localStorage.getItem("secret_lucky_locked")==="1",
        adminPicks:jsonLs<any>(LS_PICKS,null)
      },
      localData:{
        users:jsonLs<any[]>(LS_USERS,[]),
        messages:jsonLs<any[]>(LS_MESSAGES,[]),
        securityEvents:jsonLs<any[]>(LS_SECURITY_EVENTS,[]),
        audit:jsonLs<any[]>(LS_AUDIT,[]),
        email:localStorage.getItem(LS_EMAIL)||"",
        invites:jsonLs<any[]>(LS_INVITES,[]),
        migrationConflicts:jsonLs<any[]>(LS_MIGRATION_CONFLICTS,[])
      }
    };
    const unsigned=JSON.stringify(backupObject);
    backupObject.checksum=backupChecksum(unsigned);
    const payload=JSON.stringify(backupObject,null,2);
    try{
      if(Capacitor.isNativePlatform()){
        // Android: browser Blob/anchor downloads are unreliable inside WebView.
        // Write the backup to the app Documents area, then open the native share/save sheet.
        const written=await Filesystem.writeFile({path:fileName,data:payload,directory:Directory.Documents,encoding:Encoding.UTF8,recursive:true});
        localAudit("backup_export",`${results.length} results exported to ${fileName}`,true);
        try{
          await Share.share({title:"4D HOSPITAL Backup",text:`${results.length}টি Draw-এর backup`,url:written.uri,dialogTitle:"Backup কোথায় সংরক্ষণ করবেন"});
          alert(`✅ ${results.length}টি Draw-এর backup তৈরি হয়েছে। Share/Save থেকে জায়গা নির্বাচন করুন।`);
        }catch{
          alert(`✅ Backup তৈরি হয়েছে। ফাইল: ${fileName}`);
        }
      }else{
        const blob=new Blob([payload],{type:"application/json"});
        const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download=fileName; a.click();
        setTimeout(()=>URL.revokeObjectURL(url),1000);
        localAudit("backup_export",`${results.length} results exported to ${fileName}`,true);
        alert(`✅ ${results.length}টি Draw-এর backup download হয়েছে।`);
      }
    }catch(err:any){
      localAudit("backup_export",String(err?.message||err),false);
      alert(`❌ Backup তৈরি করা যায়নি। ${err?.message||"Storage permission বা Files সমস্যা"}`);
    }
  }
  function normalizeMigrationRows(input:any):LotteryResult[]{
    const rows=Array.isArray(input)?input:(Array.isArray(input?.results)?input.results:Array.isArray(input?.data)?input.data:[]);
    return rows.map((r:any,i:number)=>{
      const rawCompany=String(r.company??r.operator??r.companyId??"magnum").toLowerCase().trim();
      const company=rawCompany.includes("magnum")?"magnum":rawCompany.includes("toto")?"toto":rawCompany.includes("damacai")||rawCompany.includes("da ma cai")||rawCompany==="dmc"?"damacai":rawCompany.includes("singapore")||rawCompany==="sgp"?"singapore":rawCompany;
      const date=String(r.date??r.drawDate??"").slice(0,10);
      const first=String(r.first??r.firstPrize??r["1st"]??"").replace(/\D/g,"").padStart(4,"0").slice(-4);
      const second=String(r.second??r.secondPrize??r["2nd"]??"").replace(/\D/g,"").padStart(4,"0").slice(-4);
      const third=String(r.third??r.thirdPrize??r["3rd"]??"").replace(/\D/g,"").padStart(4,"0").slice(-4);
      const arr=(v:any)=>Array.isArray(v)?v.map(String):String(v??"").split(/[\s,;|]+/).filter(Boolean);
      return {id:Number(r.id)||Date.now()+i,company,date,drawNo:r.drawNo??r.draw??r.drawNumber??null,first,second,third,special:arr(r.special).filter(x=>/^\d{4}$/.test(x)),consolation:arr(r.consolation).filter(x=>/^\d{4}$/.test(x))};
    }).filter((r:LotteryResult)=>/^\d{4}-\d{2}-\d{2}$/.test(r.date)&&COMPANY_IDS.includes(r.company as CompanyId)&&/^\d{4}$/.test(r.first)&&/^\d{4}$/.test(r.second)&&/^\d{4}$/.test(r.third));
  }
  function parseMigrationText(text:string):LotteryResult[]{
    const t=text.trim();
    if(!t) return [];
    try{return normalizeMigrationRows(JSON.parse(t));}catch{}
    const out:LotteryResult[]=[];
    for(const line of t.split(/\r?\n/)){
      const nums=line.match(/\b\d{4}\b/g)||[];
      const dm=line.match(/\b(20\d{2})[-\/.](\d{1,2})[-\/.](\d{1,2})\b/);
      if(dm&&nums.length>=3){
        const date=`${dm[1]}-${dm[2].padStart(2,"0")}-${dm[3].padStart(2,"0")}`;
        out.push({id:Date.now()+out.length,company:"magnum",date,drawNo:null,first:nums[0],second:nums[1],third:nums[2],special:nums.slice(3,13),consolation:nums.slice(13,23)});
      }
    }
    return out;
  }
  function mergeMigration(rows:LotteryResult[]){
    const map=new Map(results.map(r=>[`${r.company}|${r.date}`,r]));
    const conflicts:any[]=[];
    let added=0;
    let nextId=Math.max(0,...results.map(r=>Number(r.id)||0))+1;
    const fingerprint=(r:LotteryResult)=>JSON.stringify({company:r.company,date:r.date,drawNo:r.drawNo,first:r.first,second:r.second,third:r.third,special:r.special,consolation:r.consolation});
    for(const raw of rows){
      const r={...raw,id:nextId++};
      const k=`${r.company}|${r.date}`;
      const existing=map.get(k);
      if(!existing){map.set(k,r);added++;continue;}
      if(fingerprint(existing)!==fingerprint(r)) conflicts.push({key:k,existing,incoming:r,createdAt:nowIso()});
    }
    const merged=[...map.values()].sort((a,b)=>String(b.date).localeCompare(String(a.date))||Number(b.id)-Number(a.id));
    // Always rewrite IDs uniquely before persistence so old/new imports can never collide.
    const seen=new Set<number>(); let idCursor=1;
    const normalized=merged.map(r=>{let id=Number(r.id);if(!Number.isSafeInteger(id)||id<1||seen.has(id)){while(seen.has(id))idCursor++;id=idCursor;}seen.add(id);idCursor=Math.max(idCursor,id+1);return {...r,id};});
    if(conflicts.length){
      const old=jsonLs<any[]>(LS_MIGRATION_CONFLICTS,[]);
      saveLs(LS_MIGRATION_CONFLICTS,[...conflicts,...old].slice(0,200));
    }
    onRestore(normalized);
    return {added,conflicts:conflicts.length};
  }
  async function importVault(e:React.ChangeEvent<HTMLInputElement>){
    const f=e.target.files?.[0]; if(!f)return;
    try{
      const raw=JSON.parse(await f.text());
      if(raw && !Array.isArray(raw) && raw.app==="4D HOSPITAL" && raw.checksum){
        const supplied=String(raw.checksum);
        const copy={...raw}; delete copy.checksum;
        const actual=backupChecksum(JSON.stringify(copy));
        if(supplied!==actual) throw new Error("Backup ফাইলটি অসম্পূর্ণ বা পরিবর্তিত হয়েছে। নতুন backup ব্যবহার করুন।");
      }
      const clean=normalizeMigrationRows(raw);
      if(!clean.length) throw new Error("কোনো বৈধ result পাওয়া যায়নি");
      const report=mergeMigration(clean);

      // Restore the local app settings/Agent data when this is a full 4D HOSPITAL backup.
      if(raw && !Array.isArray(raw)){
        if(Array.isArray(raw.agents)) saveLs(LS_AGENTS,raw.agents);
        if(raw.settings && typeof raw.settings==="object") saveLs(LS_SETTINGS,raw.settings);
        if(raw.preferences && typeof raw.preferences==="object"){
          if(typeof raw.preferences.theme==="string") localStorage.setItem(LS_THEME,raw.preferences.theme);
          if(typeof raw.preferences.language==="string") localStorage.setItem(LS_LANGUAGE,raw.preferences.language);
          localStorage.setItem(LS_COMPACT,raw.preferences.compact?"1":"0");
          if(typeof raw.preferences.luckyNumber==="string") localStorage.setItem("secret_lucky_num",raw.preferences.luckyNumber);
          localStorage.setItem("secret_lucky_locked",raw.preferences.luckyLocked?"1":"0");
          if(raw.preferences.adminPicks && typeof raw.preferences.adminPicks==="object") saveLs(LS_PICKS,raw.preferences.adminPicks);
          applyAppPreferences();
        }
        if(raw.localData && typeof raw.localData==="object") {
          if(Array.isArray(raw.localData.users)) saveLs(LS_USERS,raw.localData.users);
          if(Array.isArray(raw.localData.messages)) saveLs(LS_MESSAGES,raw.localData.messages);
          if(Array.isArray(raw.localData.securityEvents)) saveLs(LS_SECURITY_EVENTS,raw.localData.securityEvents);
          if(Array.isArray(raw.localData.audit)) saveLs(LS_AUDIT,raw.localData.audit);
          if(typeof raw.localData.email==="string") localStorage.setItem(LS_EMAIL,raw.localData.email);
          if(Array.isArray(raw.localData.invites)) saveLs(LS_INVITES,raw.localData.invites);
          if(Array.isArray(raw.localData.migrationConflicts)) saveLs(LS_MIGRATION_CONFLICTS,raw.localData.migrationConflicts);
        }
      }
      alert(`✅ ${clean.length}টি record পড়া হয়েছে, নতুন করে ${report.added}টি যোগ হয়েছে।${report.conflicts?`\n⚠️ ${report.conflicts}টি conflict আলাদা করে সংরক্ষিত হয়েছে।`:""} Backup-এর settings/Agent data থাকলে সেগুলিও Restore হয়েছে।`);
    }catch(err:any){alert(err?.message||"Restore ব্যর্থ");}
    finally{e.target.value="";}
  }
  function runMigration(){try{const clean=parseMigrationText(migrationText); if(!clean.length) throw new Error("JSON বা date + 4-digit result format পাওয়া যায়নি"); const report=mergeMigration(clean); setMigrationMsg(`✅ ${clean.length}টি record শনাক্ত হয়েছে; ${report.added}টি নতুন record যোগ হয়েছে।${report.conflicts?` ⚠️ ${report.conflicts}টি conflict সংরক্ষিত হয়েছে।`:""}`); setMigrationText("");}catch(err:any){setMigrationMsg(`❌ ${err?.message||"Migration ব্যর্থ"}`);}}
  return <ViewShell title="Data Vault / History" subtitle="সব কোম্পানির তথ্য এক জায়গায়—খোঁজা, Edit, Delete, Full Backup/Restore ও বিশ্লেষণ" icon="🗄️">
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {[{l:"মোট ড্র",v:filtered.length},{l:"৪-ডিজিট তথ্য",v:all4.length},{l:"কোম্পানি",v:new Set(filtered.map(r=>r.company)).size},{l:"সর্বশেষ",v:filtered[0]?.date??"—"}].map(x=><Card key={x.l}><div className="text-slate-500 text-xs">{x.l}</div><div className="text-white font-black text-xl mt-1">{x.v}</div></Card>)}
      </div>
      <Card><div className="flex flex-col sm:flex-row gap-2"><select value={company} onChange={e=>setCompany(e.target.value as any)} className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white text-sm"><option value="all">সব কোম্পানি</option>{COMPANY_IDS.map(c=><option key={c} value={c}>{COMPANIES[c].name}</option>)}</select><input value={q} onChange={e=>setQ(e.target.value)} placeholder="তারিখ / নাম্বার / ড্র নম্বর দিয়ে খুঁজুন…" className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white text-sm"/><button onClick={exportVault} className="px-4 py-2 rounded-xl bg-blue-600 text-white font-bold text-sm">⬇️ Backup</button><label className="px-4 py-2 rounded-xl bg-emerald-700 text-white font-bold text-sm text-center cursor-pointer">⬆️ Restore<input type="file" accept="application/json,.json,text/plain,.txt" onChange={importVault} className="hidden"/></label><button onClick={()=>{setMigrationMsg("");setMigrationOpen(true)}} className="px-4 py-2 rounded-xl bg-violet-700 text-white font-bold text-sm">🔄 Data Migration</button></div></Card>
      {filtered.length>0&&<Card><div className="text-slate-400 text-xs mb-2">🔥 সবচেয়ে বেশি ব্যবহৃত digit: {hot.map(x=><span key={x.d} className="inline-block mx-1 px-2 py-1 rounded-lg bg-yellow-900/20 text-yellow-300 font-mono">{x.d} ({x.n})</span>)}</div></Card>}
      {jsonLs<any[]>(LS_MIGRATION_CONFLICTS,[]).length>0&&<Card><div className="flex items-center justify-between gap-3"><div><div className="text-yellow-300 font-bold text-sm">⚠️ Migration Conflict Log</div><div className="text-slate-500 text-xs mt-1">একই company + date-এ ভিন্ন result পাওয়া গেলে পুরনো master record overwrite করা হয়নি। Conflict আলাদা রাখা হয়েছে।</div></div><button onClick={()=>setShowConflicts(v=>!v)} className="px-3 py-2 rounded-lg bg-yellow-900/30 text-yellow-300 text-xs font-bold">{showConflicts?'Hide':'View'} ({jsonLs<any[]>(LS_MIGRATION_CONFLICTS,[]).length})</button></div>{showConflicts&&<div className="mt-3 space-y-2 max-h-80 overflow-auto">{jsonLs<any[]>(LS_MIGRATION_CONFLICTS,[]).slice(0,50).map((c:any,i:number)=><div key={i} className="rounded-xl bg-black/20 border border-yellow-900/30 p-3 text-xs"><div className="text-white font-bold">{c.key}</div><div className="text-slate-400 mt-1">Existing: <span className="font-mono text-green-300">{c.existing?.first} / {c.existing?.second} / {c.existing?.third}</span></div><div className="text-slate-400">Incoming: <span className="font-mono text-yellow-300">{c.incoming?.first} / {c.incoming?.second} / {c.incoming?.third}</span></div></div>)}</div>}</Card>}
      <div className="space-y-2">{filtered.map(r=><Card key={r.id}><div className="flex flex-col sm:flex-row sm:items-center gap-3"><div className="flex-1"><div className="flex items-center gap-2"><span className="text-white font-bold">{COMPANIES[r.company as CompanyId]?.name??r.company}</span><span className="text-slate-600 text-xs">{r.date}</span>{r.drawNo&&<span className="text-slate-500 text-xs">#{r.drawNo}</span>}</div><div className="flex gap-2 mt-2 flex-wrap">{[r.first,r.second,r.third].map((n,i)=><span key={i} className="font-mono font-black px-3 py-1 rounded-lg bg-slate-950 border border-slate-700 text-yellow-300">{n}</span>)}</div><div className="text-slate-600 text-[10px] mt-2">Special: {r.special.length} · Consolation: {r.consolation.length}</div></div><div className="flex gap-2"><button onClick={()=>startEdit(r)} className="px-3 py-2 rounded-lg bg-indigo-900/30 text-indigo-300 text-xs font-bold">✏️ Edit</button><button onClick={()=>{if(confirm("এই ড্রটি মুছবেন?"))onDeleteResult(r.id)}} className="px-3 py-2 rounded-lg bg-red-900/30 text-red-300 text-xs font-bold">🗑️ Delete</button></div></div></Card>)}{!filtered.length&&<Card><div className="text-center text-slate-500 py-10">কোনো তথ্য পাওয়া যায়নি। আগে Data Entry থেকে তথ্য সংরক্ষণ করুন।</div></Card>}</div>
      {results.length>0&&<button onClick={()=>{if(confirm("সব কোম্পানির সব data মুছে ফেলবেন? আগে Backup নিন।"))onClearAll()}} className="w-full py-3 rounded-xl border border-red-800/50 text-red-400 text-sm font-bold">⚠️ সব Data মুছে ফেলুন</button>}
      {migrationOpen&&<div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80"><div className="w-full max-w-lg rounded-2xl p-5 bg-zinc-950 border border-violet-700/50 space-y-3 max-h-[90vh] overflow-y-auto"><h3 className="text-white font-black">🔄 Old Data Migration / Import</h3><p className="text-slate-400 text-xs leading-5">পুরনো অ্যাপের data যদি JSON/text আকারে পাওয়া যায়, এখানে paste করুন। JSON backup ছাড়াও প্রতি লাইনে <span className="text-yellow-300">YYYY-MM-DD + 3টি 4-digit number</span> দিলে record তৈরি হবে। Existing data মুছে যাবে না; নতুন record যোগ হবে, আর একই company+date-এর ভিন্ন result হলে সেটি silently overwrite না হয়ে Conflict Log-এ সংরক্ষিত হবে।</p><textarea value={migrationText} onChange={e=>setMigrationText(e.target.value)} placeholder={'উদাহরণ:\n2026-09-09 1234 5678 9012 1111 2222 ...\nঅথবা পুরো JSON backup এখানে paste করুন'} className="w-full min-h-44 bg-slate-900 border border-slate-700 rounded-xl p-3 text-white font-mono text-xs"/><div className="flex gap-2"><button onClick={()=>setMigrationOpen(false)} className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300">বন্ধ</button><button onClick={runMigration} className="flex-1 py-2.5 rounded-xl bg-violet-600 text-white font-bold">🔄 Import / Merge</button></div>{migrationMsg&&<div className={`p-3 rounded-xl text-sm ${migrationMsg.startsWith("✅")?"bg-green-900/30 border border-green-700 text-green-300":"bg-red-900/30 border border-red-700 text-red-300"}`}>{migrationMsg}</div>}<div className="p-3 rounded-xl bg-yellow-900/10 border border-yellow-800/30 text-yellow-300 text-[11px]">⚠️ এই ব্যবস্থা অন্য অ্যাপের private SQLite/localStorage নিজে থেকে পড়তে পারে না। Android-এর app sandbox-এর কারণে পুরনো app-এর database সরাসরি নতুন app-এ দেখা যায় না।</div></div></div>}
      {editing&&<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75"><div className="w-full max-w-lg rounded-2xl p-5 bg-zinc-950 border border-zinc-700 space-y-3 max-h-[90vh] overflow-y-auto"><h3 className="text-white font-black">✏️ Data Edit</h3><div className="grid grid-cols-2 gap-2"><input type="date" value={draft.date} onChange={e=>setDraft({...draft,date:e.target.value})} className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"/><input value={draft.drawNo} onChange={e=>setDraft({...draft,drawNo:e.target.value})} placeholder="Draw No" className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"/></div><div className="grid grid-cols-3 gap-2">{['first','second','third'].map((k,i)=><input key={k} maxLength={4} inputMode="numeric" value={draft[k]} onChange={e=>setDraft({...draft,[k]:e.target.value.replace(/\D/g,"").slice(0,4)})} className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white text-center font-mono" placeholder={`${i+1}th`}/>)}</div><textarea value={draft.special} onChange={e=>setDraft({...draft,special:e.target.value})} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white" placeholder="Special"/><textarea value={draft.consolation} onChange={e=>setDraft({...draft,consolation:e.target.value})} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white" placeholder="Consolation"/><div className="flex gap-2"><button onClick={()=>setEditing(null)} className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300">বাতিল</button><button onClick={saveEdit} className="flex-1 py-2.5 rounded-xl bg-green-600 text-white font-bold">💾 Save</button></div></div></div>}
    </div>
  </ViewShell>;
}

// ─── Number Pattern Explorer (from the user's supplied HTML) ─────────────────
function PatternExplorerView(){
  const [digits,setDigits]=useState(['9','6','2','1']);
  const [date,setDate]=useState(''); const [code,setCode]=useState('');
  const [generated,setGenerated]=useState('');
  const [mode,setMode]=useState<'multiset'|'substring'>('multiset');
  const vals=digits.join('');
  function perms(a:string[]){
    const out=new Set<string>(); const used=Array(a.length).fill(false); const cur:string[]=[];
    const bt=()=>{if(cur.length===a.length){out.add(cur.join(''));return;}for(let i=0;i<a.length;i++){if(used[i])continue;if(i&&a[i]===a[i-1]&&!used[i-1])continue;used[i]=true;cur.push(a[i]);bt();cur.pop();used[i]=false;}}; bt(); return [...out].sort();
  }
  function hash(s:string){let h1=5381,h2=52711;for(let i=0;i<s.length;i++){const c=s.charCodeAt(i);h1=((h1*33)^c)>>>0;h2=((h2*31)+c)>>>0;}return String((((h1^h2)>>>0)%10000)).padStart(4,'0');}
  const patterns:string[]=Array.from(new Set<string>(digits.map((_,i)=>digits.filter((__,j)=>i!==j).join(''))));
  const all=useMemo(()=>Array.from({length:10000},(_,i)=>String(i).padStart(4,'0')),[]);
  const matchCache=useMemo(()=>patterns.map(p=>{const need=p.split('').reduce((m,d)=>(m[d]=(m[d]??0)+1,m),{} as Record<string,number>);return all.filter(n=>mode==='multiset'?Object.entries(need).every(([d,c])=>n.split('').filter(x=>x===d).length>=Number(c)):n.includes(p));}),[all,patterns,mode]);
  const matches=(p:string):string[]=>matchCache[patterns.indexOf(p)]??[];
  return <ViewShell title="Number Pattern Explorer" subtitle="আপনার দেওয়া ফাইলের permutation, drop-one-digit match এবং date/code generator" icon="🔢">
    <div className="space-y-4">
      <Card><h2 className="text-white font-bold mb-3">তারিখ + ড্র কোড → ৪-অঙ্ক নাম্বার</h2><div className="grid grid-cols-1 sm:grid-cols-3 gap-2"><input type="date" value={date} onChange={e=>setDate(e.target.value)} className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white"/><input value={code} onChange={e=>setCode(e.target.value)} placeholder="ড্র কোড (যেমন A12)" className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white"/><button onClick={()=>{if(date&&code){const n=hash(date+'|'+code);setGenerated(n);setDigits(n.split(''));}}} className="bg-yellow-600 text-white font-bold rounded-xl">নাম্বার তৈরি করুন</button></div>{generated&&<div className="text-yellow-400 font-mono font-bold mt-3">তৈরি হওয়া নাম্বার: {generated}</div>}</Card>
      <Card><div className="flex flex-wrap gap-2 items-center"><h2 className="text-white font-bold mr-2">৪ অঙ্ক বিশ্লেষণ</h2>{digits.map((d,i)=><input key={i} value={d} maxLength={1} inputMode="numeric" onChange={e=>setDigits(x=>x.map((v,j)=>j===i?e.target.value.replace(/\D/g,'').slice(0,1):v))} className="w-12 h-12 text-center bg-slate-950 border border-slate-700 rounded-xl text-yellow-400 font-mono text-xl"/> )}</div>
        <div className="mt-4"><h3 className="text-yellow-400 font-bold text-sm">পূর্ণ বিন্যাস ({perms(digits).length})</h3><div className="flex flex-wrap gap-1.5 mt-2">{perms(digits).map(p=><span key={p} className={`px-2 py-1 rounded-lg border font-mono text-xs ${p===vals?'border-yellow-500 text-yellow-400':'border-slate-700 text-slate-300 bg-slate-950'}`}>{p}</span>)}</div></div>
      </Card>
      <Card><div className="flex items-center justify-between gap-2"><div><h2 className="text-white font-bold">একটি অঙ্ক বাদ দিলে মিল</h2><p className="text-slate-500 text-xs">যেকোনো অবস্থানে অথবা পাশাপাশি/ক্রমে</p></div><div className="flex gap-1"><button onClick={()=>setMode('multiset')} className={`px-2 py-1 rounded text-xs ${mode==='multiset'?'bg-green-600 text-white':'bg-slate-800 text-slate-400'}`}>যেকোনো</button><button onClick={()=>setMode('substring')} className={`px-2 py-1 rounded text-xs ${mode==='substring'?'bg-green-600 text-white':'bg-slate-800 text-slate-400'}`}>ক্রমে</button></div></div>
        <div className="space-y-3 mt-3">{patterns.map(p=>{const ms=matches(p);return <div key={p} className="bg-slate-950 border border-slate-800 rounded-xl p-3"><div className="text-yellow-400 font-mono font-bold mb-2">{p} <span className="text-slate-600 text-xs">— {ms.length}টি</span></div><div className="max-h-40 overflow-y-auto flex flex-wrap gap-1">{ms.map(n=><span key={n} className="text-slate-400 font-mono text-xs bg-slate-900 px-1.5 py-0.5 rounded">{n}</span>)}</div></div>})}</div>
      </Card>
    </div>
  </ViewShell>;
}

// ─── Local Agent / KYC Manager ───────────────────────────────────────────────
type AgentRow={id:number;name:string;phone:string;company:CompanyId;kyc:'pending'|'verified'|'rejected';active:boolean;note:string;createdAt:string};
function AgentsKYCView(){
  const [rows,setRows]=useState<AgentRow[]>(()=>jsonLs<AgentRow[]>(LS_AGENTS,[]));
  const [form,setForm]=useState({name:'',phone:'',company:'magnum' as CompanyId,kyc:'pending' as AgentRow['kyc'],note:''});
  const [editId,setEditId]=useState<number|null>(null);
  function persist(next:AgentRow[]){setRows(next);saveLs(LS_AGENTS,next);}
  function save(){if(!form.name.trim()){return;} const existing=editId?rows.find(r=>r.id===editId):null; const row:AgentRow={id:editId??Date.now(),name:form.name.trim(),phone:form.phone.trim(),company:form.company,kyc:form.kyc,active:existing?.active??true,note:form.note.trim(),createdAt:existing?.createdAt??nowIso()}; persist(editId?rows.map(r=>r.id===editId?row:r):[row,...rows]); setForm({name:'',phone:'',company:'magnum',kyc:'pending',note:''});setEditId(null);}
  function edit(r:AgentRow){setEditId(r.id);setForm({name:r.name,phone:r.phone,company:r.company,kyc:r.kyc,note:r.note});}
  return <ViewShell title="Agent / KYC Manager" subtitle="লোকাল ডিভাইসে agent তালিকা, company assignment ও KYC status পরিচালনা করুন" icon="👥"><div className="space-y-4"><Card><div className="grid grid-cols-1 sm:grid-cols-2 gap-3"><input value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} placeholder="Agent name" className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white"/><input value={form.phone} onChange={e=>setForm(f=>({...f,phone:e.target.value}))} placeholder="Phone / reference" className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white"/><CompanyPicker value={form.company} onChange={v=>setForm(f=>({...f,company:v}))}/><select value={form.kyc} onChange={e=>setForm(f=>({...f,kyc:e.target.value as AgentRow['kyc']}))} className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white"><option value="pending">KYC Pending</option><option value="verified">KYC Verified</option><option value="rejected">KYC Rejected</option></select><textarea value={form.note} onChange={e=>setForm(f=>({...f,note:e.target.value}))} placeholder="Note / assignment" className="sm:col-span-2 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white"/><button onClick={save} className="sm:col-span-2 bg-blue-600 text-white font-bold rounded-xl py-3">{editId?'✏️ Update Agent':'➕ Add Agent'}</button></div><p className="text-slate-600 text-[10px] mt-3">এটি device-local management; কোনো remote account বা server permission তৈরি করে না।</p></Card><div className="space-y-2">{rows.map(r=><Card key={r.id}><div className="flex items-start justify-between gap-3"><div><div className="text-white font-bold">{r.name}</div><div className="text-slate-500 text-xs">{r.phone||'—'} · {COMPANIES[r.company].name}</div><div className="text-xs mt-1"><span className={`px-2 py-0.5 rounded-full ${r.kyc==='verified'?'bg-green-900/40 text-green-300':r.kyc==='rejected'?'bg-red-900/40 text-red-300':'bg-yellow-900/40 text-yellow-300'}`}>KYC {r.kyc}</span><span className="ml-2 text-slate-500">{r.active?'Active':'Inactive'}</span></div>{r.note&&<div className="text-slate-400 text-xs mt-2">{r.note}</div>}</div><div className="flex gap-2"><button onClick={()=>edit(r)} className="text-indigo-300 text-xs px-2 py-1 rounded bg-indigo-900/20">✏️ Edit</button><button onClick={()=>persist(rows.filter(x=>x.id!==r.id))} className="text-red-300 text-xs px-2 py-1 rounded bg-red-900/20">🗑️</button></div></div></Card>)}{!rows.length&&<Card><p className="text-slate-500 text-center text-sm">এখনও কোনো agent যোগ করা হয়নি।</p></Card>}</div></div></ViewShell>;
}

// ─── Pattern Frequency Heatmap ────────────────────────────────────────────────
function HeatmapView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const filtered = results.filter(r=>r.company===company);
  const pairGrid: Record<string,Record<string,number>> = {};
  for (let i=0;i<10;i++) { pairGrid[i] = {}; for (let j=0;j<10;j++) pairGrid[i][j]=0; }
  for (const r of filtered) for (const n of prizeNums(r)) if (n.length===4) {
    const d=n.split(""); for (let i=0;i<3;i++) pairGrid[d[i]][d[i+1]] = (pairGrid[d[i]][d[i+1]]??0)+1;
  }
  const maxV = Math.max(...Object.values(pairGrid).flatMap(row=>Object.values(row)))||1;
  const heat = (v:number) => {
    const t = v/maxV;
    if (t>0.8) return "bg-red-600 text-white"; if (t>0.6) return "bg-orange-500 text-white";
    if (t>0.4) return "bg-yellow-500 text-black"; if (t>0.2) return "bg-blue-700 text-white";
    return t>0 ? "bg-slate-600 text-slate-300" : "bg-slate-800 text-slate-700";
  };
  return (
    <ViewShell title="Pattern Frequency Heatmap" subtitle="পাশাপাশি দুটো ডিজিটের সংমিশ্রণ কতবার এসেছে — গরম রঙ মানে বেশিবার" icon="🔥">
      <div className="flex justify-end"><CompanyPicker value={company} onChange={setCompany}/></div>
      {filtered.length<5 ? noData() : (
        <Card>
          <h2 className="text-white font-semibold mb-4 text-sm">2-Digit Consecutive Pair Matrix (row = পূর্ববর্তী ডিজিট, col = পরবর্তী ডিজিট)</h2>
          <div className="overflow-x-auto">
            <table className="text-xs border-collapse">
              <thead>
                <tr>
                  <th className="w-8 h-8 text-slate-500 font-bold">→</th>
                  {Array.from({length:10},(_,j)=><th key={j} className="w-9 h-8 text-slate-400 font-mono">{j}</th>)}
                </tr>
              </thead>
              <tbody>
                {Array.from({length:10},(_,i)=>(
                  <tr key={i}>
                    <td className="w-8 text-slate-400 font-mono font-bold text-center">{i}</td>
                    {Array.from({length:10},(_,j)=>{
                      const v=pairGrid[i]?.[j]??0;
                      return <td key={j} className={`w-9 h-9 text-center font-mono font-bold rounded ${heat(v)} transition`} title={`${i}→${j}: ${v}×`}>{v||""}</td>;
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex gap-3 mt-4 flex-wrap text-xs text-slate-400">
            {[["bg-red-600","Very Hot"],["bg-orange-500","Hot"],["bg-yellow-500","Warm"],["bg-blue-700","Cool"],["bg-slate-600","Rare"]].map(([cls,l])=>(
              <span key={l} className="flex items-center gap-1"><span className={`w-3 h-3 rounded ${cls}`}/>{l}</span>
            ))}
          </div>
        </Card>
      )}
    </ViewShell>
  );
}

// ─── Historical Regression Trends ─────────────────────────────────────────────
function RegressionView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const filtered = useMemo(()=>results.filter(r=>r.company===company).sort((a,b)=>a.date.localeCompare(b.date)),[results,company]);
  const months = useMemo(()=>{
    const map: Record<string,Record<string,number>> = {};
    for (const r of filtered) {
      const m = r.date.slice(0,7);
      if (!map[m]) map[m]={};
      for (const n of prizeNums(r)) for (const d of n.split("")) if (/\d/.test(d)) map[m][d]=(map[m][d]??0)+1;
    }
    return Object.entries(map).slice(-12).map(([m,freq])=>({month:m,...freq}));
  },[filtered]);
  const COLORS=["#ef4444","#f97316","#eab308","#22c55e","#06b6d4","#3b82f6","#8b5cf6","#ec4899","#14b8a6","#f59e0b"];
  return (
    <ViewShell title="Historical Regression Trends" subtitle="গত ১২ মাসে প্রতিটি ডিজিটের আবির্ভাব কীভাবে পরিবর্তন হয়েছে" icon="📉">
      <div className="flex justify-end"><CompanyPicker value={company} onChange={setCompany}/></div>
      {months.length<2 ? noData() : (
        <Card>
          <ResponsiveContainer width="100%" height={320}>
            <LineChart data={months} margin={{top:10,right:10,left:-20,bottom:5}}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155"/>
              <XAxis dataKey="month" tick={{fill:"#94a3b8",fontSize:10}} tickFormatter={v=>v.slice(5)}/>
              <YAxis tick={{fill:"#94a3b8",fontSize:10}}/>
              <Tooltip contentStyle={{background:"#1e293b",border:"1px solid #334155",borderRadius:8,fontSize:11}} labelStyle={{color:"#fff"}}/>
              <Legend wrapperStyle={{fontSize:11}}/>
              {Array.from({length:10},(_,i)=>String(i)).map((d,i)=>(
                <Line key={d} type="monotone" dataKey={d} name={`Digit ${d}`} stroke={COLORS[i]} strokeWidth={2} dot={false}/>
              ))}
            </LineChart>
          </ResponsiveContainer>
        </Card>
      )}
    </ViewShell>
  );
}

// ─── Calendar & Draw-Day Correlation ──────────────────────────────────────────
function CalendarView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const filtered = results.filter(r=>r.company===company);
  const DAYS = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  const dayStats = useMemo(()=>{
    const ds: Record<number,{draws:number;digits:Record<string,number>}> = {};
    for (let i=0;i<7;i++) ds[i]={draws:0,digits:{}};
    for (const r of filtered) {
      const d=new Date(r.date).getDay();
      ds[d].draws++;
      for (const n of prizeNums(r)) for (const c of n.split("")) if (/\d/.test(c)) ds[d].digits[c]=(ds[d].digits[c]??0)+1;
    }
    return ds;
  },[filtered]);
  const maxDraws = Math.max(...Object.values(dayStats).map(d=>d.draws))||1;
  return (
    <ViewShell title="Calendar & Draw-Day Correlation" subtitle="সপ্তাহের কোন দিন কোন ডিজিট বেশি আসে" icon="📅">
      <div className="flex justify-end"><CompanyPicker value={company} onChange={setCompany}/></div>
      {filtered.length<5 ? noData() : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {DAYS.map((day,i)=>{
            const s=dayStats[i]; if (s.draws===0) return null;
            const topDigit=Object.entries(s.digits).sort((a,b)=>b[1]-a[1])[0];
            return (
              <Card key={day}>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-white font-bold">{day}</span>
                  <span className="text-slate-500 text-xs">{s.draws} draws</span>
                </div>
                <div className="w-full h-2 bg-slate-700 rounded-full mb-3"><div className="h-full rounded-full bg-blue-500" style={{width:`${(s.draws/maxDraws)*100}%`}}/></div>
                {topDigit && <div className="text-center">
                  <div className="text-slate-400 text-xs mb-1">Hot Digit</div>
                  <div className="font-mono font-black text-3xl text-yellow-400">{topDigit[0]}</div>
                  <div className="text-slate-500 text-xs">×{topDigit[1]}</div>
                </div>}
              </Card>
            );
          })}
        </div>
      )}
    </ViewShell>
  );
}

// ─── High/Low & Odd/Even Matrix ───────────────────────────────────────────────
function HighLowMatrixView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const filtered = results.filter(r=>r.company===company);
  type Pattern = { hl: string; oe: string; count: number };
  const patterns = useMemo(()=>{
    const map: Record<string,{hl:string;oe:string;count:number}> = {};
    for (const r of filtered) for (const n of prizeNums(r)) if (n.length===4) {
      const d=n.split("").map(Number);
      const hl=d.map(x=>x>=5?"H":"L").join("");
      const oe=d.map(x=>x%2===0?"E":"O").join("");
      const key=`${hl}|${oe}`;
      if(!map[key])map[key]={hl,oe,count:0};
      map[key].count++;
    }
    return Object.values(map).sort((a,b)=>b.count-a.count);
  },[filtered]);
  const total=patterns.reduce((s,p)=>s+p.count,0)||1;
  const hlSummary: Record<string,number>={HHHH:0,LLLL:0,HHLL:0,LLHH:0};
  const oeSummary: Record<string,number>={EEEE:0,OOOO:0,EOEO:0};
  for (const p of patterns) { hlSummary[p.hl]=(hlSummary[p.hl]??0)+p.count; oeSummary[p.oe]=(oeSummary[p.oe]??0)+p.count; }
  const hlTotH=patterns.reduce((s,p)=>s+(p.hl.split("").filter(c=>c==="H").length*p.count),0);
  const hlTotL=patterns.reduce((s,p)=>s+(p.hl.split("").filter(c=>c==="L").length*p.count),0);
  const oeTotE=patterns.reduce((s,p)=>s+(p.oe.split("").filter(c=>c==="E").length*p.count),0);
  const oeTotO=patterns.reduce((s,p)=>s+(p.oe.split("").filter(c=>c==="O").length*p.count),0);
  const oeTotal=oeTotE+oeTotO||1; const hlTotal=hlTotH+hlTotL||1;
  return (
    <ViewShell title="High/Low & Odd/Even Matrix" subtitle="৪ডিজিটের High(5-9)/Low(0-4) এবং Odd/Even বিতরণ বিশ্লেষণ" icon="🌗">
      <div className="flex justify-end"><CompanyPicker value={company} onChange={setCompany}/></div>
      {filtered.length<5 ? noData() : (<>
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <h3 className="text-white font-semibold mb-4">High vs Low Distribution</h3>
            <div className="flex items-center gap-3 mb-3">
              <div className="flex-1"><div className="text-slate-400 text-xs mb-1">High (5-9)</div><div className="text-white font-black text-2xl">{Math.round((hlTotH/hlTotal)*100)}%</div></div>
              <div className="flex-1"><div className="text-slate-400 text-xs mb-1">Low (0-4)</div><div className="text-white font-black text-2xl">{Math.round((hlTotL/hlTotal)*100)}%</div></div>
            </div>
            <div className="flex h-4 rounded-full overflow-hidden">
              <div className="bg-red-500" style={{width:`${(hlTotH/hlTotal)*100}%`}}/>
              <div className="bg-blue-500 flex-1"/>
            </div>
          </Card>
          <Card>
            <h3 className="text-white font-semibold mb-4">Odd vs Even Distribution</h3>
            <div className="flex items-center gap-3 mb-3">
              <div className="flex-1"><div className="text-slate-400 text-xs mb-1">Odd</div><div className="text-white font-black text-2xl">{Math.round((oeTotO/oeTotal)*100)}%</div></div>
              <div className="flex-1"><div className="text-slate-400 text-xs mb-1">Even</div><div className="text-white font-black text-2xl">{Math.round((oeTotE/oeTotal)*100)}%</div></div>
            </div>
            <div className="flex h-4 rounded-full overflow-hidden">
              <div className="bg-purple-500" style={{width:`${(oeTotO/oeTotal)*100}%`}}/>
              <div className="bg-green-500 flex-1"/>
            </div>
          </Card>
        </div>
        <Card>
          <h3 className="text-white font-semibold mb-4">Top Pattern Combinations</h3>
          <div className="space-y-2">
            {patterns.slice(0,10).map((p,i)=>(
              <div key={i} className="flex items-center gap-3">
                <span className="font-mono text-white w-12 text-sm">{p.hl}</span>
                <span className="font-mono text-slate-400 w-12 text-sm">{p.oe}</span>
                <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 rounded-full" style={{width:`${(p.count/total)*100*5}%`, maxWidth:"100%"}}/>
                </div>
                <span className="text-slate-400 text-xs w-16 text-right">{Math.round((p.count/total)*100)}% ({p.count}×)</span>
              </div>
            ))}
          </div>
        </Card>
      </>)}
    </ViewShell>
  );
}

// ─── Mirror Number Logic ──────────────────────────────────────────────────────
function MirrorView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const filtered = results.filter(r=>r.company===company);
  const numSet = useMemo(()=>{
    const s=new Set<string>();
    for (const r of filtered) for (const n of [r.first,r.second,r.third,...r.special,...r.consolation]) if (/^\d{4}$/.test(n)) s.add(n);
    return s;
  },[filtered]);
  const mirrors = useMemo(()=>{
    const seen=new Set<string>(); const pairs:Array<{a:string;b:string;count:number}>=[];
    for (const n of Array.from(numSet)) {
      const rev=n.split("").reverse().join("");
      if (rev!==n && numSet.has(rev) && !seen.has(rev+n)) { seen.add(n+rev); pairs.push({a:n,b:rev,count:2}); }
    }
    return pairs;
  },[numSet]);
  const freqMap=useMemo(()=>{
    const f: Record<string,number>={};
    for (const r of filtered) for (const n of prizeNums(r)) f[n]=(f[n]??0)+1;
    return f;
  },[filtered]);
  return (
    <ViewShell title="Mirror Number Logic Filter" subtitle="কোন সংখ্যার উল্টো (mirror) সংখ্যাটিও ইতিমধ্যে এসেছে — এরা জোড়া pattern" icon="🪞">
      <div className="flex justify-end"><CompanyPicker value={company} onChange={setCompany}/></div>
      {filtered.length<5 ? noData() : (
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-semibold">Mirror Pairs Found</h3>
            <span className="bg-blue-600/30 text-blue-300 border border-blue-600/40 text-xs px-3 py-1 rounded-full font-semibold">{mirrors.length} pairs</span>
          </div>
          {mirrors.length===0
            ? <div className="text-slate-500 text-sm text-center py-8">কোনো mirror pair পাওয়া যায়নি।</div>
            : <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {mirrors.map(({a,b},i)=>(
                  <div key={i} className="bg-slate-700/50 border border-slate-600 rounded-xl p-3 flex items-center justify-center gap-3">
                    <div className="text-center"><div className="font-mono font-black text-xl text-white">{a}</div><div className="text-xs text-slate-500">×{freqMap[a]??0}</div></div>
                    <span className="text-slate-500 text-lg">🪞</span>
                    <div className="text-center"><div className="font-mono font-black text-xl text-blue-300">{b}</div><div className="text-xs text-slate-500">×{freqMap[b]??0}</div></div>
                  </div>
                ))}
              </div>
          }
          <div className="mt-4 p-3 bg-blue-900/20 border border-blue-700/30 rounded-xl text-blue-300 text-xs">
            💡 Mirror pairs often share statistical properties. Both numbers may be worth watching.
          </div>
        </Card>
      )}
    </ViewShell>
  );
}

// ─── Benford's Law ────────────────────────────────────────────────────────────
function BenfordView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const filtered = results.filter(r=>r.company===company);
  const expected = [30.1,17.6,12.5,9.7,7.9,6.7,5.8,5.1,4.6];
  const actual = useMemo(()=>{
    const freq: Record<string,number>={};
    for (const r of filtered) for (const n of prizeNums(r)) { const d=n[0]; if (d&&d!=="0") freq[d]=(freq[d]??0)+1; }
    const total=Object.values(freq).reduce((a,b)=>a+b,0)||1;
    return Array.from({length:9},(_,i)=>Math.round(((freq[String(i+1)]??0)/total)*1000)/10);
  },[filtered]);
  const data=Array.from({length:9},(_,i)=>({digit:String(i+1),expected:expected[i],actual:actual[i]}));
  const deviation=data.reduce((s,d)=>s+Math.abs(d.actual-d.expected),0)/9;
  return (
    <ViewShell title="Benford's Law Frequency Check" subtitle="প্রথম ডিজিটের প্রকৃত বিতরণ বনাম Benford's Law-এর প্রত্যাশিত বিতরণ" icon="📊">
      <div className="flex justify-end"><CompanyPicker value={company} onChange={setCompany}/></div>
      {filtered.length<10 ? noData() : (<>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="md:col-span-2">
            <h3 className="text-white font-semibold mb-4">Expected vs Actual First-Digit %</h3>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={data} margin={{top:5,right:5,left:-20,bottom:5}}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155"/>
                <XAxis dataKey="digit" tick={{fill:"#94a3b8",fontSize:11}}/>
                <YAxis tick={{fill:"#94a3b8",fontSize:11}}/>
                <Tooltip contentStyle={{background:"#1e293b",border:"1px solid #334155",borderRadius:8}} labelStyle={{color:"#fff"}}/>
                <Legend wrapperStyle={{fontSize:11}}/>
                <Bar dataKey="expected" name="Benford Expected %" fill="#3b82f6" opacity={0.7} radius={[4,4,0,0]}/>
                <Bar dataKey="actual" name="Actual %" fill="#ef4444" radius={[4,4,0,0]}/>
              </BarChart>
            </ResponsiveContainer>
          </Card>
          <Card>
            <h3 className="text-white font-semibold mb-3">Anomaly Score</h3>
            <div className="text-center">
              <div className={`text-5xl font-black mb-2 ${deviation<3?"text-green-400":deviation<7?"text-yellow-400":"text-red-400"}`}>{deviation.toFixed(1)}</div>
              <div className="text-slate-400 text-xs mb-3">avg % deviation</div>
              <div className={`inline-block px-3 py-1.5 rounded-full text-sm font-semibold ${deviation<3?"bg-green-900/40 text-green-300 border border-green-700":deviation<7?"bg-yellow-900/40 text-yellow-300 border border-yellow-700":"bg-red-900/40 text-red-300 border border-red-700"}`}>
                {deviation<3?"✅ Normal":"⚠️ Anomaly Detected"}
              </div>
            </div>
            <div className="mt-4 space-y-1">
              {data.map(d=>{
                const diff=d.actual-d.expected;
                return (
                  <div key={d.digit} className="flex items-center gap-2 text-xs">
                    <span className="text-slate-400 w-4">{d.digit}</span>
                    <span className={`font-mono ${diff>3?"text-red-400":diff<-3?"text-blue-400":"text-slate-400"}`}>{diff>0?"+":""}{diff.toFixed(1)}%</span>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>
      </>)}
    </ViewShell>
  );
}

// ─── LSTM Sequence Trend Finder ───────────────────────────────────────────────
function LSTMView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const filtered = useMemo(()=>results.filter(r=>r.company===company).sort((a,b)=>a.date.localeCompare(b.date)),[results,company]);
  const model = useMemo(()=>trainLstmDigitModel(filtered.slice(-240).map(r=>r.first),8,14),[filtered]);
  const predicted = useMemo(()=>model.map(m=>m.probabilities.indexOf(Math.max(...m.probabilities))).join(""),[model]);
  const confidence = useMemo(()=>Math.round(model.reduce((a,m)=>a+m.probabilities[Math.max(0,m.probabilities.indexOf(Math.max(...m.probabilities)))] ,0)/4*100),[model]);
  return (
    <ViewShell title="LSTM Sequence Model" subtitle="Historical 4D sequence থেকে compact recurrent model train করে পরবর্তী digit distribution বের করে" icon="🧠">
      <div className="flex justify-end"><CompanyPicker value={company} onChange={setCompany}/></div>
      {filtered.length<12 ? noData() : (<div className="space-y-4">
        <Card className="text-center">
          <div className="text-slate-400 text-xs mb-2">Model-ranked candidate</div>
          <div className="font-mono font-black text-5xl text-blue-400 tracking-widest">{predicted}</div>
          <div className="text-slate-500 text-xs mt-2">Model confidence index: {confidence}% — not a winning probability</div>
        </Card>
        <Card>
          <h3 className="text-white font-semibold mb-4">Per-position next-digit distribution</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {model.map((m,p)=><div key={p} className="bg-slate-800/70 rounded-xl p-3">
              <div className="text-slate-400 text-xs mb-2">Position {p+1}</div>
              <div className="font-mono text-2xl text-white">{predicted[p]}</div>
              <div className="text-xs text-slate-500 mt-1">top score {Math.round(Math.max(...m.probabilities)*1000)/10}%</div>
            </div>)}
          </div>
        </Card>
      </div>)}
    </ViewShell>
  );
}

// ─── Markov Chain Predictor ───────────────────────────────────────────────────
function MarkovView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const filtered = useMemo(()=>results.filter(r=>r.company===company).sort((a,b)=>a.date.localeCompare(b.date)),[results,company]);
  const { matrix, prediction } = useMemo(()=>{
    const trans: Record<string,Record<string,number>>={};
    for (let i=0;i<10;i++) { trans[i]={}; for (let j=0;j<10;j++) trans[i][j]=0; }
    const firstDigits=filtered.map(r=>r.first[0]).filter(Boolean);
    for (let i=0;i<firstDigits.length-1;i++) { const a=firstDigits[i],b=firstDigits[i+1]; trans[a][b]=(trans[a][b]??0)+1; }
    const rowTotals: Record<string,number>={};
    for (let i=0;i<10;i++) rowTotals[i]=Object.values(trans[i]).reduce((a,b)=>a+b,0)||1;
    const prob: Record<string,Record<string,number>>={};
    for (let i=0;i<10;i++) { prob[i]={}; for (let j=0;j<10;j++) prob[i][j]=Math.round((trans[i][j]/rowTotals[i])*100); }
    const last=firstDigits[firstDigits.length-1]??"5";
    const nextDigit=Object.entries(prob[last]??{}).sort((a,b)=>Number(b[1])-Number(a[1]))[0]?.[0]??"5";
    return { matrix:prob, prediction:{from:last,to:nextDigit,prob:prob[last]?.[nextDigit]??0} };
  },[filtered]);
  const maxP=100;
  return (
    <ViewShell title="Markov Chain Step Predictor" subtitle="এক ডিজিট থেকে পরের ডিজিটে যাওয়ার সম্ভাবনা matrix — last draw থেকে পরবর্তী prediction" icon="🔄">
      <div className="flex justify-end"><CompanyPicker value={company} onChange={setCompany}/></div>
      {filtered.length<10 ? noData() : (<>
        <Card>
          <div className="flex items-center gap-6 flex-wrap">
            <div className="text-center">
              <div className="text-slate-400 text-xs mb-1">Last 1st Digit</div>
              <div className="font-mono font-black text-5xl text-white">{prediction.from}</div>
            </div>
            <div className="text-slate-500 text-3xl">→</div>
            <div className="text-center">
              <div className="text-slate-400 text-xs mb-1">Predicted Next</div>
              <div className="font-mono font-black text-5xl text-blue-400">{prediction.to}</div>
            </div>
            <div className="text-center">
              <div className="text-slate-400 text-xs mb-1">Probability</div>
              <div className="font-black text-4xl text-green-400">{prediction.prob}%</div>
            </div>
          </div>
        </Card>
        <Card>
          <h3 className="text-white font-semibold mb-4 text-sm">Transition Probability Matrix (row=current, col=next, %)</h3>
          <div className="overflow-x-auto">
            <table className="text-xs border-collapse">
              <thead><tr><th className="w-8 text-slate-500 font-bold">→</th>{Array.from({length:10},(_,j)=><th key={j} className="w-9 h-8 text-slate-400 font-mono">{j}</th>)}</tr></thead>
              <tbody>
                {Array.from({length:10},(_,i)=>(
                  <tr key={i}><td className="w-8 text-slate-400 font-mono font-bold text-center">{i}</td>
                    {Array.from({length:10},(_,j)=>{
                      const v=matrix[i]?.[j]??0;
                      const bg=v>50?"bg-red-600 text-white":v>30?"bg-orange-500 text-white":v>15?"bg-yellow-500 text-black":v>5?"bg-slate-600 text-slate-200":"bg-slate-800 text-slate-600";
                      return <td key={j} className={`w-9 h-9 text-center font-mono rounded transition ${bg}`}>{v||""}</td>;
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </>)}
    </ViewShell>
  );
}

// ─── Genetic Algorithm Combinator ─────────────────────────────────────────────
function GeneticView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const [generation, setGeneration] = useState(18);
  const filtered = useMemo(()=>results.filter(r=>r.company===company),[results,company]);
  const evolved = useMemo(()=>{
    const posF=buildPosFreq(filtered.slice(-100));
    const fitness=(num:string)=>{
      if(!/^\d{4}$/.test(num)) return 0;
      const d=num.split("");
      let s=0; for(let i=0;i<4;i++) s+=(posF[i][d[i]]??0);
      const unique=new Set(d).size;
      return s + (unique===4?1.5:unique===3?.5:0);
    };
    return geneticOptimize(fitness,120,generation,0x4d484f53);
  },[filtered,generation]);
  const population=[...evolved.entries()].sort((a,b)=>b[1]-a[1]).slice(0,10);
  return (
    <ViewShell title="Genetic Algorithm Optimizer" subtitle="Selection + crossover + mutation + elitism দিয়ে historical fitness function optimize করে" icon="🧬">
      <div className="flex items-center gap-3 flex-wrap justify-between">
        <CompanyPicker value={company} onChange={setCompany}/>
        <div className="flex items-center gap-2">
          <span className="text-slate-400 text-sm">Generations: <span className="text-white font-bold">{generation}</span></span>
          <button onClick={()=>setGeneration(g=>Math.min(100,g+5))} className="bg-green-600 hover:bg-green-700 text-white text-xs font-semibold px-3 py-1.5 rounded-lg">Evolve +5</button>
          <button onClick={()=>setGeneration(18)} className="bg-slate-700 hover:bg-slate-600 text-white text-xs px-3 py-1.5 rounded-lg">Reset</button>
        </div>
      </div>
      {filtered.length<10 ? noData() : (<div className="space-y-4">
        <Card className="text-center">
          <div className="text-slate-400 text-xs mb-2">🏆 Best evolved candidate</div>
          <div className="font-mono font-black text-6xl text-green-400 tracking-widest">{population[0]?.[0]??"----"}</div>
          <div className="text-slate-500 text-xs mt-2">Fitness is historical ranking evidence, not a guaranteed prediction.</div>
        </Card>
        <Card>
          <h3 className="text-white font-semibold mb-4">Final population — top 10</h3>
          <div className="space-y-2">
            {population.map(([n,score],i)=><div key={n} className="flex items-center gap-3">
              <span className="w-5 text-slate-500 text-xs text-right">{i+1}</span>
              <span className="font-mono font-bold text-white text-lg tracking-widest">{n}</span>
              <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden"><div className="h-full bg-green-500 rounded-full" style={{width:`${(score/Math.max(population[0]?.[1]||1,1))*100}%`}}/></div>
              <span className="text-slate-400 text-xs w-16 text-right">fit:{Math.round(score*100)/100}</span>
            </div>)}
          </div>
        </Card>
      </div>)}
    </ViewShell>
  );
}

// ─── Cluster & Outlier Map ────────────────────────────────────────────────────
function OutlierView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const filtered = results.filter(r=>r.company===company);
  const { clusters, outliers } = useMemo(()=>{
    const nums=filtered.slice(-100).flatMap(r=>prizeNums(r)).filter(n=>/^\d{4}$/.test(n));
    const pts=nums.map(n=>{
      const d=n.split("").map(Number);
      const sum=d.reduce((a,b)=>a+b,0);
      const evenCount=d.filter(x=>x%2===0).length;
      return {n,sum,even:evenCount};
    });
    const groups: Record<string,typeof pts>={"Low Sum(≤10)":[], "Mid Sum(11-19)":[],"High Sum(≥20)":[]};
    for (const p of pts) { if (p.sum<=10) groups["Low Sum(≤10)"].push(p); else if (p.sum<=19) groups["Mid Sum(11-19)"].push(p); else groups["High Sum(≥20)"].push(p); }
    const allSums=pts.map(p=>p.sum); const mean=allSums.reduce((a,b)=>a+b,0)/(allSums.length||1);
    const std=Math.sqrt(allSums.reduce((a,b)=>a+(b-mean)**2,0)/(allSums.length||1));
    const outlierPts=pts.filter(p=>Math.abs(p.sum-mean)>2*std);
    return {clusters:Object.entries(groups).map(([name,pts])=>({name,count:pts.length,top:pts.slice(0,5)})),outliers:outlierPts};
  },[filtered]);
  const CLUSTER_COLORS=["text-blue-400","text-green-400","text-orange-400"];
  return (
    <ViewShell title="Cluster & Outlier Isolation Map" subtitle="সংখ্যাগুলোকে digit-sum দিয়ে cluster করে extreme outlier বের করে" icon="📍">
      <div className="flex justify-end"><CompanyPicker value={company} onChange={setCompany}/></div>
      {filtered.length<10 ? noData() : (<>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {clusters.map(({name,count,top},i)=>(
            <Card key={name}>
              <div className={`text-lg font-bold mb-1 ${CLUSTER_COLORS[i]}`}>{name}</div>
              <div className="text-slate-400 text-xs mb-3">{count} numbers in last 100 draws</div>
              <div className="flex flex-wrap gap-1.5">
                {top.map(p=><span key={p.n} className="font-mono text-white bg-slate-700 border border-slate-600 px-2 py-1 rounded-lg text-sm">{p.n}</span>)}
              </div>
            </Card>
          ))}
        </div>
        {outliers.length>0 && (
          <Card>
            <h3 className="text-white font-semibold mb-3">⚠️ Statistical Outliers (2σ from mean)</h3>
            <div className="flex flex-wrap gap-2">
              {outliers.map(p=>(
                <div key={p.n} className="bg-red-900/30 border border-red-700/50 rounded-xl px-3 py-2 text-center">
                  <div className="font-mono font-black text-red-300">{p.n}</div>
                  <div className="text-xs text-red-400/70">sum={p.sum}</div>
                </div>
              ))}
            </div>
            <p className="text-slate-500 text-xs mt-3">Outliers have unusually extreme digit sums — rare but statistically notable.</p>
          </Card>
        )}
      </>)}
    </ViewShell>
  );
}

// ─── Rule Backtesting Engine ──────────────────────────────────────────────────
function BacktestView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const [btWindow, setBtWindow] = useState(30);
  const filtered = useMemo(()=>results.filter(r=>r.company===company).sort((a,b)=>a.date.localeCompare(b.date)),[results,company]);

  // ── Run all 11 models on each rolling window, track per-model hits ──
  type BtRow = {date:string; actual:string; preds:Record<string,string>; exactHit:boolean; anyDigitHit:boolean; digitMatches:number};
  const MODELS = ["pos30","triplet","hotFreq","benford","mirror","neighbor","highlow","markov","permutation","pair","ema"] as const;

  const btResults = useMemo(():BtRow[]=>{
    if (filtered.length < btWindow + 5) return [];
    const out: BtRow[] = [];
    for (let i=btWindow; i<filtered.length && out.length<40; i++) {
      const prior = filtered.slice(i - btWindow, i);
      const posF  = buildPosFreq(prior);
      const topD  = (p:number)=>Object.entries(posF[p]).sort((a,b)=>Number(b[1])-Number(a[1]))[0]?.[0]??"5";
      const topPred = [0,1,2,3].map(topD).join("");

      // Pair model
      const pf: Record<string,number>={};
      for (const r of prior) for (const n of prizeNums(r)) if(n.length===4){const d=n.split("");[d[0]+d[1],d[1]+d[2],d[2]+d[3]].forEach(p=>pf[p]=(pf[p]??0)+1);}
      const topPair=Object.entries(pf).sort((a,b)=>b[1]-a[1])[0]?.[0]??"12";
      const pairPred=topPair+topD(2)+topD(3);

      // Hot freq model
      const hf: Record<string,number>={};
      for(const r of prior.slice(-15)) for(const n of prizeNums(r)) for(const c of n.split("")) if(/\d/.test(c)) hf[c]=(hf[c]??0)+1;
      const hotD=Object.entries(hf).sort((a,b)=>b[1]-a[1])[0]?.[0]??"5";
      const hotPred2=topPred.split("").map((d,i)=>i===0?hotD:d).join("");

      // Benford
      const benExp: Record<string,number>={"1":30.1,"2":17.6,"3":12.5,"4":9.7,"5":7.9,"6":6.7,"7":5.8,"8":5.1,"9":4.6,"0":0};
      const benFirst=Object.entries(posF[0]).sort((a,b)=>(benExp[b[0]]??0)-(benExp[a[0]]??0))[0]?.[0]??"1";
      const benPred2=benFirst+topD(1)+topD(2)+topD(3);

      // Mirror
      const lastFirst=prior[prior.length-1]?.first??"0000";
      const mirrorPred2=/^\d{4}$/.test(lastFirst)?mirrorNum(lastFirst):topPred;

      // Neighbor
      const neighborPred2=/^\d{4}$/.test(lastFirst)?lastFirst.split("").map(c=>String((Number(c)+1)%10)).join(""):topPred;

      // High/Low
      const hlF: Record<string,number>={};
      for(const r of prior.slice(-20)) for(const n of prizeNums(r)) if(n.length===4){const p=n.split("").map(Number).map(x=>x>=5?"H":"L").join("");hlF[p]=(hlF[p]??0)+1;}
      const topHL=Object.keys(hlF).sort((a,b)=>hlF[b]-hlF[a])[0]??"LLLL";
      const hlPred2=topHL.split("").map((hl,p)=>{const pd=Object.entries(posF[p]).sort((a,b)=>Number(b[1])-Number(a[1]));return(pd.find(([d])=>hl==="H"?Number(d)>=5:Number(d)<5)?.[0])??(hl==="H"?"7":"2");}).join("");

      // Markov
      const tr: Record<string,Record<string,number>>={};
      const sorted2=[...prior].sort((a,b)=>a.date.localeCompare(b.date));
      for(let j=1;j<sorted2.length;j++){const f=sorted2[j-1].first[0]??"0";const t=sorted2[j].first[0]??"0";if(!tr[f])tr[f]={};tr[f][t]=(tr[f][t]??0)+1;}
      const lastD2=lastFirst[0]??"0";
      const markovF=(Object.entries(tr[lastD2]??{}).sort((a,b)=>b[1]-a[1])[0])?.[0]??"5";
      const markovPred2=markovF+topD(1)+topD(2)+topD(3);

      // Permutation
      const lperms=/^\d{4}$/.test(lastFirst)?perms4(lastFirst):[];
      const hitSet2=new Set<string>();
      for(const r of prior.slice(-20)) for(const n of prizeNums(r)) if(/^\d{4}$/.test(n)) hitSet2.add(n);
      const unhit=lperms.find(p=>!hitSet2.has(p)&&p!==lastFirst);
      const permPred2=unhit&&/^\d{4}$/.test(unhit)?unhit:topPred;

      // Triplet model
      const trf: Record<string,number>={};
      for(const r of prior.slice(-30)) for(const n of prizeNums(r)) if(n.length===4){const d=n.split("");[d[0]+d[1]+d[2],d[1]+d[2]+d[3]].forEach(t=>trf[t]=(trf[t]??0)+1);}
      const topTr=Object.keys(trf).sort((a,b)=>trf[b]-trf[a])[0]??"123";
      const tripPred2=(topTr+topD(3)).slice(0,4);

      // EMA model
      const emaSums=prior.slice(-10).map(r=>r.first.split("").map(Number).reduce((a,b)=>a+b,0));
      const emaVal=emaSums.reduce((acc,v,i)=>i===0?v:0.3*v+0.7*acc, emaSums[0]??18);
      const emaPred=topPred; // positional fallback — EMA used for context

      const preds: Record<string,string> = {
        pos30: topPred, triplet: tripPred2, hotFreq: hotPred2,
        benford: benPred2, mirror: mirrorPred2, neighbor: neighborPred2,
        highlow: hlPred2, markov: markovPred2, permutation: permPred2,
        pair: pairPred.slice(0,4).padEnd(4,"0"), ema: emaPred,
      };

      const actual = filtered[i].first;
      if (!/^\d{4}$/.test(actual)) continue;
      const exactHit = Object.values(preds).some(p=>p===actual);
      const digitMatches = actual.split("").filter((d,j)=>Object.values(preds).some(p=>p[j]===d)).length;
      out.push({date:filtered[i].date, actual, preds, exactHit, anyDigitHit:digitMatches>0, digitMatches});
    }
    return out;
  },[filtered, btWindow]);

  // Per-model hit stats
  const modelStats = useMemo(()=>{
    const modelLabels: Record<string,string> = {
      pos30:"Position 30D", triplet:"3D Triplet", hotFreq:"Hot Freq",
      benford:"Benford", mirror:"Mirror", neighbor:"Neighbor +1",
      highlow:"High/Low", markov:"Markov Chain", permutation:"Permutation",
      pair:"Top Pair", ema:"EMA Hybrid"
    };
    return MODELS.map(m=>({
      key: m, label: modelLabels[m],
      exactHits: btResults.filter(r=>r.preds[m]===r.actual).length,
      anyDigit:  btResults.filter(r=>r.actual.split("").some((d,j)=>r.preds[m]?.[j]===d)).length,
      total:     btResults.length,
    })).sort((a,b)=>b.anyDigit-a.anyDigit);
  },[btResults]);

  const totalTests = btResults.length;
  const exactHits = btResults.filter(r=>r.exactHit).length;
  const anyHits   = btResults.filter(r=>r.anyDigitHit).length;

  return (
    <ViewShell title="Multi-Model Backtesting Engine" subtitle="১১টি model একসাথে rolling window-এ test করুন — কোন model কতটা সঠিক" icon="🧪">
      <div className="flex items-center gap-3 flex-wrap">
        <CompanyPicker value={company} onChange={setCompany}/>
        <select value={btWindow} onChange={e=>setBtWindow(Number(e.target.value))} className="bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none">
          <option value={20}>20-draw window</option>
          <option value={30}>30-draw window</option>
          <option value={50}>50-draw window</option>
        </select>
      </div>

      {filtered.length < btWindow+5 ? noData() : (<>

        {/* Summary stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="text-center"><div className="text-slate-400 text-xs mb-1">Tests Run</div><div className="text-white font-black text-3xl">{totalTests}</div></Card>
          <Card className="text-center"><div className="text-slate-400 text-xs mb-1">Exact Matches</div><div className="text-yellow-400 font-black text-3xl">{exactHits}</div><div className="text-slate-600 text-xs">{totalTests?Math.round(exactHits/totalTests*100):0}%</div></Card>
          <Card className="text-center"><div className="text-slate-400 text-xs mb-1">Any Digit Hit</div><div className="text-green-400 font-black text-3xl">{anyHits}</div><div className="text-slate-600 text-xs">{totalTests?Math.round(anyHits/totalTests*100):0}%</div></Card>
          <Card className="text-center"><div className="text-slate-400 text-xs mb-1">Best Model</div><div className="text-blue-400 font-black text-xl mt-1">{modelStats[0]?.label??"-"}</div><div className="text-slate-600 text-xs">{modelStats[0]?.anyDigit??0} hits</div></Card>
        </div>

        {/* Per-model leaderboard */}
        <Card>
          <h3 className="text-white font-bold mb-4">🏆 Model Performance Leaderboard</h3>
          <div className="space-y-2">
            {modelStats.map((m,i)=>{
              const pct = totalTests ? Math.round(m.anyDigit/totalTests*100) : 0;
              const exactPct = totalTests ? Math.round(m.exactHits/totalTests*100) : 0;
              const medal = i===0?"🥇":i===1?"🥈":i===2?"🥉":"";
              return (
                <div key={m.key} className="rounded-xl p-3" style={{background:i<3?"rgba(234,179,8,0.05)":"rgba(255,255,255,0.02)",border:i<3?"1px solid rgba(234,179,8,0.2)":"1px solid rgba(255,255,255,0.05)"}}>
                  <div className="flex items-center gap-3 mb-1.5">
                    <span className="text-sm w-5">{medal||`${i+1}`}</span>
                    <span className="text-white text-sm font-bold flex-1">{m.label}</span>
                    <span className="text-green-400 text-xs font-bold">{pct}% digit hit</span>
                    <span className="text-yellow-500 text-xs font-bold ml-2">{exactPct}% exact</span>
                  </div>
                  <div className="h-2 rounded-full overflow-hidden" style={{background:"rgba(255,255,255,0.06)"}}>
                    <div className="h-full rounded-full" style={{width:`${pct}%`,background:i===0?"#eab308":i===1?"#94a3b8":i===2?"#cd7c2f":"#3b82f6"}}/>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Detailed results table */}
        <Card>
          <h3 className="text-white font-bold mb-3">📋 ড্র-বাই-ড্র ফলাফল (সর্বশেষ {btResults.length}টি)</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead><tr className="border-b border-slate-700 text-slate-500 uppercase">
                <th className="px-2 py-2 text-left">Date</th>
                <th className="px-2 py-2">Actual</th>
                <th className="px-2 py-2">Best Pred</th>
                <th className="px-2 py-2">Digits ✓</th>
                <th className="px-2 py-2">Exact</th>
              </tr></thead>
              <tbody className="divide-y divide-slate-700/30">
                {btResults.slice(-20).reverse().map((r,i)=>{
                  const bestPred = Object.entries(r.preds).sort(([,a],[,b])=>r.actual.split("").filter((d,j)=>b[j]===d).length - r.actual.split("").filter((d,j)=>a[j]===d).length)[0]?.[1]??"----";
                  return (
                    <tr key={i} className={r.exactHit?"bg-yellow-900/20":r.anyDigitHit?"bg-green-900/10":""}>
                      <td className="px-2 py-2 text-slate-500">{r.date}</td>
                      <td className="px-2 py-2 text-center font-mono font-black text-yellow-300">{r.actual}</td>
                      <td className="px-2 py-2 text-center font-mono font-black text-white">{bestPred}</td>
                      <td className="px-2 py-2 text-center text-green-400 font-bold">{r.digitMatches}/4</td>
                      <td className="px-2 py-2 text-center">{r.exactHit?<span className="text-yellow-400 font-black">★</span>:<span className="text-slate-700">—</span>}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      </>)}
    </ViewShell>
  );
}

// ─── Sliding Window Simulator ─────────────────────────────────────────────────
function SlidingView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const [days, setDays] = useState(30);
  const filtered = useMemo(()=>results.filter(r=>r.company===company).sort((a,b)=>b.date.localeCompare(a.date)),[results,company]);
  const cutoff = new Date(); cutoff.setDate(cutoff.getDate()-days);
  const windowed = filtered.filter(r=>new Date(r.date)>=cutoff);
  const posF=buildPosFreq(windowed);
  const digitF: Record<string,number>={};
  for (let i=0;i<10;i++) digitF[String(i)]=0;
  for (const r of windowed) for (const n of [r.first,r.second,r.third,...r.special,...r.consolation]) for (const d of n.split("")) if (/\d/.test(d)) digitF[d]++;
  const sortedD=Object.entries(digitF).sort((a,b)=>b[1]-a[1]);
  const prediction=[0,1,2,3].map(p=>Object.entries(posF[p]).sort((a,b)=>Number(b[1])-Number(a[1]))[0]?.[0]??"5").join("");
  const maxD=sortedD[0]?.[1]||1;
  return (
    <ViewShell title="Sliding Window Simulator" subtitle="নির্দিষ্ট সময়ের (30/60/90 দিন) ডাটা দিয়ে fresh analysis করুন" icon="🔲">
      <div className="flex items-center gap-3 flex-wrap">
        <CompanyPicker value={company} onChange={setCompany}/>
        {[30,60,90].map(d=>(
          <button key={d} onClick={()=>setDays(d)} className={`px-4 py-2 rounded-lg text-sm font-semibold transition ${days===d?"bg-blue-600 text-white":"bg-slate-800 text-slate-400 hover:text-white border border-slate-700"}`}>{d} days</button>
        ))}
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="text-center"><div className="text-slate-400 text-xs mb-1">Draws in Window</div><div className="text-white font-black text-3xl">{windowed.length}</div></Card>
        <Card className="text-center col-span-2"><div className="text-slate-400 text-xs mb-1">Window Prediction</div><div className="font-mono font-black text-4xl text-blue-400 tracking-widest">{prediction}</div></Card>
        <Card className="text-center"><div className="text-slate-400 text-xs mb-1">Hot Digit</div><div className="font-mono font-black text-3xl text-red-400">{sortedD[0]?.[0]??"-"}</div></Card>
      </div>
      {windowed.length>0 && (
        <Card>
          <h3 className="text-white font-semibold mb-4">Digit Frequency in Last {days} Days</h3>
          <div className="space-y-2">
            {sortedD.map(([d,c])=>(
              <div key={d} className="flex items-center gap-3">
                <span className="font-mono text-white font-bold w-4">{d}</span>
                <div className="flex-1 h-3 bg-slate-700 rounded-full overflow-hidden">
                  <div className="h-full rounded-full bg-gradient-to-r from-blue-600 to-cyan-500" style={{width:`${(c/maxD)*100}%`}}/>
                </div>
                <span className="text-slate-400 text-xs w-10 text-right">×{c}</span>
              </div>
            ))}
          </div>
        </Card>
      )}
      {windowed.length===0 && noData()}
    </ViewShell>
  );
}

// ─── Multi-Model Consensus Score ──────────────────────────────────────────────
// ─── Permutation / Box Number Filter ──────────────────────────────────────────
function PermutationView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const [inputNum, setInputNum] = useState("");
  const filtered = useMemo(()=>results.filter(r=>r.company===company).sort((a,b)=>b.date.localeCompare(a.date)),[results,company]);
  const lastFirst = filtered[0]?.first ?? "";
  const targetNum = inputNum || lastFirst;
  const allPerms = useMemo(()=> /^\d{4}$/.test(targetNum) ? perms4(targetNum) : [], [targetNum]);
  const recentHit = useMemo(()=>{
    const s = new Set<string>();
    for (const r of filtered.slice(0,30)) for (const n of prizeNums(r)) if (/^\d{4}$/.test(n)) s.add(n);
    return s;
  },[filtered]);
  const hitPerms = allPerms.filter(p => recentHit.has(p));
  const unhitPerms = allPerms.filter(p => !recentHit.has(p));
  return (
    <ViewShell title="Permutation / Box Number Filter" subtitle="24-বক্স থিওরি — একটি permutation group-এর যে সংখ্যা এসেছে, বাকিগুলো পরের 2-3 draw-এ আসতে পারে" icon="🎲">
      <div className="flex items-center gap-3 flex-wrap">
        <CompanyPicker value={company} onChange={setCompany}/>
        <input value={inputNum} onChange={e=>setInputNum(e.target.value.replace(/\D/g,"").slice(0,4))}
          placeholder={`Last: ${lastFirst||"----"}`}
          className="bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm font-mono w-36 focus:outline-none focus:border-blue-500"/>
        {inputNum&&<button onClick={()=>setInputNum("")} className="text-slate-500 hover:text-white text-xs px-2 py-1 border border-slate-700 rounded">Reset</button>}
      </div>
      {filtered.length<5 ? noData() : !(/^\d{4}$/.test(targetNum)) ?
        <Card><div className="text-center text-slate-500 py-8 text-sm">Valid 4-digit number দিন।</div></Card>
      : (<>
        <div className="grid grid-cols-3 gap-4">
          <Card className="text-center">
            <div className="text-slate-400 text-xs mb-2">Permutation Group</div>
            <div className="font-mono font-black text-4xl text-white tracking-widest mb-1">{targetNum}</div>
            <div className="text-slate-500 text-xs">{allPerms.length} permutations</div>
          </Card>
          <Card className="text-center border-green-700/40 bg-green-900/5">
            <div className="text-slate-400 text-xs mb-2">✅ Already Hit</div>
            <div className="font-black text-4xl text-green-400">{hitPerms.length}</div>
            <div className="text-slate-500 text-xs">in last 30 draws</div>
          </Card>
          <Card className="text-center border-orange-700/40 bg-orange-900/5">
            <div className="text-slate-400 text-xs mb-2">⏳ Still Due</div>
            <div className="font-black text-4xl text-orange-400">{unhitPerms.length}</div>
            <div className="text-slate-500 text-xs">candidates to watch</div>
          </Card>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {unhitPerms.length>0&&<Card>
            <h3 className="text-white font-semibold mb-3">⏳ Unhit Permutations <span className="text-orange-400 text-xs font-normal ml-1">Watch These Next 2-3 Draws</span></h3>
            <div className="grid grid-cols-4 gap-2">
              {unhitPerms.map(p=>(
                <div key={p} className="bg-orange-900/20 border border-orange-700/40 rounded-lg py-2 text-center font-mono font-black text-lg text-orange-300 hover:bg-orange-800/30 transition-colors">{p}</div>
              ))}
            </div>
          </Card>}
          {hitPerms.length>0&&<Card>
            <h3 className="text-white font-semibold mb-3">✅ Hit Permutations <span className="text-green-400 text-xs font-normal ml-1">Last 30 Draws</span></h3>
            <div className="grid grid-cols-4 gap-2">
              {hitPerms.map(p=>(
                <div key={p} className="bg-green-900/20 border border-green-700/40 rounded-lg py-2 text-center font-mono font-black text-lg text-green-300">{p}</div>
              ))}
            </div>
          </Card>}
        </div>
        <div className="text-slate-600 text-xs text-center">💡 4 different digits → max 24 permutations. If a number from the group has appeared, its "box partners" are statistically due.</div>
      </>)}
    </ViewShell>
  );
}

// ─── Skip-Draw Frequency Analytics ────────────────────────────────────────────
function SkipDrawView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const filtered = useMemo(()=>results.filter(r=>r.company===company).sort((a,b)=>a.date.localeCompare(b.date)),[results,company]);
  const skipStats = useMemo(()=>{
    const stats: Array<{digit:string;lastIdx:number;avgSkip:number;currentSkip:number;ratio:number;overdue:boolean;alert:boolean}>=[];
    for (let d=0;d<10;d++) {
      const digit=String(d);
      const appearances: number[]=[];
      for (let i=0;i<filtered.length;i++) if (filtered[i].first.includes(digit)) appearances.push(i);
      if (appearances.length<3) continue;
      const gaps: number[]=[];
      for (let i=1;i<appearances.length;i++) gaps.push(appearances[i]-appearances[i-1]);
      const avgSkip=gaps.reduce((a,b)=>a+b,0)/gaps.length;
      const lastIdx=appearances[appearances.length-1];
      const currentSkip=(filtered.length-1)-lastIdx;
      const ratio=currentSkip/avgSkip;
      stats.push({digit,lastIdx,avgSkip:Math.round(avgSkip*10)/10,currentSkip,ratio:Math.round(ratio*100)/100,overdue:currentSkip>=avgSkip,alert:ratio>=1.5});
    }
    return stats.sort((a,b)=>b.ratio-a.ratio);
  },[filtered]);
  return (
    <ViewShell title="Skip-Draw Frequency Analytics" subtitle="প্রতিটি ডিজিট গড়ে কত draw পর পর আসে — বর্তমান skip কি গড় ছাড়িয়ে গেছে?" icon="⏭️">
      <div className="flex justify-end"><CompanyPicker value={company} onChange={setCompany}/></div>
      {filtered.length<20 ? noData() : (<>
        <div className="space-y-3">
          {skipStats.map(s=>{
            const pct=Math.min(s.ratio*100,100);
            const barColor=s.alert?"bg-red-500":s.overdue?"bg-orange-500":s.ratio>0.7?"bg-yellow-500":"bg-blue-500";
            return (
              <Card key={s.digit} className={`${s.alert?"border-red-700/40 bg-red-900/5":s.overdue?"border-orange-700/40 bg-orange-900/5":""}`}>
                <div className="flex items-center gap-4">
                  <div className={`font-mono font-black text-4xl w-12 text-center flex-shrink-0 ${s.alert?"text-red-400":s.overdue?"text-orange-400":s.ratio>0.7?"text-yellow-400":"text-white"}`}>{s.digit}</div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className={`text-sm font-semibold ${s.alert?"text-red-300":s.overdue?"text-orange-300":s.ratio>0.7?"text-yellow-300":"text-slate-400"}`}>
                        {s.alert?"🚨 OVERDUE — High Priority Alert":s.overdue?"⚠️ Past Average Skip":s.ratio>0.7?"🔶 Approaching Average":"✅ Normal Cycle"}
                      </span>
                      <span className="text-slate-400 text-xs font-mono">Skip {s.currentSkip} / Avg {s.avgSkip}</span>
                    </div>
                    <div className="relative w-full h-3 bg-slate-700 rounded-full overflow-hidden">
                      <div className={`h-full ${barColor} rounded-full transition-all`} style={{width:`${pct}%`}}/>
                      <div className="absolute inset-y-0 w-0.5 bg-white/40" style={{left:"66%"}}/>
                    </div>
                    <div className="flex justify-between mt-1 text-slate-600 text-xs">
                      <span>{Math.round(s.ratio*100)}% of avg skip</span>
                      <span>Last seen: draw #{s.lastIdx+1} of {filtered.length}</span>
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
        <div className="text-slate-600 text-xs text-center">White marker = average skip limit. 🚨 Alert = skip ≥ 1.5× average → digit statistically overdue.</div>
      </>)}
    </ViewShell>
  );
}

// ─── Neighboring Digits Logic ──────────────────────────────────────────────────
function NeighborView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const filtered = useMemo(()=>results.filter(r=>r.company===company).sort((a,b)=>b.date.localeCompare(a.date)),[results,company]);
  const analysis = useMemo(()=>{
    if (filtered.length<5) return null;
    const last5=filtered.slice(0,5);
    const posNeighborFreq: Array<Record<string,number>>=[{},{},{},{}];
    for (const r of last5) {
      if (!/^\d{4}$/.test(r.first)) continue;
      r.first.split("").forEach((ch,p)=>{
        const dn=Number(ch);
        const prev=String((dn+9)%10); const next=String((dn+1)%10);
        posNeighborFreq[p][prev]=(posNeighborFreq[p][prev]??0)+1;
        posNeighborFreq[p][next]=(posNeighborFreq[p][next]??0)+1;
      });
    }
    const predicted=posNeighborFreq.map(pf=>Object.entries(pf).sort((a,b)=>b[1]-a[1])[0]?.[0]??"5").join("");
    const prevPred=filtered[0]?.first.split("").map(ch=>String((Number(ch)+9)%10)).join("")??"----";
    const nextPred=filtered[0]?.first.split("").map(ch=>String((Number(ch)+1)%10)).join("")??"----";
    return {predicted,prevPred,nextPred,lastFirst:filtered[0]?.first??"----",last5,posNeighborFreq};
  },[filtered]);
  return (
    <ViewShell title="Neighboring Digits Logic" subtitle="শেষ winner-এর প্রতিটি position-এর n-1 ও n+1 — পরের draw-এ আসার সম্ভাবনা বেশি" icon="🔢">
      <div className="flex justify-end"><CompanyPicker value={company} onChange={setCompany}/></div>
      {filtered.length<5||!analysis ? noData() : (<>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="text-center border-blue-700/40">
            <div className="text-slate-400 text-xs mb-2">n-1 Prediction</div>
            <div className="font-mono font-black text-4xl text-blue-400 tracking-widest mb-1">{analysis.prevPred}</div>
            <div className="text-slate-500 text-xs">Each digit −1</div>
          </Card>
          <Card className="text-center border-yellow-700/40">
            <div className="text-slate-400 text-xs mb-2">Last 1st Prize</div>
            <div className="font-mono font-black text-4xl text-white tracking-widest mb-1">{analysis.lastFirst}</div>
            <div className="text-slate-500 text-xs">Reference number</div>
          </Card>
          <Card className="text-center border-purple-700/40">
            <div className="text-slate-400 text-xs mb-2">n+1 Prediction</div>
            <div className="font-mono font-black text-4xl text-purple-400 tracking-widest mb-1">{analysis.nextPred}</div>
            <div className="text-slate-500 text-xs">Each digit +1</div>
          </Card>
        </div>
        <Card>
          <h3 className="text-white font-semibold mb-3">Per-Position Neighbor Analysis</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[0,1,2,3].map(p=>{
              const ch=analysis.lastFirst[p]??"?"; const dn=Number(ch);
              const prev=String((dn+9)%10); const nxt=String((dn+1)%10);
              return (
                <Card key={p} className="text-center p-4">
                  <div className="text-slate-500 text-xs mb-3 font-semibold">Position {p+1}</div>
                  <div className="flex items-center justify-center gap-2 mb-3">
                    <div className="bg-blue-900/40 border border-blue-700/50 rounded-lg px-3 py-2">
                      <div className="font-mono font-black text-2xl text-blue-300">{prev}</div>
                      <div className="text-blue-600 text-xs">n-1</div>
                    </div>
                    <div className="bg-slate-700 rounded-lg px-3 py-2">
                      <div className="font-mono font-black text-2xl text-white">{ch}</div>
                      <div className="text-slate-500 text-xs">last</div>
                    </div>
                    <div className="bg-purple-900/40 border border-purple-700/50 rounded-lg px-3 py-2">
                      <div className="font-mono font-black text-2xl text-purple-300">{nxt}</div>
                      <div className="text-purple-600 text-xs">n+1</div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </Card>
        <Card>
          <h3 className="text-white font-semibold mb-3">Last 5 Winners — Neighbor Frequency per Position</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead><tr className="text-slate-500 border-b border-slate-700">
                <th className="text-left pb-2 pr-4">Date</th>
                <th className="text-center pb-2 pr-4">1st Prize</th>
                {[0,1,2,3].map(p=><th key={p} className="text-center pb-2 pr-3">P{p+1} (n-1 / n / n+1)</th>)}
              </tr></thead>
              <tbody>
                {analysis.last5.map(r=>(
                  <tr key={r.id} className="border-b border-slate-800/40">
                    <td className="py-2 pr-4 text-slate-400">{r.date}</td>
                    <td className="py-2 pr-4 text-center font-mono font-bold text-white text-sm">{r.first}</td>
                    {[0,1,2,3].map(p=>{
                      const ch=r.first[p]??"-"; const dn=Number(ch);
                      return <td key={p} className="py-2 pr-3 text-center">
                        <span className="text-blue-400">{String((dn+9)%10)}</span>
                        <span className="text-slate-600 mx-0.5">/</span>
                        <span className="text-white font-bold">{ch}</span>
                        <span className="text-slate-600 mx-0.5">/</span>
                        <span className="text-purple-400">{String((dn+1)%10)}</span>
                      </td>;
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-3 text-slate-600 text-xs">💡 If last 1st prize pos-1 was 7, neighbors are 6 (n-1) and 8 (n+1). These are statistically more likely in the next draw.</div>
        </Card>
      </>)}
    </ViewShell>
  );
}

// ─── Enhanced Consensus Dashboard (BRD Formula) ───────────────────────────────
type ModelKey = "pos30"|"pos90"|"triplet"|"hotFreq"|"benford"|"mirror4d"|"neighbor"|"highlow"|"calendar"|"permutation"|"markov";
const MODEL_INFO: Record<ModelKey,{label:string;group:string;icon:string;defaultW:number}> = {
  pos30:       {label:"30-Day Position Freq",   group:"Deep Learning",  icon:"🧠", defaultW:18},
  pos90:       {label:"90-Day Position Freq",   group:"Deep Learning",  icon:"🧠", defaultW:12},
  triplet:     {label:"Triplet + Position",     group:"Statistics",     icon:"📊", defaultW:12},
  hotFreq:     {label:"Hot Digit Frequency",    group:"Statistics",     icon:"🔥", defaultW:10},
  benford:     {label:"Benford's Law",          group:"Statistics",     icon:"📐", defaultW:8},
  mirror4d:    {label:"Mirror Digit [0↔5]",    group:"Math Filters",   icon:"🪞", defaultW:8},
  neighbor:    {label:"Neighbor Digits (n±1)",  group:"Math Filters",   icon:"🔢", defaultW:7},
  highlow:     {label:"High/Low Pattern",       group:"Math Filters",   icon:"🌗", defaultW:7},
  calendar:    {label:"Calendar Day Sync",      group:"Behavior",       icon:"📅", defaultW:7},
  permutation: {label:"Permutation Box",        group:"Behavior",       icon:"🎲", defaultW:6},
  markov:      {label:"Markov Chain",           group:"Deep Learning",  icon:"🔄", defaultW:5},
};
function ConsensusView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const [showConfig, setShowConfig] = useState(false);
  const [weights, setWeights] = useState<Record<ModelKey,number>>(()=>
    Object.fromEntries(Object.entries(MODEL_INFO).map(([k,v])=>[k,v.defaultW])) as Record<ModelKey,number>
  );
  const [active, setActive] = useState<Record<ModelKey,boolean>>(()=>
    Object.fromEntries(Object.keys(MODEL_INFO).map(k=>[k,true])) as Record<ModelKey,boolean>
  );
  const filtered = useMemo(()=>results.filter(r=>r.company===company).sort((a,b)=>b.date.localeCompare(a.date)),[results,company]);

  const {candidates,modelPreds} = useMemo(()=>{
    if (filtered.length<10) return {candidates:[],modelPreds:[]};
    const posF30=buildPosFreq(filtered.slice(0,30));
    const posF90=buildPosFreq(filtered.slice(0,90));
    function topPred(pf:Record<number,Record<string,number>>) {
      return [0,1,2,3].map(p=>Object.entries(pf[p]).sort((a,b)=>Number(b[1])-Number(a[1]))[0]?.[0]??"5").join("");
    }
    // Triplet
    const pairF:Record<string,number>={};
    for (const r of filtered.slice(0,50)) for (const n of prizeNums(r)) if (n.length===4) {
      const d=n.split(""); [d[0]+d[1]+d[2],d[1]+d[2]+d[3]].forEach(t=>pairF[t]=(pairF[t]??0)+1);
    }
    const topTrip=(Object.keys(pairF).sort((a,b)=>pairF[b]-pairF[a])[0])??"123";
    const tripPred=(topTrip+(Object.entries(posF30[3]).sort((a,b)=>Number(b[1])-Number(a[1]))[0]?.[0]??"5")).slice(0,4);
    // Hot digit
    const hotF:Record<string,number>={};
    for (const r of filtered.slice(0,30)) for (const n of prizeNums(r)) for (const c of n.split("")) if(/\d/.test(c)) hotF[c]=(hotF[c]??0)+1;
    const hotDig=Object.entries(hotF).sort((a,b)=>b[1]-a[1])[0]?.[0]??"7";
    const hotPred=topPred(posF30).split("").map((d,i)=>i===0?hotDig:d).join("");
    // Benford — weight first digit toward Benford's law expected distribution
    const benfordExp:Record<string,number>={"1":30.1,"2":17.6,"3":12.5,"4":9.7,"5":7.9,"6":6.7,"7":5.8,"8":5.1,"9":4.6,"0":0};
    const benFirst=Object.entries(posF30[0]).sort((a,b)=>(benfordExp[b[0]]??0)-(benfordExp[a[0]]??0))[0]?.[0]??"1";
    const benPred=benFirst+topPred(posF30).slice(1);
    // Mirror [0↔5] on last winner
    const lastFirst=filtered[0]?.first??"0000";
    const mirrorPred=/^\d{4}$/.test(lastFirst)?mirrorNum(lastFirst):topPred(posF30);
    // Neighbor n+1 on each position of last winner
    const neighborPred=/^\d{4}$/.test(lastFirst)?
      lastFirst.split("").map(c=>String((Number(c)+1)%10)).join(""):topPred(posF30);
    // High/Low dominant pattern
    const hlFreq:Record<string,number>={};
    for (const r of filtered.slice(0,30)) for (const n of prizeNums(r)) if (n.length===4) {
      const p=n.split("").map(Number).map(x=>x>=5?"H":"L").join(""); hlFreq[p]=(hlFreq[p]??0)+1;
    }
    const topHL=(Object.keys(hlFreq).sort((a,b)=>hlFreq[b]-hlFreq[a])[0])??"LLLL";
    const hlPred=topHL.split("").map((hl,p)=>{
      const posD=Object.entries(posF30[p]).sort((a,b)=>Number(b[1])-Number(a[1]));
      return (posD.find(([d])=>hl==="H"?Number(d)>=5:Number(d)<5)?.[0])??(hl==="H"?"7":"2");
    }).join("");
    // Calendar day sync (+15% weight for matching day-of-week data)
    const todayDOW=new Date().getDay();
    const calFil=filtered.filter(r=>{const d=new Date(r.date).getDay(); return d===3||d===6||d===0;});
    const calPF=calFil.length>=10?buildPosFreq(calFil.slice(0,30)):posF30;
    const calPred=topPred(calPF);
    // Permutation: first unhit perm of last winner
    const lastPerms=/^\d{4}$/.test(lastFirst)?perms4(lastFirst):[];
    const recentHitSet=new Set<string>();
    for (const r of filtered.slice(0,30)) for (const n of prizeNums(r)) if (/^\d{4}$/.test(n)) recentHitSet.add(n);
    const unhitPerm=lastPerms.find(p=>!recentHitSet.has(p)&&p!==lastFirst);
    const permPred=unhitPerm&&/^\d{4}$/.test(unhitPerm)?unhitPerm:topPred(posF30);
    // Markov: first-digit transition
    const trans:Record<string,Record<string,number>>={};
    const sorted2=[...filtered].sort((a,b)=>a.date.localeCompare(b.date));
    for (let i=1;i<sorted2.length;i++) {
      const from=sorted2[i-1].first[0]??"0"; const to=sorted2[i].first[0]??"0";
      if(!trans[from])trans[from]={};
      trans[from][to]=(trans[from][to]??0)+1;
    }
    const lastD=lastFirst[0]??"0";
    const markovFirst=(Object.entries(trans[lastD]??{}).sort((a,b)=>b[1]-a[1])[0])?.[0]??"5";
    const markovPred=markovFirst+topPred(posF30).slice(1);

    // Build model list
    type MPred={key:ModelKey;label:string;group:string;icon:string;pred:string};
    const mPreds:MPred[]=[
      {key:"pos30",       label:MODEL_INFO.pos30.label,       group:MODEL_INFO.pos30.group,       icon:MODEL_INFO.pos30.icon,       pred:topPred(posF30)},
      {key:"pos90",       label:MODEL_INFO.pos90.label,       group:MODEL_INFO.pos90.group,       icon:MODEL_INFO.pos90.icon,       pred:topPred(posF90)},
      {key:"triplet",     label:MODEL_INFO.triplet.label,     group:MODEL_INFO.triplet.group,     icon:MODEL_INFO.triplet.icon,     pred:tripPred},
      {key:"hotFreq",     label:MODEL_INFO.hotFreq.label,     group:MODEL_INFO.hotFreq.group,     icon:MODEL_INFO.hotFreq.icon,     pred:hotPred},
      {key:"benford",     label:MODEL_INFO.benford.label,     group:MODEL_INFO.benford.group,     icon:MODEL_INFO.benford.icon,     pred:benPred},
      {key:"mirror4d",    label:MODEL_INFO.mirror4d.label,    group:MODEL_INFO.mirror4d.group,    icon:MODEL_INFO.mirror4d.icon,    pred:mirrorPred},
      {key:"neighbor",    label:MODEL_INFO.neighbor.label,    group:MODEL_INFO.neighbor.group,    icon:MODEL_INFO.neighbor.icon,    pred:neighborPred},
      {key:"highlow",     label:MODEL_INFO.highlow.label,     group:MODEL_INFO.highlow.group,     icon:MODEL_INFO.highlow.icon,     pred:hlPred},
      {key:"calendar",    label:MODEL_INFO.calendar.label,    group:MODEL_INFO.calendar.group,    icon:MODEL_INFO.calendar.icon,    pred:calPred},
      {key:"permutation", label:MODEL_INFO.permutation.label, group:MODEL_INFO.permutation.group, icon:MODEL_INFO.permutation.icon, pred:permPred},
      {key:"markov",      label:MODEL_INFO.markov.label,      group:MODEL_INFO.markov.group,      icon:MODEL_INFO.markov.icon,      pred:markovPred},
    ];

    // BRD Weighted Aggregation: C_s = Σ(W_i × M_i)
    const scoreMap:Record<string,{score:number;models:string[]}> = {};
    let totW=0;
    for (const m of mPreds) {
      if (!active[m.key]) continue;
      const w=weights[m.key];
      totW+=w;
      if (/^\d{4}$/.test(m.pred)) {
        if (!scoreMap[m.pred]) scoreMap[m.pred]={score:0,models:[]};
        scoreMap[m.pred].score+=w;
        scoreMap[m.pred].models.push(`${m.icon} ${m.label}`);
      }
    }
    const maxW=totW||1;
    const cands=Object.entries(scoreMap)
      .map(([num,{score,models}])=>({num,score:Math.round((score/maxW)*100),rawScore:score,models}))
      .sort((a,b)=>b.rawScore-a.rawScore).slice(0,10);
    return {candidates:cands,modelPreds:mPreds};
  },[filtered,weights,active]);

  function confInfo(score:number){
    if(score>=80) return {label:"Very High",badge:"bg-green-900/30 border border-green-600/50 text-green-300"};
    if(score>=60) return {label:"High",badge:"bg-blue-900/30 border border-blue-600/50 text-blue-300"};
    if(score>=40) return {label:"Medium",badge:"bg-yellow-900/30 border border-yellow-600/50 text-yellow-300"};
    return {label:"Low",badge:"bg-slate-700/30 border border-slate-600/50 text-slate-400"};
  }
  const activeW=Object.entries(weights).reduce((s,[k,v])=>s+(active[k as ModelKey]?v:0),0);

  return (
    <ViewShell title="Consensus Dashboard — Next Best Matrix" subtitle="সকল analytics model-এর BRD weighted aggregation → চূড়ান্ত Top-10 Predictions Master Chart" icon="🏆">
      <div className="flex items-center gap-3 flex-wrap">
        <CompanyPicker value={company} onChange={setCompany}/>
        <button onClick={()=>setShowConfig(c=>!c)}
          className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs px-3 py-2 rounded-lg transition">
          ⚙️ Configure Model Weights {showConfig?"▲":"▼"}
        </button>
        <div className="text-slate-500 text-xs">Active weight sum: {activeW}%</div>
      </div>

      {/* Weight Config Panel */}
      {showConfig&&(
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-semibold">Model Weight Configuration</h3>
            <button onClick={()=>setWeights(Object.fromEntries(Object.entries(MODEL_INFO).map(([k,v])=>[k,v.defaultW])) as Record<ModelKey,number>)}
              className="text-xs text-slate-400 hover:text-white border border-slate-700 rounded px-2 py-1">Reset Defaults</button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {(Object.keys(MODEL_INFO) as ModelKey[]).map(key=>{
              const info=MODEL_INFO[key];
              return (
                <div key={key} className="flex items-center gap-2 p-2 rounded-lg bg-slate-800/50">
                  <input type="checkbox" checked={active[key]} onChange={e=>setActive(a=>({...a,[key]:e.target.checked}))} className="w-4 h-4 rounded accent-blue-500 flex-shrink-0"/>
                  <span className="text-slate-300 text-xs flex-1 truncate">{info.icon} {info.label}</span>
                  <span className="text-slate-600 text-xs w-20 text-right hidden md:block">{info.group}</span>
                  <input type="number" value={weights[key]} min={0} max={100}
                    onChange={e=>setWeights(w=>({...w,[key]:Math.max(0,Math.min(100,Number(e.target.value)))}))}
                    disabled={!active[key]}
                    className="w-14 bg-slate-700 border border-slate-600 text-white text-xs rounded px-2 py-1 text-right focus:outline-none focus:border-blue-500 disabled:opacity-30"/>
                  <span className="text-slate-500 text-xs">%</span>
                </div>
              );
            })}
          </div>
          <div className="mt-3 p-3 bg-slate-800 rounded-lg text-slate-500 text-xs">
            💡 BRD Formula: C_s = (W₁×M₁) + (W₂×M₂) + ... | Weights don't need to sum to 100 — scores are auto-normalized. Deep Learning: 40% | Statistics: 30% | Math Filters: 22% | Behavior: 13% (default)
          </div>
        </Card>
      )}

      {filtered.length<10 ? noData() : (<>
        {/* #1 Hero card */}
        {candidates[0]&&(
          <Card className="border-yellow-700/30 bg-gradient-to-br from-yellow-900/10 to-slate-800/80">
            <div className="text-center">
              <div className="text-yellow-500/60 text-xs font-bold uppercase tracking-widest mb-2">🏆 #1 Consensus Top Pick</div>
              <div className="font-mono font-black text-7xl text-yellow-400 tracking-[0.15em] mb-3">{candidates[0].num}</div>
              <div className="flex items-center justify-center gap-3 mb-3">
                <span className={`px-4 py-1.5 rounded-full text-sm font-semibold ${confInfo(candidates[0].score).badge}`}>{confInfo(candidates[0].score).label} Confidence</span>
                <span className="text-white font-black text-xl">{candidates[0].score}%</span>
              </div>
              <div className="text-slate-500 text-xs">{candidates[0].models.map(m=>m.split(" ")[0]).join("  ")}</div>
            </div>
          </Card>
        )}

        {/* Master Chart Table */}
        <Card>
          <h3 className="text-white font-semibold mb-4">📊 Top Predictions Master Chart</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-slate-500 text-xs border-b border-slate-700">
                  <th className="text-left pb-3 pr-3 w-10">Rank</th>
                  <th className="text-left pb-3 pr-4">4-Digit Number</th>
                  <th className="text-left pb-3 pr-4 w-36">Consensus %</th>
                  <th className="text-left pb-3 pr-4">Supporting Models</th>
                  <th className="text-left pb-3">Confidence</th>
                </tr>
              </thead>
              <tbody>
                {candidates.map(({num,score,models},i)=>{
                  const {label,badge}=confInfo(score);
                  return (
                    <tr key={num} className="border-b border-slate-800/40 hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 pr-3">
                        <span className={`w-7 h-7 rounded-full inline-flex items-center justify-center text-xs font-black ${i===0?"bg-yellow-500 text-black":i===1?"bg-slate-400 text-black":i===2?"bg-orange-700 text-white":"bg-slate-700 text-slate-400"}`}>{i+1}</span>
                      </td>
                      <td className="py-3 pr-4">
                        <span className="font-mono font-black text-2xl text-white tracking-widest">{num}</span>
                      </td>
                      <td className="py-3 pr-4">
                        <div className="flex items-center gap-2">
                          <div className="w-24 h-2 bg-slate-700 rounded-full overflow-hidden flex-shrink-0">
                            <div className={`h-full rounded-full ${i===0?"bg-yellow-500":i<3?"bg-blue-500":"bg-slate-500"}`} style={{width:`${score}%`}}/>
                          </div>
                          <span className="text-white text-xs font-bold">{score}%</span>
                        </div>
                      </td>
                      <td className="py-3 pr-4">
                        <div className="text-xs text-slate-400">{models.slice(0,3).map(m=>m.split(" ")[0]).join(" ")}{models.length>3?` +${models.length-3}`:""}</div>
                        <div className="text-slate-600 text-xs">{models.length} model{models.length!==1?"s":""} agree</div>
                      </td>
                      <td className="py-3">
                        <span className={`px-2 py-0.5 rounded text-xs font-semibold ${badge}`}>{label}</span>
                      </td>
                    </tr>
                  );
                })}
                {candidates.length===0&&<tr><td colSpan={5} className="py-8 text-center text-slate-500 text-sm">পর্যাপ্ত data নেই।</td></tr>}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Model breakdown */}
        <Card>
          <h3 className="text-white font-semibold mb-4">Model Predictions Breakdown</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {modelPreds.filter(m=>active[m.key]).map(m=>(
              <div key={m.key} className="flex items-center gap-3 p-2.5 bg-slate-800/50 rounded-xl">
                <span className="text-lg flex-shrink-0">{m.icon}</span>
                <div className="flex-1 min-w-0">
                  <div className="text-white text-xs font-medium truncate">{m.label}</div>
                  <div className="text-slate-600 text-xs">{m.group} · wt {weights[m.key]}%</div>
                </div>
                <div className="font-mono font-black text-lg text-blue-300 flex-shrink-0">{m.pred}</div>
              </div>
            ))}
          </div>
        </Card>
      </>)}
    </ViewShell>
  );
}

// ─── Breakout Alerts ──────────────────────────────────────────────────────────
function AlertsView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const filtered = useMemo(()=>results.filter(r=>r.company===company).sort((a,b)=>b.date.localeCompare(a.date)),[results,company]);
  const { alerts: alertList, stats } = useMemo(()=>{
    const recent=filtered.slice(0,10); const older=filtered.slice(10,40);
    const rf: Record<string,number>={}; const of_: Record<string,number>={};
    for (const r of recent) for (const n of prizeNums(r)) for (const d of n.split("")) if(/\d/.test(d)) rf[d]=(rf[d]??0)+1;
    for (const r of older) for (const n of prizeNums(r)) for (const d of n.split("")) if(/\d/.test(d)) of_[d]=(of_[d]??0)+1;
    const rTotal=Object.values(rf).reduce((a,b)=>a+b,0)||1;
    const oTotal=Object.values(of_).reduce((a,b)=>a+b,0)||1;
    const als: Array<{digit:string;type:"breakout"|"cold";rPct:number;oPct:number;delta:number}>=[];
    for (let i=0;i<10;i++) {
      const d=String(i); const rp=(rf[d]??0)/rTotal*100; const op=(of_[d]??0)/oTotal*100;
      const delta=rp-op;
      if (delta>8) als.push({digit:d,type:"breakout",rPct:Math.round(rp*10)/10,oPct:Math.round(op*10)/10,delta:Math.round(delta*10)/10});
      if (delta<-8) als.push({digit:d,type:"cold",rPct:Math.round(rp*10)/10,oPct:Math.round(op*10)/10,delta:Math.round(delta*10)/10});
    }
    return {alerts:als.sort((a,b)=>Math.abs(b.delta)-Math.abs(a.delta)),stats:{recent:recent.length,older:older.length}};
  },[filtered]);
  return (
    <ViewShell title="Breakout & Cold-Digit Alerts" subtitle="গত 10 draw বনাম তার আগের 30 draw — কোন ডিজিট হঠাৎ বেড়েছে বা কমেছে?" icon="🔔">
      <div className="flex justify-end"><CompanyPicker value={company} onChange={setCompany}/></div>
      {filtered.length<15 ? noData() : (<>
        {alertList.length===0
          ? <Card><div className="text-center text-slate-500 py-8 text-sm">কোনো significant breakout/cold signal নেই।</div></Card>
          : <div className="space-y-3">
              {alertList.map(a=>(
                <Card key={a.digit} className={`border ${a.type==="breakout"?"border-red-700/50 bg-red-900/10":"border-blue-700/50 bg-blue-900/10"}`}>
                  <div className="flex items-center gap-4 flex-wrap">
                    <div className={`font-mono font-black text-5xl ${a.type==="breakout"?"text-red-400":"text-blue-400"}`}>{a.digit}</div>
                    <div className="flex-1">
                      <div className={`text-sm font-bold mb-1 ${a.type==="breakout"?"text-red-300":"text-blue-300"}`}>
                        {a.type==="breakout"?"🔥 BREAKOUT — Sudden Surge":"❄️ COLD — Sudden Drop"}
                      </div>
                      <div className="text-slate-400 text-xs">Recent 10 draws: <span className="text-white font-semibold">{a.rPct}%</span> vs Baseline 30: <span className="text-white font-semibold">{a.oPct}%</span></div>
                    </div>
                    <div className={`text-2xl font-black ${a.type==="breakout"?"text-red-400":"text-blue-400"}`}>{a.delta>0?"+":""}{a.delta}%</div>
                  </div>
                </Card>
              ))}
            </div>
        }
        <div className="text-slate-600 text-xs text-center">Comparing last {stats.recent} draws vs prior {stats.older} draws for {COMPANIES[company as CompanyId]?.name}</div>
      </>)}
    </ViewShell>
  );
}

// ─── Performance Dashboard ────────────────────────────────────────────────────
function PerformanceView({ results }: { results:LotteryResult[] }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const asc = useMemo(()=>results.filter(r=>r.company===company).sort((a,b)=>a.date.localeCompare(b.date)),[results,company]);
  const desc = useMemo(()=>[...asc].reverse(),[asc]);

  const stats = useMemo(()=>{
    if (asc.length < 15) return null;
    const WIN = 20;

    // Per-model rolling backtest
    type ModelKey2 = "pos30"|"triplet"|"hotFreq"|"benford"|"mirror"|"neighbor"|"highlow"|"markov";
    const modelHits: Record<ModelKey2, {digit:number; exact:number; total:number}> = {
      pos30:{digit:0,exact:0,total:0}, triplet:{digit:0,exact:0,total:0},
      hotFreq:{digit:0,exact:0,total:0}, benford:{digit:0,exact:0,total:0},
      mirror:{digit:0,exact:0,total:0}, neighbor:{digit:0,exact:0,total:0},
      highlow:{digit:0,exact:0,total:0}, markov:{digit:0,exact:0,total:0},
    };
    const modelLabels: Record<ModelKey2,string> = {
      pos30:"Position 30D", triplet:"3D Triplet", hotFreq:"Hot Freq",
      benford:"Benford's Law", mirror:"Mirror", neighbor:"Neighbor+1",
      highlow:"High/Low", markov:"Markov Chain"
    };

    for (let i=WIN; i<asc.length; i++) {
      const prior = asc.slice(i-WIN, i);
      const actual = asc[i].first;
      if (!/^\d{4}$/.test(actual)) continue;
      const posF = buildPosFreq(prior);
      const topD = (p:number)=>Object.entries(posF[p]).sort((a,b)=>Number(b[1])-Number(a[1]))[0]?.[0]??"5";
      const topPred = [0,1,2,3].map(topD).join("");
      const lastFirst = prior[prior.length-1]?.first??"0000";

      // triplet
      const trf: Record<string,number>={};
      for(const r of prior) for(const n of prizeNums(r)) if(n.length===4){const d=n.split("");[d[0]+d[1]+d[2],d[1]+d[2]+d[3]].forEach(t=>trf[t]=(trf[t]??0)+1);}
      const topTr=Object.keys(trf).sort((a,b)=>trf[b]-trf[a])[0]??"123";
      const tripPred3=(topTr+topD(3)).slice(0,4);

      // hotFreq
      const hf: Record<string,number>={};
      for(const r of prior.slice(-10)) for(const n of prizeNums(r)) for(const c of n.split("")) if(/\d/.test(c)) hf[c]=(hf[c]??0)+1;
      const hotD3=Object.entries(hf).sort((a,b)=>b[1]-a[1])[0]?.[0]??"5";
      const hotPred3=topPred.split("").map((d,i)=>i===0?hotD3:d).join("");

      // benford
      const benExp: Record<string,number>={"1":30.1,"2":17.6,"3":12.5,"4":9.7,"5":7.9,"6":6.7,"7":5.8,"8":5.1,"9":4.6,"0":0};
      const benFirst3=Object.entries(posF[0]).sort((a,b)=>(benExp[b[0]]??0)-(benExp[a[0]]??0))[0]?.[0]??"1";
      const benPred3=benFirst3+topD(1)+topD(2)+topD(3);

      // mirror
      const mirrorPred3=/^\d{4}$/.test(lastFirst)?mirrorNum(lastFirst):topPred;
      // neighbor
      const neighborPred3=/^\d{4}$/.test(lastFirst)?lastFirst.split("").map(c=>String((Number(c)+1)%10)).join(""):topPred;
      // highlow
      const hlF: Record<string,number>={};
      for(const r of prior.slice(-15)) for(const n of prizeNums(r)) if(n.length===4){const p=n.split("").map(Number).map(x=>x>=5?"H":"L").join("");hlF[p]=(hlF[p]??0)+1;}
      const topHL3=Object.keys(hlF).sort((a,b)=>hlF[b]-hlF[a])[0]??"LLLL";
      const hlPred3=topHL3.split("").map((hl,p)=>{const pd=Object.entries(posF[p]).sort((a,b)=>Number(b[1])-Number(a[1]));return(pd.find(([d])=>hl==="H"?Number(d)>=5:Number(d)<5)?.[0])??(hl==="H"?"7":"2");}).join("");
      // markov
      const tr: Record<string,Record<string,number>>={};
      const sorted3=[...prior].sort((a,b)=>a.date.localeCompare(b.date));
      for(let j=1;j<sorted3.length;j++){const f=sorted3[j-1].first[0]??"0";const t=sorted3[j].first[0]??"0";if(!tr[f])tr[f]={};tr[f][t]=(tr[f][t]??0)+1;}
      const markovF3=(Object.entries(tr[lastFirst[0]??"0"]??{}).sort((a,b)=>b[1]-a[1])[0])?.[0]??"5";
      const markovPred3=markovF3+topD(1)+topD(2)+topD(3);

      const predMap: Record<ModelKey2,string> = {
        pos30:topPred, triplet:tripPred3, hotFreq:hotPred3,
        benford:benPred3, mirror:mirrorPred3, neighbor:neighborPred3,
        highlow:hlPred3, markov:markovPred3,
      };
      for (const [mk, pred] of Object.entries(predMap) as [ModelKey2,string][]) {
        modelHits[mk].total++;
        if (actual.split("").some((d,j)=>pred[j]===d)) modelHits[mk].digit++;
        if (pred===actual) modelHits[mk].exact++;
      }
    }

    // Digit stats
    const digitF: Record<string,number>={};
    for(const r of desc) for(const n of prizeNums(r)) for(const d of n.split("")) if(/\d/.test(d)) digitF[d]=(digitF[d]??0)+1;
    const sortedD=Object.entries(digitF).sort((a,b)=>b[1]-a[1]);

    // Odd/Even & High/Low distribution
    let odd=0,even=0,high=0,low=0,tot=0;
    for(const r of desc.slice(0,50)) for(const n of prizeNums(r)) if(n.length===4) for(const d of n.split("")){const dn=Number(d);if(dn%2===0)even++;else odd++;if(dn>=5)high++;else low++;tot++;}

    const models = (Object.keys(modelHits) as ModelKey2[]).map(k=>({
      key:k, label:modelLabels[k],
      digitPct: modelHits[k].total ? Math.round(modelHits[k].digit/modelHits[k].total*100):0,
      exactPct: modelHits[k].total ? Math.round(modelHits[k].exact/modelHits[k].total*100):0,
      hits: modelHits[k].digit, total: modelHits[k].total,
    })).sort((a,b)=>b.digitPct-a.digitPct);

    const bestModel=models[0];
    const overallDigitHit=Math.round(models.reduce((s,m)=>s+m.digitPct,0)/models.length);

    return { models, bestModel, overallDigitHit, sortedD, totalDraws:asc.length,
      oddPct:tot?Math.round(odd/tot*100):50, highPct:tot?Math.round(high/tot*100):50 };
  },[asc, desc]);

  return (
    <ViewShell title="Performance Analytics Dashboard" subtitle="প্রতিটি model কতটা সঠিক — real rolling backtest দিয়ে পরিমাপ" icon="📊">
      <div className="flex justify-end"><CompanyPicker value={company} onChange={setCompany}/></div>
      {!stats ? noData() : (<>

        {/* Top summary */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="text-center"><div className="text-slate-400 text-xs mb-1">মোট ড্র</div><div className="text-white font-black text-4xl">{stats.totalDraws}</div></Card>
          <Card className="text-center"><div className="text-slate-400 text-xs mb-1">গড় Digit Hit</div><div className="text-green-400 font-black text-4xl">{stats.overallDigitHit}%</div><div className="text-slate-500 text-xs">সব model গড়</div></Card>
          <Card className="text-center"><div className="text-slate-400 text-xs mb-1">🏆 সেরা Model</div><div className="text-yellow-400 font-bold text-lg mt-1">{stats.bestModel?.label}</div><div className="text-slate-500 text-xs">{stats.bestModel?.digitPct}% hit</div></Card>
          <Card className="text-center"><div className="text-slate-400 text-xs mb-1">🔥 হটেস্ট ডিজিট</div><div className="text-red-400 font-black text-5xl font-mono">{stats.sortedD[0]?.[0]??"?"}</div></Card>
        </div>

        {/* Odd/Even + High/Low */}
        <div className="grid grid-cols-2 gap-3">
          <Card>
            <div className="text-slate-400 text-xs mb-2">🌗 High vs Low (গত ৫০ ড্র)</div>
            <div className="flex gap-2 mb-1 text-xs"><span className="text-blue-400 font-bold">High {stats.highPct}%</span><span className="text-slate-600 flex-1 text-right">Low {100-stats.highPct}%</span></div>
            <div className="h-3 rounded-full overflow-hidden bg-slate-700"><div className="h-full rounded-full bg-blue-500" style={{width:`${stats.highPct}%`}}/></div>
          </Card>
          <Card>
            <div className="text-slate-400 text-xs mb-2">🔢 Odd vs Even (গত ৫০ ড্র)</div>
            <div className="flex gap-2 mb-1 text-xs"><span className="text-purple-400 font-bold">Odd {stats.oddPct}%</span><span className="text-slate-600 flex-1 text-right">Even {100-stats.oddPct}%</span></div>
            <div className="h-3 rounded-full overflow-hidden bg-slate-700"><div className="h-full rounded-full bg-purple-500" style={{width:`${stats.oddPct}%`}}/></div>
          </Card>
        </div>

        {/* Model leaderboard — real backtest results */}
        <Card>
          <h3 className="text-white font-bold mb-4">🏆 Model Leaderboard — Real Backtest</h3>
          <div className="space-y-2">
            {stats.models.map((m,i)=>{
              const medal=i===0?"🥇":i===1?"🥈":i===2?"🥉":"";
              const color=i===0?"#eab308":i===1?"#94a3b8":i===2?"#cd7c2f":"#3b82f6";
              return (
                <div key={m.key} className="rounded-xl p-3" style={{background:i<3?"rgba(234,179,8,0.05)":"rgba(255,255,255,0.02)",border:`1px solid ${i<3?"rgba(234,179,8,0.2)":"rgba(255,255,255,0.05)"}`}}>
                  <div className="flex items-center gap-3 mb-2">
                    <span className="w-6 text-sm">{medal||`${i+1}`}</span>
                    <span className="text-white font-bold flex-1 text-sm">{m.label}</span>
                    <span className="text-xs font-bold" style={{color}}>{m.digitPct}% digit</span>
                    <span className="text-yellow-600 text-xs ml-2">{m.exactPct}% exact</span>
                  </div>
                  <div className="flex gap-1">
                    <div className="flex-1 h-2 rounded-full overflow-hidden bg-slate-700">
                      <div className="h-full rounded-full" style={{width:`${m.digitPct}%`,background:color}}/>
                    </div>
                  </div>
                  <div className="text-slate-600 text-xs mt-1">{m.hits}/{m.total} tests-এ ≥১ ডিজিট মিল</div>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Digit frequency ranking */}
        <Card>
          <h3 className="text-white font-bold mb-3">📊 সব ডিজিটের Frequency Rank</h3>
          <div className="grid grid-cols-5 gap-2">
            {stats.sortedD.map(([d,c],i)=>(
              <div key={d} className="rounded-xl p-3 text-center" style={{background:i===0?"rgba(239,68,68,0.15)":i===9?"rgba(100,116,139,0.1)":"rgba(255,255,255,0.03)",border:i===0?"1px solid rgba(239,68,68,0.3)":i===9?"1px solid rgba(100,116,139,0.2)":"1px solid rgba(255,255,255,0.06)"}}>
                <div className="font-mono font-black text-2xl text-white">{d}</div>
                <div className={`text-xs font-bold mt-1 ${i===0?"text-red-400":i===9?"text-slate-500":"text-slate-400"}`}>×{c}</div>
                <div className="text-slate-700 text-[10px]">#{i+1}</div>
              </div>
            ))}
          </div>
        </Card>
      </>)}
    </ViewShell>
  );
}

// ─── Master Prediction Sheet ──────────────────────────────────────────────────
// ─── Smart Generator — 27 Formula/Statistical Signals Combined ───────────────
function generateTopNumbers(
  results: LotteryResult[], company: CompanyId, count=5, offset=0
): Array<{number:string; score:number; methods:string[]}> {
  const filtered = results.filter(r=>r.company===company).sort((a,b)=>b.date.localeCompare(a.date));
  if (filtered.length < 3) return [];

  const all4D = filtered.flatMap(r=>prizeNums(r)).filter(n=>/^\d{4}$/.test(n));
  const recentSet = new Set(all4D.slice(0,10));

  const scores  = new Float32Array(10000);
  const methods = Array.from({length:10000},()=>[] as string[]);

  const addScore = (n:string, pts:number, method:string) => {
    if(!/^\d{4}$/.test(n)) return;
    const idx = parseInt(n, 10);
    scores[idx] += pts;
    if (!methods[idx].includes(method)) methods[idx].push(method);
  };

  // ①  Position frequency (last 30 draws)
  const pos30 = buildPosFreq(filtered.slice(0,30));
  const pos90 = buildPosFreq(filtered.slice(0,90));
  for (let i=0;i<10000;i++) {
    const s=String(i).padStart(4,'0');
    let p30=0,p90=0;
    for(let p=0;p<4;p++){ p30+=(pos30[p][s[p]]??0); p90+=(pos90[p][s[p]]??0); }
    if(p30>0){ scores[i]+=p30*3; if(!methods[i].includes("Position")) methods[i].push("Position"); }
    if(p90>0){ scores[i]+=p90*1.5; }
  }

  // ②  Hot digits
  const hotF:Record<string,number>={};
  for(const n of all4D.slice(0,50)) for(const c of n.split("")) hotF[c]=(hotF[c]??0)+1;
  const hotDigits=Object.entries(hotF).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([d])=>d);
  for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0');
    const hc=s.split("").filter(c=>hotDigits.includes(c)).length;
    if(hc>=2){ scores[i]+=hc*4; if(!methods[i].includes("HotDigit")) methods[i].push("HotDigit"); }
  }

  // ③  Pair frequency
  const pairs=pairFrequency(results,company).slice(0,10);
  for(const {pair} of pairs) for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0');
    if(s.includes(pair)){ scores[i]+=8; if(!methods[i].includes("PairFreq")) methods[i].push("PairFreq"); }
  }

  // ④  Triplet frequency
  const trips=tripletFrequency(results,company).slice(0,5);
  for(const {triplet} of trips) for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0');
    if(s.includes(triplet)){ scores[i]+=12; if(!methods[i].includes("TripletFreq")) methods[i].push("TripletFreq"); }
  }

  // ⑤  Markov chain (first-digit transition)
  const sorted2=[...filtered].sort((a,b)=>a.date.localeCompare(b.date));
  const trans:Record<string,Record<string,number>>={};
  for(let i=1;i<sorted2.length;i++){
    const from=sorted2[i-1]?.first?.[0]??"0", to=sorted2[i]?.first?.[0]??"0";
    if(!trans[from]) trans[from]={};
    trans[from][to]=(trans[from][to]??0)+1;
  }
  const lastD=filtered[0]?.first?.[0]??"0";
  const markovNext=Object.entries(trans[lastD]??{}).sort((a,b)=>b[1]-a[1]).slice(0,3).map(([d])=>d);
  for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0');
    if(markovNext.includes(s[0])){ scores[i]+=10; if(!methods[i].includes("Markov")) methods[i].push("Markov"); }
  }

  // ⑥  Mirror & Neighbor of last 1st prize
  const lastFirst=filtered[0]?.first??"";
  if(/^\d{4}$/.test(lastFirst)){
    addScore(mirrorNum(lastFirst),15,"Mirror");
    const n1=lastFirst.split("").map(c=>String((Number(c)+1)%10)).join(""); addScore(n1,12,"Neighbor+1");
    const n9=lastFirst.split("").map(c=>String((Number(c)+9)%10)).join(""); addScore(n9,10,"Neighbor-1");
  }

  // ⑦  High/Low pattern
  const hlFreq:Record<string,number>={};
  for(const n of all4D.slice(0,50)){ const p=n.split("").map(Number).map(x=>x>=5?"H":"L").join(""); hlFreq[p]=(hlFreq[p]??0)+1; }
  const topHL=Object.keys(hlFreq).sort((a,b)=>hlFreq[b]-hlFreq[a])[0]??"LLLL";
  for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0');
    const hl=s.split("").map(Number).map(x=>x>=5?"H":"L").join("");
    if(hl===topHL){ scores[i]+=8; if(!methods[i].includes("HighLow")) methods[i].push("HighLow"); }
  }

  // ⑧  Benford's Law first-digit weighting
  const benW:Record<string,number>={"1":5,"2":4,"3":3,"4":2,"5":2,"6":1,"7":1,"8":1,"9":1,"0":0};
  for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0');
    const w=benW[s[0]]??0;
    if(w>0){ scores[i]+=w; if(!methods[i].includes("Benford")) methods[i].push("Benford"); }
  }

  // ⑨  Gap / overdue analysis
  const lastSeen:Record<string,number>={};
  for(let i=0;i<all4D.length;i++) if(!(all4D[i] in lastSeen)) lastSeen[all4D[i]]=i;
  for(const [num,idx] of Object.entries(lastSeen)){
    if(idx>=20) addScore(num, Math.min(idx,50)*0.5, "Overdue");
  }

  // ⑩  Digit sum pattern
  const sums=all4D.slice(0,50).map(n=>n.split("").reduce((a,c)=>a+Number(c),0));
  const avgSum=sums.reduce((a,b)=>a+b,0)/(sums.length||1);
  const stdSum=Math.sqrt(sums.map(s=>(s-avgSum)**2).reduce((a,b)=>a+b,0)/(sums.length||1));
  const minS=Math.max(0,Math.round(avgSum-stdSum)), maxS=Math.round(avgSum+stdSum);
  for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0');
    const sum=s.split("").reduce((a,c)=>a+Number(c),0);
    if(sum>=minS&&sum<=maxS){ scores[i]+=5; if(!methods[i].includes("SumPattern")) methods[i].push("SumPattern"); }
  }

  // ⑪  Even/Odd balance
  const eoR=all4D.slice(0,50).map(n=>n.split("").filter(c=>Number(c)%2===0).length);
  const avgEO=Math.round(eoR.reduce((a,b)=>a+b,0)/(eoR.length||1));
  for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0');
    if(s.split("").filter(c=>Number(c)%2===0).length===avgEO){ scores[i]+=5; if(!methods[i].includes("EvenOdd")) methods[i].push("EvenOdd"); }
  }

  // ⑫  Calendar / day-of-week
  const todayDay=new Date().getDay();
  const dayFil=filtered.filter(r=>new Date(r.date).getDay()===todayDay);
  if(dayFil.length>=5){
    const dayPos=buildPosFreq(dayFil.slice(0,20));
    for(let i=0;i<10000;i++){
      const s=String(i).padStart(4,'0');
      let ds=0; for(let p=0;p<4;p++) ds+=dayPos[p][s[p]]??0;
      if(ds>0){ scores[i]+=ds*2; if(!methods[i].includes("Calendar")) methods[i].push("Calendar"); }
    }
  }

  // ⑬  Sliding window trend (last 10 vs prior 10)
  const rec10=buildPosFreq(filtered.slice(0,10));
  const pri10=buildPosFreq(filtered.slice(10,20));
  const trending:Record<number,string[]>={};
  for(let p=0;p<4;p++) trending[p]=Object.entries(rec10[p]).filter(([d,v])=>Number(v)>(pri10[p][d]??0)).sort((a,b)=>Number(b[1])-Number(a[1])).slice(0,3).map(([d])=>d);
  for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0');
    let ts=0; for(let p=0;p<4;p++) if(trending[p].includes(s[p])) ts+=6;
    if(ts>0){ scores[i]+=ts; if(!methods[i].includes("Trending")) methods[i].push("Trending"); }
  }

  // ⑭  Permutation of last first prize
  if(/^\d{4}$/.test(lastFirst)){
    for(const p of perms4(lastFirst).filter(p=>!recentSet.has(p)&&p!==lastFirst).slice(0,6)) addScore(p,10,"Permutation");
  }

  // ⑮  Digit diversity bonus
  for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0');
    const u=new Set(s.split("")).size;
    if(u>=3){ scores[i]+=3; if(!methods[i].includes("Diversity")) methods[i].push("Diversity"); }
    if(u===4) scores[i]+=2;
  }

  // ⑯  Cross-company correlation
  const otherRecent=COMPANY_IDS.filter(c=>c!==company).flatMap(c=>
    results.filter(r=>r.company===c).sort((a,b)=>b.date.localeCompare(a.date)).slice(0,3).flatMap(r=>prizeNums(r))
  ).filter(n=>/^\d{4}$/.test(n));
  for(const n of otherRecent) addScore(n,6,"CrossCompany");

  // ⑰  Regression trend (digit sum direction)
  const recentSums=filtered.slice(0,10).flatMap(r=>prizeNums(r).filter(n=>/^\d{4}$/.test(n)).map(n=>n.split("").reduce((a,c)=>a+Number(c),0)));
  let sumTrend=0;
  for(let i=1;i<recentSums.length;i++) sumTrend+=recentSums[i]-recentSums[i-1];
  const targetSum=Math.round(avgSum+(sumTrend>0?1:-1)*2);
  for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0');
    if(Math.abs(s.split("").reduce((a,c)=>a+Number(c),0)-targetSum)<=1){ scores[i]+=6; if(!methods[i].includes("Regression")) methods[i].push("Regression"); }
  }

  // ⑱  LSTM-like: sequence of last 3 first-digits → predict next
  const lstmSeq=filtered.slice(0,3).map(r=>r.first[0]??"0").join("");
  const lstmNext:Record<string,number>={};
  for(let i=0;i<sorted2.length-3;i++){
    if(sorted2.slice(i,i+3).map(r=>r.first[0]??"0").join("")===lstmSeq){
      const nd=sorted2[i+3]?.first[0]; if(nd) lstmNext[nd]=(lstmNext[nd]??0)+1;
    }
  }
  const lstmBest=Object.entries(lstmNext).sort((a,b)=>b[1]-a[1]).slice(0,3).map(([d])=>d);
  for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0');
    if(lstmBest.includes(s[0])){ scores[i]+=9; if(!methods[i].includes("LSTM")) methods[i].push("LSTM"); }
  }

  // ⑲  Genetic: best digit at each position from top historical winners
  const winFreq:Record<string,number>={};
  for(const n of all4D) winFreq[n]=(winFreq[n]??0)+1;
  const top10w=Object.entries(winFreq).sort((a,b)=>b[1]-a[1]).slice(0,10).map(([n])=>n);
  const genePos:Record<number,Record<string,number>>={0:{},1:{},2:{},3:{}};
  for(const n of top10w) for(let p=0;p<4;p++){ const d=n[p]; if(d) genePos[p][d]=(genePos[p][d]??0)+1; }
  for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0'); let gs=0;
    for(let p=0;p<4;p++) gs+=genePos[p][s[p]]??0;
    if(gs>=3){ scores[i]+=gs*2; if(!methods[i].includes("Genetic")) methods[i].push("Genetic"); }
  }

  // ⑳  Skip-draw: numbers whose typical reappearance gap puts them due
  const skipGaps:Record<string,number[]>={};
  for(let i=0;i<all4D.length;i++){
    if(!skipGaps[all4D[i]]) skipGaps[all4D[i]]=[];
    for(let j=i+1;j<Math.min(all4D.length,i+60);j++) if(all4D[j]===all4D[i]){ skipGaps[all4D[i]].push(j-i); break; }
  }
  for(const [num,gaps] of Object.entries(skipGaps)){
    if(!gaps.length) continue;
    const ag=gaps.reduce((a,b)=>a+b,0)/gaps.length;
    const li=all4D.indexOf(num);
    if(li>=0&&Math.abs(li-ag)<5) addScore(num,8,"SkipDraw");
  }

  // ㉑  Cold digit opportunity (coldest digit at each position gets a boost)
  for(let p=0;p<4;p++){
    const coldD=Object.entries(pos30[p]).sort((a,b)=>Number(a[1])-Number(b[1])).slice(0,2).map(([d])=>d);
    for(let i=0;i<10000;i++){
      const s=String(i).padStart(4,'0');
      if(coldD.includes(s[p])){ scores[i]+=4; if(!methods[i].includes("ColdDue")) methods[i].push("ColdDue"); }
    }
  }

  // ㉒  Backtest proxy: triplet → extend with most likely 4th digit
  for(const {triplet} of trips.slice(0,3)){
    const ext=Object.entries(pos30[3]).sort((a,b)=>Number(b[1])-Number(a[1]))[0]?.[0]??"5";
    addScore(triplet+ext,8,"Backtest"); addScore(ext+triplet,8,"Backtest");
  }

  // ㉓  Digit spread (balanced range preferred)
  for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0'); const digs=s.split("").map(Number);
    const sp=Math.max(...digs)-Math.min(...digs);
    if(sp>=4&&sp<=8){ scores[i]+=3; if(!methods[i].includes("Spread")) methods[i].push("Spread"); }
  }

  // ㉔  Consensus boost: numbers scoring in 5+ methods get extra weight
  for(let i=0;i<10000;i++) if(methods[i].length>=5){ scores[i]+=methods[i].length*3; if(!methods[i].includes("Consensus")) methods[i].push("Consensus"); }

  // ㉕  Recency penalty (avoid last 10 drawn numbers)
  for(const n of all4D.slice(0,10)){ const idx=parseInt(n,10); if(idx>=0&&idx<10000) scores[idx]-=100; }

  // ㉖  Bayesian/Laplace-smoothed position model. This prevents zero-frequency
  //     digits from being treated as impossible and reduces overfitting to small samples.
  const bayesPos:Record<number,Record<string,number>>={0:{},1:{},2:{},3:{}};
  for(let p=0;p<4;p++) for(let d=0;d<10;d++) bayesPos[p][String(d)]=1;
  for(const n of all4D.slice(0,120)) for(let p=0;p<4;p++) if(n[p]) bayesPos[p][n[p]]=(bayesPos[p][n[p]]??1)+1;
  const bayesLog:Record<number,number>={};
  for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0'); let lp=0;
    for(let p=0;p<4;p++){
      const total=Object.values(bayesPos[p]).reduce((a,b)=>a+b,0);
      lp += Math.log((bayesPos[p][s[p]]??1)/total);
    }
    bayesLog[i]=lp;
  }
  const bayesVals=Object.values(bayesLog);
  const bMin=Math.min(...bayesVals), bMax=Math.max(...bayesVals);
  for(let i=0;i<10000;i++){
    const norm=bMax===bMin?0:(bayesLog[i]-bMin)/(bMax-bMin);
    if(norm>0.55){ scores[i]+=norm*10; if(!methods[i].includes("Bayesian")) methods[i].push("Bayesian"); }
  }

  // ㉗  Anti-repeat / diversity guard. It does NOT claim a number is “certain”;
  //     it simply makes the returned shortlist distinct and less concentrated.
  const recent15=new Set(all4D.slice(0,15));
  for(let i=0;i<10000;i++){
    const s=String(i).padStart(4,'0');
    if(recent15.has(s)) scores[i]-=120;
    const uniq=new Set(s).size;
    if(uniq===4){ scores[i]+=1.5; if(!methods[i].includes("AntiRepeat")) methods[i].push("AntiRepeat"); }
  }

  // ── Rank and return ──
  const ranked:Array<{number:string;score:number;methods:string[]}>=[];
  for(let i=0;i<10000;i++) if(scores[i]>0&&!recentSet.has(String(i).padStart(4,'0'))) ranked.push({number:String(i).padStart(4,'0'),score:scores[i],methods:[...methods[i]]});
  ranked.sort((a,b)=>b.score-a.score);
  return ranked.slice(offset,offset+count);
}

// ─── Generator View ────────────────────────────────────────────────────────────
function GeneratorView({ results }: { results: LotteryResult[] }) {
  const [offsets, setOffsets] = useState<Record<CompanyId,number>>(()=>Object.fromEntries(COMPANY_IDS.map(c=>[c,0])) as Record<CompanyId,number>);
  const [generated, setGenerated] = useState<Record<CompanyId,Array<{number:string;score:number;methods:string[]}>>>({} as any);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const hasData = results.length >= 3;

  function runGenerate() {
    setLoading(true); setDone(false);
    setTimeout(()=>{
      const res:Record<CompanyId,Array<{number:string;score:number;methods:string[]}>>={} as any;
      for(const c of COMPANY_IDS) res[c]=generateTopNumbers(results,c,5,offsets[c]);
      setGenerated(res); setLoading(false); setDone(true);
    }, 100);
  }

  function nextSet(company: CompanyId) {
    const newOff={...offsets,[company]:offsets[company]+5};
    setOffsets(newOff);
    const r={...generated,[company]:generateTopNumbers(results,company,5,newOff[company])};
    setGenerated(r);
  }

  const maxScore = Math.max(...Object.values(generated).flat().map(x=>x.score), 1);

  const METHOD_COLOR: Record<string,string> = {
    Position:"bg-blue-800/60 text-blue-300", HotDigit:"bg-orange-800/60 text-orange-300",
    PairFreq:"bg-purple-800/60 text-purple-300", TripletFreq:"bg-pink-800/60 text-pink-300",
    Markov:"bg-cyan-800/60 text-cyan-300", Mirror:"bg-indigo-800/60 text-indigo-300",
    "Neighbor+1":"bg-teal-800/60 text-teal-300", HighLow:"bg-yellow-800/60 text-yellow-300",
    Benford:"bg-lime-800/60 text-lime-300", Overdue:"bg-red-800/60 text-red-300",
    SumPattern:"bg-sky-800/60 text-sky-300", EvenOdd:"bg-violet-800/60 text-violet-300",
    Calendar:"bg-amber-800/60 text-amber-300", Trending:"bg-emerald-800/60 text-emerald-300",
    Permutation:"bg-fuchsia-800/60 text-fuchsia-300", Diversity:"bg-green-800/60 text-green-300",
    CrossCompany:"bg-rose-800/60 text-rose-300", Regression:"bg-blue-900/60 text-blue-200",
    LSTM:"bg-violet-900/60 text-violet-200", Genetic:"bg-green-900/60 text-green-200",
    SkipDraw:"bg-amber-900/60 text-amber-200", ColdDue:"bg-slate-600/60 text-slate-200",
    Backtest:"bg-red-900/60 text-red-200", Spread:"bg-teal-900/60 text-teal-200",
    Consensus:"bg-yellow-600/60 text-yellow-100",
  };

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-white">🎯 Smart Generator</h1>
          <p className="text-slate-400 text-xs mt-0.5">২৭টি statistical/formula signal combine করে প্রতিটা company-র জন্য শীর্ষ ৫টি আলাদা candidate number</p>
        </div>
        <button onClick={runGenerate} disabled={loading||!hasData}
          className="flex items-center gap-2 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-500 hover:to-teal-500 disabled:opacity-40 text-white font-black px-5 py-3 rounded-2xl transition shadow-lg shadow-green-900/30 text-sm">
          {loading?<><span className="animate-spin">⏳</span> Analyzing…</>:<>🔄 Generate করুন</>}
        </button>
      </div>

      {!hasData&&(
        <div className="bg-amber-900/20 border border-amber-700/30 rounded-xl p-5 text-center">
          <div className="text-4xl mb-2">📊</div>
          <p className="text-amber-300 font-semibold">পর্যাপ্ত Data নেই</p>
          <p className="text-amber-400/70 text-xs mt-1">Generator ব্যবহার করতে কমপক্ষে ৩টি 4D result ইনপুট করুন।</p>
        </div>
      )}

      {/* Formula legend */}
      {!done&&hasData&&(
        <div className="bg-slate-800/60 border border-slate-700 rounded-2xl p-4">
          <p className="text-slate-300 text-xs font-semibold mb-3">ব্যবহৃত ২৫টি Formula:</p>
          <div className="flex flex-wrap gap-1.5">
            {["Position","HotDigit","PairFreq","TripletFreq","Markov","Mirror","Neighbor+1","HighLow","Benford","Overdue","SumPattern","EvenOdd","Calendar","Trending","Permutation","Diversity","CrossCompany","Regression","LSTM","Genetic","SkipDraw","ColdDue","Backtest","Spread","Consensus","Bayesian","AntiRepeat"].map(m=>(
              <span key={m} className={`text-[10px] px-2 py-0.5 rounded-full font-mono ${METHOD_COLOR[m]??"bg-slate-700 text-slate-300"}`}>{m}</span>
            ))}
          </div>
          <p className="text-slate-500 text-xs mt-3">👆 "Generate করুন" বাটনে ক্লিক করুন</p>
        </div>
      )}

      {/* Results per company */}
      {done && COMPANY_IDS.map(company=>{
        const nums = generated[company] ?? [];
        const co = COMPANIES[company];
        const hasNums = nums.length>0;
        return (
          <div key={company} className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden">
            {/* Company header */}
            <div className="flex items-center justify-between px-4 py-3" style={{background:`linear-gradient(135deg,${co.color}22,${co.color}11)`,borderBottom:"1px solid rgba(255,255,255,0.06)"}}>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full" style={{background:co.color}}/>
                <span className="text-white font-black text-sm">{co.name}</span>
                <span className="text-slate-400 text-xs">({results.filter(r=>r.company===company).length} records)</span>
              </div>
              {hasNums&&(
                <button onClick={()=>nextSet(company)}
                  className="text-xs flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition"
                  style={{background:`${co.color}25`,border:`1px solid ${co.color}50`,color:co.color}}>
                  ▶ পরবর্তী সেট
                </button>
              )}
            </div>

            {!hasNums ? (
              <div className="p-5 text-center text-slate-500 text-xs">এই company-র জন্য পর্যাপ্ত data নেই</div>
            ):(
              <div className="p-4 space-y-2">
                {nums.map((item,idx)=>{
                  const pct=Math.round(item.score/maxScore*100);
                  const conf=pct>=70?"High":pct>=40?"Medium":"Low";
                  const confColor=conf==="High"?"text-green-400":conf==="Medium"?"text-yellow-400":"text-red-400";
                  const barColor=conf==="High"?"#22c55e":conf==="Medium"?"#eab308":"#ef4444";
                  return (
                    <div key={item.number} className="bg-slate-900/60 border border-slate-700/50 rounded-xl p-3">
                      <div className="flex items-center gap-3">
                        {/* Rank */}
                        <span className="text-slate-600 text-xs font-bold w-4">{idx+1}</span>
                        {/* Number */}
                        <span className="font-black text-2xl tracking-[0.2em] text-white tabular-nums">{item.number}</span>
                        {/* Confidence */}
                        <div className="flex-1">
                          <div className="h-1.5 rounded-full bg-slate-700 mb-1">
                            <div className="h-full rounded-full transition-all" style={{width:`${pct}%`,background:barColor}}/>
                          </div>
                          <span className={`text-[10px] font-bold ${confColor}`}>{conf} {pct}%</span>
                        </div>
                        {/* Method count */}
                        <span className="text-slate-500 text-[10px]">{item.methods.length} formula</span>
                      </div>
                      {/* Method tags */}
                      <div className="flex flex-wrap gap-1 mt-2 ml-7">
                        {item.methods.slice(0,6).map(m=>(
                          <span key={m} className={`text-[9px] px-1.5 py-0.5 rounded-full font-mono ${METHOD_COLOR[m]??"bg-slate-700 text-slate-400"}`}>{m}</span>
                        ))}
                        {item.methods.length>6&&<span className="text-[9px] text-slate-600">+{item.methods.length-6}</span>}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function MasterPredictionView({ results, onView, user }: { results: LotteryResult[]; onView:(v:View)=>void; user:AuthUser }) {
  const [company, setCompany] = useState<CompanyId>("magnum");
  const [openFolders, setOpenFolders] = useState<Set<string>>(new Set());
  const toggleFolder = (g: string) => setOpenFolders(s => { const n = new Set(s); n.has(g) ? n.delete(g) : n.add(g); return n; });
  const [secretNum, setSecretNum] = useState<string>(()=>localStorage.getItem("secret_lucky_num")??"");
  const [secretLocked, setSecretLocked] = useState<boolean>(()=>localStorage.getItem("secret_lucky_locked")==="1");
  const isAdmin = user.role==="admin";
  const [customPicks, setCustomPicks] = useState<[string,string]>(()=>{
    try{ return JSON.parse(localStorage.getItem("eng_custom_picks")??"[\"\",\"\"]") as [string,string]; }catch{ return ["",""]; }
  });
  const [editingCustom, setEditingCustom] = useState(false);
  function saveCustomPick(idx:0|1, val:string){
    const next:[string,string]=[customPicks[0],customPicks[1]];
    next[idx]=val.replace(/\D/g,"").slice(0,4);
    setCustomPicks(next);
    localStorage.setItem("eng_custom_picks", JSON.stringify(next));
  }
  function handleSecretLock() {
    if(!isAdmin) return;
    const next=!secretLocked; setSecretLocked(next);
    localStorage.setItem("secret_lucky_locked", next?"1":"0");
    localStorage.setItem("secret_lucky_num", secretNum);
  }
  function handleSecretChange(v:string){ setSecretNum(v); localStorage.setItem("secret_lucky_num",v); }
  const filtered = useMemo(() =>
    results.filter(r => r.company === company).sort((a,b) => b.date.localeCompare(a.date)),
    [results, company]
  );

  const analysis = useMemo(() => {
    if (filtered.length < 10) return null;

    // ── Replicate all 11 model predictions (identical logic to ConsensusView) ──
    const posF30 = buildPosFreq(filtered.slice(0, 30));
    const posF90 = buildPosFreq(filtered.slice(0, 90));
    function topPred(pf: Record<number, Record<string,number>>) {
      return [0,1,2,3].map(p => Object.entries(pf[p]).sort((a,b) => Number(b[1])-Number(a[1]))[0]?.[0] ?? "5").join("");
    }
    const pairF: Record<string,number> = {};
    for (const r of filtered.slice(0,50)) for (const n of prizeNums(r)) if (n.length===4) {
      const d=n.split(""); [d[0]+d[1]+d[2],d[1]+d[2]+d[3]].forEach(t=>pairF[t]=(pairF[t]??0)+1);
    }
    const topTrip = (Object.keys(pairF).sort((a,b)=>pairF[b]-pairF[a])[0]) ?? "123";
    const tripPred = (topTrip + (Object.entries(posF30[3]).sort((a,b)=>Number(b[1])-Number(a[1]))[0]?.[0]??"5")).slice(0,4);
    const hotF: Record<string,number> = {};
    for (const r of filtered.slice(0,30)) for (const n of prizeNums(r)) for (const c of n.split("")) if(/\d/.test(c)) hotF[c]=(hotF[c]??0)+1;
    const hotDig = Object.entries(hotF).sort((a,b)=>b[1]-a[1])[0]?.[0] ?? "7";
    const hotPred = topPred(posF30).split("").map((d,i)=>i===0?hotDig:d).join("");
    const benfordExp: Record<string,number>={"1":30.1,"2":17.6,"3":12.5,"4":9.7,"5":7.9,"6":6.7,"7":5.8,"8":5.1,"9":4.6,"0":0};
    const benFirst = Object.entries(posF30[0]).sort((a,b)=>(benfordExp[b[0]]??0)-(benfordExp[a[0]]??0))[0]?.[0] ?? "1";
    const benPred = benFirst + topPred(posF30).slice(1);
    const lastFirst = filtered[0]?.first ?? "0000";
    const mirrorPred = /^\d{4}$/.test(lastFirst) ? mirrorNum(lastFirst) : topPred(posF30);
    const neighborPred = /^\d{4}$/.test(lastFirst)
      ? lastFirst.split("").map(c=>String((Number(c)+1)%10)).join("") : topPred(posF30);
    const hlFreqM: Record<string,number> = {};
    for (const r of filtered.slice(0,30)) for (const n of prizeNums(r)) if (n.length===4) {
      const p=n.split("").map(Number).map(x=>x>=5?"H":"L").join(""); hlFreqM[p]=(hlFreqM[p]??0)+1;
    }
    const topHL = (Object.keys(hlFreqM).sort((a,b)=>hlFreqM[b]-hlFreqM[a])[0]) ?? "LLLL";
    const hlPred = topHL.split("").map((hl,p)=>{
      const posD = Object.entries(posF30[p]).sort((a,b)=>Number(b[1])-Number(a[1]));
      return (posD.find(([d])=>hl==="H"?Number(d)>=5:Number(d)<5)?.[0]) ?? (hl==="H"?"7":"2");
    }).join("");
    const calFil = filtered.filter(r=>{const d=new Date(r.date).getDay(); return d===3||d===6||d===0;});
    const calPF = calFil.length>=10 ? buildPosFreq(calFil.slice(0,30)) : posF30;
    const calPred = topPred(calPF);
    const lastPerms = /^\d{4}$/.test(lastFirst) ? perms4(lastFirst) : [];
    const recentHitSet = new Set<string>();
    for (const r of filtered.slice(0,30)) for (const n of prizeNums(r)) if (/^\d{4}$/.test(n)) recentHitSet.add(n);
    const unhitPerm = lastPerms.find(p=>!recentHitSet.has(p)&&p!==lastFirst);
    const permPred = unhitPerm&&/^\d{4}$/.test(unhitPerm) ? unhitPerm : topPred(posF30);
    const trans: Record<string,Record<string,number>> = {};
    const sorted2 = [...filtered].sort((a,b)=>a.date.localeCompare(b.date));
    for (let i=1;i<sorted2.length;i++) {
      const from=sorted2[i-1].first[0]??"0"; const to=sorted2[i].first[0]??"0";
      if(!trans[from]) trans[from]={};
      trans[from][to]=(trans[from][to]??0)+1;
    }
    const lastD = lastFirst[0] ?? "0";
    const markovFirst = (Object.entries(trans[lastD]??{}).sort((a,b)=>b[1]-a[1])[0])?.[0] ?? "5";
    const markovPred = markovFirst + topPred(posF30).slice(1);

    const mPreds: {key:ModelKey; pred:string}[] = [
      {key:"pos30",       pred:topPred(posF30)},
      {key:"pos90",       pred:topPred(posF90)},
      {key:"triplet",     pred:tripPred},
      {key:"hotFreq",     pred:hotPred},
      {key:"benford",     pred:benPred},
      {key:"mirror4d",    pred:mirrorPred},
      {key:"neighbor",    pred:neighborPred},
      {key:"highlow",     pred:hlPred},
      {key:"calendar",    pred:calPred},
      {key:"permutation", pred:permPred},
      {key:"markov",      pred:markovPred},
    ];

    // ── BRD Weighted Aggregation ──
    const scoreMap: Record<string,{score:number;models:string[]}> = {};
    let totW = 0;
    for (const m of mPreds) {
      const w = MODEL_INFO[m.key].defaultW;
      totW += w;
      if (/^\d{4}$/.test(m.pred)) {
        if (!scoreMap[m.pred]) scoreMap[m.pred]={score:0,models:[]};
        scoreMap[m.pred].score += w;
        scoreMap[m.pred].models.push(MODEL_INFO[m.key].icon + " " + MODEL_INFO[m.key].label);
      }
    }
    const maxW = totW || 1;
    const top6 = Object.entries(scoreMap)
      .map(([num,{score,models}])=>({num, pct:Math.round((score/maxW)*100), rawScore:score, models}))
      .sort((a,b)=>b.rawScore-a.rawScore).slice(0,6);

    // ── Ultimate 1-Digit: weighted digit tally across all model predictions ──
    const digitW: Record<string,number> = {};
    for (let i=0;i<10;i++) digitW[String(i)]=0;
    let totDigW = 0;
    for (const m of mPreds) {
      const w = MODEL_INFO[m.key].defaultW;
      totDigW += w * 4; // 4 digits per prediction
      for (const d of m.pred.split("")) if(/\d/.test(d)) digitW[d]=(digitW[d]??0)+w;
    }
    const sortedDigs = Object.entries(digitW).sort((a,b)=>b[1]-a[1]);
    const ultimateDigit = sortedDigs[0]?.[0] ?? "5";
    const ultimateConf = Math.round(((sortedDigs[0]?.[1] ?? 0) / (totDigW || 1)) * 100);
    const secondDigit  = sortedDigs[1]?.[0] ?? "3";
    const secondConf   = Math.round(((sortedDigs[1]?.[1] ?? 0) / (totDigW || 1)) * 100);

    // ── Top 3-Digit Hit Sequences ──
    const tripFreq: Record<string,number> = {};
    for (const r of filtered.slice(0,50)) for (const n of prizeNums(r)) if (n.length===4) {
      const d=n.split("");
      [d[0]+d[1]+d[2], d[1]+d[2]+d[3], d[0]+d[1]+d[3], d[0]+d[2]+d[3]].forEach(t=>tripFreq[t]=(tripFreq[t]??0)+1);
    }
    const topTrips = Object.entries(tripFreq).sort((a,b)=>b[1]-a[1]).slice(0,2)
      .map(([seq,count])=>({seq,count}));

    // ── Cut Digits: bottom 2 by weighted tally ──
    const cutDigits = sortedDigs.slice(-2).map(([d,w])=>({
      digit:d, conf: Math.round((w/(totDigW||1))*100)
    })).reverse();

    // ── Avoid Patterns (HHHH / LLLL occurrences last 30 draws) ──
    const hlFreqAll: Record<string,number> = {};
    const totalPrize = filtered.slice(0,30).reduce((s,r)=>s+prizeNums(r).filter(n=>n.length===4).length,0);
    for (const r of filtered.slice(0,30)) for (const n of prizeNums(r)) if (n.length===4) {
      const p=n.split("").map(Number).map(x=>x>=5?"H":"L").join(""); hlFreqAll[p]=(hlFreqAll[p]??0)+1;
    }
    const avoidPats = ["HHHH","LLLL","HLHL","LHLH"].map(p=>({
      pattern:p, count:hlFreqAll[p]??0,
      pct: totalPrize>0 ? Math.round(((hlFreqAll[p]??0)/totalPrize)*100) : 0
    })).filter(p=>p.pct<3);

    // ── Hit / Hot / Powerful / Common — each from a DIFFERENT algorithm ──
    // HIT: highest consensus across all 11 models
    const hitNum = top6[0]?.num ?? "????";

    // HOT: most frequently appearing exact 4-digit number in last 50 draws
    const exactFreq: Record<string,number> = {};
    for (const r of filtered.slice(0,50)) for (const n of prizeNums(r)) if (/^\d{4}$/.test(n)) exactFreq[n]=(exactFreq[n]??0)+1;
    const hotCandidates = Object.entries(exactFreq).sort((a,b)=>b[1]-a[1]);
    const hotNum = hotCandidates.find(([n])=>n!==hitNum)?.[0] ?? hotCandidates[0]?.[0] ?? hotPred;

    // POWERFUL: 3D Triplet-based prediction (sequential pattern)
    const powerfulNum = tripPred !== hitNum && tripPred !== hotNum ? tripPred : (top6[1]?.num ?? tripPred);

    // COMMON: Markov chain prediction (transition-based)
    const commonNum = (() => {
      const candidates = [markovPred, hlPred, benPred, calPred, permPred, neighborPred];
      return candidates.find(c=> /^\d{4}$/.test(c) && c!==hitNum && c!==hotNum && c!==powerfulNum) ?? top6[1]?.num ?? markovPred;
    })();

    // ── High/Low & Odd/Even digit distribution (last 30 draws) ──
    let hlH=0,hlL=0,oeO=0,oeE=0;
    for (const r of filtered.slice(0,30)) for (const n of prizeNums(r)) if (n.length===4) {
      for (const d of n.split("")) { const dn=Number(d); if(dn>=5)hlH++;else hlL++; if(dn%2===0)oeE++;else oeO++; }
    }
    const hlTot=hlH+hlL||1; const oeTot=oeO+oeE||1;
    const highPct=Math.round((hlH/hlTot)*100);
    const oddPct =Math.round((oeO/oeTot)*100);

    // ── Special Even/Odd boxes from dominant OE pattern ──
    const oePatsM: Record<string,number>={};
    for (const r of filtered.slice(0,30)) for (const n of prizeNums(r)) if (n.length===4) {
      const p=n.split("").map(d=>Number(d)%2===0?"E":"O").join(""); oePatsM[p]=(oePatsM[p]??0)+1;
    }
    const topOEP=Object.keys(oePatsM).sort((a,b)=>oePatsM[b]-oePatsM[a])[0]??"EOEO";
    const evenBox=topOEP.split("").map((oe,p)=>{
      const pd=Object.entries(posF30[p]).sort((a,b)=>Number(b[1])-Number(a[1]));
      return(pd.find(([d])=>oe==="E"?Number(d)%2===0:Number(d)%2!==0)?.[0])??(oe==="E"?"2":"1");
    }).join("");
    const oddBox=topOEP.split("").map((oe,p)=>{
      const pd=Object.entries(posF30[p]).sort((a,b)=>Number(b[1])-Number(a[1]));
      const inv=oe==="E"?"O":"E";
      return(pd.find(([d])=>inv==="E"?Number(d)%2===0:Number(d)%2!==0)?.[0])??(inv==="E"?"2":"1");
    }).join("");

    // ── Top 4 triplets ──
    const topTrips4=Object.entries(tripFreq).sort((a,b)=>b[1]-a[1]).slice(0,4).map(([seq,count])=>({seq,count}));

    return { ultimateDigit, ultimateConf, secondDigit, secondConf, topTrips, top6, cutDigits, avoidPats, mPreds, lastDate: filtered[0]?.date??"", drawCount: filtered.length, hitNum, hotNum, powerfulNum, commonNum, highPct, oddPct, evenBox, oddBox, topTrips4 };
  }, [filtered]);

  const noData = filtered.length < 10;

  // ── PROBABILITY FILTERING ENGINE (Top 20 from 10,000) ───────────────────────
  const engineResult = useMemo(() => {
    if (filtered.length < 10) return null;
    const draws = filtered.map(r => ({
      date: r.date, first: r.first, second: r.second, third: r.third,
      special: r.special, consolation: r.consolation,
    }));
    return runPatternEngine(draws, 20);
  }, [filtered]);

  // ── 6D ANALYSIS ───────────────────────────────────────────────────────────────
  const analysis6D = useMemo(() => {
    if (filtered.length < 5) return null;
    const allNums: string[] = [];
    for (const r of filtered) for (const n of prizeNums(r)) if (/^\d{4}$/.test(n)) allNums.push(n);
    if (allNums.length < 10) return null;

    // 6-position frequency: pos0-3 from all 4D, pos4 from specials, pos5 from consolations
    const pf6: Record<string,number>[] = Array.from({length:6}, ()=>({"0":0,"1":0,"2":0,"3":0,"4":0,"5":0,"6":0,"7":0,"8":0,"9":0}));
    for (const n of allNums) for (let p=0;p<4;p++) { const d=n[p]; if(d) pf6[p][d]=(pf6[p][d]??0)+1; }
    for (const r of filtered) {
      for (const s of (r.special??[])) if(/^\d{4}$/.test(s)) { pf6[4][s[0]]=(pf6[4][s[0]]??0)+1; pf6[4][s[1]]=(pf6[4][s[1]]??0)+0.5; }
      for (const c of (r.consolation??[])) if(/^\d{4}$/.test(c)) { pf6[5][c[0]]=(pf6[5][c[0]]??0)+1; pf6[5][c[1]]=(pf6[5][c[1]]??0)+0.5; }
      for (const s of (r.special??[])) if(/^\d{4}$/.test(s)) pf6[5][s[2]]=(pf6[5][s[2]]??0)+0.3;
    }
    const bestD = (pf: Record<string,number>) => Object.entries(pf).sort((a,b)=>b[1]-a[1])[0]?.[0]??"0";

    // Global digit frequency across all 4D numbers
    const globalF: Record<string,number> = {};
    for (const n of allNums) for (const d of n) if(/\d/.test(d)) globalF[d]=(globalF[d]??0)+1;
    const sortedG = Object.entries(globalF).sort((a,b)=>b[1]-a[1]);

    // Hot digits (last 15 draws)
    const recentNs = filtered.slice(0,15).flatMap(r=>prizeNums(r)).filter(n=>/^\d{4}$/.test(n));
    const hotF: Record<string,number> = {};
    for (const n of recentNs) for (const d of n) hotF[d]=(hotF[d]??0)+1;
    const sortedHot = Object.entries(hotF).sort((a,b)=>b[1]-a[1]);

    // Cold/due digits (least frequent recently)
    const coldDigs = [...sortedHot].reverse().slice(0,3).map(([d])=>d);

    // 2-digit pairs
    const pairF: Record<string,number> = {};
    for (const n of allNums) for (let i=0;i<3;i++) { const p=n[i]+n[i+1]; pairF[p]=(pairF[p]??0)+1; }
    const topPairs6 = Object.entries(pairF).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([pair,count])=>({pair,count}));

    // 3-digit triplets
    const tripF: Record<string,number> = {};
    for (const n of allNums) { const d=n.split(""); [d[0]+d[1]+d[2],d[1]+d[2]+d[3]].forEach(t=>tripF[t]=(tripF[t]??0)+1); }
    const topTrips6 = Object.entries(tripF).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([trip,count])=>({trip,count}));

    // Generate 6D candidates from multiple methods
    type Cand = {num:string; method:string; score:number; methodIcon:string};
    const cands: Cand[] = [];
    function addC(num:string, method:string, icon:string, score:number) {
      if(!/^\d{6}$/.test(num)) return;
      const ex = cands.find(c=>c.num===num);
      if(ex) { ex.score+=score*0.4; } else cands.push({num,method,score,methodIcon:icon});
    }

    const ext45 = bestD(pf6[4])+bestD(pf6[5]);
    const posBase = Array.from({length:6},(_,i)=>bestD(pf6[i])).join("");

    // M1: Pure position frequency
    addC(posBase, "অবস্থান ফ্রিকোয়েন্সি", "📊", 100);
    // M2: Engine top 4D + pos5/6 extension
    if (engineResult?.scores[0]) {
      addC(engineResult.scores[0].num+ext45, "সেরা ৪D + বিস্তার", "🧠", 98);
      if(engineResult.scores[1]) addC(engineResult.scores[1].num+ext45, "২য় সেরা ৪D + বিস্তার", "🧠", 88);
      if(engineResult.scores[2]) addC(engineResult.scores[2].num+ext45, "৩য় সেরা ৪D + বিস্তার", "🧠", 80);
    }
    // M3: Top triplet + 3 more
    if(topTrips6[0]&&topTrips6[1]) addC(topTrips6[0].trip+topTrips6[1].trip, "শীর্ষ ৩D জোড়া", "🔗", 92);
    if(topTrips6[0]) addC(topTrips6[0].trip+ext45+bestD(pf6[3]), "ট্রিপলেট + অবস্থান", "🎯", 85);
    // M4: Hot digits arranged by position
    const hotPred6 = Array.from({length:6},(_,i)=>sortedHot[i%Math.max(sortedHot.length,1)]?.[0]??"5").join("");
    addC(hotPred6, "সাম্প্রতিক গরম ডিজিট", "🔥", 90);
    // M5: Top-6 global freq digits arranged by pos
    const g6 = sortedG.slice(0,6).map(([d])=>d);
    const freqArr = Array.from({length:6},(_,p)=>[...g6].sort((a,b)=>(pf6[p][b]??0)-(pf6[p][a]??0))[0]??g6[p]??"5").join("");
    addC(freqArr, "সবচেয়ে জনপ্রিয় ডিজিট", "⭐", 87);
    // M6: Top-3 pairs combined
    if(topPairs6[0]&&topPairs6[1]&&topPairs6[2]) addC(topPairs6[0].pair+topPairs6[1].pair+topPairs6[2].pair, "জনপ্রিয় জোড়া ত্রয়ী", "🔢", 82);
    // M7: Mirror of last first + hot extension
    const lastF=filtered[0]?.first??"";
    if(/^\d{4}$/.test(lastF)) {
      const mir=lastF.split("").map(d=>String(9-Number(d))).join("");
      addC(mir+(sortedG[0]?.[0]??"1")+(sortedG[1]?.[0]??"2"), "মিরর + গরম ডিজিট", "🪞", 75);
      // M8: Neighbor+1 of last + extension
      const neigh=lastF.split("").map(d=>String((Number(d)+1)%10)).join("");
      addC(neigh+ext45, "প্রতিবেশী সম্প্রসারণ", "🔀", 70);
    }
    // M9: Cold/due extension with engine
    if(engineResult?.scores[0]&&coldDigs.length>=2)
      addC(engineResult.scores[0].num+coldDigs[0]+coldDigs[1], "ঠান্ডা ডিজিট সম্প্রসারণ", "❄️", 65);
    // M10: Benford-guided 6D
    const benF=["1","2","3"].find(d=>(pf6[0][d]??0)>0)??bestD(pf6[0]);
    addC(benF+Array.from({length:5},(_,i)=>bestD(pf6[i+1])).join(""), "বেনফোর্ড ৬D", "📐", 68);
    // M11: Markov first digit + pos rest
    if(filtered.length>=2&&lastF) addC(lastF+ext45, "মার্কভ ৬D বিস্তার", "🔄", 72);
    // M12: 11-model consensus 4D extended
    if(analysis?.top6[0]) addC(analysis.top6[0].num+ext45, "১১ মডেল সম্মতি + বিস্তার", "🤝", 94);
    if(analysis?.top6[1]) addC(analysis.top6[1].num+ext45, "১১ মডেল ২য় সম্মতি", "🤝", 84);

    const seen=new Set<string>();
    const top15=cands.sort((a,b)=>b.score-a.score).filter(c=>{if(seen.has(c.num))return false;seen.add(c.num);return true;}).slice(0,15);

    // Normalize confidence to 60-99%
    const maxS=top15[0]?.score??100;
    top15.forEach((c,i)=>{(c as any).confidence=Math.max(60,Math.min(99,Math.round(60+(c.score/maxS)*39-(i*1.5))));});

    // Position heatmap
    const posHM = Array.from({length:6},(_,p)=>{
      const tot=Object.values(pf6[p]).reduce((a,b)=>a+b,0)||1;
      return {pos:p,label:["১ম","২য়","৩য়","৪র্থ","৫ম","৬ষ্ঠ"][p],
        digits:Object.entries(pf6[p]).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([d,w])=>({d,pct:Math.round((w/tot)*100)}))};
    });

    const commonDigits=sortedG.slice(0,6).map(([d,count])=>({d,count,pct:Math.round((count/(allNums.length*4))*100)}));
    const hotTop5=sortedHot.slice(0,6).map(([d,count])=>({d,count}));

    return {top15,posHM,commonDigits,hotTop5,topPairs6,topTrips6,coldDigs,totalNums:allNums.length,totalDraws:filtered.length};
  }, [filtered, engineResult, analysis]);

  // ── 3-STAGE PREDICTION PIPELINE ──────────────────────────────────────────────
  const pipeline = useMemo(() => {
    if (!analysis) return null;
    return run3StagePipeline(
      analysis.mPreds,
      MODEL_INFO,
      analysis.topTrips4,
      analysis.ultimateDigit,
      analysis.secondDigit,
      analysis.cutDigits,
      engineResult?.scores.map(s => ({ num: s.num, score: s.confidence / 99 })) ?? [],
    );
  }, [analysis, engineResult]);

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-5">

      {/* ══ Top Section (Timer + Date + Mascot + Helpline) ══ */}
      <TopSection user={user} />

      {/* ══ SECRET LUCKY NUMBER BOX ══ */}
      <div className={`rounded-2xl overflow-hidden${secretLocked&&secretNum?" lucky-vibrate":""}`} style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.08)",boxShadow:"0 0 30px rgba(124,58,237,0.08)"}}>
        <div className="flex items-center justify-between px-4 py-2.5" style={{borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
          <div className="flex items-center gap-2">
            <span className="text-base">{secretLocked?"🔒":"🔓"}</span>
            <span className="text-white font-bold text-sm">Your Lucky Number</span>
            <span className="text-zinc-600 text-xs">— শুধু আপনার জন্য</span>
          </div>
          {isAdmin && (
            <button
              onClick={handleSecretLock}
              className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl transition-all active:scale-95"
              style={secretLocked
                ? {background:"rgba(34,197,94,0.15)",color:"#4ade80",border:"1px solid rgba(34,197,94,0.3)"}
                : {background:"rgba(220,38,38,0.15)",color:"#f87171",border:"1px solid rgba(220,38,38,0.3)"}
              }
            >
              {secretLocked ? "🔓 Unlock" : "🔒 Lock"}
            </button>
          )}
        </div>
        <div className="relative px-4 py-4">
          <input
            type="text"
            value={secretNum}
            onChange={e=>handleSecretChange(e.target.value)}
            disabled={secretLocked}
            placeholder="আপনার lucky number লিখুন…"
            className="w-full bg-transparent font-mono font-black text-3xl tracking-[0.3em] text-center text-white outline-none placeholder:text-zinc-800 placeholder:font-normal placeholder:text-base placeholder:tracking-normal transition-all"
            style={{caretColor:"#dc2626"}}
          />
          {secretLocked && (
            <div
              className="absolute inset-0 rounded-xl flex items-center justify-center"
              style={{backdropFilter:"blur(12px)",WebkitBackdropFilter:"blur(12px)",background:"rgba(10,10,15,0.55)",cursor:isAdmin?"pointer":"default"}}
              onClick={isAdmin ? handleSecretLock : undefined}
            >
              <div className="flex flex-col items-center gap-1 select-none pointer-events-none">
                <span className="text-2xl">🔒</span>
                <span className="text-zinc-500 text-xs">{isAdmin ? "ট্যাপ করে Unlock করুন" : "শুধু Admin Unlock করতে পারবে"}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ══ Admin Picks ══ */}
      <AdminPicksBox user={user} />

      {/* ── Header ── */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-2xl">⭐</span>
            <h1 className="text-xl font-black text-white">Master Prediction Sheet</h1>
            <span className="text-[10px] font-black px-2 py-0.5 rounded-full" style={{background:"rgba(234,179,8,0.15)",color:"#eab308",border:"1px solid rgba(234,179,8,0.3)"}}>LIVE</span>
          </div>
          <p className="text-zinc-600 text-xs">আপনার ডেটার ওপর ভিত্তি করে ১১টি মডেলের পূর্বাভাস · নতুন ড্র যোগ করলেই আপডেট হবে</p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <CompanyPicker value={company} onChange={setCompany}/>
          {analysis&&<span className="text-zinc-700 text-xs">{analysis.drawCount} draws · {analysis.lastDate}</span>}
        </div>
      </div>

      {/* ── No data notice ── */}
      {noData && (
        <div className="rounded-2xl p-10 text-center" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.06)"}}>
          <div className="text-5xl mb-4">📭</div>
          <div className="text-white font-bold mb-1">ডেটা পর্যাপ্ত নয়</div>
          <div className="text-zinc-600 text-sm">Admin ড্র যোগ করলে এখানে prediction দেখা যাবে</div>
          <div className="text-zinc-700 text-xs mt-2">({filtered.length} / ১০ ড্র আছে)</div>
        </div>
      )}

      {/* ══ PATTERN INTELLIGENCE ENGINE ══ */}
      {engineResult && engineResult.scores.length > 0 && (() => {
        const reasonMap: Record<string,string> = {
          posFreq:"বেশি বার এসেছে", pairScore:"জোড়া মিল আছে",
          skipBonus:"অনেকদিন আসেনি", momentumScore:"এখন উঠছে",
          clusterScore:"গুচ্ছে আছে", balanceBonus:"সুষম বিন্যাস",
        };
        const reasonColor: Record<string,string> = {
          posFreq:"#60a5fa", pairScore:"#c084fc", skipBonus:"#fb923c",
          momentumScore:"#f43f5e", clusterScore:"#a78bfa", balanceBonus:"#4ade80",
        };
        return (
        <div className="rounded-2xl overflow-hidden" style={{background:"rgba(4,8,16,0.99)",border:"1px solid rgba(99,102,241,0.25)"}}>

          {/* ── Header (clickable folder toggle) ── */}
          <button
            onClick={()=>toggleFolder("m_engine")}
            className="w-full px-5 py-4 flex items-center justify-between flex-wrap gap-2 text-left transition-all"
            style={{background:openFolders.has("m_engine")?"rgba(99,102,241,0.1)":"rgba(99,102,241,0.05)"}}
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl">🧠</span>
              <div>
                <div className="text-white font-black text-sm">সম্ভাবনাময় নাম্বার তালিকা</div>
                <div className="text-zinc-600 text-xs mt-0.5">
                  {engineResult.scores[0]?.num && !openFolders.has("m_engine")
                    ? `সেরা নাম্বার: ${engineResult.scores.slice(0,3).map(s=>s.num).join(" · ")} — ক্লিক করে সব দেখুন`
                    : `${engineResult.stats.drawsUsed} টি ড্র বিশ্লেষণ → ১০,০০০ নাম্বার স্কোর → সেরা ২০টি`}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {!openFolders.has("m_engine") && engineResult.scores[0] && (
                <span className="font-mono font-black text-base px-3 py-1 rounded-xl" style={{background:"rgba(99,102,241,0.2)",color:"#818cf8"}}>{engineResult.scores[0].num}</span>
              )}
              <span className="text-zinc-500 text-sm font-bold" style={{transform:openFolders.has("m_engine")?"rotate(180deg)":"none",transition:"transform 0.2s"}}>▼</span>
            </div>
          </button>

          {/* ── Content (collapsible) ── */}
          {openFolders.has("m_engine") && <div style={{borderTop:"1px solid rgba(99,102,241,0.2)"}}>

          {/* ── Folder helper ── */}
          {(()=>{
            const fKey = (k:string) => "eng_"+k;
            const isOpen = (k:string) => openFolders.has(fKey(k));
            const Folder = ({id,accent,icon,title,sub,children}:{id:string;accent:string;icon:string;title:string;sub:string;children:React.ReactNode}) => (
              <div className="rounded-xl overflow-hidden" style={{border:`1px solid ${isOpen(id)?accent+"40":"rgba(255,255,255,0.07)"}`}}>
                <button
                  onClick={()=>toggleFolder(fKey(id))}
                  className="w-full flex items-center justify-between px-4 py-3 text-left transition-all"
                  style={{background:isOpen(id)?`${accent}12`:"rgba(255,255,255,0.025)"}}
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-base">{icon}</span>
                    <div>
                      <div className="text-white text-sm font-black leading-tight">{title}</div>
                      <div className="text-zinc-600 text-[10px]">{sub}</div>
                    </div>
                  </div>
                  <span className="text-zinc-600 text-xs font-bold transition-transform" style={{transform:isOpen(id)?"rotate(180deg)":"rotate(0deg)"}}>▼</span>
                </button>
                {isOpen(id) && (
                  <div className="px-4 pb-4 pt-1" style={{borderTop:`1px solid ${accent}20`}}>
                    {children}
                  </div>
                )}
              </div>
            );
            return (
          <div className="p-3 space-y-2">

            {/* ══ FOLDER A: সেরা নাম্বার তালিকা ══ */}
            <Folder id="top20" accent="#6366f1" icon="🏆" title="সেরা নাম্বার তালিকা" sub={`১০,০০০ থেকে বাছাই করা ${engineResult.stats.finalTop}টি · ক্লিক করে খুলুন`}>
              <div className="grid grid-cols-3 gap-2 mb-3 mt-3">
                {engineResult.scores.slice(0,3).map((s,i)=>{
                  const cfg=[
                    {bg:"linear-gradient(145deg,rgba(234,179,8,0.18),rgba(120,80,0,0.08))",border:"rgba(234,179,8,0.35)",col:"#fde68a",medal:"🥇",rank:"১ম পছন্দ"},
                    {bg:"linear-gradient(145deg,rgba(148,163,184,0.14),rgba(80,100,120,0.06))",border:"rgba(148,163,184,0.25)",col:"#e2e8f0",medal:"🥈",rank:"২য় পছন্দ"},
                    {bg:"linear-gradient(145deg,rgba(180,83,9,0.16),rgba(100,50,0,0.06))",border:"rgba(180,83,9,0.25)",col:"#fdba74",medal:"🥉",rank:"৩য় পছন্দ"},
                  ][i];
                  return (
                    <div key={s.num} className="rounded-xl p-3 text-center" style={{background:cfg.bg,border:`1px solid ${cfg.border}`}}>
                      <div className="text-sm mb-0.5">{cfg.medal}</div>
                      <div className="font-mono font-black text-2xl tracking-[0.12em] my-1.5" style={{color:cfg.col}}>{s.num}</div>
                      <div className="text-[10px] font-bold mb-2" style={{color:cfg.col+"99"}}>{cfg.rank}</div>
                      <div className="text-[10px] text-zinc-600 mb-1">সম্ভাবনা {s.confidence}%</div>
                      <div className="h-1 rounded-full overflow-hidden" style={{background:"rgba(255,255,255,0.07)"}}>
                        <div className="h-full rounded-full" style={{width:`${s.confidence}%`,background:cfg.col}}/>
                      </div>
                      <div className="mt-1.5 text-[9px] font-semibold" style={{color:reasonColor[s.mainReason]??"#71717a"}}>
                        ↑ {reasonMap[s.mainReason]??"বিশ্লেষণ"}
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="rounded-xl overflow-hidden" style={{border:"1px solid rgba(255,255,255,0.06)"}}>
                <div className="grid px-3 py-2 text-[10px] font-bold text-zinc-700 uppercase" style={{gridTemplateColumns:"2.2rem 4.5rem 1fr 4rem",background:"rgba(255,255,255,0.03)"}}>
                  <span>#</span><span>নাম্বার</span><span>কারণ</span><span className="text-right">%</span>
                </div>
                {engineResult.scores.slice(3).map((s,i)=>(
                  <div key={s.num} className="grid items-center px-3 py-2" style={{gridTemplateColumns:"2.2rem 4.5rem 1fr 4rem",borderTop:"1px solid rgba(255,255,255,0.035)",background:i%2===0?"transparent":"rgba(255,255,255,0.01)"}}>
                    <span className="text-zinc-700 text-xs font-bold">{i+4}</span>
                    <span className="font-mono font-black text-sm text-white tracking-wider">{s.num}</span>
                    <span className="text-[10px] font-semibold" style={{color:reasonColor[s.mainReason]??"#71717a"}}>{reasonMap[s.mainReason]??"–"}</span>
                    <span className="text-right font-black text-xs" style={{color:"#6366f1"}}>{s.confidence}%</span>
                  </div>
                ))}
                {/* ── Custom editable picks ── */}
                {([0,1] as const).map((idx)=>{
                  const rowNum = engineResult.scores.slice(3).length + 4 + idx;
                  const val = customPicks[idx];
                  return (
                    <div key={`custom-${idx}`} className="grid items-center px-3 py-2" style={{gridTemplateColumns:"2.2rem 4.5rem 1fr 4rem",borderTop:"1px solid rgba(99,102,241,0.18)",background:"rgba(99,102,241,0.05)"}}>
                      <span className="text-indigo-600 text-xs font-bold">{rowNum}</span>
                      {isAdmin && editingCustom ? (
                        <input
                          type="text"
                          inputMode="numeric"
                          maxLength={4}
                          value={val}
                          onChange={e=>saveCustomPick(idx, e.target.value)}
                          placeholder="0000"
                          className="font-mono font-black text-sm tracking-wider bg-transparent border-b border-indigo-500 outline-none w-16 text-indigo-300 placeholder-indigo-800"
                        />
                      ) : (
                        <span className="font-mono font-black text-sm tracking-wider" style={{color: val ? "#a5b4fc" : "#3f3f5a"}}>{val || "––––"}</span>
                      )}
                      <span className="text-[10px] font-semibold text-indigo-600">আমার পছন্দ {idx+1}</span>
                      <span className="text-right text-[10px] text-indigo-800">–</span>
                    </div>
                  );
                })}
              </div>
              {/* Edit / Done button — admin only */}
              {isAdmin && (
                <div className="flex justify-end mt-2">
                  <button
                    onClick={()=>setEditingCustom(e=>!e)}
                    className="text-[11px] font-bold px-3 py-1 rounded-lg transition-all"
                    style={{background: editingCustom?"rgba(99,102,241,0.25)":"rgba(99,102,241,0.1)", color:"#a5b4fc", border:"1px solid rgba(99,102,241,0.3)"}}
                  >
                    {editingCustom ? "✅ সম্পন্ন" : "✏️ আমার পছন্দ এডিট করুন"}
                  </button>
                </div>
              )}
            </Folder>

            {/* ══ FOLDER B: Digit Momentum ══ */}
            <Folder id="momentum" accent="#f43f5e" icon="🔥" title="Digit Momentum" sub="কোন digit এখন উঠছে বা নামছে · ক্লিক করে খুলুন">
              <div className="grid grid-cols-5 gap-1.5 mt-3">
                {engineResult.digitMomentum.map(dm=>{
                  const isUp=dm.label.includes("উঠছে"), isDown=dm.label.includes("নামছে");
                  const col=isUp?"#4ade80":isDown?"#f87171":"#94a3b8";
                  return (
                    <div key={dm.digit} className="rounded-xl p-2 text-center" style={{background:isUp?"rgba(34,197,94,0.08)":isDown?"rgba(248,113,113,0.08)":"rgba(255,255,255,0.03)",border:`1px solid ${isUp?"rgba(34,197,94,0.2)":isDown?"rgba(248,113,113,0.2)":"rgba(255,255,255,0.07)"}`}}>
                      <div className="font-black text-xl" style={{color:col}}>{dm.digit}</div>
                      <div className="text-[9px] mt-0.5 font-bold" style={{color:col+"cc"}}>{isUp?"🔥":isDown?"❄️":"➡️"}</div>
                      <div className="text-[8px] text-zinc-700 mt-0.5">{dm.recentCount}→{dm.olderCount}</div>
                    </div>
                  );
                })}
              </div>
              <div className="flex gap-3 mt-2 text-[10px] text-zinc-700">
                <span>🔥 উঠছে = সাম্প্রতিক বেশি</span>
                <span>❄️ নামছে = কমে যাচ্ছে</span>
                <span>➡️ স্থির = একই রকম</span>
              </div>
            </Folder>

            {/* ══ FOLDER C: Position Heatmap ══ */}
            <Folder id="position" accent="#0ea5e9" icon="📊" title="ঘর ভিত্তিক বিশ্লেষণ" sub="কোন ঘরে কোন digit বেশি আসে · ক্লিক করে খুলুন">
              <div className="grid grid-cols-4 gap-2 mt-3">
                {engineResult.positionHeatmap.map(ph=>(
                  <div key={ph.pos} className="rounded-xl p-3" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.06)"}}>
                    <div className="text-[10px] font-bold text-zinc-500 mb-2">{ph.label}</div>
                    {ph.digits.slice(0,5).map((dg,i)=>(
                      <div key={dg.d} className="flex items-center gap-1.5 mb-1">
                        <span className="font-mono font-black text-xs w-3" style={{color:i===0?"#fde68a":i===1?"#60a5fa":"#71717a"}}>{dg.d}</span>
                        <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{background:"rgba(255,255,255,0.05)"}}>
                          <div className="h-full rounded-full" style={{width:`${dg.pct}%`,background:`rgba(14,165,233,${Math.max(0.2,dg.pct/100)})`}}/>
                        </div>
                        <span className="text-[9px] text-zinc-700 w-6 text-right">{dg.pct}%</span>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </Folder>

            {/* ══ FOLDER D: Pair Network ══ */}
            <Folder id="pairs" accent="#c084fc" icon="🔗" title="শক্তিশালী জোড়া (Pair Network)" sub="বারবার একসাথে আসে এমন digit জোড়া · ক্লিক করে খুলুন">
              <div className="grid grid-cols-6 gap-1.5 mt-3">
                {engineResult.topPairs.map(p=>(
                  <div key={p.pair} className="rounded-xl py-2 px-1 text-center" style={{background:"rgba(255,255,255,0.03)",border:`1px solid ${p.color}30`}}>
                    <div className="font-mono font-black text-lg" style={{color:p.color}}>{p.pair}</div>
                    <div className="text-[8px] mt-0.5 font-bold" style={{color:p.color+"99"}}>{p.strength}</div>
                  </div>
                ))}
              </div>
            </Folder>

            {/* ══ FOLDER: Advanced Mathematical Engine ══ */}
            <Folder id="advanced" accent="#10b981" icon="🧮" title="Advanced Mathematical Engine" sub="Matrix + entropy + rolling window + adaptive reliability · ক্লিক করে খুলুন">
              <div className="space-y-3 mt-3">
                <div className="grid grid-cols-2 gap-2">
                  <div className="rounded-xl p-3" style={{background:"rgba(16,185,129,0.06)",border:"1px solid rgba(16,185,129,0.15)"}}>
                    <div className="text-[10px] text-zinc-500">Engine quality</div>
                    <div className="text-xs font-bold text-emerald-300 mt-1">{engineResult.advanced.quality || "History বাড়লে adaptive weighting আরও নির্ভরযোগ্য হবে"}</div>
                  </div>
                  <div className="rounded-xl p-3" style={{background:"rgba(99,102,241,0.06)",border:"1px solid rgba(99,102,241,0.15)"}}>
                    <div className="text-[10px] text-zinc-500">Signal count</div>
                    <div className="text-2xl font-black text-indigo-300 mt-1">27</div>
                  </div>
                </div>

                <div className="rounded-xl p-3" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.06)"}}>
                  <div className="text-white text-xs font-black mb-2">📐 Position Entropy / Stability</div>
                  <div className="grid grid-cols-2 gap-2">
                    {engineResult.advanced.digitEntropy.map(e=><div key={e.position} className="text-[10px] text-zinc-400">{e.label}: entropy <b className="text-white">{e.entropy}</b> · stability <b className="text-emerald-300">{Math.round(e.stability*100)}%</b></div>)}
                  </div>
                </div>

                <div className="rounded-xl p-3" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.06)"}}>
                  <div className="text-white text-xs font-black mb-2">🔄 Transition Matrix — সবচেয়ে শক্তিশালী পরিবর্তন</div>
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
                    {engineResult.advanced.transitionMatrix.slice(0,10).map(x=><div key={x.from+x.to} className="rounded-lg px-2 py-1.5 text-center bg-slate-900"><span className="font-mono font-black text-emerald-300">{x.from}→{x.to}</span><div className="text-[8px] text-zinc-600">{x.count} · {x.pct}%</div></div>)}
                  </div>
                </div>

                <div className="rounded-xl p-3" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.06)"}}>
                  <div className="text-white text-xs font-black mb-2">🔗 Pair + Triplet Matrix</div>
                  <div className="grid grid-cols-2 gap-3">
                    <div><div className="text-[9px] text-zinc-600 mb-1">Top pairs</div>{engineResult.advanced.pairMatrix.slice(0,8).map(x=><div key={x.pair} className="flex justify-between text-[10px] py-0.5"><span className="font-mono text-purple-300">{x.pair}</span><span className="text-zinc-600">{x.count}</span></div>)}</div>
                    <div><div className="text-[9px] text-zinc-600 mb-1">Top triplets</div>{engineResult.advanced.tripletPatterns.slice(0,8).map(x=><div key={x.triplet} className="flex justify-between text-[10px] py-0.5"><span className="font-mono text-sky-300">{x.triplet}</span><span className="text-zinc-600">{x.count}</span></div>)}</div>
                  </div>
                </div>

                <div className="rounded-xl p-3" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.06)"}}>
                  <div className="text-white text-xs font-black mb-2">🧩 Pattern Classification</div>
                  <div className="grid grid-cols-3 gap-1.5">
                    {engineResult.advanced.patternClassification.map(x=><div key={x.pattern} className="rounded-lg bg-slate-900 p-2 text-center"><div className="font-mono text-[10px] text-sky-300">{x.pattern}</div><div className="text-[9px] text-zinc-500">{x.count} · {x.pct}%</div></div>)}
                  </div>
                </div>

                <div className="rounded-xl p-3" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.06)"}}>
                  <div className="text-white text-xs font-black mb-2">🧪 Rolling Window</div>
                  <div className="grid grid-cols-2 gap-2">
                    {engineResult.advanced.rollingWindows.map(w=><div key={w.window} className="rounded-lg bg-slate-900 p-2"><div className="text-[9px] text-zinc-600">শেষ {w.window} draw</div><div className="font-mono text-xs text-white mt-1">{w.top.join(" · ")}</div></div>)}
                  </div>
                </div>

                <div className="rounded-xl p-3" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.06)"}}>
                  <div className="text-white text-xs font-black mb-2">⚖️ Signal Reliability — Walk-forward test</div>
                  <div className="space-y-1.5">
                    {engineResult.advanced.signalReliability.slice().sort((a,b)=>b.weight-a.weight).slice(0,10).map(r=><div key={r.key} className="grid items-center gap-2" style={{gridTemplateColumns:"1fr 3.2rem 3.2rem"}}><span className="text-[10px] text-zinc-400">{r.label}</span><span className="text-right text-[10px] text-emerald-300">{Math.round(r.rate*100)}%</span><span className="text-right text-[10px] text-indigo-300">×{r.weight.toFixed(2)}</span></div>)}
                  </div>
                  <div className="text-[9px] text-zinc-700 mt-2">ইতিহাসে ভালো out-of-sample rank করা signal-এর weight বেশি; দুর্বল signal-এর weight কম।</div>
                </div>

                <div className="rounded-xl p-3" style={{background:"rgba(99,102,241,0.05)",border:"1px solid rgba(99,102,241,0.14)"}}>
                  <div className="text-white text-xs font-black mb-2">🏆 Candidate Score Breakdown</div>
                  {engineResult.scores.slice(0,5).map(s=><div key={s.num} className="mb-3 last:mb-0"><div className="flex justify-between"><span className="font-mono font-black text-indigo-300">#{s.rank} — {s.num}</span><span className="text-xs text-zinc-400">Score {s.confidence}</span></div><div className="grid grid-cols-2 gap-x-3 gap-y-1 mt-1">{(s.contributions||[]).sort((a,b)=>b.contribution-a.contribution).slice(0,8).map(c=><div key={c.key} className="flex justify-between text-[9px] text-zinc-600"><span>{c.label}</span><span className="text-zinc-400">{c.contribution.toFixed(2)}</span></div>)}</div></div>)}
                </div>
              </div>
            </Folder>

            {/* ══ FOLDER E: Backtest ══ */}
            {engineResult.backtest.total > 0 && (
              <Folder id="backtest" accent="#fbbf24" icon="🧪" title="পরীক্ষার ফলাফল" sub={`গত ${engineResult.backtest.total}টি draw এ এই পদ্ধতি কতটা কাজ করেছে · ক্লিক করে খুলুন`}>
                <div className="grid grid-cols-2 gap-2 mt-3">
                  {[
                    {icon:"🎯",label:"হুবহু মিলেছে",sub:"৪টি digit সম্পূর্ণ মিল",val:engineResult.backtest.exact4DRate,hits:engineResult.backtest.exact4DHits,color:"#4ade80"},
                    {icon:"🔗",label:"প্রথম জোড়া মিল",sub:"১ম ও ২য় ঘর মিলেছে",val:engineResult.backtest.frontPairRate,hits:engineResult.backtest.frontPairHits,color:"#60a5fa"},
                    {icon:"🔗",label:"শেষ জোড়া মিল",sub:"৩য় ও ৪র্থ ঘর মিলেছে",val:engineResult.backtest.backPairRate,hits:engineResult.backtest.backPairHits,color:"#c084fc"},
                    {icon:"⭐",label:"আংশিক মিল",sub:"২+ digit একই জায়গায়",val:engineResult.backtest.anyDigitRate,hits:engineResult.backtest.anyDigitHits,color:"#fbbf24"},
                  ].map(b=>(
                    <div key={b.sub} className="rounded-xl p-3" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.06)"}}>
                      <div className="flex items-center justify-between mb-2">
                        <div><div className="text-white text-xs font-bold">{b.icon} {b.label}</div><div className="text-zinc-700 text-[10px]">{b.sub}</div></div>
                        <div className="text-right"><div className="font-black text-xl leading-none" style={{color:b.color}}>{b.val}%</div><div className="text-zinc-700 text-[9px] mt-0.5">{b.hits}/{engineResult.backtest.total} বার</div></div>
                      </div>
                      <div className="h-1.5 rounded-full overflow-hidden" style={{background:"rgba(255,255,255,0.05)"}}>
                        <div className="h-full rounded-full" style={{width:`${b.val}%`,background:b.color}}/>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-2 rounded-lg px-3 py-2 text-center" style={{background:"rgba(255,255,255,0.02)"}}>
                  <span className="text-[11px] text-zinc-600">💡 হুবহু না মিললেও জোড়া বা আংশিক মিল 4D-তে বড় সুবিধা দেয়</span>
                </div>
              </Folder>
            )}

          </div>
            );
          })()}
          </div>}
        </div>
        );
      })()}

      {/* ══ FOLDER: ৬ ডিজিট বিশ্লেষণ ══ */}
      {analysis6D && (() => {
        const a6 = analysis6D;
        const top3 = a6.top15.slice(0,3);
        const rest = a6.top15.slice(3);
        const cardCfg = [
          {bg:"linear-gradient(145deg,rgba(234,179,8,0.18),rgba(120,80,0,0.08))",border:"rgba(234,179,8,0.35)",col:"#fde68a",medal:"🥇",rank:"১ম পছন্দ"},
          {bg:"linear-gradient(145deg,rgba(148,163,184,0.14),rgba(80,100,120,0.06))",border:"rgba(148,163,184,0.25)",col:"#e2e8f0",medal:"🥈",rank:"২য় পছন্দ"},
          {bg:"linear-gradient(145deg,rgba(180,83,9,0.16),rgba(100,50,0,0.06))",border:"rgba(180,83,9,0.25)",col:"#fdba74",medal:"🥉",rank:"৩য় পছন্দ"},
        ];
        return (
        <div className="rounded-2xl overflow-hidden" style={{border:`1px solid ${openFolders.has("m_6d")?"rgba(16,185,129,0.4)":"rgba(255,255,255,0.08)"}`}}>
          <button onClick={()=>toggleFolder("m_6d")} className="w-full px-5 py-4 flex items-center justify-between text-left transition-all" style={{background:openFolders.has("m_6d")?"rgba(16,185,129,0.08)":"rgba(255,255,255,0.02)"}}>
            <div className="flex items-center gap-3">
              <span className="text-xl">🎲</span>
              <div>
                <div className="font-bold text-white text-sm">৬ ডিজিট বিশ্লেষণ</div>
                <div className="text-[11px] text-zinc-500 mt-0.5">
                  {openFolders.has("m_6d")
                    ? `${a6.totalDraws} ড্র · ${a6.totalNums} নাম্বার · ১২টি পদ্ধতি বিশ্লেষণ`
                    : `সেরা ৬D: ${top3.map(c=>c.num).join(" · ")} — ক্লিক করে দেখুন`}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {!openFolders.has("m_6d") && top3[0] && (
                <span className="font-mono font-black text-base px-3 py-1 rounded-xl" style={{background:"rgba(16,185,129,0.2)",color:"#34d399"}}>{top3[0].num}</span>
              )}
              <span className="text-zinc-500 text-sm font-bold" style={{transform:openFolders.has("m_6d")?"rotate(180deg)":"none",transition:"transform 0.2s"}}>▼</span>
            </div>
          </button>

          {openFolders.has("m_6d") && (
            <div className="p-4 space-y-4" style={{borderTop:"1px solid rgba(16,185,129,0.2)"}}>

              {/* Info banner */}
              <div className="rounded-xl px-4 py-2.5 text-[11px] text-emerald-400 font-semibold" style={{background:"rgba(16,185,129,0.08)",border:"1px solid rgba(16,185,129,0.2)"}}>
                ✅ সকল {a6.totalDraws}টি ড্রয়ের {a6.totalNums}টি নাম্বার বিশ্লেষণ · ১২টি আলাদা পদ্ধতি · ৬টি অবস্থান ফ্রিকোয়েন্সি · পেয়ার · ট্রিপলেট · মমেন্টাম সব একসাথে
              </div>

              {/* Top 3 big cards */}
              <div className="grid grid-cols-3 gap-2">
                {top3.map((c,i)=>{
                  const cfg=cardCfg[i];
                  return (
                    <div key={c.num} className="rounded-xl p-3 text-center" style={{background:cfg.bg,border:`1px solid ${cfg.border}`}}>
                      <div className="text-sm mb-0.5">{cfg.medal}</div>
                      <div className="font-mono font-black text-xl tracking-[0.1em] my-1.5 leading-tight" style={{color:cfg.col}}>{c.num.slice(0,3)}<br/>{c.num.slice(3)}</div>
                      <div className="text-[10px] font-bold mb-2" style={{color:cfg.col+"99"}}>{cfg.rank}</div>
                      <div className="text-[10px] text-zinc-600 mb-1">সম্ভাবনা {(c as any).confidence}%</div>
                      <div className="h-1 rounded-full overflow-hidden" style={{background:"rgba(255,255,255,0.07)"}}>
                        <div className="h-full rounded-full" style={{width:`${(c as any).confidence}%`,background:cfg.col}}/>
                      </div>
                      <div className="mt-1.5 text-[9px] font-semibold text-emerald-600">{c.methodIcon} {c.method}</div>
                    </div>
                  );
                })}
              </div>

              {/* Remaining list */}
              {rest.length > 0 && (
                <div className="rounded-xl overflow-hidden" style={{border:"1px solid rgba(255,255,255,0.06)"}}>
                  <div className="grid px-3 py-2 text-[10px] font-bold text-zinc-700 uppercase" style={{gridTemplateColumns:"2rem 7rem 1fr 3.5rem",background:"rgba(255,255,255,0.03)"}}>
                    <span>#</span><span>৬ ডিজিট</span><span>পদ্ধতি</span><span className="text-right">%</span>
                  </div>
                  {rest.map((c,i)=>(
                    <div key={c.num} className="grid items-center px-3 py-2" style={{gridTemplateColumns:"2rem 7rem 1fr 3.5rem",borderTop:"1px solid rgba(255,255,255,0.035)",background:i%2===0?"transparent":"rgba(255,255,255,0.01)"}}>
                      <span className="text-zinc-700 text-xs font-bold">{i+4}</span>
                      <span className="font-mono font-black text-sm text-emerald-300 tracking-wider">{c.num}</span>
                      <span className="text-[10px] text-zinc-500">{c.methodIcon} {c.method}</span>
                      <span className="text-right font-black text-xs text-emerald-600">{(c as any).confidence}%</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Position Heatmap for 6 positions */}
              <div>
                <div className="text-[11px] font-bold text-zinc-400 mb-2 uppercase tracking-wider">প্রতিটি অবস্থানে কোন ডিজিট সবচেয়ে বেশি আসে</div>
                <div className="grid grid-cols-6 gap-1.5">
                  {a6.posHM.map(ph=>(
                    <div key={ph.pos} className="rounded-xl p-2" style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.06)"}}>
                      <div className="text-[9px] font-bold text-zinc-600 text-center mb-1.5">{ph.label} ঘর</div>
                      {ph.digits.slice(0,4).map((d,di)=>(
                        <div key={d.d} className="flex items-center justify-between mb-1">
                          <span className="font-mono font-black text-sm" style={{color:di===0?"#34d399":di===1?"#60a5fa":"#94a3b8"}}>{d.d}</span>
                          <div className="flex-1 mx-1.5 h-1 rounded-full overflow-hidden" style={{background:"rgba(255,255,255,0.05)"}}>
                            <div className="h-full rounded-full" style={{width:`${d.pct}%`,background:di===0?"#34d399":di===1?"#3b82f6":"#475569"}}/>
                          </div>
                          <span className="text-[8px] text-zinc-700">{d.pct}%</span>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>

              {/* Common + Hot + Cold digits */}
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-xl p-3" style={{background:"rgba(16,185,129,0.07)",border:"1px solid rgba(16,185,129,0.2)"}}>
                  <div className="text-[10px] font-bold text-emerald-500 mb-2 uppercase">⭐ সবচেয়ে কমন</div>
                  <div className="flex flex-wrap gap-1.5">
                    {a6.commonDigits.map(cd=>(
                      <div key={cd.d} className="flex flex-col items-center rounded-lg px-2 py-1" style={{background:"rgba(16,185,129,0.12)"}}>
                        <span className="font-mono font-black text-lg text-emerald-300">{cd.d}</span>
                        <span className="text-[8px] text-emerald-700">{cd.pct}%</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="rounded-xl p-3" style={{background:"rgba(251,191,36,0.07)",border:"1px solid rgba(251,191,36,0.2)"}}>
                  <div className="text-[10px] font-bold text-yellow-500 mb-2 uppercase">🔥 সাম্প্রতিক গরম</div>
                  <div className="flex flex-wrap gap-1.5">
                    {a6.hotTop5.map(h=>(
                      <div key={h.d} className="flex flex-col items-center rounded-lg px-2 py-1" style={{background:"rgba(251,191,36,0.12)"}}>
                        <span className="font-mono font-black text-lg text-yellow-300">{h.d}</span>
                        <span className="text-[8px] text-yellow-700">{h.count}×</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="rounded-xl p-3" style={{background:"rgba(99,102,241,0.07)",border:"1px solid rgba(99,102,241,0.2)"}}>
                  <div className="text-[10px] font-bold text-indigo-400 mb-2 uppercase">❄️ ঠান্ডা / বাকি</div>
                  <div className="flex flex-wrap gap-1.5">
                    {a6.coldDigs.map(d=>(
                      <div key={d} className="flex flex-col items-center rounded-lg px-2 py-1" style={{background:"rgba(99,102,241,0.12)"}}>
                        <span className="font-mono font-black text-lg text-indigo-300">{d}</span>
                        <span className="text-[8px] text-indigo-700">কম দেখা</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Top Pairs & Triplets */}
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl p-3" style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)"}}>
                  <div className="text-[10px] font-bold text-zinc-400 mb-2 uppercase">🔢 জনপ্রিয় ২ ডিজিট জোড়া</div>
                  {a6.topPairs6.slice(0,5).map((p,i)=>(
                    <div key={p.pair} className="flex items-center justify-between py-1" style={{borderTop:i>0?"1px solid rgba(255,255,255,0.04)":"none"}}>
                      <span className="font-mono font-black text-base text-white">{p.pair}</span>
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 rounded-full" style={{width:`${Math.round((p.count/a6.topPairs6[0].count)*60)}px`,background:"rgba(16,185,129,0.6)"}}/>
                        <span className="text-[10px] text-emerald-600 font-bold">{p.count}×</span>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="rounded-xl p-3" style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)"}}>
                  <div className="text-[10px] font-bold text-zinc-400 mb-2 uppercase">🔗 জনপ্রিয় ৩ ডিজিট ক্রম</div>
                  {a6.topTrips6.slice(0,5).map((t,i)=>(
                    <div key={t.trip} className="flex items-center justify-between py-1" style={{borderTop:i>0?"1px solid rgba(255,255,255,0.04)":"none"}}>
                      <span className="font-mono font-black text-base text-white">{t.trip}</span>
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 rounded-full" style={{width:`${Math.round((t.count/a6.topTrips6[0].count)*60)}px`,background:"rgba(99,102,241,0.6)"}}/>
                        <span className="text-[10px] text-indigo-500 font-bold">{t.count}×</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}
        </div>
        );
      })()}

      {analysis && pipeline && <>

        {/* ══ FOLDER: মডেল বিশ্লেষণ (3-Stage Pipeline) ══ */}
        <div className="rounded-2xl overflow-hidden" style={{border:`1px solid ${openFolders.has("m_pipeline")?"rgba(220,38,38,0.4)":"rgba(255,255,255,0.08)"}`}}>
          <button
            onClick={()=>toggleFolder("m_pipeline")}
            className="w-full px-5 py-4 flex items-center justify-between text-left transition-all"
            style={{background:openFolders.has("m_pipeline")?"rgba(220,38,38,0.08)":"rgba(255,255,255,0.02)"}}
          >
            <div className="flex items-center gap-3">
              <span className="text-xl">🔬</span>
              <div>
                <div className="text-white font-black text-sm">মডেল বিশ্লেষণ (3-Stage Pipeline)</div>
                <div className="text-zinc-600 text-xs">১১টি মডেল → Threshold Filter → Borda Count · {analysis.drawCount} draws</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] px-2 py-0.5 rounded-full font-bold" style={{background:"rgba(220,38,38,0.15)",color:"#f87171"}}>Stage 1→2→3</span>
              <span className="text-zinc-500 text-sm font-bold" style={{transform:openFolders.has("m_pipeline")?"rotate(180deg)":"none",transition:"transform 0.2s"}}>▼</span>
            </div>
          </button>
          {openFolders.has("m_pipeline") && <div style={{borderTop:"1px solid rgba(220,38,38,0.2)"}}>
          <div className="rounded-2xl overflow-hidden" style={{background:"linear-gradient(135deg,rgba(5,5,15,0.98),rgba(10,10,20,0.98))"}}>

          {/* ── Pipeline inner header ── */}
          <div className="px-5 py-3" style={{background:"linear-gradient(90deg,rgba(220,38,38,0.08),rgba(124,58,237,0.06))"}}>
            <div className="flex items-center gap-2">
              <div className="hidden sm:flex items-center gap-1.5">
                {["Stage 1","→","Stage 2","→","Stage 3"].map((s,i)=>(
                  <span key={i} className={`text-[10px] font-black px-2 py-0.5 rounded-full ${s==="→"?"text-zinc-700":s==="Stage 3"?"text-yellow-400":"text-zinc-400"}`}
                    style={s!=="→"?{background:"rgba(255,255,255,0.06)",border:"1px solid rgba(255,255,255,0.1)"}:{}}>{s}</span>
                ))}
              </div>
            </div>
          </div>

          <div className="p-5 space-y-6">

            {/* ╔══════════════════════════════════════════════════════════╗
                ║  STAGE 1 — Data Collection & Frequency Matrix            ║
                ╚══════════════════════════════════════════════════════════╝ */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-[10px] font-black px-2.5 py-1 rounded-full" style={{background:"rgba(59,130,246,0.2)",color:"#60a5fa",border:"1px solid rgba(59,130,246,0.35)"}}>STAGE 1</span>
                <span className="text-white font-bold text-sm">ডেটা সংগ্রহ ও Frequency Matrix</span>
                <span className="text-zinc-700 text-xs">— {pipeline.stage1.length}টি unique number পাওয়া গেছে</span>
              </div>
              <div className="rounded-xl overflow-hidden" style={{border:"1px solid rgba(255,255,255,0.07)"}}>
                {/* Table header */}
                <div className="grid text-[10px] font-black uppercase tracking-widest px-3 py-2" style={{gridTemplateColumns:"2rem 5rem 1fr 4rem 4rem",background:"rgba(59,130,246,0.08)",color:"rgba(255,255,255,0.3)"}}>
                  <span>#</span><span>Number</span><span>Models</span><span className="text-center">Weight</span><span className="text-center">Count</span>
                </div>
                {pipeline.stage1.map((entry,i)=>{
                  const maxW = pipeline.stage1[0]?.totalWeight ?? 1;
                  const barPct = Math.round((entry.totalWeight/maxW)*100);
                  const survived = pipeline.stage2Survived.some(e=>e.num===entry.num);
                  return (
                    <div key={entry.num} className="grid items-center px-3 py-2 text-xs" style={{gridTemplateColumns:"2rem 5rem 1fr 4rem 4rem",borderTop:i>0?"1px solid rgba(255,255,255,0.04)":"none",background:survived?"rgba(59,130,246,0.04)":"transparent",opacity:survived?1:0.4}}>
                      <span className="text-zinc-700 text-[10px]">{i+1}</span>
                      <span className="font-mono font-black text-base" style={{color:survived?"#93c5fd":"#52525b"}}>{entry.num}</span>
                      <div className="flex flex-col gap-0.5">
                        <div className="flex flex-wrap gap-1">
                          {entry.models.map(m=>(
                            <span key={m.key} className="text-[10px] px-1 rounded" style={{background:"rgba(255,255,255,0.06)",color:"#a1a1aa"}}>{m.icon} {m.label.split(" ")[0]}</span>
                          ))}
                        </div>
                        <div className="h-1 rounded-full overflow-hidden" style={{background:"rgba(255,255,255,0.06)"}}>
                          <div className="h-full rounded-full" style={{width:`${barPct}%`,background:survived?"#3b82f6":"#52525b"}}/>
                        </div>
                      </div>
                      <span className="text-center font-bold" style={{color:survived?"#93c5fd":"#52525b"}}>{entry.totalWeight}</span>
                      <span className="text-center text-zinc-500">{entry.modelCount}/11</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="h-px" style={{background:"rgba(255,255,255,0.05)"}}/>

            {/* ╔══════════════════════════════════════════════════════════╗
                ║  STAGE 2 — Probability Filtering & Elimination           ║
                ╚══════════════════════════════════════════════════════════╝ */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-[10px] font-black px-2.5 py-1 rounded-full" style={{background:"rgba(234,179,8,0.2)",color:"#fbbf24",border:"1px solid rgba(234,179,8,0.35)"}}>STAGE 2</span>
                <span className="text-white font-bold text-sm">Threshold Filtering</span>
                <span className="text-zinc-700 text-xs">— নিয়ম: ≥{pipeline.threshold.minModels} মডেলে আসতে হবে বা weight ≥{pipeline.threshold.minWeight}</span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {/* Survived */}
                <div className="rounded-xl p-3 space-y-2" style={{background:"rgba(34,197,94,0.06)",border:"1px solid rgba(34,197,94,0.2)"}}>
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className="text-green-400 text-sm">✅</span>
                    <span className="text-green-400 font-bold text-xs">টিকে গেছে ({pipeline.stage2Survived.length}টি)</span>
                  </div>
                  {pipeline.stage2Survived.map(e=>(
                    <div key={e.num} className="flex items-center gap-2">
                      <span className="font-mono font-black text-sm" style={{color:"#86efac"}}>{e.num}</span>
                      <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{background:"rgba(255,255,255,0.06)"}}>
                        <div className="h-full rounded-full bg-emerald-500" style={{width:`${Math.round(e.totalWeight/((pipeline.stage1[0]?.totalWeight??1))*100)}%`}}/>
                      </div>
                      <span className="text-zinc-600 text-[10px]">{e.modelCount}m</span>
                    </div>
                  ))}
                  {pipeline.stage2Survived.length===0&&<div className="text-zinc-700 text-xs">—</div>}
                </div>
                {/* Eliminated */}
                <div className="rounded-xl p-3 space-y-2" style={{background:"rgba(220,38,38,0.05)",border:"1px solid rgba(220,38,38,0.15)"}}>
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className="text-red-500 text-sm">❌</span>
                    <span className="text-red-400 font-bold text-xs">বাতিল ({pipeline.stage2Eliminated.length}টি)</span>
                  </div>
                  {pipeline.stage2Eliminated.map(e=>(
                    <div key={e.num} className="flex items-center gap-2 opacity-50">
                      <span className="font-mono text-sm line-through" style={{color:"#f87171"}}>{e.num}</span>
                      <span className="text-zinc-700 text-[10px]">{e.modelCount} model / w{e.totalWeight}</span>
                    </div>
                  ))}
                  {pipeline.stage2Eliminated.length===0&&<div className="text-zinc-700 text-xs">সব number qualify করেছে</div>}
                </div>
              </div>
            </div>

            <div className="h-px" style={{background:"rgba(255,255,255,0.05)"}}/>

            {/* ╔══════════════════════════════════════════════════════════╗
                ║  STAGE 3 — Borda Count Final Ranking (Result Sheet)      ║
                ╚══════════════════════════════════════════════════════════╝ */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-[10px] font-black px-2.5 py-1 rounded-full" style={{background:"rgba(234,179,8,0.2)",color:"#fde68a",border:"1px solid rgba(234,179,8,0.4)"}}>STAGE 3</span>
                <span className="text-white font-bold text-sm">Borda Count চূড়ান্ত র‌্যাংকিং</span>
                <span className="text-zinc-700 text-xs">— সর্বোচ্চ সম্ভাবনার number সবচেয়ে উপরে</span>
              </div>
              <div className="rounded-xl overflow-hidden" style={{border:"1px solid rgba(234,179,8,0.2)"}}>
                {/* Table header */}
                <div className="grid text-[10px] font-black uppercase tracking-widest px-3 py-2" style={{gridTemplateColumns:"2.5rem 5rem 1fr 4.5rem 3.5rem",background:"rgba(234,179,8,0.08)",color:"rgba(255,255,255,0.3)"}}>
                  <span>Rank</span><span>Number</span><span>Model Agreement</span><span className="text-center">Borda</span><span className="text-center">Prob</span>
                </div>
                {pipeline.stage3.map((e,i)=>{
                  const medals=["🥇","🥈","🥉"];
                  const probColors: Record<string,string> = { HIGH:"#4ade80", MED:"#fbbf24", LOW:"#f87171" };
                  const probBg: Record<string,string> = { HIGH:"rgba(34,197,94,0.15)", MED:"rgba(234,179,8,0.15)", LOW:"rgba(220,38,38,0.12)" };
                  const numColor = i===0?"#fde68a":i===1?"#e2e8f0":i===2?"#fdba74":"#94a3b8";
                  return (
                    <div key={e.num} className="grid items-center px-3 py-3 text-xs" style={{gridTemplateColumns:"2.5rem 5rem 1fr 4.5rem 3.5rem",borderTop:i>0?"1px solid rgba(255,255,255,0.04)":"none",background:i===0?"rgba(234,179,8,0.06)":i%2===0?"transparent":"rgba(255,255,255,0.01)"}}>
                      <span className="text-base">{medals[i]??<span className="text-zinc-600 font-bold">#{i+1}</span>}</span>
                      <span className="font-mono font-black text-xl tracking-widest" style={{color:numColor}}>{e.num}</span>
                      <div className="flex flex-col gap-1 pr-2">
                        <div className="flex flex-wrap gap-0.5">
                          {e.models.map(m=>(
                            <span key={m.key} title={m.label} className="text-base leading-none">{m.icon}</span>
                          ))}
                          {e.models.length===0&&<span className="text-zinc-700 text-[10px]">single model</span>}
                        </div>
                        <div className="h-1.5 rounded-full overflow-hidden" style={{background:"rgba(255,255,255,0.06)"}}>
                          <div className="h-full rounded-full" style={{width:`${e.bordaPct}%`,background:i===0?"#eab308":i===1?"#94a3b8":i===2?"#cd7c2f":"#4b5563"}}/>
                        </div>
                        <div className="text-zinc-700 text-[9px]">{e.bordaPct}% agreement</div>
                      </div>
                      <span className="text-center font-bold text-[11px]" style={{color:numColor}}>{e.bordaScore}</span>
                      <div className="flex justify-center">
                        <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full" style={{background:probBg[e.probLabel],color:probColors[e.probLabel]}}>{e.probLabel}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="h-px" style={{background:"rgba(255,255,255,0.05)"}}/>

            {/* ── Final Output Sets (Stage 3 থেকে derive করা) ── */}
            <div className="space-y-4">
              <p className="text-zinc-600 text-[11px] font-bold uppercase tracking-widest">🏆 চূড়ান্ত আউটপুট সেট — Stage 3 থেকে</p>

              {/* 4D: 5 sets */}
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[11px] font-black uppercase tracking-widest text-red-600">▶ ৪-ডিজিট</span>
                  <span className="text-zinc-700 text-[10px]">৫টি unique সেট</span>
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {pipeline.final4.map((n,i)=>{
                    const styles4=[
                      {bg:"linear-gradient(135deg,rgba(220,38,38,0.3),rgba(180,20,20,0.2))",border:"rgba(220,38,38,0.6)",color:"#fca5a5",glow:"0 4px 24px rgba(220,38,38,0.3)"},
                      {bg:"linear-gradient(135deg,rgba(234,179,8,0.2),rgba(180,120,0,0.12))",border:"rgba(234,179,8,0.4)",color:"#fde68a",glow:"0 4px 16px rgba(234,179,8,0.15)"},
                      {bg:"linear-gradient(135deg,rgba(124,58,237,0.2),rgba(80,30,180,0.12))",border:"rgba(124,58,237,0.35)",color:"#c4b5fd",glow:"none"},
                      {bg:"rgba(34,197,94,0.1)",border:"rgba(34,197,94,0.3)",color:"#86efac",glow:"none"},
                      {bg:"rgba(255,255,255,0.04)",border:"rgba(255,255,255,0.1)",color:"#a1a1aa",glow:"none"},
                    ];
                    const s=styles4[i]??styles4[4];
                    return (
                      <div key={i} className="rounded-xl py-3 px-1 text-center relative" style={{background:s.bg,border:`1px solid ${s.border}`,boxShadow:s.glow}}>
                        {i===0&&<div className="absolute -top-1.5 left-1/2 -translate-x-1/2 text-xs">🥇</div>}
                        <div className="text-[9px] font-black uppercase tracking-widest mb-1.5" style={{color:`${s.color}80`}}>সেট {i+1}</div>
                        <div className="font-mono font-black text-xl tracking-widest" style={{color:s.color}}>{n}</div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="h-px" style={{background:"rgba(255,255,255,0.04)"}}/>

              {/* 3D: 5 sets */}
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[11px] font-black uppercase tracking-widest text-orange-600">▶ ৩-ডিজিট</span>
                  <span className="text-zinc-700 text-[10px]">৫টি unique সেট</span>
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {pipeline.final3.map((n,i)=>{
                    const styles3=[
                      {bg:"linear-gradient(135deg,rgba(234,88,12,0.25),rgba(180,60,0,0.15))",border:"rgba(234,88,12,0.5)",color:"#fdba74"},
                      {bg:"rgba(234,88,12,0.1)",border:"rgba(234,88,12,0.25)",color:"#fb923c"},
                      {bg:"rgba(234,88,12,0.07)",border:"rgba(234,88,12,0.18)",color:"#f97316"},
                      {bg:"rgba(255,255,255,0.04)",border:"rgba(255,255,255,0.08)",color:"#a1a1aa"},
                      {bg:"rgba(255,255,255,0.03)",border:"rgba(255,255,255,0.06)",color:"#71717a"},
                    ];
                    const s=styles3[i]??styles3[4];
                    return (
                      <div key={i} className="rounded-xl py-3 px-1 text-center" style={{background:s.bg,border:`1px solid ${s.border}`}}>
                        <div className="text-[9px] font-black uppercase tracking-widest mb-1.5" style={{color:`${s.color}70`}}>সেট {i+1}</div>
                        <div className="font-mono font-black text-xl tracking-widest" style={{color:s.color}}>{n}</div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="h-px" style={{background:"rgba(255,255,255,0.04)"}}/>

              {/* 2D: 5 sets */}
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[11px] font-black uppercase tracking-widest text-purple-500">▶ ২-ডিজিট</span>
                  <span className="text-zinc-700 text-[10px]">৫টি unique সেট</span>
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {pipeline.final2.map((n,i)=>{
                    const styles2=[
                      {bg:"linear-gradient(135deg,rgba(124,58,237,0.25),rgba(80,20,200,0.15))",border:"rgba(124,58,237,0.5)",color:"#c4b5fd"},
                      {bg:"rgba(124,58,237,0.12)",border:"rgba(124,58,237,0.25)",color:"#a78bfa"},
                      {bg:"rgba(124,58,237,0.08)",border:"rgba(124,58,237,0.18)",color:"#8b5cf6"},
                      {bg:"rgba(255,255,255,0.04)",border:"rgba(255,255,255,0.08)",color:"#a1a1aa"},
                      {bg:"rgba(255,255,255,0.03)",border:"rgba(255,255,255,0.06)",color:"#71717a"},
                    ];
                    const s=styles2[i]??styles2[4];
                    return (
                      <div key={i} className="rounded-xl py-3 px-1 text-center" style={{background:s.bg,border:`1px solid ${s.border}`}}>
                        <div className="text-[9px] font-black uppercase tracking-widest mb-1.5" style={{color:`${s.color}70`}}>সেট {i+1}</div>
                        <div className="font-mono font-black text-2xl tracking-widest" style={{color:s.color}}>{n}</div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="h-px" style={{background:"rgba(255,255,255,0.04)"}}/>

              {/* 1D: 5 sets */}
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[11px] font-black uppercase tracking-widest text-green-600">▶ ১-ডিজিট</span>
                  <span className="text-zinc-700 text-[10px]">৫টি unique সেট</span>
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {pipeline.final1.map((d,i)=>(
                    <div key={i} className="rounded-xl py-3 px-1 text-center" style={{
                      background: i===0?"linear-gradient(135deg,#15803d,#166534)":"rgba(255,255,255,0.04)",
                      border:`1px solid ${i===0?"rgba(34,197,94,0.5)":"rgba(255,255,255,0.08)"}`,
                      boxShadow: i===0?"0 4px 20px rgba(34,197,94,0.2)":"none",
                    }}>
                      <div className="text-[9px] font-black uppercase tracking-widest mb-1" style={{color:i===0?"rgba(134,239,172,0.6)":"rgba(255,255,255,0.2)"}}>সেট {i+1}</div>
                      <div className="font-mono font-black text-3xl text-white">{d}</div>
                      {i===0&&<div className="text-[10px] text-green-300 mt-0.5">{analysis.ultimateConf}%</div>}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* ── Per-method fold-out table ── */}
            <details className="group">
              <summary className="cursor-pointer flex items-center gap-2 text-zinc-600 hover:text-zinc-400 text-xs font-bold select-none list-none">
                <span className="group-open:rotate-90 transition-transform inline-block">▶</span>
                প্রতিটি model-এর আলাদা result দেখুন ({pipeline.methodBoard.length}টি model)
              </summary>
              <div className="mt-3 rounded-xl overflow-hidden" style={{border:"1px solid rgba(255,255,255,0.06)"}}>
                <div className="grid grid-cols-5 text-[10px] font-black uppercase tracking-widest px-3 py-2" style={{background:"rgba(255,255,255,0.04)",color:"rgba(255,255,255,0.3)"}}>
                  <span>Model</span><span className="text-center">4D</span><span className="text-center">3D</span><span className="text-center">2D</span><span className="text-center">1D</span>
                </div>
                {pipeline.methodBoard.map((m,i)=>(
                  <div key={m.key} className="grid grid-cols-5 items-center px-3 py-2 text-xs" style={{borderTop:i>0?"1px solid rgba(255,255,255,0.04)":"none",background:i%2===0?"transparent":"rgba(255,255,255,0.01)"}}>
                    <span className="text-zinc-500 truncate">{m.icon} {m.label}</span>
                    <span className="font-mono font-black text-center" style={{color:"#fca5a5"}}>{m.pred}</span>
                    <span className="font-mono font-bold text-center" style={{color:"#fdba74"}}>{m.pair3}</span>
                    <span className="font-mono font-bold text-center" style={{color:"#c4b5fd"}}>{m.pair2}</span>
                    <span className="font-mono font-bold text-center" style={{color:"#86efac"}}>{m.digit}</span>
                  </div>
                ))}
              </div>
            </details>

          </div>
          </div>
          </div>}
        </div>

        {/* ══ FOLDER: চূড়ান্ত ফলাফল ══ */}
        <div className="rounded-2xl overflow-hidden" style={{border:`1px solid ${openFolders.has("m_results")?"rgba(234,179,8,0.4)":"rgba(255,255,255,0.08)"}`}}>
          <button
            onClick={()=>toggleFolder("m_results")}
            className="w-full px-5 py-4 flex items-center justify-between text-left transition-all"
            style={{background:openFolders.has("m_results")?"rgba(234,179,8,0.07)":"rgba(255,255,255,0.02)"}}
          >
            <div className="flex items-center gap-3">
              <span className="text-xl">🏆</span>
              <div>
                <div className="text-white font-black text-sm">চূড়ান্ত ফলাফল ও বিশ্লেষণ</div>
                <div className="text-zinc-600 text-xs">
                  {analysis.top6.length > 0
                    ? `TOP 6: ${analysis.top6.slice(0,3).map(c=>c.num).join(" · ")} — HIT: ${analysis.hitNum} · HOT: ${analysis.hotNum}`
                    : "TOP 6 · HIT/HOT · High/Low · Triplet · বাদের ডিজিট"}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {!openFolders.has("m_results") && analysis.top6[0] && (
                <span className="font-mono font-black text-base px-3 py-1 rounded-xl" style={{background:"rgba(234,179,8,0.18)",color:"#fde68a"}}>{analysis.top6[0].num}</span>
              )}
              <span className="text-zinc-500 text-sm font-bold" style={{transform:openFolders.has("m_results")?"rotate(180deg)":"none",transition:"transform 0.2s"}}>▼</span>
            </div>
          </button>
          {openFolders.has("m_results") && <div className="p-4 space-y-4" style={{borderTop:"1px solid rgba(234,179,8,0.2)"}}>

        {/* ══ TOP 6 CANDIDATES ══ */}
        {analysis.top6.length > 1 && (
          <div className="rounded-2xl p-5" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.06)"}}>
            <p className="text-white font-black text-sm mb-1">🏆 সম্পূর্ণ ৬টি সম্ভাব্য ৪-ডিজিট</p>
            <p className="text-zinc-700 text-xs mb-4">আপনার ইতিহাসের ওপর ভিত্তি করে র‌্যাংক করা</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {analysis.top6.map((c,i)=>{
                const medals=["🥇","🥈","🥉","④","⑤","⑥"];
                const gs=[
                  "linear-gradient(135deg,rgba(217,119,6,0.25),rgba(146,64,14,0.15))",
                  "linear-gradient(135deg,rgba(71,85,105,0.25),rgba(30,41,59,0.15))",
                  "linear-gradient(135deg,rgba(146,64,14,0.2),rgba(120,53,15,0.1))",
                  "rgba(255,255,255,0.03)","rgba(255,255,255,0.03)","rgba(255,255,255,0.03)"
                ];
                const bc=["rgba(234,179,8,0.35)","rgba(148,163,184,0.2)","rgba(180,83,9,0.25)","rgba(255,255,255,0.06)","rgba(255,255,255,0.06)","rgba(255,255,255,0.06)"];
                return (
                  <div key={c.num} className="rounded-xl p-4 text-center relative" style={{background:gs[i],border:`1px solid ${bc[i]}`}}>
                    <div className="absolute top-2 left-2 text-sm">{medals[i]}</div>
                    <div className="font-mono font-black text-3xl text-white tracking-widest mt-1 mb-1">{c.num}</div>
                    <div className="h-1.5 rounded-full overflow-hidden mb-1.5" style={{background:"rgba(255,255,255,0.06)"}}>
                      <div className="h-full rounded-full" style={{width:`${Math.max(c.pct,3)}%`,background:i===0?"#eab308":i===1?"#94a3b8":i===2?"#cd7c2f":"#4b5563"}}/>
                    </div>
                    <div className="text-xs font-bold" style={{color:i===0?"#eab308":i<3?"#94a3b8":"#6b7280"}}>{c.pct}%</div>
                    <div className="text-zinc-800 text-[10px]">{c.models.length} মডেল</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ══ HIT / HOT / POWERFUL / COMMON ══ */}
        <div className="grid grid-cols-2 gap-3">
          {([
            {icon:"🎯",label:"HIT NUMBER",  num:analysis.hitNum,       desc:"১১ মডেলের সর্বোচ্চ মিল",  bg:"linear-gradient(135deg,rgba(234,179,8,0.18),rgba(217,119,6,0.08))",   border:"rgba(234,179,8,0.35)",   color:"#fde68a"},
            {icon:"🔥",label:"HOT NUMBER",  num:analysis.hotNum,       desc:"৫০ ড্রে সবচেয়ে বেশিবার আসা",bg:"linear-gradient(135deg,rgba(239,68,68,0.18),rgba(220,38,38,0.08))",border:"rgba(239,68,68,0.35)",   color:"#fca5a5"},
            {icon:"⚡",label:"POWERFUL",    num:analysis.powerfulNum,  desc:"৩D Triplet সিকোয়েন্স",   bg:"linear-gradient(135deg,rgba(16,185,129,0.18),rgba(5,150,105,0.08))",  border:"rgba(16,185,129,0.35)",  color:"#6ee7b7"},
            {icon:"🔗",label:"COMMON",      num:analysis.commonNum,    desc:"Markov চেইন পূর্বাভাস",   bg:"linear-gradient(135deg,rgba(124,58,237,0.18),rgba(109,40,217,0.08))", border:"rgba(124,58,237,0.35)",  color:"#c4b5fd"},
          ] as {icon:string;label:string;num:string;desc:string;bg:string;border:string;color:string}[]).map(card=>(
            <div key={card.label} className="rounded-2xl p-4" style={{background:card.bg,border:`1px solid ${card.border}`}}>
              <div className="flex items-center gap-1.5 mb-2">
                <span className="text-base">{card.icon}</span>
                <span className="text-[10px] font-black tracking-widest" style={{color:card.color}}>{card.label}</span>
              </div>
              <div className="font-mono font-black text-3xl text-white tracking-widest mb-1">{card.num}</div>
              <div className="text-[11px]" style={{color:`${card.color}90`}}>{card.desc}</div>
            </div>
          ))}
        </div>

        {/* ══ HIGH/LOW + ODD/EVEN BARS ══ */}
        <div className="rounded-2xl p-4 space-y-3" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.07)"}}>
          <p className="text-zinc-500 text-[11px] font-bold uppercase tracking-widest">📊 ডিজিট বিতরণ — গত ৩০ ড্র</p>
          <div>
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-blue-400 font-bold">🔵 High (5–9): {analysis.highPct}%</span>
              <span className="text-orange-400 font-bold">🟠 Low (0–4): {100-analysis.highPct}%</span>
            </div>
            <div className="h-3 rounded-full overflow-hidden" style={{background:"rgba(255,255,255,0.06)"}}>
              <div className="h-full rounded-full" style={{width:`${analysis.highPct}%`,background:"linear-gradient(90deg,#3b82f6,#60a5fa)"}}/>
            </div>
          </div>
          <div>
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-purple-400 font-bold">🟣 Odd: {analysis.oddPct}%</span>
              <span className="text-green-400 font-bold">🟢 Even: {100-analysis.oddPct}%</span>
            </div>
            <div className="h-3 rounded-full overflow-hidden" style={{background:"rgba(255,255,255,0.06)"}}>
              <div className="h-full rounded-full" style={{width:`${analysis.oddPct}%`,background:"linear-gradient(90deg,#7c3aed,#a78bfa)"}}/>
            </div>
          </div>
        </div>

        {/* ══ SPECIAL EVEN / ODD BOXES ══ */}
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-2xl p-5 text-center" style={{background:"linear-gradient(135deg,rgba(16,185,129,0.15),rgba(5,150,105,0.06))",border:"1px solid rgba(16,185,129,0.35)"}}>
            <div className="text-emerald-400 font-black text-[10px] tracking-widest mb-3">🟢 EVEN NUMBER SET</div>
            <div className="font-mono font-black text-4xl text-white tracking-[0.2em] mb-2">{analysis.evenBox}</div>
            <div className="text-emerald-900 text-xs">জোড় ডিজিট প্যাটার্ন</div>
          </div>
          <div className="rounded-2xl p-5 text-center" style={{background:"linear-gradient(135deg,rgba(124,58,237,0.15),rgba(109,40,217,0.06))",border:"1px solid rgba(124,58,237,0.35)"}}>
            <div className="text-purple-400 font-black text-[10px] tracking-widest mb-3">🟣 ODD NUMBER SET</div>
            <div className="font-mono font-black text-4xl text-white tracking-[0.2em] mb-2">{analysis.oddBox}</div>
            <div className="text-purple-900 text-xs">বিজোড় ডিজিট প্যাটার্ন</div>
          </div>
        </div>

        {/* ══ TOP 4 TRIPLET SEQUENCES ══ */}
        {analysis.topTrips4.length > 0 && (
          <div className="rounded-2xl p-4" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.07)"}}>
            <p className="text-zinc-500 text-[11px] font-bold uppercase tracking-widest mb-3">🔷 শীর্ষ ৩D Triplet Sequence — গত ৫০ ড্র</p>
            <div className="grid grid-cols-2 gap-2">
              {analysis.topTrips4.map((t,i)=>(
                <div key={t.seq} className="rounded-xl p-3 flex items-center gap-3" style={{background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.08)"}}>
                  <span className="text-zinc-600 text-xs font-bold">#{i+1}</span>
                  <span className="font-mono font-black text-2xl text-white tracking-widest">{t.seq}</span>
                  <span className="ml-auto text-emerald-500 font-bold text-sm">{t.count}x</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══ AVOID (cut digits) ══ */}
        <div className="rounded-2xl p-4 flex items-center gap-4 flex-wrap" style={{background:"rgba(220,38,38,0.06)",border:"1px solid rgba(220,38,38,0.2)"}}>
          <span className="text-red-400 text-lg">✂️</span>
          <div className="flex-1 min-w-0">
            <p className="text-red-300 font-bold text-sm">বাদ দেওয়া ডিজিট (Drop)</p>
            <p className="text-zinc-700 text-xs">এই ডিজিটগুলো সবচেয়ে কম সম্ভাবনার — বাদ দিন</p>
          </div>
          <div className="flex gap-2">
            {analysis.cutDigits.map((cd,i)=>(
              <div key={cd.digit} className="rounded-xl w-12 h-12 flex flex-col items-center justify-center" style={{background:"rgba(220,38,38,0.15)",border:"1px solid rgba(220,38,38,0.3)"}}>
                <span className="font-mono font-black text-2xl text-red-400">{cd.digit}</span>
                <span className="text-red-800 text-[9px]">{cd.conf}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* ══ ANALYSIS FOLDERS ══ */}
        {(() => {
          const groups: {key:string; label:string; icon:string; color:string; border:string}[] = [
            {key:"Deep Learning",  label:"Deep Learning মডেল",    icon:"🧠", color:"rgba(124,58,237,0.12)", border:"rgba(124,58,237,0.35)"},
            {key:"Statistics",     label:"Statistics মডেল",       icon:"📊", color:"rgba(59,130,246,0.10)", border:"rgba(59,130,246,0.30)"},
            {key:"Math Filters",   label:"Math Filter মডেল",      icon:"➗", color:"rgba(234,179,8,0.10)",  border:"rgba(234,179,8,0.30)"},
            {key:"Behavior",       label:"Behavior মডেল",         icon:"📅", color:"rgba(16,185,129,0.10)", border:"rgba(16,185,129,0.30)"},
          ];
          return (
            <div className="space-y-2">
              <p className="text-zinc-600 text-[11px] font-bold uppercase tracking-widest">📁 বিশ্লেষণ ফোল্ডার — ক্লিক করলে খুলবে</p>
              {groups.map(g => {
                const models = analysis.mPreds.filter(m => MODEL_INFO[m.key].group === g.key);
                const isOpen = openFolders.has(g.key);
                return (
                  <div key={g.key} className="rounded-xl overflow-hidden" style={{border:`1px solid ${g.border}`}}>
                    {/* Folder Header */}
                    <button
                      onClick={() => toggleFolder(g.key)}
                      className="w-full flex items-center gap-3 px-4 py-3 text-left transition-all"
                      style={{background: isOpen ? g.color : "rgba(255,255,255,0.02)"}}>
                      <span className="text-lg">{g.icon}</span>
                      <div className="flex-1">
                        <span className="text-white font-bold text-sm">{g.label}</span>
                        <span className="text-zinc-600 text-xs ml-2">({models.length}টি পদ্ধতি)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex gap-1">
                          {models.map(m => (
                            <span key={m.key} className="font-mono text-xs font-black px-2 py-0.5 rounded-lg text-white" style={{background:"rgba(255,255,255,0.1)"}}>{m.pred}</span>
                          ))}
                        </div>
                        <span className="text-zinc-500 text-xs ml-1">{isOpen ? "▲" : "▼"}</span>
                      </div>
                    </button>
                    {/* Folder Content */}
                    {isOpen && (
                      <div className="px-4 pb-4 pt-2 space-y-2" style={{background: g.color}}>
                        {models.map(m => {
                          const info = MODEL_INFO[m.key];
                          const w = info.defaultW;
                          return (
                            <div key={m.key} className="rounded-xl p-3 flex items-center gap-3" style={{background:"rgba(0,0,0,0.25)",border:"1px solid rgba(255,255,255,0.06)"}}>
                              <span className="text-xl">{info.icon}</span>
                              <div className="flex-1 min-w-0">
                                <div className="text-white text-xs font-bold">{info.label}</div>
                                <div className="flex items-center gap-2 mt-1">
                                  <div className="h-1.5 rounded-full flex-1 overflow-hidden" style={{background:"rgba(255,255,255,0.08)"}}>
                                    <div className="h-full rounded-full" style={{width:`${w}%`,background:g.border.replace("0.3","0.8").replace("0.35","0.8")}}/>
                                  </div>
                                  <span className="text-zinc-600 text-[10px] w-8 text-right">w:{w}</span>
                                </div>
                              </div>
                              <div className="rounded-xl px-4 py-2 text-center" style={{background:"rgba(0,0,0,0.3)",border:`1px solid ${g.border}`}}>
                                <div className="font-mono font-black text-2xl text-white tracking-widest">{m.pred}</div>
                                <div className="text-[10px] mt-0.5" style={{color:g.border.replace("0.3","1").replace("0.35","1")}}>পূর্বাভাস</div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          );
        })()}

        {/* ══ ENGINE INFO ══ */}
        <div className="rounded-xl px-4 py-3 flex flex-wrap gap-x-5 gap-y-1 text-[11px] text-zinc-800" style={{background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.04)"}}>
          <span>⚡ ১১-মডেল BRD ইঞ্জিন</span>
          <span>📊 ৩০/৫০/৯০-ড্র window</span>
          <span>🔄 প্রতিটা নতুন ড্রে আপডেট</span>
          <span>🏢 {COMPANIES[company].name}</span>
          <span>📅 সর্বশেষ: {analysis.lastDate}</span>
        </div>
          </div>}
        </div>
      </>}

      {/* ══ FOLDER: সব বিশ্লেষণ পেজ (ToolGrid) ══ */}
      <div className="rounded-2xl overflow-hidden" style={{border:`1px solid ${openFolders.has("m_toolsgrid")?"rgba(16,185,129,0.4)":"rgba(255,255,255,0.08)"}`}}>
        <button
          onClick={()=>toggleFolder("m_toolsgrid")}
          className="w-full px-5 py-4 flex items-center justify-between text-left transition-all"
          style={{background:openFolders.has("m_toolsgrid")?"rgba(16,185,129,0.07)":"rgba(255,255,255,0.02)"}}
        >
          <div className="flex items-center gap-3">
            <span className="text-xl">⚡</span>
            <div>
              <div className="text-white font-black text-sm">সব বিশ্লেষণ পেজ</div>
              <div className="text-zinc-600 text-xs">২৪টি বিশ্লেষণ পেজ — ক্লিক করলেই সরাসরি যাবে</div>
            </div>
          </div>
          <span className="text-zinc-500 text-sm font-bold" style={{transform:openFolders.has("m_toolsgrid")?"rotate(180deg)":"none",transition:"transform 0.2s"}}>▼</span>
        </button>
        {openFolders.has("m_toolsgrid") && (
          <div className="px-5 pb-5 pt-2" style={{borderTop:"1px solid rgba(16,185,129,0.2)"}}>
            <ToolGrid onView={onView}/>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Top Section CSS (injected once) ──────────────────────────────────────────
const TOP_SECTION_CSS = `
  @keyframes timerGlow{0%,100%{opacity:1;text-shadow:0 0 18px rgba(251,191,36,0.7)}50%{opacity:.85;text-shadow:0 0 35px rgba(251,191,36,1)}}
  @keyframes timerGlowRed{0%,100%{opacity:1;text-shadow:0 0 18px rgba(239,68,68,0.8)}50%{opacity:.85;text-shadow:0 0 35px rgba(239,68,68,1)}}
  @keyframes dateGlowAnim{0%,100%{box-shadow:0 0 14px var(--dg,rgba(59,130,246,0.3))}50%{box-shadow:0 0 35px var(--dg,rgba(59,130,246,0.5)),0 0 60px var(--dg2,rgba(99,102,241,0.2))}}
  @keyframes mascotBob{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
  @keyframes armDown{0%,35%{transform:rotate(-15deg)}40%,60%{transform:rotate(55deg)}65%,100%{transform:rotate(-15deg)}}
  @keyframes armWave{0%,100%{transform:rotate(25deg)}50%{transform:rotate(-40deg)}}
  @keyframes eyeBlink{0%,88%,100%{transform:scaleY(1)}92%,96%{transform:scaleY(0.08)}}
  @keyframes arrowBounceDown{0%,100%{transform:translateY(0);opacity:.7}50%{transform:translateY(5px);opacity:1}}
  @keyframes arrowBounceUp{0%,100%{transform:translateY(0);opacity:.7}50%{transform:translateY(-5px);opacity:1}}
  @keyframes numLTR{0%{left:-90px;opacity:0}8%{opacity:1}92%{opacity:1}100%{left:calc(100% + 20px);opacity:0}}
  @keyframes numRTL{0%{left:calc(100% + 20px);opacity:0}8%{opacity:1}92%{opacity:1}100%{left:-90px;opacity:0}}
  @keyframes numHighPass{0%{left:-90px;top:15%;opacity:0;filter:brightness(2.5) drop-shadow(0 0 8px currentColor)}15%{opacity:1}50%{top:48%}85%{opacity:1}100%{left:calc(100% + 20px);top:82%;opacity:0}}
  @keyframes numHighPass2{0%{left:calc(100% + 20px);top:82%;opacity:0;filter:brightness(2.5) drop-shadow(0 0 8px currentColor)}15%{opacity:1}50%{top:48%}85%{opacity:1}100%{left:-90px;top:15%;opacity:0}}
  @keyframes luckyVibrate{0%,100%{transform:translateX(0) rotate(0)}8%{transform:translateX(-4px) rotate(-.4deg)}16%{transform:translateX(4px) rotate(.4deg)}24%{transform:translateX(-3px)}32%{transform:translateX(3px)}40%{transform:translateX(-2px)}48%{transform:translateX(2px)}56%{transform:translateX(-1px)}64%{transform:translateX(1px)}}
  .lucky-vibrate{animation:luckyVibrate .7s ease-in-out infinite!important}
  @keyframes drawBadgePulse{0%,100%{transform:scale(1)}50%{transform:scale(1.08)}}
`;

function useTopSectionCSS() {
  useEffect(()=>{
    const id='cbc-top-section-css';
    if(document.getElementById(id)) return;
    const el=document.createElement('style');
    el.id=id; el.textContent=TOP_SECTION_CSS;
    document.head.appendChild(el);
  },[]);
}

// ─── Draw Timer Box ────────────────────────────────────────────────────────────
function DrawTimerBox(){
  const [parts,setParts]=useState({hh:"00",mm:"00",ss:"00",ms:"00"});
  const [nextLabel,setNextLabel]=useState("");
  const [periodLabel,setPeriodLabel]=useState("");
  const [urgent,setUrgent]=useState(false);
  const [isDrawDay,setIsDrawDay]=useState(false);

  useEffect(()=>{
    function calc(){
      const now=new Date();
      const mytMs=now.getTime()+(now.getTimezoneOffset()+480)*60000;
      const myt=new Date(mytMs);
      const drawDays=[0,3,6];
      const H=19;
      let next:Date|null=null;
      for(let i=0;i<8;i++){
        const c=new Date(mytMs);
        c.setDate(c.getDate()+i);
        c.setHours(H,0,0,0);
        if(drawDays.includes(c.getDay())&&c.getTime()>mytMs){next=c;break;}
      }
      if(!next) return;
      const nd=next.getDay();
      const dayBn=['রবিবার','সোমবার','মঙ্গলবার','বুধবার','বৃহস্পতিবার','শুক্রবার','শনিবার'];
      const fromTo:Record<number,[string,string]>={0:["শনিবার","রবিবার"],3:["রবিবার","বুধবার"],6:["বুধবার","শনিবার"]};
      const [fr,to]=fromTo[nd]??["",""];
      setPeriodLabel(`${fr} → ${to} ড্র`);
      setNextLabel(`${dayBn[nd]} সন্ধ্যা ৭:০০`);
      setIsDrawDay(drawDays.includes(myt.getDay()));
      const diffMs=Math.max(0,next.getTime()-mytMs);
      const diffS=Math.floor(diffMs/1000);
      const hh=Math.floor(diffS/3600);
      const mm=Math.floor((diffS%3600)/60);
      const ss=diffS%60;
      const ms=Math.floor((diffMs%1000)/10);
      setParts({
        hh:String(hh).padStart(2,'0'),
        mm:String(mm).padStart(2,'0'),
        ss:String(ss).padStart(2,'0'),
        ms:String(ms).padStart(2,'0'),
      });
      setUrgent(diffS<3600);
    }
    calc();
    const t=setInterval(calc,50);
    return()=>clearInterval(t);
  },[]);

  const accent=urgent?"#ef4444":"#facc15";
  const accentRgb=urgent?"239,68,68":"251,191,36";
  const units=[
    {val:parts.hh,label:"ঘণ্টা"},
    {val:parts.mm,label:"মিনিট"},
    {val:parts.ss,label:"সেকেন্ড"},
    {val:parts.ms,label:"মি.সে."},
  ];

  return(
    <div className="rounded-2xl p-2.5 relative overflow-hidden flex flex-col gap-1.5" style={{
      background:`linear-gradient(145deg,rgba(10,10,20,0.97) 0%,rgba(20,10,40,0.95) 100%)`,
      border:`1px solid rgba(${accentRgb},0.35)`,
      boxShadow:`0 0 24px rgba(${accentRgb},0.12)`,
    }}>
      <div className="absolute inset-0 pointer-events-none" style={{background:`radial-gradient(ellipse at 50% 0%,rgba(${accentRgb},0.06) 0%,transparent 70%)`}}/>
      {/* Header */}
      <div className="relative flex items-center justify-between">
        <span className="text-[9px] font-black uppercase tracking-widest" style={{color:`rgba(${accentRgb},0.65)`}}>পরবর্তী ড্র</span>
        {isDrawDay&&(
          <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full" style={{
            background:`rgba(${accentRgb},0.15)`,color:accent,
            border:`1px solid rgba(${accentRgb},0.3)`,
            animation:"drawBadgePulse 1s ease-in-out infinite",
          }}>🎰 আজ!</span>
        )}
      </div>
      {/* 4 unit boxes */}
      <div className="relative grid grid-cols-4 gap-1">
        {units.map((u,i)=>(
          <div key={i} className="flex flex-col items-center rounded-xl py-1.5 px-1" style={{
            background:`rgba(${accentRgb},0.07)`,
            border:`1px solid rgba(${accentRgb},0.2)`,
          }}>
            <div className="font-mono font-black leading-none" style={{
              fontSize:19,
              color:accent,
              animation:`${urgent?"timerGlowRed":"timerGlow"} 1s ease-in-out infinite`,
              letterSpacing:"0.05em",
            }}>{u.val}</div>
            <div className="text-[8px] font-bold mt-0.5 uppercase tracking-wide" style={{color:`rgba(${accentRgb},0.5)`}}>{u.label}</div>
          </div>
        ))}
      </div>
      {/* Labels */}
      <div className="relative text-center space-y-0.5">
        <div className="font-bold text-[10px]" style={{color:accent}}>{periodLabel}</div>
        <div className="text-zinc-700 text-[9px]">{nextLabel}</div>
      </div>
    </div>
  );
}

// ─── Date Day Box ──────────────────────────────────────────────────────────────
function DateDayBox(){
  const [now,setNow]=useState(new Date());
  useEffect(()=>{const t=setInterval(()=>setNow(new Date()),30000);return()=>clearInterval(t);},[]);

  const dayBn=['রবিবার','সোমবার','মঙ্গলবার','বুধবার','বৃহস্পতিবার','শুক্রবার','শনিবার'];
  const monBn=['জানু','ফেব্রু','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টে','অক্টো','নভে','ডিসে'];
  function bn(n:number){return String(n).replace(/[0-9]/g,d=>'০১২৩৪৫৬৭৮৯'[+d]);}

  // day-based theme
  const themes:Record<number,[string,string,string,string]>={
    0:["#818cf8","#4338ca","rgba(99,102,241,0.18)","rgba(67,56,202,0.1)"],
    1:["#34d399","#065f46","rgba(16,185,129,0.18)","rgba(6,95,70,0.1)"],
    2:["#f472b6","#9d174d","rgba(236,72,153,0.18)","rgba(157,23,77,0.1)"],
    3:["#60a5fa","#1d4ed8","rgba(59,130,246,0.18)","rgba(29,78,216,0.1)"],
    4:["#fb923c","#9a3412","rgba(249,115,22,0.18)","rgba(154,52,18,0.1)"],
    5:["#a78bfa","#5b21b6","rgba(139,92,246,0.18)","rgba(91,33,182,0.1)"],
    6:["#fbbf24","#92400e","rgba(251,191,36,0.18)","rgba(146,64,14,0.1)"],
  };
  const [tc,gc,bc,bc2]=themes[now.getDay()];
  const drawDay=[0,3,6].includes(now.getDay());

  return(
    <div className="rounded-2xl p-4 relative overflow-hidden flex flex-col items-center justify-center text-center" style={{
      background:`linear-gradient(145deg,${bc} 0%,${bc2} 100%)`,
      border:`1.5px solid ${gc}55`,
      animation:"dateGlowAnim 3s ease-in-out infinite",
      ["--dg" as any]:`${gc}40`,
      ["--dg2" as any]:`${gc}20`,
      minHeight:102,
    }}>
      <div className="text-[10px] font-black uppercase tracking-widest mb-1" style={{color:`${tc}99`}}>আজকের তারিখ</div>
      <div className="font-black leading-none" style={{fontSize:44,color:tc,textShadow:`0 0 30px ${gc}80`}}>
        {bn(now.getDate())}
      </div>
      <div className="text-zinc-400 text-xs font-semibold mt-0.5">{monBn[now.getMonth()]} {bn(now.getFullYear())}</div>
      <div className="mt-2">
        <span className="font-black text-sm px-3 py-1 rounded-xl" style={{
          background:`${gc}25`,color:tc,
          border:`1.5px solid ${gc}55`,
          boxShadow:`0 0 12px ${gc}30`,
        }}>{dayBn[now.getDay()]}</span>
      </div>
      {drawDay&&(
        <div className="mt-1.5">
          <span className="text-[10px] font-black px-2 py-0.5 rounded-full" style={{
            background:"rgba(251,191,36,0.18)",color:"#fbbf24",
            border:"1px solid rgba(251,191,36,0.35)",
          }}>🎰 ড্র দিন</span>
        </div>
      )}
    </div>
  );
}

// ─── Cartoon Mascot ────────────────────────────────────────────────────────────
function CartoonMascot(){
  return(
    <div className="rounded-2xl px-4 py-3 flex items-center gap-4" style={{
      background:"rgba(255,255,255,0.025)",
      border:"1px solid rgba(255,255,255,0.07)",
    }}>
      {/* SVG stick figure */}
      <div className="flex-shrink-0" style={{width:52,height:68}}>
        <svg viewBox="0 0 52 68" fill="none" xmlns="http://www.w3.org/2000/svg"
          style={{animation:"mascotBob 2s ease-in-out infinite",overflow:"visible"}}>
          {/* Body */}
          <rect x="18" y="26" width="16" height="19" rx="5" fill="#2563eb"/>
          {/* Head */}
          <circle cx="26" cy="18" r="11" fill="#fbbf24"/>
          {/* Eyes */}
          <ellipse cx="22.5" cy="16.5" rx="1.8" ry="2.2" fill="#1e293b"
            style={{transformOrigin:"22.5px 16.5px",animation:"eyeBlink 3.5s ease-in-out infinite"}}/>
          <ellipse cx="29.5" cy="16.5" rx="1.8" ry="2.2" fill="#1e293b"
            style={{transformOrigin:"29.5px 16.5px",animation:"eyeBlink 3.5s ease-in-out infinite .12s"}}/>
          {/* Smile */}
          <path d="M21.5 21.5 Q26 25 30.5 21.5" stroke="#92400e" strokeWidth="1.5" strokeLinecap="round" fill="none"/>
          {/* Right arm — alternates pointing DOWN and RIGHT */}
          <g style={{transformOrigin:"34px 30px",animation:"armDown 4s ease-in-out infinite"}}>
            <line x1="34" y1="30" x2="46" y2="41" stroke="#fbbf24" strokeWidth="3" strokeLinecap="round"/>
            <circle cx="47" cy="42" r="2.5" fill="#fbbf24"/>
          </g>
          {/* Left arm — wave */}
          <g style={{transformOrigin:"18px 30px",animation:"armWave 3s ease-in-out infinite"}}>
            <line x1="18" y1="30" x2="7" y2="39" stroke="#fbbf24" strokeWidth="3" strokeLinecap="round"/>
            <circle cx="6" cy="40" r="2.5" fill="#fbbf24"/>
          </g>
          {/* Legs */}
          <line x1="22" y1="45" x2="18" y2="60" stroke="#1d4ed8" strokeWidth="3" strokeLinecap="round"/>
          <line x1="30" y1="45" x2="34" y2="60" stroke="#1d4ed8" strokeWidth="3" strokeLinecap="round"/>
          <ellipse cx="17" cy="61" rx="4" ry="2" fill="#0f172a"/>
          <ellipse cx="35" cy="61" rx="4" ry="2" fill="#0f172a"/>
        </svg>
      </div>

      {/* Guide text */}
      <div className="flex-1 min-w-0">
        <div className="text-white font-bold text-sm mb-1.5">আমি আপনাকে গাইড করছি!</div>
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs text-zinc-400">
            <span className="text-emerald-400 font-black text-sm" style={{animation:"arrowBounceUp 1.2s ease-in-out infinite"}}>↑</span>
            <span><span className="text-emerald-300 font-semibold">হেল্প লাইন</span>-এ মেসেজ করুন</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-zinc-400">
            <span className="text-yellow-400 font-black text-sm" style={{animation:"arrowBounceDown 1.2s ease-in-out infinite .6s"}}>↓</span>
            <span>নিচে <span className="text-yellow-300 font-semibold">Lucky Number</span> লিখুন</span>
          </div>
        </div>
      </div>

      {/* Animated arrows */}
      <div className="flex-shrink-0 flex flex-col items-center gap-1.5 pr-1">
        <div className="text-emerald-400 text-xl font-black" style={{animation:"arrowBounceUp 1.4s ease-in-out infinite"}}>⬆</div>
        <div className="w-px h-5 bg-zinc-800"/>
        <div className="text-yellow-400 text-xl font-black" style={{animation:"arrowBounceDown 1.4s ease-in-out infinite .7s"}}>⬇</div>
      </div>
    </div>
  );
}

// ─── Helpline Message Box ─────────────────────────────────────────────────────
function HelplineBox({ user }: { user: AuthUser }) {
  const [name, setName] = useState(user.username);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState("");
  const MAX = 500;

  async function handleSend(e: React.FormEvent) {
    e.preventDefault();
    if (!text.trim()) return;
    setSending(true); setErr("");
    try {
      await api.post("/messages", { senderName: name.trim() || user.username, text: text.trim() });
      setSent(true);
      setText("");
      setTimeout(() => setSent(false), 5000);
    } catch (e: any) {
      setErr(e?.message ?? "পাঠানো ব্যর্থ হয়েছে");
    } finally { setSending(false); }
  }

  // Orbit number data
  // top/bottom: fixed row for LTR/RTL; absent for HighPass (animation controls)
  const ORBIT=[
    {num:"5024",tag:"HIGH",row:"top",anim:"numLTR",delay:"0s",dur:"6s",color:"#f59e0b"},
    {num:"8317",tag:null,row:"top",anim:"numLTR",delay:"3.2s",dur:"4.8s",color:"#60a5fa"},
    {num:"7423",tag:"🔥HIGH",row:null,anim:"numHighPass",delay:"1.5s",dur:"8s",color:"#ef4444"},
    {num:"3691",tag:null,row:"bottom",anim:"numRTL",delay:"0.8s",dur:"5.5s",color:"#a78bfa"},
    {num:"9012",tag:null,row:"bottom",anim:"numRTL",delay:"4s",dur:"4.5s",color:"#f472b6"},
    {num:"6174",tag:"HIGH",row:null,anim:"numHighPass2",delay:"2.5s",dur:"7s",color:"#22c55e"},
    {num:"2589",tag:null,row:"top",anim:"numLTR",delay:"5.5s",dur:"5s",color:"#fbbf24"},
    {num:"4401",tag:null,row:"bottom",anim:"numRTL",delay:"6.5s",dur:"6s",color:"#818cf8"},
  ];

  return (
    <div className="relative" style={{overflow:"visible"}}>
      {/* Orbit number particles */}
      {ORBIT.map((o,i)=>(
        <div key={i} className="absolute pointer-events-none select-none z-20" style={{
          ...(o.row==="top" ? {top:"-16px"} : o.row==="bottom" ? {bottom:"-16px"} : {top:0}),
          animation:`${o.anim} ${o.dur} ease-in-out ${o.delay} infinite`,
        }}>
          <span className="inline-flex items-center gap-1 text-[11px] font-black px-2 py-0.5 rounded-md whitespace-nowrap" style={{
            color:o.color,
            background:`${o.color}18`,
            border:`1px solid ${o.color}45`,
            boxShadow:`0 0 8px ${o.color}35`,
          }}>
            {o.tag&&<span className="text-[10px]">{o.tag}</span>}{o.num}
          </span>
        </div>
      ))}

      {/* Actual helpline card */}
      <div className="rounded-2xl overflow-hidden" style={{background:"linear-gradient(135deg,rgba(16,185,129,0.06) 0%,rgba(0,0,0,0) 100%)",border:"1px solid rgba(16,185,129,0.22)",boxShadow:"0 4px 28px rgba(16,185,129,0.1)"}}>
        {/* Header */}
        <div className="flex items-center gap-3 px-4 py-3" style={{background:"rgba(16,185,129,0.08)",borderBottom:"1px solid rgba(16,185,129,0.12)"}}>
          <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0" style={{background:"rgba(16,185,129,0.15)",border:"1px solid rgba(16,185,129,0.25)"}}>
            <span className="text-base">📞</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-white font-bold text-sm">হেল্প লাইন</span>
              <span className="text-emerald-400 font-black text-sm">— মো: আপন</span>
              <span className="hidden sm:inline text-[10px] font-black px-2 py-0.5 rounded-full" style={{background:"rgba(16,185,129,0.15)",color:"#34d399",border:"1px solid rgba(16,185,129,0.25)"}}>ONLINE</span>
            </div>
            <div className="text-zinc-500 text-[11px] mt-0.5">আপনার মতামত, সমস্যা বা পরামর্শ সরাসরি জানান</div>
          </div>
        </div>

        {/* Form */}
        <div className="px-4 py-3">
          {sent ? (
            <div className="flex items-center gap-3 py-4 px-3 rounded-xl" style={{background:"rgba(16,185,129,0.1)",border:"1px solid rgba(16,185,129,0.2)"}}>
              <span className="text-2xl">✅</span>
              <div>
                <div className="text-emerald-400 font-bold text-sm">মেসেজ পাঠানো হয়েছে!</div>
                <div className="text-zinc-500 text-xs mt-0.5">মো: আপন শীঘ্রই দেখবেন। ধন্যবাদ।</div>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSend} className="space-y-2.5">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={name}
                  onChange={e=>setName(e.target.value)}
                  placeholder="আপনার নাম (ঐচ্ছিক)"
                  maxLength={60}
                  className="w-36 flex-shrink-0 bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-white text-xs focus:outline-none focus:border-emerald-500 placeholder:text-zinc-600 transition"
                />
                <div className="relative flex-1">
                  <textarea
                    value={text}
                    onChange={e=>setText(e.target.value.slice(0, MAX))}
                    placeholder="আপনার মেসেজ লিখুন… সমস্যা, পরামর্শ, বা যেকোনো কথা"
                    rows={2}
                    maxLength={MAX}
                    className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-2 text-white text-xs focus:outline-none focus:border-emerald-500 placeholder:text-zinc-600 resize-none transition"
                  />
                  <span className="absolute bottom-1.5 right-2 text-[10px] text-zinc-700">{text.length}/{MAX}</span>
                </div>
              </div>
              {err&&<div className="text-red-400 text-xs px-1">{err}</div>}
              <div className="flex items-center justify-between">
                <span className="text-zinc-700 text-[10px]">⏱️ মেসেজ ২৪ ঘন্টায় auto-delete হয়</span>
                <button
                  type="submit"
                  disabled={sending||!text.trim()}
                  className="flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-bold transition-all active:scale-95 disabled:opacity-40"
                  style={{background:"linear-gradient(135deg,#059669,#10b981)",color:"#fff",boxShadow:"0 2px 8px rgba(16,185,129,0.3)"}}
                >
                  {sending?(<><span className="animate-spin text-sm">⟳</span>পাঠানো হচ্ছে…</>):(<><span>📤</span>পাঠান</>)}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Top Section wrapper (Timer + Date + Mascot + Helpline) ───────────────────
function TopSection({ user }: { user: AuthUser }) {
  useTopSectionCSS();
  return (
    <div className="space-y-2">
      {/* Row 1: Timer + Date side by side */}
      <div className="grid grid-cols-2 gap-2">
        <DrawTimerBox />
        <DateDayBox />
      </div>
      {/* Row 2: Cartoon mascot guide */}
      <CartoonMascot />
      {/* Row 3: Helpline with orbiting numbers */}
      <HelplineBox user={user} />
    </div>
  );
}

// ─── Admin Messages Panel ─────────────────────────────────────────────────────
type UserMsg={id:string;senderUsername:string;senderName:string;text:string;ts:string;read:boolean};

function MessagesPanel({onClose,onRead}:{onClose:()=>void;onRead:(n:number)=>void}){
  const [msgs,setMsgs]=useState<UserMsg[]>([]);
  const [loading,setLoading]=useState(true);
  const [clearing,setClearing]=useState(false);

  const load=async()=>{
    setLoading(true);
    try{const d=await api.get("/admin/messages");setMsgs(d.messages??[]);onRead(d.unread??0);}
    catch{}finally{setLoading(false);}
  };
  useEffect(()=>{load();},[]);

  const markAll=async()=>{
    await api.post("/admin/messages/mark-read",{});
    setMsgs(p=>p.map(m=>({...m,read:true})));
    onRead(0);
  };
  const del=async(id:string)=>{
    const r=await api.delete(`/admin/messages/${id}`);
    setMsgs(p=>p.filter(m=>m.id!==id));
    onRead(r.unread??0);
  };
  const clearAll=async()=>{
    if(!confirm("সব মেসেজ মুছে দেবেন?")) return;
    setClearing(true);
    try{await api.delete("/admin/messages");setMsgs([]);onRead(0);}
    catch{}finally{setClearing(false);}
  };

  function timeAgo(ts:string){
    const diff=Date.now()-new Date(ts).getTime();
    const m=Math.floor(diff/60000);
    if(m<1) return "এইমাত্র";
    if(m<60) return `${m} মিনিট আগে`;
    const h=Math.floor(m/60);
    if(h<24) return `${h} ঘন্টা আগে`;
    return `${Math.floor(h/24)} দিন আগে`;
  }

  return(
    <div className="fixed inset-0 z-50 flex items-start justify-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm"/>
      <div className="relative w-full max-w-md h-full bg-zinc-950 border-l border-zinc-800 flex flex-col shadow-2xl" onClick={e=>e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-zinc-800 flex-shrink-0" style={{background:"rgba(16,185,129,0.05)"}}>
          <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{background:"rgba(16,185,129,0.15)",border:"1px solid rgba(16,185,129,0.25)"}}>
            <span className="text-lg">💬</span>
          </div>
          <div className="flex-1">
            <div className="text-white font-bold text-sm">ইউজার মেসেজ</div>
            <div className="text-emerald-500/70 text-xs">{msgs.filter(m=>!m.read).length} অপঠিত · হেল্প লাইন বার্তা</div>
          </div>
          <button onClick={markAll} className="text-xs text-emerald-400 hover:text-emerald-300 transition px-2 py-1 rounded border border-emerald-900/50 hover:bg-emerald-900/20">সব পড়া</button>
          <button onClick={clearAll} disabled={clearing} className="text-xs text-red-400 hover:text-red-300 transition px-2 py-1 rounded border border-red-900/50 hover:bg-red-900/20">{clearing?"…":"মুছুন"}</button>
          <button onClick={onClose} className="text-zinc-500 hover:text-white ml-1 text-lg leading-none">✕</button>
        </div>

        {/* Message list */}
        <div className="flex-1 overflow-y-auto divide-y divide-zinc-900">
          {loading?(
            <div className="flex items-center justify-center h-40 text-zinc-600 text-sm gap-2">
              <span className="animate-spin">⟳</span> Loading…
            </div>
          ):msgs.length===0?(
            <div className="flex flex-col items-center justify-center h-52 gap-3 text-zinc-600">
              <span className="text-4xl">💬</span>
              <span className="text-sm">কোনো মেসেজ নেই</span>
              <span className="text-xs text-zinc-700">ইউজাররা হেল্প লাইন থেকে মেসেজ পাঠালে এখানে দেখা যাবে</span>
            </div>
          ):msgs.map(msg=>(
            <div key={msg.id} className={`px-5 py-4 transition hover:bg-zinc-900/40 ${msg.read?"":"bg-emerald-950/10"}`}>
              <div className="flex items-start gap-3">
                {/* Avatar */}
                <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 font-black text-base" style={{background:"rgba(16,185,129,0.12)",border:"1px solid rgba(16,185,129,0.2)",color:"#34d399"}}>
                  {msg.senderName.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-white font-bold text-sm">{msg.senderName}</span>
                    {msg.senderUsername!==msg.senderName&&<span className="text-zinc-600 text-xs">@{msg.senderUsername}</span>}
                    {!msg.read&&<span className="w-2 h-2 rounded-full bg-emerald-500 ml-auto flex-shrink-0"/>}
                  </div>
                  <div className="text-zinc-300 text-sm leading-relaxed whitespace-pre-wrap break-words">{msg.text}</div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-zinc-700 text-[11px]">⏱️ {timeAgo(msg.ts)}</span>
                    <button onClick={()=>del(msg.id)} className="text-[11px] text-red-700 hover:text-red-500 transition px-2 py-0.5 rounded hover:bg-red-900/20">🗑️ মুছুন</button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-zinc-800 flex-shrink-0 text-center">
          <button onClick={load} className="text-xs text-zinc-600 hover:text-zinc-400 transition">↻ Refresh</button>
          <p className="text-zinc-800 text-[10px] mt-1">মেসেজ ২৪ ঘন্টা পরে স্বয়ংক্রিয়ভাবে মুছে যায়</p>
        </div>
      </div>
    </div>
  );
}

// ─── Security Events Panel ────────────────────────────────────────────────────
type SecEvent={id:string;severity:"critical"|"high"|"medium"|"info";type:string;title:string;detail:string;ip?:string;username?:string;ts:string;read:boolean};
const SEV_COLOR:Record<string,string>={critical:"text-red-400 bg-red-900/30 border-red-800",high:"text-orange-400 bg-orange-900/30 border-orange-800",medium:"text-yellow-400 bg-yellow-900/30 border-yellow-800",info:"text-blue-400 bg-blue-900/30 border-blue-800"};
const SEV_LABEL:Record<string,string>={critical:"🔴 CRITICAL",high:"🟠 HIGH",medium:"🟡 MEDIUM",info:"🔵 INFO"};

function SecurityPanel({onClose,onRead}:{onClose:()=>void;onRead:()=>void}){
  const [events,setEvents]=useState<SecEvent[]>([]);
  const [loading,setLoading]=useState(true);
  const [clearing,setClearing]=useState(false);

  const load=async()=>{
    try{const d=await api.get("/admin/security-events");setEvents(d.events??[]);}catch{}finally{setLoading(false);}
  };
  useEffect(()=>{load();},[]);

  const markAll=async()=>{
    await api.post("/admin/security-events/mark-read",{});
    setEvents(p=>p.map(e=>({...e,read:true})));
    onRead();
  };
  const clearAll=async()=>{
    if(!confirm("সব security events মুছে দেবেন?")) return;
    setClearing(true);
    try{
      await api.delete("/admin/security-events");
      setEvents([]);
      onRead();
    }catch{}finally{setClearing(false);}
  };

  return(
    <div className="fixed inset-0 z-50 flex items-start justify-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm"/>
      <div className="relative w-full max-w-md h-full bg-zinc-950 border-l border-zinc-800 flex flex-col shadow-2xl" onClick={e=>e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-zinc-800 flex-shrink-0">
          <span className="text-xl">🔔</span>
          <div className="flex-1">
            <div className="text-white font-bold">Security Notifications</div>
            <div className="text-zinc-500 text-xs">{events.filter(e=>!e.read).length} unread</div>
          </div>
          <button onClick={markAll} className="text-xs text-blue-400 hover:text-blue-300 transition px-2 py-1 rounded border border-blue-900/50 hover:bg-blue-900/20">সব পড়া</button>
          <button onClick={clearAll} disabled={clearing} className="text-xs text-red-400 hover:text-red-300 transition px-2 py-1 rounded border border-red-900/50 hover:bg-red-900/20">{clearing?"…":"মুছুন"}</button>
          <button onClick={onClose} className="text-zinc-500 hover:text-white ml-1">✕</button>
        </div>
        {/* Events list */}
        <div className="flex-1 overflow-y-auto divide-y divide-zinc-900">
          {loading?(<div className="flex items-center justify-center h-40 text-zinc-600 text-sm">Loading…</div>)
          :events.length===0?(<div className="flex flex-col items-center justify-center h-40 gap-2 text-zinc-600"><span className="text-3xl">✅</span><span className="text-sm">কোনো alert নেই</span></div>)
          :events.map(ev=>(
            <div key={ev.id} className={`px-5 py-3.5 ${ev.read?"opacity-60":""}`}>
              <div className="flex items-start gap-2">
                <span className={`text-[10px] font-black px-1.5 py-0.5 rounded border flex-shrink-0 mt-0.5 ${SEV_COLOR[ev.severity]}`}>{SEV_LABEL[ev.severity]}</span>
                <div className="flex-1 min-w-0">
                  <div className="text-white text-sm font-medium leading-tight">{ev.title}</div>
                  <div className="text-zinc-500 text-xs mt-0.5 leading-relaxed">{ev.detail}</div>
                  <div className="flex items-center gap-3 mt-1.5 text-[11px] text-zinc-600">
                    {ev.ip&&<span>📍 {ev.ip}</span>}
                    {ev.username&&<span>👤 {ev.username}</span>}
                    <span className="ml-auto">{new Date(ev.ts).toLocaleString()}</span>
                  </div>
                </div>
                {!ev.read&&<span className="w-2 h-2 rounded-full bg-red-500 flex-shrink-0 mt-1.5"/>}
              </div>
            </div>
          ))}
        </div>
        {/* Footer */}
        <div className="px-5 py-3 border-t border-zinc-800 flex-shrink-0">
          <button onClick={load} className="w-full text-xs text-zinc-500 hover:text-zinc-300 transition py-1">↻ Refresh</button>
        </div>
      </div>
    </div>
  );
}

// ─── Free Settings View ───────────────────────────────────────────────────────
// ─── Guest Lock Screen ────────────────────────────────────────────────────────
function GuestLockScreen({ onUnlock }: { onUnlock:()=>void }) {
  const [code,setCode]=useState(""); const [err,setErr]=useState("");
  async function tryUnlock(e: React.FormEvent) {
    e.preventDefault(); setErr("");
    if(await verifyGuestCode(code)){ lsSetGuestUnlocked(code); onUnlock(); }
    else setErr("ভুল কোড! আবার চেষ্টা করুন।");
  }
  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{background:"#0f0f0f"}}>
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="w-20 h-20 mx-auto mb-4 rounded-3xl overflow-hidden" style={{border:"2px solid rgba(220,38,38,0.4)"}}>
            <img src="/cbc-logo.png" alt="4D HOSPITAL" className="w-full h-full object-cover"/>
          </div>
          <h1 className="text-white font-black text-2xl">4D <span className="text-red-500">HOSPITAL</span></h1>
          <p className="text-slate-400 text-sm mt-1">এই App-টি সীমিত অ্যাক্সেস-এ আছে</p>
        </div>
        <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6">
          <h2 className="text-white font-bold mb-1">🔒 Access Code প্রয়োজন</h2>
          <p className="text-slate-400 text-xs mb-5">App মালিকের কাছ থেকে Access Code নিন</p>
          <form onSubmit={tryUnlock} className="space-y-4">
            <input value={code} onChange={e=>{setCode(e.target.value);setErr("");}}
              placeholder="Access Code লিখুন"
              className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-red-500 text-center tracking-widest font-mono text-lg" autoFocus/>
            {err&&<p className="text-red-400 text-xs text-center">{err}</p>}
            <button type="submit" disabled={!code.trim()}
              className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 disabled:opacity-40 text-white font-black py-3 rounded-xl transition">
              প্রবেশ করুন →
            </button>
          </form>
        </div>
        <p className="text-slate-600 text-xs text-center mt-4">4D HOSPITAL — Free Version</p>
      </div>
    </div>
  );
}

function AppearanceLanguageSettings(){
  const [color,setColor]=useState(()=>localStorage.getItem(LS_THEME)||"#22c55e");
  const [language,setLanguage]=useState(()=>localStorage.getItem(LS_LANGUAGE)||"bn");
  const [compact,setCompact]=useState(()=>localStorage.getItem(LS_COMPACT)==="1");
  const presets=["#22c55e","#3b82f6","#a855f7","#f59e0b","#ef4444","#06b6d4","#ec4899","#84cc16"];
  function applyColor(v:string){setColor(v);localStorage.setItem(LS_THEME,v);applyAppPreferences();}
  function applyLanguage(v:string){setLanguage(v);localStorage.setItem(LS_LANGUAGE,v);applyAppPreferences();}
  function applyCompact(v:boolean){setCompact(v);localStorage.setItem(LS_COMPACT,v?"1":"0");applyAppPreferences();}
  return (
    <div className="settings-card bg-slate-800 border border-slate-700 rounded-2xl p-4 space-y-4">
      <div><h2 className="text-white font-semibold">🎨 চেহারা, রং ও ভাষা</h2><p className="text-slate-300 text-xs mt-1">অ্যাপটিকে আপনার পছন্দমতো Android-style করে নিন।</p></div>
      <div>
        <label className="block text-slate-300 text-xs font-semibold mb-2">অ্যাপের প্রধান রং</label>
        <div className="flex flex-wrap gap-2 items-center">
          {presets.map(c=><button key={c} onClick={()=>applyColor(c)} aria-label={c} className="w-8 h-8 rounded-full border-2" style={{background:c,borderColor:color===c?"white":"rgba(255,255,255,.15)",boxShadow:color===c?`0 0 0 2px ${c}66`:"none"}}/>)}
          <label className="flex items-center gap-2 text-xs text-slate-400 border border-slate-700 rounded-xl px-2 py-1.5 cursor-pointer">নিজের রং <input type="color" value={color} onChange={e=>applyColor(e.target.value)} className="w-7 h-7 bg-transparent border-0 p-0"/></label>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div><label className="block text-slate-300 text-xs font-semibold mb-2">ভাষা</label><select value={language} onChange={e=>applyLanguage(e.target.value)} className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-2 text-sm"><option value="bn">বাংলা</option><option value="en">English</option></select></div>
        <div><label className="block text-slate-300 text-xs font-semibold mb-2">ফোনে compact view</label><button onClick={()=>applyCompact(!compact)} className="w-full rounded-xl px-3 py-2 text-sm font-bold" style={{background:compact?"rgba(34,197,94,.15)":"rgba(100,116,139,.15)",color:compact?"#4ade80":"#94a3b8",border:`1px solid ${compact?"rgba(34,197,94,.3)":"rgba(100,116,139,.25)"}`}}>{compact?"✓ চালু":"বন্ধ"}</button></div>
      </div>
      <p className="text-[10px] text-slate-600">রং ও compact mode সঙ্গে সঙ্গে কাজ করবে। ভাষার পছন্দ সংরক্ষিত থাকবে; সম্পূর্ণ অনুবাদ ধাপে ধাপে প্রয়োগ করা যাবে।</p>
    </div>
  );
}

function FreeSettingsView({ results, onClearData, onImportData }: { results:LotteryResult[]; onClearData:()=>void; onImportData:(rows:LotteryResult[])=>Promise<void> }) {
  const [importText,setImportText]=useState("");
  const [importErr,setImportErr]=useState("");
  const [importOk,setImportOk]=useState(false);

  // Guest lock state
  const [guestCode,    setGuestCode]    = useState(()=>lsGetGuestCode());
  const [guestEnabled, setGuestEnabled] = useState(()=>!!lsGetGuestCode());
  const [newCode,      setNewCode]      = useState("");
  const [codeMsg,      setCodeMsg]      = useState("");
  const [revokeMsg,    setRevokeMsg]    = useState("");

  function handleExport() {
    const blob=new Blob([JSON.stringify(results,null,2)],{type:"application/json"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");
    a.href=url; a.download=`cbc_lt4_data_${new Date().toISOString().slice(0,10)}.json`;
    a.click(); URL.revokeObjectURL(url);
  }
  async function handleImport() {
    try {
      const data=JSON.parse(importText);
      if(!Array.isArray(data)) throw new Error("Invalid format — array প্রয়োজন");
      const clean=data.map((r:any,i:number)=>({
        id:Number(r?.id)||Date.now()+i,
        company:(()=>{const x=String(r?.company??r?.operator??r?.companyId??"magnum").toLowerCase().trim();return x.includes("magnum")?"magnum":x.includes("toto")?"toto":x.includes("damacai")||x.includes("da ma cai")||x==="dmc"?"damacai":x.includes("singapore")||x==="sgp"?"singapore":x;})(),
        date:String(r?.date??r?.drawDate??"").slice(0,10),
        drawNo:r?.drawNo??r?.draw??r?.drawNumber??null,
        first:String(r?.first??r?.firstPrize??r?.["1st"]??"").replace(/\D/g,"").padStart(4,"0").slice(-4),
        second:String(r?.second??r?.secondPrize??r?.["2nd"]??"").replace(/\D/g,"").padStart(4,"0").slice(-4),
        third:String(r?.third??r?.thirdPrize??r?.["3rd"]??"").replace(/\D/g,"").padStart(4,"0").slice(-4),
        special:Array.isArray(r?.special)?r.special.map(String).filter((x:string)=>/^\d{4}$/.test(x)):String(r?.special??"").split(/[\s,;|]+/).filter((x:string)=>/^\d{4}$/.test(x)),
        consolation:Array.isArray(r?.consolation)?r.consolation.map(String).filter((x:string)=>/^\d{4}$/.test(x)):String(r?.consolation??"").split(/[\s,;|]+/).filter((x:string)=>/^\d{4}$/.test(x)),
      })).filter((r:LotteryResult)=>COMPANY_IDS.includes(r.company as CompanyId)&&/^\d{4}-\d{2}-\d{2}$/.test(r.date)&&/^\d{4}$/.test(r.first)&&/^\d{4}$/.test(r.second)&&/^\d{4}$/.test(r.third));
      if(!clean.length) throw new Error("কোনো বৈধ result পাওয়া যায়নি");
      await onImportData(clean);
      setImportOk(true); setImportErr(""); setImportText("");
    } catch(e:any) { setImportErr(e.message||"Import ব্যর্থ"); }
  }
  async function handleSaveCode() {
    const value=newCode.trim();
    if (value.length<6) { setCodeMsg("❌ Access Code কমপক্ষে ৬ অক্ষরের দিন।"); return; }
    await setGuestCodeSecure(value);
    setGuestCode("••••••••");
    setGuestEnabled(true);
    setNewCode("");
    setCodeMsg("✅ Access Code নিরাপদভাবে সেট হয়েছে। আসল code storage-এ plain text হিসেবে রাখা নেই।");
    setTimeout(()=>setCodeMsg(""),5000);
  }
  function handleDisableLock() {
    lsSetGuestCode("");
    lsRevokeAllGuests();
    setGuestCode(""); setGuestEnabled(false);
    setCodeMsg("🔓 Guest lock সরানো হয়েছে — সবাই অ্যাক্সেস করতে পারবে।");
    setTimeout(()=>setCodeMsg(""),4000);
  }
  function handleRevoke() {
    lsRevokeAllGuests();
    setRevokeMsg("✅ সব guest session বাতিল হয়েছে! এখন সবাইকে নতুন করে code দিতে হবে।");
    setTimeout(()=>setRevokeMsg(""),5000);
  }

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-white">⚙️ Settings</h1>
        <p className="text-slate-400 text-xs mt-0.5">App নিয়ন্ত্রণ ও ডেটা ব্যবস্থাপনা — ফ্রি ভার্শন</p>
      </div>

      {/* ── Appearance / Language ── */}
      <AppearanceLanguageSettings />

      {/* ── Guest Access Lock ── */}
      <div className="settings-card bg-slate-800 border border-slate-700 rounded-2xl p-5 space-y-4">
        <div className="flex items-center gap-2">
          <span className="text-xl">{guestEnabled?"🔒":"🔓"}</span>
          <div>
            <h2 className="text-white font-semibold">Guest Access Control</h2>
            <p className="text-slate-300 text-xs">এই ডিভাইসে Guest Access নিয়ন্ত্রণ করুন</p>
          </div>
          <span className={`ml-auto text-xs font-bold px-2 py-1 rounded-full ${guestEnabled?"bg-red-900/40 text-red-400 border border-red-700/40":"bg-green-900/30 text-green-400 border border-green-700/30"}`}>
            {guestEnabled?"লক আছে":"খোলা"}
          </span>
        </div>

        {guestEnabled && (
          <div className="bg-slate-900/60 border border-slate-600 rounded-xl p-3 text-xs space-y-1">
            <p className="text-slate-300">বর্তমান Access Code: <span className="font-mono font-bold text-yellow-400">{guestCode}</span></p>
            <p className="text-slate-300">এই ডিভাইসে code না দিলে Guest ব্যবহারকারী app-এ ঢুকতে পারবে না।</p>
          </div>
        )}

        {/* Set new code */}
        <div className="space-y-2">
          <label className="text-slate-200 text-xs block">নতুন Access Code সেট করুন:</label>
          <div className="flex gap-2">
            <input value={newCode} onChange={e=>setNewCode(e.target.value)}
              placeholder="যেমন: MYCODE123"
              className="flex-1 bg-slate-950 border border-slate-700 text-white font-mono rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-blue-500"/>
            <button onClick={handleSaveCode} disabled={!newCode.trim()}
              className="bg-blue-600 hover:bg-blue-500 disabled:opacity-75 text-white rounded-xl px-4 py-2 text-sm font-bold transition">
              সেট করুন
            </button>
          </div>
        </div>

        {codeMsg&&<p className="text-green-400 text-xs bg-green-900/20 border border-green-700/30 rounded-xl p-3">{codeMsg}</p>}

        {/* Revoke / Disable */}
        <div className="flex flex-wrap gap-2 pt-1">
          {guestEnabled && (
            <button onClick={handleRevoke}
              className="bg-orange-900/40 hover:bg-orange-900/60 border border-orange-700/40 text-orange-400 rounded-xl py-2 px-4 text-xs font-bold transition">
              🚫 সবার Access বাতিল করুন
            </button>
          )}
          {guestEnabled && (
            <button onClick={handleDisableLock}
              className="bg-slate-700 hover:bg-slate-600 border border-slate-600 text-slate-300 rounded-xl py-2 px-4 text-xs font-bold transition">
              🔓 Lock সরিয়ে দিন
            </button>
          )}
        </div>
        {revokeMsg&&<p className="text-orange-400 text-xs bg-orange-900/20 border border-orange-700/30 rounded-xl p-3">{revokeMsg}</p>}

        <div className="bg-blue-900/30 border border-blue-700/40 rounded-xl p-3 text-xs text-blue-200 space-y-1">
          <p className="font-semibold text-blue-300">ℹ️ কিভাবে কাজ করে:</p>
          <p>• Access Code সেট করলে এই ডিভাইসে নতুন Guest code ছাড়া ঢুকতে পারবে না।</p>
          <p>• "সবার Access বাতিল" করলে এই ডিভাইসের আগের Guest sessions বাতিল হবে।</p>
          <p>• Code পরিবর্তন করলে পুরনো code আর কাজ করবে না। এই ব্যবস্থা offline/local; অন্য ফোনে code নিজে থেকে পৌঁছাবে না।</p>
        </div>
      </div>

      {/* ── Data Export/Import ── */}
      <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5 space-y-4">
        <h2 className="text-white font-semibold">📊 ডেটা Export / Import</h2>
        <p className="text-slate-400 text-xs">সংরক্ষিত 4D results export ও import করুন।</p>
        <button onClick={handleExport} className="w-full bg-blue-600 hover:bg-blue-500 text-white rounded-xl py-2.5 text-sm font-bold transition">
          ⬇️ Export JSON ({results.length} records)
        </button>
        <div className="border-t border-slate-700 pt-4">
          <p className="text-slate-400 text-xs mb-2">Import (JSON paste করুন):</p>
          <textarea rows={4} value={importText} onChange={e=>{setImportText(e.target.value);setImportErr("");setImportOk(false);}}
            className="w-full bg-slate-950 border border-slate-700 text-white font-mono rounded-xl px-3 py-2.5 text-xs focus:outline-none focus:border-blue-500 resize-none" placeholder="JSON data এখানে paste করুন"/>
          {importErr&&<p className="text-red-400 text-xs mt-1">{importErr}</p>}
          {importOk&&<p className="text-green-400 text-xs mt-1">✅ Import সফল! পেজ reload হচ্ছে…</p>}
          <button onClick={handleImport} disabled={!importText.trim()} className="mt-2 w-full bg-green-600 hover:bg-green-500 disabled:opacity-40 text-white rounded-xl py-2.5 text-sm font-bold transition">
            ⬆️ Import করুন
          </button>
        </div>
      </div>

      {/* ── Clear Data ── */}
      <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5">
        <h2 className="text-white font-semibold mb-2">🗑️ সব Data মুছুন</h2>
        <p className="text-slate-400 text-xs mb-4">সব 4D data browser থেকে মুছে ফেলুন (এটি পুনরুদ্ধার করা যাবে না)।</p>
        <button onClick={onClearData} className="bg-red-900/40 hover:bg-red-900/60 border border-red-700/40 text-red-400 rounded-xl py-2.5 px-5 text-sm font-bold transition">
          🗑️ সব Data মুছুন
        </button>
      </div>
    </div>
  );
}

// ─── Admin Login Modal ────────────────────────────────────────────────────────
function AdminLoginModal({ onSuccess, onClose }: { onSuccess:()=>void; onClose:()=>void }) {
  const [pass,setPass]=useState(""); const [confirm,setConfirm]=useState(""); const [err,setErr]=useState(""); const [busy,setBusy]=useState(false); const [setup,setSetup]=useState(false);
  useEffect(()=>{hasAdminPassword().then(v=>setSetup(!v));},[]);
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setErr("");
    try{
      if(setup){ if(pass.length<10){setErr("কমপক্ষে ১০ অক্ষরের শক্ত password দিন।");return;} if(pass!==confirm){setErr("দুইটি password একই নয়।");return;} await setAdminPassword(pass); localAudit("admin_setup","Admin security credential created",true); lsSetAdmin(true); onSuccess(); return; }
      if(await verifyAdminPassword(pass)){ lsSetAdmin(true); localAudit("login","Local admin login",true); onSuccess(); }
      else { localAudit("login_failed","Invalid local admin password",false); setErr("ভুল পাসওয়ার্ড! আবার চেষ্টা করুন।"); }
    }catch(e:any){setErr(e?.message||"Security setup failed");}finally{setBusy(false);}
  }
  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-red-900/50 rounded-2xl p-6 w-full max-w-sm shadow-2xl">
        <h2 className="text-white font-black text-xl mb-1">🛡️ Admin Mode</h2>
        <p className="text-slate-500 text-xs mb-5">{setup?"প্রথমবার একটি নতুন শক্ত Admin password সেট করুন":"Admin password দিয়ে প্রবেশ করুন"}</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input type="password" value={pass} onChange={e=>{setPass(e.target.value);setErr("");}} placeholder={setup?"নতুন password (কমপক্ষে ১০ অক্ষর)":"পাসওয়ার্ড"}
            className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-red-500" autoFocus/>
          {setup&&<input type="password" value={confirm} onChange={e=>setConfirm(e.target.value)} placeholder="নতুন password আবার লিখুন" className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-red-500"/>}{err&&<p className="text-red-400 text-xs">{err}</p>}
          <div className="flex gap-3">
            <button type="button" onClick={onClose} className="flex-1 text-slate-400 border border-slate-700 rounded-xl py-2.5 text-sm hover:text-white transition">বাতিল</button>
            <button type="submit" disabled={busy} className="flex-1 bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white rounded-xl py-2.5 text-sm font-black transition">{busy?(setup?"সেট হচ্ছে…":"যাচাই হচ্ছে…"):(setup?"🔐 নিরাপদ করুন":"প্রবেশ করুন")}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ─── Main App (Free Version — No Backend) ─────────────────────────────────────
export default function App() {
  const [user,setUser]=useState<AuthUser>(()=>({
    id:1, username:lsIsAdmin()?"CBC LT4 APON":"Guest", role:lsIsAdmin()?"admin":"user",
  }));
  const [adminModalOpen,setAdminModalOpen]=useState(false);

  // Guest lock: if guest code is set and user is not admin, check if unlocked
  const [guestUnlocked,setGuestUnlocked]=useState(()=>{
    if(lsIsAdmin()) return true; // admin always unlocked
    const code=lsGetGuestCode();
    if(!code) return true;       // no lock set = open access
    return lsIsGuestUnlocked();
  });

  // Re-check when admin status changes
  const isAdmin = user.role==="admin";
  const guestLockActive = !!lsGetGuestCode() && !isAdmin && !guestUnlocked;

  const [view,setView]=useState<View>("master");
  const [viewHistory,setViewHistory]=useState<View[]>([]);
  const [selectedCompany,setSelectedCompany]=useState<CompanyId>("magnum");
  const [sidebarOpen,setSidebarOpen]=useState(false);
  const [results,setResults]=useState<LotteryResult[]>(()=>lsGetResults());
  const [dbReady,setDbReady]=useState(false);

  useEffect(()=>{ applyAppPreferences(); },[]);

  // Android: initialize native SQLite, migrate any old localStorage records once,
  // then use SQLite as the source of truth. Web/free fallback remains localStorage.
  useEffect(()=>{
    let alive=true;
    (async()=>{
      try{
        const native=await initResultsDatabase();
        if(native){
          const rows=(await loadResultsFromSQLite()) ?? [];
          const legacy=lsGetResults();

          // IMPORTANT: an app update may retain the old WebView/localStorage
          // while the native SQLite database is new/empty (or vice-versa).
          // Never choose one source and discard the other. Merge both sources
          // by company+date, preferring the SQLite row when the same draw exists
          // because it is the native source of truth after migration.
          const mergedMap=new Map<string,LotteryResult>();
          for(const r of legacy){ const key=`${r.company}|${r.date}`; if(!mergedMap.has(key)) mergedMap.set(key,r); }
          for(const r of rows as LotteryResult[]){ const key=`${r.company}|${r.date}`; mergedMap.set(key,r); }
          const merged=normalizeMasterRows([...mergedMap.values()]);

          if(alive){
            setResults(merged);
            previousResultsRef.current=merged;
          }
          // Persist the union back to SQLite so future launches have one
          // complete dataset. This is additive: existing rows are not lost.
          if(JSON.stringify(normalizeMasterRows(rows as LotteryResult[]))!==JSON.stringify(merged)){
            await replaceResultsInSQLite(merged as any);
          }
        }
      } finally { if(alive) setDbReady(true); }
    })();
    return ()=>{alive=false;};
  },[]);

  // Keep a small compatibility copy in localStorage and, on Android, persist
  // the full result set in native SQLite.
  const previousResultsRef = useRef<LotteryResult[]>([]);
  useEffect(()=>{
    if(!dbReady) return;
    lsSaveResults(results);
    void syncResultsInSQLite(previousResultsRef.current, results);
    previousResultsRef.current = results;
  },[results,dbReady]);


  if(guestLockActive) return <GuestLockScreen onUnlock={()=>setGuestUnlocked(true)}/>;

  // ── Navigation ────────────────────────────────────────────────────────────
  function navigateTo(v:View){ setViewHistory(p=>[...p,view]); setView(v); window.history.pushState({inApp:true,view:v},""); }
  function goBack(){ setViewHistory(prev=>{ if(!prev.length) return prev; const n=[...prev]; const pv=n.pop()!; setView(pv); return n; }); }
  useEffect(()=>{
    window.history.pushState({inApp:true},"");
    const h=()=>{ setViewHistory(prev=>{ if(prev.length>0){ const n=[...prev]; const pv=n.pop()!; setView(pv); window.history.pushState({inApp:true},""); return n; } window.history.pushState({inApp:true},""); return prev; }); };
    window.addEventListener("popstate",h); return()=>window.removeEventListener("popstate",h);
  },[]);

  function handleLogout(){ lsSetAdmin(false); setUser({id:1,username:"Guest",role:"user"}); }
  function handleAdminLogin(){ setAdminModalOpen(true); }
  function handleAdminSuccess(){ setAdminModalOpen(false); setUser({id:1,username:"CBC LT4 APON",role:"admin"}); }

  async function handleAddResult(r:any){
    const norm=(v:any)=>String(v??"").replace(/\D/g,"").slice(0,4).padStart(4,"0");
    if(!COMPANY_IDS.includes(r.company)) throw new Error("সঠিক Company নির্বাচন করুন।");
    if(!/^\d{4}$/.test(norm(r.first))||!/^\d{4}$/.test(norm(r.second))||!/^\d{4}$/.test(norm(r.third))) throw new Error("১ম, ২য় ও ৩য়—তিনটিই ৪ ডিজিট হতে হবে।");
    if(!/^\d{4}-\d{2}-\d{2}$/.test(String(r.date??""))) throw new Error("সঠিক তারিখ দিন।");
    const cleanList=(v:any)=>Array.isArray(v)?v.map(norm).filter(x=>/^\d{4}$/.test(x)):String(v??"").split(/[\s,]+/).map(norm).filter(x=>/^\d{4}$/.test(x));
    const nr:LotteryResult={id:Date.now(),company:r.company,date:r.date,drawNo:r.drawNo??null,first:norm(r.first),second:norm(r.second),third:norm(r.third),special:cleanList(r.special),consolation:cleanList(r.consolation)};
    if(results.some(x=>x.company===nr.company&&x.date===nr.date)) throw new Error("এই company ও date-এর record আগে থেকেই আছে। নতুন করে overwrite করা হয়নি; Edit দিয়ে সংশোধন করুন।");
    setResults(prev=>[...prev,nr]);
  }
  async function handleUpdateResult(id:number,r:any){
    const norm=(v:any)=>String(v??"").replace(/\D/g,"").slice(0,4).padStart(4,"0");
    const existing=results.find(x=>x.id===id);
    if(!existing) throw new Error("Record পাওয়া যায়নি।");
    const company=String(r?.company??existing.company).toLowerCase();
    const date=String(r?.date??existing.date);
    const first=norm(r?.first??existing.first), second=norm(r?.second??existing.second), third=norm(r?.third??existing.third);
    if(!COMPANY_IDS.includes(company as CompanyId)) throw new Error("সঠিক Company নির্বাচন করুন।");
    if(!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error("সঠিক তারিখ দিন।");
    if(!/^\d{4}$/.test(first)||!/^\d{4}$/.test(second)||!/^\d{4}$/.test(third)) throw new Error("১ম, ২য় ও ৩য়—তিনটিই ৪ ডিজিট হতে হবে।");
    const cleanList=(v:any)=>Array.isArray(v)?v.map(norm).filter((x:string)=>/^\d{4}$/.test(x)):String(v??"").split(/[\s,;|]+/).map(norm).filter((x:string)=>/^\d{4}$/.test(x));
    const updated:LotteryResult={...existing,...r,id,company,date,drawNo:r?.drawNo??existing.drawNo??null,first,second,third,special:cleanList(r?.special??existing.special),consolation:cleanList(r?.consolation??existing.consolation)};
    if(results.some(x=>x.id!==id && x.company===updated.company && x.date===updated.date)) throw new Error("এই company ও date-এর আরেকটি record আগে থেকেই আছে। অন্য record overwrite করা হয়নি।");
    setResults(prev=>prev.map(x=>x.id===id?updated:x));
  }
  async function handleImportData(rows:LotteryResult[]){
    const clean=rows.map((r:any,i:number)=>({
      id:Number(r?.id)||Date.now()+i, company:String(r?.company??"").toLowerCase(), date:String(r?.date??"").slice(0,10),
      drawNo:r?.drawNo??null, first:String(r?.first??"").replace(/\D/g,"").padStart(4,"0").slice(-4),
      second:String(r?.second??"").replace(/\D/g,"").padStart(4,"0").slice(-4), third:String(r?.third??"").replace(/\D/g,"").padStart(4,"0").slice(-4),
      special:Array.isArray(r?.special)?r.special.map(String).filter((x:string)=>/^\d{4}$/.test(x)):[], consolation:Array.isArray(r?.consolation)?r.consolation.map(String).filter((x:string)=>/^\d{4}$/.test(x)):[]
    })).filter((r:LotteryResult)=>COMPANY_IDS.includes(r.company as CompanyId)&&/^\d{4}-\d{2}-\d{2}$/.test(r.date)&&/^\d{4}$/.test(r.first)&&/^\d{4}$/.test(r.second)&&/^\d{4}$/.test(r.third));
    const map=new Map(results.map(r=>[`${r.company}|${r.date}`,r]));
    for(const r of clean) map.set(`${r.company}|${r.date}`,r);
    setResults([...map.values()]);
  }

  const canGoBack=viewHistory.length>0;

  const content=()=>{
    if(user.role!=="admin"&&(view==="users")) return <MasterPredictionView results={results} onView={navigateTo} user={user}/>;
    switch(view){
      case "generator":  return <GeneratorView results={results}/>;
      case "master":     return <MasterPredictionView results={results} onView={navigateTo} user={user}/>;
      case "dashboard":  return <DashboardView results={results} loadingData={false} onView={navigateTo} user={user}/>;
      case "company":    return <CompanyView companyId={selectedCompany} results={results} loadingData={false} isAdmin={user.role==="admin"} onAddResult={handleAddResult} onUpdateResult={handleUpdateResult} onResetDone={()=>setResults(r=>r.filter(x=>x.company!==selectedCompany))}/>;
      case "triplets":   return <TripletsView results={results}/>;
      case "pairs":      return <PairsView results={results}/>;
      case "cross":      return <CrossView results={results}/>;
      case "correlation":return <CorrelationView results={results}/>;
      case "researchCycle": return <ResearchCycleView results={results} companyId={selectedCompany} onApplyBatch={async (cycle)=>{ const startId=Math.max(0,...results.map(r=>r.id))+1; const rows=cycle.actualBatch.map((num,i)=>({id:startId+i,company:cycle.company,date:cycle.actualDate || new Date().toISOString().slice(0,10),drawNo:`${cycle.id}-${i+1}`,first:num,second:"",third:"",special:[],consolation:[]} as LotteryResult)); const next=[...results,...rows]; setResults(next); lsSaveResults(next); }} />;
      case "predictions":return <PredictionsView results={results}/>;
      case "deep":       return <DeepAnalysisView results={results}/>;
      case "scan":       return <ScanView onAddResult={handleAddResult}/>;
      case "ocr":        return <ScreenshotOCRView onAddResult={handleAddResult}/>;
      case "patterns":   return <PatternExplorerView/>;
      case "vault":      return <DataVaultView results={results} onUpdateResult={handleUpdateResult} onDeleteResult={(id)=>setResults(p=>p.filter(r=>r.id!==id))} onClearAll={()=>setResults([])} onRestore={(rows)=>setResults(rows)}/>;
      case "agents":     return <AgentsKYCView/>;
      case "live":       return <LiveResultsView onAddResult={handleAddResult}/>;
      case "heatmap":    return <HeatmapView results={results}/>;
      case "regression": return <RegressionView results={results}/>;
      case "calendar":   return <CalendarView results={results}/>;
      case "highlowmatrix": return <HighLowMatrixView results={results}/>;
      case "mirror":     return <MirrorView results={results}/>;
      case "benford":    return <BenfordView results={results}/>;
      case "lstm":       return <LSTMView results={results}/>;
      case "markov":     return <MarkovView results={results}/>;
      case "genetic":    return <GeneticView results={results}/>;
      case "outlier2":   return <OutlierView results={results}/>;
      case "backtest":   return <BacktestView results={results}/>;
      case "sliding":    return <SlidingView results={results}/>;
      case "consensus":  return <ConsensusView results={results}/>;
      case "alerts":     return <AlertsView results={results}/>;
      case "performance":return <PerformanceView results={results}/>;
      case "permutation":return <PermutationView results={results}/>;
      case "skipdraw":   return <SkipDrawView results={results}/>;
      case "neighbor":   return <NeighborView results={results}/>;
      case "users":      return <div className="p-8 text-center"><div className="text-5xl mb-4">👥</div><h2 className="text-white font-bold text-xl mb-2">User Management</h2><p className="text-slate-400 text-sm">লোকাল Agent / KYC Manager ব্যবহার করুন।</p></div>;
      case "settings":   return <FreeSettingsView results={results} onImportData={handleImportData} onClearData={()=>{ if(window.confirm("সব data মুছে ফেলবেন? এটি অপরিবর্তনযোগ্য।")){ setResults([]); lsSaveResults([]); } }}/>;
      default: return null;
    }
  };

  return (
    <div className="min-h-screen flex" style={{background:"#0f0f0f"}}>
      {adminModalOpen&&<AdminLoginModal onSuccess={handleAdminSuccess} onClose={()=>setAdminModalOpen(false)}/>}
      <Sidebar view={view} company={selectedCompany} user={user} results={results} onView={navigateTo} onCompany={setSelectedCompany} onLogout={handleLogout} onAdminLogin={handleAdminLogin} isOpen={sidebarOpen} onClose={()=>setSidebarOpen(false)}/>
      <div className="flex-1 flex flex-col min-w-0">
        <header className="lg:hidden flex items-center gap-3 px-4 py-3 sticky top-0 z-30" style={{background:"#0d0d0d",borderBottom:"1px solid rgba(220,38,38,0.2)"}}>
          {canGoBack?(
            <button onClick={goBack} className="flex items-center gap-1.5 text-red-400 hover:text-red-300 p-1 transition font-bold text-sm">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7"/></svg>ফিরে যান
            </button>
          ):(
            <button onClick={()=>setSidebarOpen(true)} className="text-zinc-500 hover:text-red-400 p-1 transition">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16"/></svg>
            </button>
          )}
          {canGoBack&&<button onClick={()=>setSidebarOpen(true)} className="text-zinc-600 hover:text-zinc-400 p-1 transition"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16"/></svg></button>}
          <div className="w-7 h-7 rounded-lg overflow-hidden flex-shrink-0" style={{border:"1px solid rgba(220,38,38,0.3)"}}><img src="/cbc-logo.png" alt="4D HOSPITAL" className="w-full h-full object-cover"/></div>
          <span className="text-white font-black text-sm">4D <span className="text-red-500">HOSPITAL</span></span>
          <div className="flex-1"/>
          {view==="company"&&<div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{background:COMPANIES[selectedCompany].color}}/><span className="text-zinc-400 text-xs">{COMPANIES[selectedCompany].name}</span></div>}
        </header>
        <main className="flex-1 overflow-y-auto relative">
          {canGoBack&&(
            <button onClick={goBack} className="hidden lg:flex items-center gap-2 sticky top-4 left-4 z-40 ml-4 mt-4 text-sm font-bold px-4 py-2 rounded-xl transition-all hover:scale-105"
              style={{background:"rgba(220,38,38,0.15)",border:"1px solid rgba(220,38,38,0.35)",color:"#f87171",width:"fit-content"}}>
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7"/></svg>← ফিরে যান
            </button>
          )}
          {content()}
        </main>
        <AppFooter dark/>
      </div>
    </div>
  );
}
