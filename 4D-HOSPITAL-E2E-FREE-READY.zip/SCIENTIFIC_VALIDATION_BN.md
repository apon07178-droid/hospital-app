# 4D HOSPITAL — Scientific Validation Layer

এই সংস্করণে historical analysis engine-এর সঙ্গে একটি offline statistical validation layer যোগ করা হয়েছে।

## যুক্ত করা হয়েছে
- Chi-Square Goodness-of-Fit — ৪টি position-এর digit distribution uniform hypothesis-এর সঙ্গে তুলনা।
- ACF — lag অনুযায়ী historical autocorrelation।
- Digit Independence Test — position pair-এর correlation ও chi-square independence test।
- Signal redundancy grouping — highly correlated signal series চিহ্নিত করার ভিত্তি।
- Score normalization — ensemble-এর আগে 0–1 normalization utility।
- Monte Carlo random-baseline test — observed backtest hits বনাম uniform random top-N null।
- Blocked K-Fold validation — temporal leakage কমানোর জন্য contiguous folds।
- Wilson confidence interval — hit-rate uncertainty।
- Look-ahead safety flag এবং validation notes।

## গুরুত্বপূর্ণ নকশা
কোনো 4D pattern (AAAA/AABB/ABAB/ABBA/ABCD) hard-delete করা হয় না। Pattern নিজে একটি signal হিসেবে থাকতে পারে; final ranking evidence-driven হবে।

## Overfitting / leakage
Training/test separation, normalization এবং validation metrics আলাদা layer-এ রাখা হয়েছে। Time-dependent data-তে ordinary shuffled K-Fold-এর বদলে blocked K-Fold রাখা হয়েছে, যাতে ভবিষ্যৎ তথ্য training-এ ঢুকে না যায়।

## Interpretation
Statistical significance historical non-uniformity বা dependence-এর evidence দিতে পারে; এটি ভবিষ্যৎ lottery outcome-এর নিশ্চয়তা বা guaranteed winning probability নয়।


## Correction pass (2026-09)

এই correction pass-এ আগের placeholder integration সরানো হয়েছে। Model-level K-Fold এখন real ranking callback ব্যবহার করে; newest-first dataset-এ প্রতিটি test block-এর training কেবল তার পরের (অর্থাৎ পুরোনো) records থেকে নেওয়া হয়। Ensemble ranking-এ প্রতিটি signal আগে 0–1 normalize হয়, তারপর walk-forward reliability এবং redundancy discount প্রয়োগ করা হয়। 3-stage pipeline-এর Stage 3-এ একই scientific score secondary evidence হিসেবে যোগ করা হয়েছে।

Automatic Android responsiveness-এর জন্য K-Fold-এর 5 contiguous folds রাখা হলেও training না পাওয়া earliest fold বাদ পড়ে; এটি ordinary shuffled K-Fold নয়, time-aware blocked validation।
