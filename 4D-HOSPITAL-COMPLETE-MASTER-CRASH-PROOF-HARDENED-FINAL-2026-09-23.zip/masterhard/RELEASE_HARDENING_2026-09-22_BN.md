# 4D Hospital — Release Hardening 2026-09-22

## Applied in this release candidate
1. Removed the duplicate application source tree. The project root is now the single authoritative build tree.
2. Fixed `index.html` so Vite loads the root `main.tsx` after the duplicate tree removal.
3. Admin export/import/company-reset paths now use the canonical durable result store (SQLite on Android, IndexedDB on web), not a second localStorage result store.
4. Import uses the same additive merge rules and company/date/draw-number logical identity as the main data path.
5. Web dataset metadata now reports `indexeddb` instead of the obsolete `localStorage-fallback` label.
6. Removed the misleading AES-256-GCM API-key claim. The free offline build does not require an external API key.
7. Disabled CDN-based Tesseract loading. OCR will fail closed rather than silently downloading code from the network.

## Verification performed
- Static audit: PASS
- 107 engine audit: PASS
- Reconciliation audit: PASS
- Sequence math audit: PASS
- Runtime contract audit: PASS
- Research-cycle E2E: PASS

## Remaining release gates
- Offline OCR still needs a bundled OCR engine/worker/WASM/traineddata asset. Network access is intentionally disabled and no fake fallback was added.
- Android APK/device E2E could not be executed in this environment because Android build tooling/dependencies are unavailable.
- `package-lock.json` could not be generated because package registry access is unavailable here. CI should not claim reproducible installs until a real lockfile is generated and the build switches to `npm ci`.
- SQLite encryption is not enabled and is not falsely advertised as enabled.
