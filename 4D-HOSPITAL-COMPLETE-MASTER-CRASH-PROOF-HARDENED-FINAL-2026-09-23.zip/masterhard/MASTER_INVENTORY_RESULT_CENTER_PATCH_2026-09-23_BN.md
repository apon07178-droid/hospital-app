# Master Inventory + Research Result Center Patch — 2026-09-23

## What was corrected

1. The project no longer presents `107 + 6` as the complete inventory.
2. A consolidated **Research Result Center** was added inside Research Cycle.
3. The Result Center shows the full 107 result register, the 28 active signal reliability view, six validation layers, special/advanced modules, and retained legacy pipelines in one place.
4. A master inventory document was added so counts are separated by layer and overlapping methods are not double-counted.
5. The old Smart Generator label was corrected from “27 Formula/Statistical Signals” to **27 numbered paths + 1 aggregation stage**. The source comments contain 27 numbered analytical paths; aggregation is a separate stage.
6. Legacy model channels are explicitly listed instead of being silently treated as removed.

## Important counting rule

The numbers are **layer counts**, not additive independent analyses. Several methods overlap between 107 Core, 28 active signals, the legacy Smart Generator, and legacy model channels.

Source-of-truth counts:

- 107 Core Analysis
- 28 Active Signals
- 27 Smart Generator numbered paths + 1 aggregation stage
- 11 legacy model channels
- 6 Validation Layers
- 9 Special/Advanced modules

## Data flow

`Cumulative Dataset → 107 Core → 28 Active Signals → Special/Advanced evidence → 6 Validation Layers → Research Result Center`

When new historical rows are imported, the cumulative dataset remains the source for recalculation. The Result Center is not a static copy of the previous result.

## Safety of interpretation

The UI labels these outputs as historical research diagnostics. Scores, ranks, and evidence states are not guaranteed future outcomes or winning probabilities.
