# 4D HOSPITAL — A-to-Z Implementation Status — 2026-09-22

## গবেষণা-কেন্দ্রিক মূল flow

`Cumulative Dataset → Data Quality → 107 Analysis → 28 Signals/Advanced Models → Evidence/Validation → Research Output → LOCK → Actual Result → Match/Mismatch → Failure Diagnostics → Observation Reconciliation → Next Cycle`

## এই pass-এ শক্ত করা হয়েছে

- 107-analysis public contract ও dependency graph audit রাখা হয়েছে।
- 6 pair + 4 triplet coverage রাখা হয়েছে।
- Arithmetic/Geometric sequence mathematics ও rank/term checks রাখা হয়েছে।
- Walk-forward/OOS validation ও baseline comparison রাখা হয়েছে।
- Correlated evidence-কে independent vote হিসেবে গণনা না করার guard রাখা হয়েছে।
- Research Cycle pre-lock dataset fingerprint করে এবং future/actual result lock-এর আগে engine-এ ঢুকতে দেয় না।
- Actual result-এর exact match, position/digit mismatch, nearest candidate এবং measurable structural differences সংরক্ষণ করা হয়।
- Research observations master dataset থেকে duplicate না হওয়ার জন্য reconciliation রাখা হয়েছে।
- Additive import/merge পুরনো data replace না করে নতুন draw যোগ করে এবং logical conflicts শনাক্ত করে।
- নতুন deterministic Research Cycle E2E test যোগ হয়েছে: `npm run test:research-cycle`।
- CI build pipeline-এ Research Cycle E2E gate যুক্ত হয়েছে।
- Android build-এর জন্য networked CI path রাখা হয়েছে।

## Data continuity

পুরনো master data নতুন import-এর কারণে silently delete/replace করার অনুমতি নেই। Native Android-এ SQLite primary persistence; browser/PWA-তে IndexedDB fallback/persistence path ব্যবহৃত হয়। Legacy migration/import আলাদা reconciliation path দিয়ে করা হয়।

## Free-use scope

কোনো paid API বা paid prediction service প্রয়োজনীয় dependency হিসেবে রাখা হয়নি। OCR-এর বর্তমান web path একটি free CDN resource ব্যবহার করে; সম্পূর্ণ offline OCR-এর জন্য dependency bundle আলাদা build-time artifact হিসেবে যোগ করতে হবে।

## Release honesty

এই sandbox-এ npm registry access timeout এবং Android SDK/Gradle project generation locally unavailable হওয়ায় APK build/install/device E2E এখানে certified নয়। Source-level audits এবং Research Cycle E2E এই environment-এ চালিয়ে PASS পাওয়া গেছে। Networked CI workflow-তেই web build ও Android Gradle build-এর সম্পূর্ণ gate চালানো হবে।

## গবেষণামূলক সীমা

সব analysis historical evidence/signals ও validation metrics দেয়। কোনো module বা formula ভবিষ্যৎ ফল নিশ্চিত করে না।
