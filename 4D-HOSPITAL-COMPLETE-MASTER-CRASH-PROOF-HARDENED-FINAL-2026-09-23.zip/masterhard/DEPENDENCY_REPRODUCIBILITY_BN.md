# Dependency Reproducibility

- `package.json` must not contain `latest`, `*`, or open-ended dependency tags.
- `.npmrc` enables exact dependency saves and strict Node engine checking.
- A committed `package-lock.json` is required before declaring the dependency-lock gate PASS.
- The current sandbox cannot reach the npm registry, so the lockfile cannot be generated here without inventing integrity data. CI/build machines with registry access must run `npm install` once and commit the resulting lockfile; subsequent builds must use `npm ci`.
- Android/iOS dependencies are likewise resolved from the committed lockfile and Capacitor platform sync.
