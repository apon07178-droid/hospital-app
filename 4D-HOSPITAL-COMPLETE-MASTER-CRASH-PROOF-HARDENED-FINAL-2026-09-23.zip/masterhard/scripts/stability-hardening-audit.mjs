import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const app = fs.readFileSync(path.join(root,'App.tsx'),'utf8');
const worker = fs.readFileSync(path.join(root,'lib','analysis-worker.ts'),'utf8');
const sqlite = fs.readFileSync(path.join(root,'lib','sqlite-results.ts'),'utf8');
const web = fs.readFileSync(path.join(root,'lib','web-results-store.ts'),'utf8');

const checks = [
  ['heavy analysis moved to Web Worker', /new Worker\(new URL\('\.\/lib\/analysis-worker\.ts'/.test(app) && /runHistoricalAnalysisCore/.test(worker)],
  ['analysis timeout/termination guard', /timeoutMs|worker\.terminate\(\)/.test(app)],
  ['stale analysis job guard', /analysisJobRef/.test(app)],
  ['React error boundary', /class AppErrorBoundary extends Component/.test(app)],
  ['global error/rejection logging', /unhandledrejection/.test(app) && /window-error/.test(app)],
  ['SQLite persistence queue', /sqliteWriteQueue/.test(sqlite)],
  ['IndexedDB persistence queue', /webWriteQueue/.test(web)],
  ['SQLite rollback on failure', /ROLLBACK/.test(sqlite)],
  ['IndexedDB transaction abort handling', /tx\.onabort/.test(web)],
  ['no synchronous historical-core call in App', !/const historicalCore = useMemo\(\(\) => .*runHistoricalAnalysisCore/.test(app)],
];
let failed = 0;
for (const [name, ok] of checks) console.log(`${ok ? 'PASS' : 'FAIL'}: ${name}`), failed += ok ? 0 : 1;
process.exitCode = failed ? 2 : 0;
