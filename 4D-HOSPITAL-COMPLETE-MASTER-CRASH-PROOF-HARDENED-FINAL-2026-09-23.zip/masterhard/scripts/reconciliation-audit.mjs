import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const must=[
 'lib/analysis-catalog.ts','lib/analysis-contract.ts','lib/canonical-data.ts',
 'lib/data-merge.ts','lib/scorer.ts','lib/advanced-validation.ts',
 'lib/research-cycle.ts','lib/sqlite-results.ts','App.tsx',
 'docs/00-MASTER/MASTER_RECONCILIATION_2026-09-22_BN.md',
 'docs/01-107-ANALYSIS/107-Analysis-Master-Matrix.md',
 'docs/02-RESULT-SHEET/RESULT_SHEET_SPEC_BN.md',
 'docs/03-DATA-STORAGE/DATA_CONTINUITY_MASTER_BN.md',
 'docs/04-MATHEMATICAL-ARCHITECTURE/107-Analysis-Family-Architecture-v2.md',
 'docs/05-E2E-RELEASE/FINAL_RELEASE_GATE_BN.md'
];
const missing=must.filter(f=>!fs.existsSync(path.join(root,f)));
if(missing.length) throw new Error('Missing reconciliation artifacts: '+missing.join(', '));
const catalog=fs.readFileSync(path.join(root,'lib/analysis-catalog.ts'),'utf8');
const contract=fs.readFileSync(path.join(root,'lib/analysis-contract.ts'),'utf8');
const names=[...catalog.matchAll(/\['([^']+)',\[(.*?)\],'[^']*'\]/gs)].flatMap(m=>[...m[2].matchAll(/'([^']+)'/g)].map(x=>x[1])).slice(0,107);
if(names.length!==107 || new Set(names).size!==107) throw new Error('107 public catalog uniqueness failed');
if(!contract.includes('implementationStatus')||!contract.includes('dependencyIds')||!contract.includes('dependencyType')) throw new Error('analysis contract incomplete');
const app=fs.readFileSync(path.join(root,'App.tsx'),'utf8');
if(!/Result Sheet|চূড়ান্ত ফলাফল|STAGE 3 — Borda Count Final Ranking/.test(app)) throw new Error('Result output UI evidence missing');
console.log('RECONCILIATION AUDIT PASS: 107 catalog + contract + canonical docs + result-sheet evidence + storage/e2e docs present.');
