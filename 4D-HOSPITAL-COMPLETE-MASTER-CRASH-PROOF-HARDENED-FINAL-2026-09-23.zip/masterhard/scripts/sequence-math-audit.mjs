import assert from 'node:assert/strict';

const diff = (a, order=1) => {
  let x=[...a];
  for(let k=0;k<order;k++) x=x.slice(1).map((v,i)=>v-x[i]);
  return x;
};
const approx=(a,b)=>Math.abs(a-b)<=1e-10*Math.max(1,Math.abs(a),Math.abs(b));
const arith=(a,d,n)=>a+(n-1)*d;
const geo=(a,r,n)=>a*r**(n-1);
const arank=(term,a,d)=>{if(approx(d,0))return approx(term,a)?1:null;const n=1+(term-a)/d;return Number.isInteger(n)&&n>=1?n:null};
const grank=(term,a,r)=>{if(approx(a,0))return approx(term,0)?1:null;if(approx(r,0))return approx(term,a)?1:null;const n=1+Math.log(Math.abs(term/a))/Math.log(Math.abs(r));const rn=Math.round(n);return rn>=1&&approx(n,rn)&&approx(geo(a,r,rn),term)?rn:null};

assert.deepEqual(diff([2,5,8,11]),[3,3,3]);
assert.deepEqual(diff([2,5,8,11],2),[0,0]);
assert.equal(arith(2,3,5),14);
assert.equal(arank(14,2,3),5);
assert.equal(arank(15,2,3),null);
assert.equal(geo(2,3,4),54);
assert.equal(grank(54,2,3),4);
assert.equal(grank(55,2,3),null);
console.log('SEQUENCE MATH AUDIT PASS');
