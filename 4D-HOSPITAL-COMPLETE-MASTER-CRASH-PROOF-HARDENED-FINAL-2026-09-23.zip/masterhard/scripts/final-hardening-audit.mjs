import fs from 'node:fs';
const files=['App.tsx','lib/sqlite-results.ts','lib/web-results-store.ts','lib/backup-crypto.ts','capacitor.config.ts','package.json'];
for(const f of files) if(!fs.existsSync(f)) throw new Error(`Missing ${f}`);
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const all={...(pkg.dependencies||{}),...(pkg.devDependencies||{})};
const latest=Object.entries(all).filter(([,v])=>String(v).includes('latest'));
const duplicateSrc=fs.existsSync('src');
console.log(JSON.stringify({
  canonicalSourceTree: !duplicateSrc,
  nativeSqliteEncryption: /androidIsEncryption:\s*true/.test(fs.readFileSync('capacitor.config.ts','utf8')),
  legacySqliteMigration: /migrateLegacySQLiteDatabases/.test(fs.readFileSync('lib/sqlite-results.ts','utf8')),
  encryptedBackups: /AES-256-GCM/.test(fs.readFileSync('lib/backup-crypto.ts','utf8')),
  indexedDbAtomicDurability: /durability/.test(fs.readFileSync('lib/web-results-store.ts','utf8')),
  forbiddenLatestDependencies: latest.map(([k,v])=>[k,v]),
  lockfilePresent: fs.existsSync('package-lock.json'),
  backendRequired: false,
  predictionGuarantee: false
},null,2));
process.exit(duplicateSrc || latest.length || !fs.existsSync('package-lock.json') ? 2 : 0);
