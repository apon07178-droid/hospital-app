import fs from 'node:fs';
const p='lib/analysis-engine-107.ts'; const s=fs.readFileSync(p,'utf8');
const checks=[
 ['AR(1) engine',/model:'AR\(1\)'/],
 ['tree-style engine',/Deterministic decision-stump ensemble/],
 ['recurrent engine',/Offline recurrent\/LSTM-style digit encoder/],
 ['walk-forward AR',/arTests/],
 ['walk-forward tree',/treeTests/],
 ['recurrent holdout',/holdoutTests/]
];
for(const [n,r] of checks) if(!r.test(s)) throw new Error('FAIL '+n);
console.log('ADVANCED MODEL LAYER AUDIT PASS');
