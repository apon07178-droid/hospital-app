import fs from 'node:fs';
const layer=fs.readFileSync('lib/research-layers.ts','utf8');
const scorer=fs.readFileSync('lib/scorer.ts','utf8');
const app=fs.readFileSync('App.tsx','utf8');
const required=['WalkForward20','OOSStability','DriftRegime','ModelAgreement','AblationSensitivity','EvidenceScorecard'];
for(const x of required) if(!layer.includes(x)) throw new Error('Missing research layer: '+x);
for(const x of ['runResearchLayers','researchLayers']) if(!scorer.includes(x)) throw new Error('Scorer integration missing: '+x);
for(const x of ['Walk-Forward 2.0','OOS Stability','Drift / Regime Detection','Model Agreement / Disagreement','Ablation + Sensitivity','Evidence / Uncertainty Scorecard']) if(!app.includes(x)) throw new Error('UI layer missing: '+x);
console.log('CORE RESEARCH LAYERS AUDIT PASS: 6 meta-validation layers integrated; no expansion of the public 107-analysis catalog.');
