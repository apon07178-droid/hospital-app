import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const catalog = fs.readFileSync(path.join(root, 'lib/analysis-catalog.ts'), 'utf8');
const names = [...catalog.matchAll(/\['([^']+)',\[(.*?)\],'[^']*'\]/gs)]
  .flatMap(m => [...m[2].matchAll(/'([^']+)'/g)].map(x => x[1]));
const publicCount = Math.min(names.length, 107);
const unique = new Set(names.slice(0, publicCount));
const contract = fs.readFileSync(path.join(root, 'lib/analysis-contract.ts'), 'utf8');
const canonical = fs.readFileSync(path.join(root, 'lib/canonical-data.ts'), 'utf8');
const required = [
  'App.tsx','lib/scorer.ts','lib/pipeline.ts','lib/advanced-models.ts',
  'lib/advanced-validation.ts','lib/research-cycle.ts','lib/sqlite-results.ts','lib/web-results-store.ts','lib/sequence-math.ts','lib/analysis-contract.ts','lib/canonical-data.ts'
];
const missing = required.filter(f => !fs.existsSync(path.join(root, f)));
if (publicCount !== 107) throw new Error(`Expected 107 public catalog entries, found ${publicCount}`);

if (!contract.includes('implementationStatus') || !contract.includes('IMPLEMENTATION_STATUS')) throw new Error('Numbered implementation-status contract missing');
if (!contract.includes('dependencyIds') || !contract.includes('dependencyType')) throw new Error('Formal dependency contract missing');
if (!canonical.includes('targetDefinition') || !canonical.includes('CANONICAL_DATASET_SCHEMA_VERSION')) throw new Error('Canonical dataset/target contract missing');
const contractIds=[...contract.matchAll(/Array\.from\(\{length:107\}/g)].length;
if (!contractIds) throw new Error('107 analysis contract registry missing');
if (contract.includes('dependencyIds: [1') && contract.includes('dependencyIds: [1')) { /* dependency graph is checked below by source function */ }

if (unique.size !== 107) throw new Error(`Duplicate analysis names detected: ${107-unique.size}`);
if (missing.length) throw new Error(`Missing core files: ${missing.join(', ')}`);
const app = fs.readFileSync(path.join(root, 'App.tsx'), 'utf8');
if (!app.includes('}, [analysis, engineResult]);')) throw new Error('Pipeline memo dependency guard missing');
const validation = fs.readFileSync(path.join(root, 'lib/advanced-validation.ts'), 'utf8');
if (!validation.includes('const train=validDraws.slice(0,start);')) throw new Error('Chronological blocked K-fold guard missing');
const scorer = fs.readFileSync(path.join(root, 'lib/scorer.ts'), 'utf8');
if (!scorer.includes('const pairKeys=[[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]]')) throw new Error('Canonical 6-pair coverage missing');
if (!scorer.includes('const tripKeys=[[0,1,2],[0,1,3],[0,2,3],[1,2,3]]')) throw new Error('Canonical 4-triplet coverage missing');
if (scorer.includes('out.crosscompany=out.pair*0.6+out.position*0.4')) throw new Error('Cross-company proxy still active');
if (scorer.includes('out.backtest=0.5')) throw new Error('Fake 0.5 backtest still active');
if (!scorer.includes('transitions:Array<Record<string,number>>=Array.from({length:4}')) throw new Error('Transition state must be position-aware');
const sequence = fs.readFileSync(path.join(root, 'lib/sequence-math.ts'), 'utf8');
for (const token of ['analyzeArithmeticSequence','nthArithmeticTerm','arithmeticRankOfTerm','analyzeGeometricSequence','nthGeometricTerm','geometricRankOfTerm']) if (!sequence.includes(`export function ${token}`)) throw new Error(`Explicit sequence math missing: ${token}`);
const webStore = fs.readFileSync(path.join(root, 'lib/web-results-store.ts'), 'utf8');
if (!webStore.includes('indexedDB') || !webStore.includes('10k+')) throw new Error('Large web dataset IndexedDB store missing');
const sqlite = fs.readFileSync(path.join(root, 'lib/sqlite-results.ts'), 'utf8');
const resultsCreate = sqlite.slice(sqlite.indexOf('CREATE TABLE IF NOT EXISTS results'), sqlite.indexOf(');', sqlite.indexOf('CREATE TABLE IF NOT EXISTS results')) + 2);
if (/UNIQUE\s*\(\s*company\s*,\s*date\s*\)/i.test(resultsCreate)) throw new Error('New SQLite schema must allow multiple draws per date');
const appSource = fs.readFileSync(path.join(root, 'App.tsx'), 'utf8');
if (!appSource.includes('mergeRows(results,clean)')) throw new Error('Central import merge guard missing');
if (!appSource.includes('loadResultsFromWebStore') || !appSource.includes('saveResultsToWebStore')) throw new Error('Web durable result-store integration missing');
const canonicalSource = canonical;
if (!canonicalSource.includes('r.special.every') || !canonicalSource.includes('r.consolation.every')) throw new Error('Canonical list validation guard missing');
if (appSource.includes('actualBatch.map((num,i)=>({id:startId+i') && appSource.includes('second:"",third:""')) throw new Error('Incomplete Research Cycle records must not enter master dataset');
console.log(`STATIC AUDIT PASS: ${publicCount} public analysis entries, unique; core files present; validation guards; canonical pairs/triplets; SQLite multi-draw schema; additive import merge; no fake backtest/cross-company proxy.`);
