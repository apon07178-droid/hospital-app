import fs from 'node:fs';
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const all={...(pkg.dependencies||{}),...(pkg.devDependencies||{})};
const bad=Object.entries(all).filter(([,v])=>typeof v==='string' && /^(latest|\*|[~^]|>=|>|<=|<)/.test(v));
if(bad.length){ console.error('Unpinned dependencies:',bad.map(([k,v])=>`${k}=${v}`).join(', ')); process.exit(1); }
if(!fs.existsSync('package-lock.json')){ console.error('package-lock.json missing: dependency lock gate is NOT PASS'); process.exit(2); }
const lock=JSON.parse(fs.readFileSync('package-lock.json','utf8'));
if(lock.lockfileVersion!==3){ console.error('package-lock.json must use lockfileVersion 3'); process.exit(3); }
console.log('Dependency lock gate PASS');
