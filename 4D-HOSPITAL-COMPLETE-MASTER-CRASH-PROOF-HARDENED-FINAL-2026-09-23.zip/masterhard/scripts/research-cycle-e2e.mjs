import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const root = process.cwd();
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), '4d-hospital-e2e-'));
const compiled = path.join(tmp, 'compiled');
fs.mkdirSync(compiled, { recursive: true });

try {
  execFileSync('tsc', [
    '--target', 'ES2022',
    '--module', 'commonjs',
    '--moduleResolution', 'node',
    '--skipLibCheck',
    '--outDir', compiled,
    'lib/research-cycle.ts',
    'lib/data-merge.ts',
    'lib/research-observations.ts',
  ], { cwd: root, stdio: 'inherit' });

  globalThis.localStorage = {
    _m: new Map(),
    getItem(k) { return this._m.has(k) ? this._m.get(k) : null; },
    setItem(k, v) { this._m.set(k, String(v)); },
    removeItem(k) { this._m.delete(k); },
  };

  const { createLockedCycle, validateLockedCycle, markCycleApplied, cycleSummary } = await import(pathToFile(compiled, 'research-cycle.js'));
  const { mergeRows } = await import(pathToFile(compiled, 'data-merge.js'));
  const { addResearchObservations, observationsForTraining } = await import(pathToFile(compiled, 'research-observations.js'));

  const rows = [];
  for (let i = 0; i < 20; i++) {
    const first = String(1000 + ((i * 137) % 9000)).padStart(4, '0');
    rows.push({
      id: i + 1,
      company: 'E2E-TEST',
      date: `2026-07-${String((i % 20) + 1).padStart(2, '0')}`,
      drawNo: String(i + 1),
      first,
      second: String(2000 + i).padStart(4, '0'),
      third: String(3000 + i).padStart(4, '0'),
      special: [],
      consolation: [],
    });
  }

  const cycle = createLockedCycle('E2E-TEST', rows, 2, 20);
  assert.equal(cycle.status, 'LOCKED');
  assert.equal(cycle.trainingCount, 20);
  assert.ok(cycle.datasetFingerprint);
  assert.ok(cycle.lockedCandidates.length > 0);

  const exact = cycle.lockedCandidates[0].num;
  const mismatch = exact === '9999' ? '8888' : '9999';
  const validated = validateLockedCycle(cycle, [exact, mismatch], '2026-09-22');
  assert.equal(validated.status, 'VALIDATED');
  assert.deepEqual(validated.validationFinal.exactMatches, [exact]);
  assert.deepEqual(validated.validationFinal.unmatched, [mismatch]);
  assert.equal(validated.validationFinal.totalActual, 2);
  assert.equal(validated.validationFinal.trace.length, 2);
  assert.equal(validated.validationFinal.mismatchDiagnostics.length, 1);
  assert.ok(validated.validationFinal.aggregate.commonFactors.length > 0);

  const applied = markCycleApplied(validated);
  assert.equal(applied.status, 'APPLIED');

  let observations = addResearchObservations([], 'E2E-TEST', '2026-09-22', [exact, mismatch, exact], applied.id);
  assert.equal(observations.length, 2, 'duplicate actual numbers must not duplicate observations');
  observations = addResearchObservations(observations, 'E2E-TEST', '2026-09-22', [exact], applied.id);
  assert.equal(observations.length, 2, 'same observation must remain idempotent');
  const trainingObs = observationsForTraining(observations, [{ company: 'E2E-TEST', date: '2026-09-22', first: exact }]);
  assert.equal(trainingObs.length, 1, 'master draw must suppress the matching research observation');

  const incoming = [
    { ...rows[0], id: 999 },
    { id: 1000, company: 'E2E-TEST', date: '2026-09-22', drawNo: '21', first: exact, second: '1111', third: '2222', special: [], consolation: [] },
  ];
  const merged = mergeRows(rows, incoming);
  assert.equal(merged.length, 21, 'new draw must append while same logical key is reconciled');
  assert.equal(merged.find(r => r.company === 'E2E-TEST' && r.date === rows[0].date && r.drawNo === rows[0].drawNo).id, rows[0].id);

  const summary = cycleSummary([applied]);
  assert.equal(summary.totalCycles, 1);
  assert.equal(summary.applied, 1);

  console.log('RESEARCH CYCLE E2E PASS');
  console.log(JSON.stringify({
    training: cycle.trainingCount,
    candidates: cycle.lockedCandidates.length,
    exactMatches: validated.validationFinal.exactMatches.length,
    unmatched: validated.validationFinal.unmatched.length,
    mismatchDiagnostics: validated.validationFinal.mismatchDiagnostics.length,
    observations: observations.length,
    mergedRows: merged.length,
  }, null, 2));
} finally {
  fs.rmSync(tmp, { recursive: true, force: true });
}

function pathToFile(dir, name) {
  return path.join(dir, name);
}
