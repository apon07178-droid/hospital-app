# 4D HOSPITAL — Final Release Gate

এই release-এ runtime source এবং audit source একই root codebase (`App.tsx`, `lib/`, `components/`) থেকে যাচাই করা হয়। পুরনো duplicate `src/` snapshot build/typecheck path থেকে বাদ রাখা হয়েছে যাতে audit/runtime drift না হয়; snapshot-এর ফাইল ZIP-এ সংরক্ষিত আছে।

## Local gates
1. `npm install --no-audit --no-fund`
2. `npm run typecheck`
3. `npm run audit:static`
4. `npm run audit:runtime-contract`
5. `npm run build`
6. `npx cap add android`
7. `npx cap sync android`
8. `cd android && ./gradlew assembleDebug`

## Data/research gates
- Existing + imported data are merged additively.
- Invalid non-4-digit rows are rejected.
- Locked research cycle uses only pre-lock data.
- Actual result is validated after the lock.
- Exact/digit/position/mismatch diagnostics are retained.
- Feedback observations are available to subsequent research cycles.
- Duplicate actual-result observations are reconciled.

## Release honesty
এই environment-এ npm registry access timeout হওয়ায় dependency installation এবং Android Gradle execution locally certified করা হয়নি। তাই APK PASS দাবি করা হয়নি। Included GitHub Actions workflows perform the complete dependency → web build → Capacitor → Gradle APK gate when run in a networked CI environment.
