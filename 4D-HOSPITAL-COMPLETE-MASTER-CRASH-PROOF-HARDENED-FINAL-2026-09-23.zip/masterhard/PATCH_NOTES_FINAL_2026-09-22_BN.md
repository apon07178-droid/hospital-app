# Final Patch Notes — 2026-09-22

1. Added `src/lib/analysis-contract.ts`.
2. Added `src/lib/canonical-data.ts`.
3. Extended `analysis-catalog.ts` with status/family/definition/input/output/data/dependency/target/validation metadata.
4. Extended Analysis Catalog UI with the new metadata columns.
5. Fixed all six pair and four triplet scorer coverage.
6. Fixed chronological transition direction.
7. Replaced ad-hoc regression score with a historical linear trend estimate.
8. Hardened merge identity for same-date multi-draw data.
9. Hardened strict 4-digit input/import handling.
10. Hardened backup restore against invalid rows.
11. Made SQLite sync transactional.
12. Unified mirror mapping in the 6D extension.
13. Strengthened static audit for the new contracts.
