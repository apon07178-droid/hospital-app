# 4D Hospital — Crash-Proof / Stability Hardening — 2026-09-23

## Completed source-level hardening

1. **Heavy research analysis moved off the UI thread**
   - `runHistoricalAnalysisCore()` now runs inside `lib/analysis-worker.ts`.
   - Prevents the React/Android WebView main thread from being blocked by the 107-analysis + signal engine on large datasets.

2. **Stale-job protection**
   - Every analysis run receives a job id.
   - If new data arrives before the previous analysis completes, the previous worker is terminated and its result is ignored.

3. **Analysis timeout protection**
   - Long-running analysis is automatically terminated after a bounded timeout.
   - The saved dataset is not modified by analysis timeout/failure.

4. **React crash containment**
   - Added `AppErrorBoundary`.
   - A render/component exception shows a recovery screen instead of leaving a blank/broken WebView.
   - A small crash log is kept locally for diagnostics.

5. **Unhandled runtime error logging**
   - `window.error` and `unhandledrejection` are captured into a bounded local security-event log.

6. **Serialized SQLite writes**
   - Rapid React state changes can no longer start overlapping SQLite write transactions.
   - Writes are queued and run one at a time.
   - Existing transaction rollback remains active.

7. **Serialized IndexedDB writes**
   - Rapid browser/PWA imports/edits are queued to avoid overlapping clear/put transactions.
   - Existing transaction abort/error checks remain active.

8. **Persistence promise handling**
   - Background persistence calls now attach rejection handlers so a storage failure does not become an unhandled promise rejection.

## What this does not claim

- This is **source-level crash/stability hardening**, not proof that no Android OS-level process kill can ever happen.
- A real APK build, physical-device stress test, Android logcat crash test, and 10,000+ record long-run test still require a networked Android build environment/device.
- No data is silently deleted to reduce memory usage.
