# 4D Hospital — Master Merge Audit — 2026-09-23

এই package-টি 2026-09-23-এর user-supplied MASTER/RESEARCH CENTER ZIP এবং 2026-09-22-এর SECURITY/STORAGE HARDENED ZIP-এর সমন্বিত source tree।

## Merge policy
- Research Center / 107-analysis inventory / 28 active signals / special modules / six meta-validation layers: latest MASTER/RESEARCH CENTER source retained.
- SQLite encryption, legacy SQLite migration, encrypted backup, IndexedDB durability, dependency reproducibility gates, Android emulator workflow: SECURITY/STORAGE HARDENED source retained.
- Public 107 analysis catalog is not expanded or silently reduced.
- Duplicate `src/` tree removed; root is the canonical source tree.
- Same Android applicationId remains `com.cbc.lt4my.hospital` for update continuity.

## OCR network rule
- Silent CDN OCR loading is disabled.
- The browser build does not silently download an OCR engine.
- Android release requirement: OCR engine/model must be bundled locally before claiming fully offline OCR PASS.
- Therefore this package does not falsely mark Android offline OCR as device-certified PASS without an actual APK/device test.

## Storage rule
- Existing/legacy SQLite sources are migrated additively when accessible in the same Android application sandbox.
- Encrypted backup uses AES-256-GCM with password-derived key material.
- Web result persistence uses IndexedDB with atomic write/integrity metadata.

## Verification
- Research inventory audit: PASS.
- Six research-layer audit: PASS.
- Storage/security source audit: PASS.
- Dependency lock gate: pending until a networked build environment can generate and commit `package-lock.json`.
- APK/device E2E: not claimed from this sandbox.
