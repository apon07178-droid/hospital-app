# Security / Storage Hardening Status

## Completed in source
- Native Android SQLite encryption is enabled through Capacitor SQLite SQLCipher configuration.
- A device-local random 256-bit-equivalent secret is generated once and stored by the plugin secure store; it is never stored in app source or localStorage.
- Existing native plaintext DBs are opened through the plugin's `encryption` migration mode before normal encrypted operation.
- Known legacy DB names are scanned and merged additively without deleting the source database.
- Web IndexedDB writes now update data + integrity metadata in one readwrite transaction and request strict durability when supported.
- Backups are AES-256-GCM encrypted with a user password using PBKDF2-SHA256 (310,000 iterations). Wrong passwords and tampered ciphertext are rejected.
- Legacy unencrypted JSON backups remain importable for compatibility; new backups are encrypted.
- Duplicate `src/` source tree removed; root is the sole canonical source tree.

## Cannot honestly be certified inside this sandbox
- A real Android device install/E2E test.
- npm lockfile generation because registry DNS/network access is unavailable here.
- Full bundled/offline OCR runtime until the native OCR dependency/model is installed and exercised in an Android build environment.

## Product decision
No production backend/authentication service is required for the free/offline app. Local authentication remains local-only; no paid cloud service is introduced.
