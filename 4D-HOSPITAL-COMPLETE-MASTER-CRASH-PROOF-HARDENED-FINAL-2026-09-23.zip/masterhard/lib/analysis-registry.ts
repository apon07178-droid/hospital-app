import { runHistoricalAnalysisCore, type HistoricalAnalysisCoreResult } from './historical-analysis-core';
import { ANALYSIS_CONTRACTS, validateAnalysisContracts } from './analysis-contract';
import type { CanonicalDraw } from './canonical-data';

export interface CentralAnalysisRegistryResult extends HistoricalAnalysisCoreResult {
  registryVersion: '107-registry-v1';
  contractCount: number;
  contractErrors: string[];
  executableIds: number[];
}

/** One public boundary for the historical analysis layer. */
export function runCentralAnalysisRegistry(draws: CanonicalDraw[], datasetVersion='runtime'): CentralAnalysisRegistryResult {
  const report = runHistoricalAnalysisCore(draws, datasetVersion);
  const contractErrors = validateAnalysisContracts();
  const executableIds = report.analysis107.filter(x => x.applicable).map(x => x.id);
  return { ...report, registryVersion:'107-registry-v1', contractCount:ANALYSIS_CONTRACTS.length, contractErrors, executableIds };
}
