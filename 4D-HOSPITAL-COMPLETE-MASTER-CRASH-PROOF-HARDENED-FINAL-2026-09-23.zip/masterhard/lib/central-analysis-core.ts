/**
 * 4D HOSPITAL — Central Analysis Core
 * One canonical input -> 107 historical modules + 28 signal layer -> one report.
 * Historical evidence only; no guaranteed future-result claim.
 */
import { run107Analysis, type Analysis107Result } from './analysis-engine-107';
import { runPatternEngine, type DrawEntry, type EngineAnalysis } from './scorer';
import type { CanonicalDraw } from './canonical-data';

export interface CentralAnalysisReport {
  version: 'central-core-v1';
  dataset: { rows: number; valid4D: number; companies: number; dateMin: string|null; dateMax: string|null };
  analyses107: Analysis107Result[];
  signals28: EngineAnalysis;
  resultSheet: {
    analysisCount: number;
    signalCount: number;
    implemented: number;
    insufficientData: number;
    validationModules: number;
    modelModules: number;
    historicalEvidenceOnly: true;
  };
}

function toDraws(rows: CanonicalDraw[]): DrawEntry[] {
  return rows.map(r => ({first:r.first,second:r.second,third:r.third,special:r.special||[],consolation:r.consolation||[],date:r.date}));
}

export function runCentralAnalysisCore(rows: CanonicalDraw[], topN=20): CentralAnalysisReport {
  const ordered = [...rows].sort((a,b)=>a.date.localeCompare(b.date)||a.company.localeCompare(b.company)||String(a.drawNo??'').localeCompare(String(b.drawNo??''))||a.id-b.id);
  const analyses107 = run107Analysis(ordered);
  const signals28 = runPatternEngine(toDraws(ordered), topN);
  const dates = ordered.map(x=>x.date).filter(Boolean).sort();
  return {
    version:'central-core-v1',
    dataset:{rows:ordered.length,valid4D:ordered.filter(x=>/^\d{4}$/.test(x.first)).length,companies:new Set(ordered.map(x=>x.company)).size,dateMin:dates[0]??null,dateMax:dates[dates.length-1]??null},
    analyses107,
    signals28,
    resultSheet:{
      analysisCount:analyses107.length,
      signalCount:28,
      implemented:analyses107.filter(x=>x.status===1||x.status===3||x.status===4).length,
      insufficientData:analyses107.filter(x=>x.status===5).length,
      validationModules:analyses107.filter(x=>x.status===4).length,
      modelModules:analyses107.filter(x=>x.id>=104).length,
      historicalEvidenceOnly:true
    }
  };
}
