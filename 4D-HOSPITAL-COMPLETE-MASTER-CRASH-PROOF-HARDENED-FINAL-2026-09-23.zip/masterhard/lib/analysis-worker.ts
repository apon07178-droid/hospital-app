import { runHistoricalAnalysisCore } from './historical-analysis-core';
import type { CanonicalDraw } from './canonical-data';

self.onmessage = (event: MessageEvent<{draws: CanonicalDraw[]; datasetVersion: string}>) => {
  try {
    const draws = Array.isArray(event.data?.draws) ? event.data.draws : [];
    const result = runHistoricalAnalysisCore(draws, String(event.data?.datasetVersion || 'runtime'));
    self.postMessage({ ok: true, result });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    self.postMessage({ ok: false, error: message });
  }
};
