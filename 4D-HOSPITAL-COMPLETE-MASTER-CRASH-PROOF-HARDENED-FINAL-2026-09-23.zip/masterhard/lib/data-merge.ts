export interface MergeRow {
  id: number; company: string; date: string; drawNo: string | null;
  first: string; second: string; third: string; special: string[]; consolation: string[];
}

export interface MergeOptions { preferIncoming?: boolean; }

export function rowKey(r: Pick<MergeRow,'company'|'date'|'drawNo'|'id'> & Partial<Pick<MergeRow,'first'|'second'|'third'>>): string {
  const company=String(r.company||'').trim().toLowerCase();
  const date=String(r.date||'').slice(0,10);
  const draw=r.drawNo == null || String(r.drawNo).trim()==='' ? '' : String(r.drawNo).trim();
  // Without drawNo there is no safe date-only identity because multiple draws can
  // occur on one date. Use the complete main-prize tuple as the deterministic key;
  // a different result remains additive, while an exact duplicate is merged.
  return draw ? `${company}|${date}|DRAW:${draw}` : `${company}|${date}|RESULT:${String(r.first??'')}|${String(r.second??'')}|${String(r.third??'')}`;
}

export function rowFingerprint(r: MergeRow): string {
  return JSON.stringify({company:String(r.company).trim().toLowerCase(),date:String(r.date).slice(0,10),drawNo:r.drawNo==null?null:String(r.drawNo).trim(),first:r.first,second:r.second,third:r.third,special:r.special??[],consolation:r.consolation??[]});
}

export interface MergeConflict<T extends MergeRow> { key: string; existing: T; incoming: T; }

/**
 * Additive merge. By default an existing logical record wins; imports therefore
 * cannot silently overwrite historical data. `preferIncoming` is reserved for
 * trusted source reconciliation (for example native SQLite over a legacy mirror).
 */
export function mergeRows<T extends MergeRow>(existing:T[], incoming:T[], options:MergeOptions={}): T[] {
  const preferIncoming=options.preferIncoming===true;
  const map=new Map<string,T>();
  for(const r of existing) map.set(rowKey(r),r);
  for(const r of incoming){
    const k=rowKey(r);
    const prior=map.get(k);
    map.set(k, prior && !preferIncoming ? prior : (prior ? {...prior,...r,id:prior.id} : r));
  }
  const used=new Set<number>(); let next=1;
  return [...map.values()].map(r=>{
    let id=Number(r.id);
    if(!Number.isSafeInteger(id)||id<1||used.has(id)){ while(used.has(next)) next++; id=next; }
    used.add(id); next=Math.max(next,id+1);
    return {...r,id};
  }).sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id);
}

export function findMergeConflicts<T extends MergeRow>(existing:T[], incoming:T[]): MergeConflict<T>[] {
  const byKey=new Map(existing.map(r=>[rowKey(r),r]));
  const conflicts:MergeConflict<T>[]=[];
  for(const incomingRow of incoming){
    const prior=byKey.get(rowKey(incomingRow));
    if(prior && rowFingerprint(prior)!==rowFingerprint(incomingRow)) conflicts.push({key:rowKey(incomingRow),existing:prior,incoming:incomingRow});
  }
  return conflicts;
}
