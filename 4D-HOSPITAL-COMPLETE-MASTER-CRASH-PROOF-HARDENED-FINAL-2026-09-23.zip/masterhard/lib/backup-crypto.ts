/** 4D HOSPITAL encrypted backup envelope. Browser WebCrypto only; no server required. */
const PBKDF2_ITERATIONS = 310000;
const SALT_BYTES = 16;
const IV_BYTES = 12;
const te = new TextEncoder();
const td = new TextDecoder();

function b64(bytes: Uint8Array): string { return btoa(String.fromCharCode(...bytes)); }
function unb64(value: string): Uint8Array { return Uint8Array.from(atob(value), c => c.charCodeAt(0)); }

async function derive(password: string, salt: Uint8Array): Promise<CryptoKey> {
  if (password.length < 10) throw new Error('Backup password must be at least 10 characters.');
  const base = await crypto.subtle.importKey('raw', te.encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
    base,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt'],
  );
}

export interface EncryptedBackupEnvelope {
  app: '4D HOSPITAL';
  format: '4DH-BACKUP-AES256-GCM';
  version: 1;
  kdf: 'PBKDF2-SHA256';
  iterations: number;
  cipher: 'AES-256-GCM';
  salt: string;
  iv: string;
  ciphertext: string;
  createdAt: string;
}

export async function encryptBackup(plainText: string, password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(SALT_BYTES));
  const iv = crypto.getRandomValues(new Uint8Array(IV_BYTES));
  const key = await derive(password, salt);
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, te.encode(plainText));
  const envelope: EncryptedBackupEnvelope = {
    app: '4D HOSPITAL', format: '4DH-BACKUP-AES256-GCM', version: 1,
    kdf: 'PBKDF2-SHA256', iterations: PBKDF2_ITERATIONS, cipher: 'AES-256-GCM',
    salt: b64(salt), iv: b64(iv), ciphertext: b64(new Uint8Array(encrypted)), createdAt: new Date().toISOString(),
  };
  return JSON.stringify(envelope, null, 2);
}

export function isEncryptedBackup(value: any): value is EncryptedBackupEnvelope {
  return !!value && value.app === '4D HOSPITAL' && value.format === '4DH-BACKUP-AES256-GCM' &&
    value.version === 1 && value.kdf === 'PBKDF2-SHA256' && value.cipher === 'AES-256-GCM' &&
    typeof value.salt === 'string' && typeof value.iv === 'string' && typeof value.ciphertext === 'string';
}

export async function decryptBackup(envelope: EncryptedBackupEnvelope, password: string): Promise<string> {
  const key = await derive(password, unb64(envelope.salt));
  try {
    const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(envelope.iv) }, key, unb64(envelope.ciphertext));
    return td.decode(plain);
  } catch {
    throw new Error('Backup password ভুল, অথবা backup ফাইলটি পরিবর্তিত/ক্ষতিগ্রস্ত হয়েছে।');
  }
}
