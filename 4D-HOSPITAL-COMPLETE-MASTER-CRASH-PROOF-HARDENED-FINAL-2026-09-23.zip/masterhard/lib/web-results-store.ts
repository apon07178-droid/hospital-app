/**
 * Durable browser persistence for large datasets.
 * A single IndexedDB readwrite transaction updates data + commit metadata atomically.
 * localStorage remains a legacy migration source only.
 */
export interface WebStoredResult {
  id: number; company: string; date: string; drawNo: string | null;
  first: string; second: string; third: string; special: string[]; consolation: string[];
}

const DB_NAME = '4d-hospital-web';
const DB_VERSION = 2;
const STORE = 'results';
const META = 'meta';

function fingerprint(rows: WebStoredResult[]): string {
  const text=JSON.stringify([...rows].sort((a,b)=>a.id-b.id));
  let h=2166136261;
  for(let i=0;i<text.length;i++) h=Math.imul(h^text.charCodeAt(i),16777619);
  return `web2-${(h>>>0).toString(16).padStart(8,'0')}`;
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onupgradeneeded=()=>{
      const db=req.result;
      if(!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE,{keyPath:'id'});
      if(!db.objectStoreNames.contains(META)) db.createObjectStore(META,{keyPath:'key'});
    };
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error ?? new Error('IndexedDB open failed'));
  });
}

export async function loadResultsFromWebStore(): Promise<WebStoredResult[] | null> {
  if(typeof indexedDB==='undefined') return null;
  const db=await openDb();
  try{
    return await new Promise<WebStoredResult[]>((resolve,reject)=>{
      const tx=db.transaction([STORE,META],'readonly');
      const req=tx.objectStore(STORE).getAll();
      const metaReq=tx.objectStore(META).get('dataset');
      tx.oncomplete=()=>{
        const rows=(req.result??[]) as WebStoredResult[];
        const meta=metaReq.result as {key:string;fingerprint:string;count:number}|undefined;
        if(meta && (meta.count!==rows.length || meta.fingerprint!==fingerprint(rows))) return reject(new Error('IndexedDB integrity check failed; stored dataset was not accepted.'));
        // v1 databases have no metadata store contents; accept them once and let the next atomic save seal them with integrity metadata.
        resolve(rows);
      };
      tx.onerror=()=>reject(tx.error ?? new Error('IndexedDB read failed'));
      tx.onabort=()=>reject(tx.error ?? new Error('IndexedDB read aborted'));
    });
  } finally { db.close(); }
}

async function saveResultsToWebStoreNow(rows: WebStoredResult[]): Promise<boolean> {
  if(typeof indexedDB==='undefined') return false;
  const db=await openDb();
  try{
    await new Promise<void>((resolve,reject)=>{
      let tx: IDBTransaction;
      try { tx=db.transaction([STORE,META],'readwrite',{durability:'strict'} as IDBTransactionOptions); }
      catch { tx=db.transaction([STORE,META],'readwrite'); }
      const store=tx.objectStore(STORE);
      store.clear();
      for(const row of rows) store.put(row);
      tx.objectStore(META).put({key:'dataset',version:2,count:rows.length,fingerprint:fingerprint(rows),savedAt:new Date().toISOString()});
      tx.oncomplete=()=>resolve();
      tx.onerror=()=>reject(tx.error ?? new Error('IndexedDB write failed'));
      tx.onabort=()=>reject(tx.error ?? new Error('IndexedDB write aborted'));
    });
    return true;
  } finally { db.close(); }
}

export async function clearResultsFromWebStore(): Promise<boolean> {
  return saveResultsToWebStore([]);
}


// Serialize IndexedDB writes so rapid imports/edits cannot overlap clear/put
// transactions and produce intermittent quota/transaction failures.
let webWriteQueue: Promise<boolean> = Promise.resolve(true);
export function saveResultsToWebStore(rows: WebStoredResult[]): Promise<boolean> {
  const job = webWriteQueue.then(() => saveResultsToWebStoreNow(rows));
  webWriteQueue = job.catch(() => false);
  return job;
}
