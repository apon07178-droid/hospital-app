/**
 * Master inventory for the complete research stack.
 * Counts are intentionally separated by layer so overlapping methods are not
 * double-counted as if they were independent analyses.
 */
export const VALIDATION_LAYERS = [
  { id: 'WF20', name: 'Walk-Forward 2.0', purpose: 'chronological multi-window out-of-sample validation' },
  { id: 'OOS', name: 'OOS Stability', purpose: 'rolling top-set and top-1 stability' },
  { id: 'DRIFT', name: 'Drift / Regime Detection', purpose: 'recent-vs-baseline distribution and regime change' },
  { id: 'AGREEMENT', name: 'Model Agreement / Disagreement', purpose: 'independent method consensus and disagreement' },
  { id: 'ABLATION', name: 'Ablation + Sensitivity', purpose: 'signal contribution sensitivity' },
  { id: 'EVIDENCE', name: 'Evidence / Uncertainty Scorecard', purpose: 'evidence strength and uncertainty diagnostics' },
] as const;

export const LEGACY_MODEL_CHANNELS = [
  '30-Day Position Frequency', '90-Day Position Frequency', 'Triplet + Position',
  'Hot Digit Frequency', "Benford's Law", 'Mirror Digit', 'Neighbor Digits (n±1)',
  'High/Low Pattern', 'Calendar Day Sync', 'Permutation Box', 'Markov Chain',
] as const;

/** The Smart Generator currently contains 27 numbered analytical paths plus a separate aggregation/ranking stage. */
export const SMART_GENERATOR_PATHS = [
  'Position frequency', 'Hot digits', 'Pair frequency', 'Triplet frequency',
  'Markov chain', 'Mirror + Neighbor', 'High/Low pattern', 'Benford-style weighting',
  'Gap / overdue', 'Digit sum pattern', 'Even/Odd balance', 'Calendar / day-of-week',
  'Sliding-window trend', 'Permutation', 'Digit diversity', 'Cross-company correlation',
  'Regression trend', 'LSTM-like sequence signal', 'Genetic search', 'Skip-draw',
  'Cold-digit opportunity', 'Backtest proxy', 'Digit spread', 'Consensus boost',
  'Recency penalty', 'Bayesian/Laplace smoothing', 'Anti-repeat / diversity guard',
] as const;

export const SMART_GENERATOR_AGGREGATION = 'Generator aggregation / ranking';

export const SPECIAL_MODULES = [
  { id: 'SEQ', name: 'Sequence Mathematics', source: 'lib/sequence-math.ts', purpose: 'arithmetic/geometric sequence diagnostics and term/rank helpers' },
  { id: 'ADVVAL', name: 'Advanced Validation & Null Diagnostics', source: 'lib/advanced-validation.ts', purpose: 'OOS checks, null-model diagnostics, redundancy grouping and intervals' },
  { id: 'LSTM', name: 'Lightweight Recurrent/LSTM-style Model', source: 'lib/advanced-models.ts', purpose: 'offline recurrent signal; evidence only when trained' },
  { id: 'GA', name: 'Genetic Optimizer', source: 'lib/advanced-models.ts', purpose: 'offline deterministic candidate-search signal' },
  { id: '107ENGINE', name: 'Central 107 Analysis Executor', source: 'lib/analysis-engine-107.ts', purpose: 'executes the public 107 analysis contracts' },
  { id: 'CENTRAL', name: 'Central Analysis Orchestrator', source: 'lib/central-analysis-core.ts', purpose: 'one canonical input to 107 + 28 signal report' },
  { id: 'HIST', name: 'Historical Analysis Core', source: 'lib/historical-analysis-core.ts', purpose: 'single historical-data boundary for 107 + 28' },
  { id: 'CYCLE', name: 'Leakage-Safe Research Cycle', source: 'lib/research-cycle.ts', purpose: 'lock → actual → validate → apply workflow' },
  { id: '6D', name: '6D Analysis View', source: 'App.tsx', purpose: 'extended position analysis for 4D/special/consolation data' },
] as const;

export const INVENTORY_POLICY = {
  core107: 107,
  activeSignals28: 28,
  validationLayers6: 6,
  legacyModelChannels11: 11,
  smartGeneratorPaths27: 27,
  smartGeneratorAggregationStages: 1,
  orchestrationFamilies12: 12,
  catalogDivisions18: 18,
  note: 'Do not add these counts arithmetically: several legacy/model paths overlap the 107 and 28 layers.',
} as const;
