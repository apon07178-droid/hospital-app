import { ANALYSIS_CONTRACTS, IMPLEMENTATION_STATUS, type ImplementationStatusCode } from './analysis-contract';

export interface AnalysisOption { id:number; division:string; name:string; purpose:string; category:'descriptive'|'structural'|'statistical'|'predictive'|'validation'; implementation:'active-signal'|'advanced-metric'|'validation'|'catalog'; signalKeys:string[]; implementationStatus:ImplementationStatusCode; implementationStatusLabel:string; family:string; definition:string; input:string; output:string; dataRequirement:string; dependencyIds:number[]; dependencyType:string; target:string; validation:string; redundancyGroup:string; }

const groups: [string,string[],string][] = [
['01 Data Science',['Data integrity audit','Missing-value audit','Duplicate detection','Ordering audit','Sample-size adequacy','Distribution profile'],'ডেটার মান, completeness ও sampling সমস্যা শনাক্ত করে।'],
['02 Arithmetic',['First difference','Second difference','Third difference','Absolute difference','Ratio analysis','Percentage change'],'ক্রমিক সংখ্যার arithmetic structure পরীক্ষা করে।'],
['03 Number Theory',['Prime/composite','Divisibility','Factorization','GCD/LCM','Parity','Digital root'],'সংখ্যাতত্ত্বভিত্তিক বৈশিষ্ট্য বিশ্লেষণ করে।'],
['04 Digit Mathematics',['Digit frequency','Position frequency','Digit sum','Digit product','Repeated digits','Distinct-digit count','Reverse number'],'৪টি position ও digit-level structure বিশ্লেষণ করে।'],
['05 Sequence Theory',['Recurrence search','Lag matching','Pattern repetition','Run-length analysis','Subsequence search','Motif discovery'],'sequence-এর পুনরাবৃত্তি ও recurrence খোঁজে।'],
['06 Polynomial & Algebra',['Linear fit','Quadratic fit','Cubic fit','Finite-difference polynomial','Residual analysis','Complexity penalty'],'algebraic/polynomial hypothesis পরীক্ষা করে।'],
['07 Modular Mathematics',['Modulo 2','Modulo 3','Modulo 4','Modulo 5','Modulo 7','Modulo 9','Modulo 10','Modulo 11'],'modular residue ও divisibility structure পরীক্ষা করে।'],
['08 Combinatorics',['Pair frequency','Triplet frequency','Permutation groups','Combination coverage','Position-pair matrix','Pattern class frequency'],'pair/triplet/permutation ও combinatorial coverage বিশ্লেষণ করে।'],
['09 Statistics',['Mean/median/mode','Variance/std-dev','Quantiles','Z-score','Robust outlier score','Bootstrap interval','Wilson interval'],'descriptive ও inferential statistics প্রয়োগ করে।'],
['10 Dependency',['Autocorrelation','Partial autocorrelation','Cross-position correlation','Mutual information','Chi-square independence','Transition matrix'],'সময় ও position dependency পরিমাপ করে।'],
['11 Time Series',['Rolling mean','Rolling variance','Exponential smoothing','Change-point detection','Trend decomposition','Walk-forward windows'],'time-ordered data-এর dynamic behavior পরীক্ষা করে।'],
['12 Spectral',['DFT/FFT spectrum','Dominant frequency','Spectral entropy','Periodogram','Peak periodicity'],'periodic signal ও frequency-domain structure পরীক্ষা করে।'],
['13 Information Theory',['Shannon entropy','Min-entropy','Rényi entropy','Approximate entropy','Conditional entropy','Information gain'],'অনিশ্চয়তা ও information content পরিমাপ করে।'],
['14 Randomness',['Frequency test','Block frequency','Runs test','Long-run test','Serial test','Cumulative sums','Permutation test'],'randomness/null-model compatibility পরীক্ষা করে।'],
['15 Complexity',['Lempel-Ziv complexity','Linear complexity','Compression ratio','Pattern complexity','Description-length penalty'],'sequence কতটা compressible/structured তা পরীক্ষা করে।'],
['16 Dynamical Systems',['State-space encoding','Recurrence plot','Attractor-style clustering','Transition stability','Regime detection'],'state transition ও regime behavior পরীক্ষা করে।'],
['17 Symbolic Discovery',['Symbolic regression','Rule mining','Association patterns','Feature interaction search','Formula candidate ranking'],'ডেটা থেকে symbolic hypothesis তৈরি করে।'],
['18 Prediction & Validation',['Baseline prediction','AR/ARIMA-style signal','Tree/ensemble signal','Recurrent model signal','Genetic optimizer','Ensemble ranking','Uncertainty interval','Blocked K-fold','Monte Carlo null test','Multiple-testing audit','Out-of-sample validation','Reproducibility check'],'Prediction ও validation pipeline-এর candidate generation, backtesting এবং leakage control করে.']
];

export const ANALYSIS_CATALOG: AnalysisOption[] = (() => {
  let id = 1;
  const out: AnalysisOption[] = [];
  for (const [division, names, purpose] of groups) {
    for (const name of names) {
      const category: AnalysisOption['category'] =
        division === '09 Statistics' || division === '10 Dependency' || division === '14 Randomness'
          ? 'statistical'
          : division === '18 Prediction & Validation'
            ? (/Validation|test|audit|interval|Bootstrap|Wilson/.test(name) ? 'validation' : 'predictive')
            : /Prediction|model|optimizer|ranking|AR|ensemble|recurrent|Genetic/.test(name)
              ? 'predictive'
              : /frequency|entropy|mean|variance|quantile|Z-score|correlation|matrix|trend|spectrum|periodicity|change-point|transition|complexity|regression|rule|association/.test(name)
                ? 'structural'
                : 'descriptive';
      const linked: Record<string,string[]> = {
        'Position frequency':['position'], 'Digit frequency':['hot','cold'], 'Pair frequency':['pair'], 'Triplet frequency':['triplet'],
        'Transition matrix':['transition'], 'Mirror':['mirror'], 'Neighbor +1/-1':['neighbor'], 'High/Low':['highlow'],
        'Benford-style':['benford'], 'Overdue/GAP':['overdue'], 'Sum Distribution':['sum'], 'Even/Odd':['evenodd'],
        'Calendar/Weekday':['calendar'], 'Recent Trend':['trending'], 'Permutation':['permutation'], 'Digit Diversity':['diversity'],
        'Cross-Company':['crosscompany'], 'Regression Sum Trend':['regression'], 'Sequence Match':['sequence'],
        'Trained LSTM Signal':['lstm'], 'Genetic optimizer':['genetic'], 'Skip-Draw':['skip'], 'Cold/Due':['cold'],
        'Backtest Support':['backtest'], 'Digit Spread':['spread'], 'Consensus':['consensus'], 'Bayesian Smoothing':['bayesian'],
        'Anti-Repeat/Diversity Guard':['antiRepeat'], 'Autocorrelation':['transition'], 'Cross-position correlation':['crosscompany'],
        'Transition stability':['transition'], 'Ensemble ranking':['consensus'], 'Blocked K-fold':['backtest'],
        'Out-of-sample validation':['backtest'], 'Reproducibility check':['backtest'], 'Uncertainty interval':['bayesian']
      };
      const signalKeys = linked[name] ?? [];
      const implementation: AnalysisOption['implementation'] =
        signalKeys.length ? 'active-signal' :
        /Validation|K-fold|test|audit|interval|Bootstrap|Wilson|out-of-sample|Reproducibility/i.test(name) ? 'validation' :
        /entropy|correlation|rolling|transition|pair|triplet|pattern|frequency|autocorrelation|spectrum|complexity/i.test(name) ? 'advanced-metric' : 'catalog';
      const publicId=id++; const contract=publicId<=107 ? ANALYSIS_CONTRACTS[publicId-1] : undefined; out.push({ id: publicId, division, name, purpose, category, implementation, signalKeys, implementationStatus: contract?.implementationStatus ?? 7, implementationStatusLabel: contract ? IMPLEMENTATION_STATUS[contract.implementationStatus] : 'REQUIRES_FIX', family: contract?.family ?? 'UNREGISTERED', definition: contract?.definition ?? 'Not part of the public 107 contract.', input: contract?.input ?? 'N/A', output: contract?.output ?? 'N/A', dataRequirement: contract?.dataRequirement ?? 'N/A', dependencyIds: contract?.dependencyIds ?? [], dependencyType: contract?.dependencyType ?? 'DATA', target: contract?.target ?? 'N/A', validation: contract?.validation ?? 'Contract validation required', redundancyGroup: contract?.redundancyGroup ?? 'R0' });
    }
  }
  // The product specification is 107 catalog entries. Keep the first 107
  // entries as the canonical public catalog; later research ideas remain out
  // of the user-facing registry rather than silently being assigned IDs.
  return out.slice(0, 107);
})();

export const ANALYSIS_CATALOG_COUNT = ANALYSIS_CATALOG.length;

