/** Central executable layer for the public 107 historical analyses. */
import { ANALYSIS_CATALOG } from './analysis-catalog';
import { getAnalysisContract, type ImplementationStatusCode } from './analysis-contract';
import { analyzeArithmeticSequence, analyzeGeometricSequence, nthArithmeticTerm, nthGeometricTerm, arithmeticRankOfTerm, geometricRankOfTerm } from './sequence-math';
import { chiSquareUniform, autocorrelation, digitIndependence, wilsonInterval } from './advanced-validation';
import { trainLstmDigitModel } from './advanced-models';
import type { CanonicalDraw } from './canonical-data';

export type Evidence='SUPPORT'|'NEUTRAL'|'CONFLICT'|'INSUFFICIENT_DATA'|'NOT_APPLICABLE';
export interface Analysis107Result {id:number;name:string;status:ImplementationStatusCode;applicable:boolean;sampleSize:number;raw:unknown;evidence:Evidence;note:string;calculationVersion:'107-core-v1'}
const V=(x:string)=>/^\d{4}$/.test(x);
const rows=(d:CanonicalDraw[])=>d.filter(x=>V(x.first)).sort((a,b)=>a.date.localeCompare(b.date)||a.company.localeCompare(b.company)||(Number(a.drawNo??0)-Number(b.drawNo??0))||a.id-b.id);
const mean=(a:number[])=>a.length?a.reduce((s,x)=>s+x,0)/a.length:0;
const variance=(a:number[])=>a.length>1?(()=>{const m=mean(a);return a.reduce((s,x)=>s+(x-m)**2,0)/(a.length-1)})():0;
const quant=(a:number[],q:number)=>{if(!a.length)return null;const s=[...a].sort((x,y)=>x-y),p=(s.length-1)*q,i=Math.floor(p),f=p-i;return s[i+1]===undefined?s[i]:s[i]+(s[i+1]-s[i])*f};
const counts=(a:string[])=>{const m:Record<string,number>={};for(const x of a)m[x]=(m[x]??0)+1;return m};
const corr=(a:number[],b:number[])=>{const n=Math.min(a.length,b.length);if(n<3)return 0;const ma=mean(a.slice(0,n)),mb=mean(b.slice(0,n));let xy=0,aa=0,bb=0;for(let i=0;i<n;i++){const x=a[i]-ma,y=b[i]-mb;xy+=x*y;aa+=x*x;bb+=y*y}return aa&&bb?xy/Math.sqrt(aa*bb):0};
const diff=(a:number[],o=1)=>{let x=[...a];for(let k=0;k<o;k++){if(x.length<2)return[];x=x.slice(1).map((v,i)=>v-x[i])}return x};
const mod=(a:number[],m:number)=>{const c=Array(m).fill(0);for(const x of a)c[((x%m)+m)%m]++;return c};
const gcd=(a:number,b:number)=>{a=Math.abs(a);b=Math.abs(b);while(b){const t=a%b;a=b;b=t}return a};
const lcm=(a:number,b:number)=>a&&b?Math.abs(a/gcd(a,b)*b):0;
const prime=(n:number)=>n>=2&&Number.isInteger(n)&&Array.from({length:Math.floor(Math.sqrt(n))-1},(_,i)=>i+2).every(p=>n%p!==0);
const factors=(n:number)=>{let x=Math.abs(Math.trunc(n)),o:number[]=[];for(let p=2;p*p<=x;p++)while(x%p===0){o.push(p);x/=p}if(x>1)o.push(x);return o};
const digitRoot=(n:number)=>n===0?'0':String(((Math.abs(n)-1)%9)+1);
const entropy=(a:string[])=>{const c=counts(a),n=a.length||1;return Object.values(c).reduce((s,v)=>{const p=v/n;return s-p*Math.log2(p)},0)};
const pairs=[[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]] as const;
const trips=[[0,1,2],[0,1,3],[0,2,3],[1,2,3]] as const;
const pattern=(s:string)=>{const d=s.split(''), groups=new Map<string,string>();let next=0;const labels:string[]=[];for(const ch of d){if(!groups.has(ch))groups.set(ch,String.fromCharCode(65+next++));labels.push(groups.get(ch)!);}const k=labels.join('');return k==='AAAA'?'AAAA':k==='AAAB'?'AAAB':k==='AABB'?'AABB':k==='ABAB'?'ABAB':k==='ABBA'?'ABBA':new Set(d).size===2?'AABC':'ABCD'};
const status=(id:number,ok:boolean,n:number):ImplementationStatusCode=>n===0?5:!ok?6:(getAnalysisContract(id).implementationStatus as ImplementationStatusCode);

function berlekampMassey(s:number[]){let C=[1],B=[1],L=0,m=1,b=1;for(let n=0;n<s.length;n++){let d=s[n]&1;for(let i=1;i<=L;i++)d^=(C[i]??0)&(s[n-i]&1);if(d===0){m++;continue}const T=[...C],coef=d/b;while(C.length<B.length+m)C.push(0);for(let j=0;j<B.length;j++)C[j+m]^=Math.round(coef*B[j]);if(2*L<=n){L=n+1-L;B=T;b=d;m=1}else m++}return L}

export function run107Analysis(draws:CanonicalDraw[]):Analysis107Result[]{
 const rs=rows(draws), ns=rs.map(r=>Number(r.first)), ds=rs.map(r=>r.first), n=ns.length, out:Analysis107Result[]=[];
 const push=(id:number,raw:unknown,ok=n>0,evidence:Evidence='NEUTRAL',note='')=>out.push({id,name:ANALYSIS_CATALOG[id-1]?.name??`Analysis ${id}`,status:status(id,ok,n),applicable:ok,sampleSize:n,raw,evidence,note,calculationVersion:'107-core-v1'});
 const d1=diff(ns),d2=diff(ns,2),d3=diff(ns,3),pf=Array.from({length:4},(_,p)=>counts(ds.map(x=>x[p])));
 push(1,{total:draws.length,valid:n,invalid:draws.length-n},draws.length>0,draws.length===n?'SUPPORT':'CONFLICT');
 const missing=draws.length-n;push(2,{invalidRows:missing,rate:draws.length?missing/draws.length:0},draws.length>0,missing?'CONFLICT':'SUPPORT');
 const keys=rs.map(r=>`${r.company}|${r.date}|${r.drawNo??''}`),dups=keys.filter((x,i)=>keys.indexOf(x)!==i);push(3,{duplicateKeys:[...new Set(dups)],count:dups.length},draws.length>0,dups.length?'CONFLICT':'NEUTRAL');
 const ord=rs.every((r,i)=>i===0||rs[i-1].date<=r.date);push(4,{chronological:ord},n>1,ord?'SUPPORT':'CONFLICT');push(5,{n,minimumDescriptive:10,stableInference:100},n>0,n>=10?'SUPPORT':'INSUFFICIENT_DATA');push(6,{mean:mean(ns),median:quant(ns,.5),min:Math.min(...ns),max:Math.max(...ns)},n>0);
 push(7,d1,n>1);push(8,d2,n>2);push(9,d3,n>3);push(10,d1.map(Math.abs),n>1);push(11,{ratios:ns.slice(1).map((x,i)=>ns[i]?x/ns[i]:null),zeroDenominators:ns.slice(1).filter((_,i)=>ns[i]===0).length},n>1);push(12,{changes:ns.slice(1).map((x,i)=>ns[i]?((x-ns[i])/Math.abs(ns[i])):null)},n>1);
 push(13,{prime:ns.filter(prime).length,composite:ns.filter(x=>x>1&&!prime(x)).length},n>0);push(14,{divisors:[2,3,4,5,7,9,10,11].map(m=>({m,count:ns.filter(x=>x%m===0).length}))},n>0);push(15,{factorPatterns:counts(ns.map(x=>factors(x).join('×')||'0'))},n>0);push(16,{gcd:ns.slice(1).map((x,i)=>gcd(ns[i],x)),lcm:ns.slice(1).map((x,i)=>lcm(ns[i],x))},n>1);push(17,{even:ns.filter(x=>x%2===0).length,odd:ns.filter(x=>x%2).length},n>0);push(18,{roots:counts(ns.map(digitRoot))},n>0);
 push(19,{global:counts(ds.flatMap(x=>x.split(''))),byPosition:pf},n>0);push(20,pf,n>0);push(21,{distribution:counts(ds.map(x=>String([...x].reduce((s,d)=>s+Number(d),0))) )},n>0);push(22,{distribution:counts(ds.map(x=>String([...x].reduce((s,d)=>s*Number(d),1))) )},n>0);push(23,{patterns:counts(ds.map(pattern))},n>0);push(24,{distribution:counts(ds.map(x=>String(new Set(x).size)))},n>0);push(25,{rows:ds.map(x=>({value:x,reverse:x.split('').reverse().join(''),isPalindrome:x===x.split('').reverse().join('')})),palindromes:ds.filter(x=>x===x.split('').reverse().join('')).length},n>0);
 const lag=Array.from({length:Math.min(20,n-1)},(_,k)=>({lag:k+1,match:ns.slice(k+1).filter((x,i)=>x===ns[i]).length/Math.max(1,n-k-1)}));push(26,{lags:lag,best:lag.slice().sort((a,b)=>b.match-a.match)[0]??null},n>1);push(27,lag,n>2);const windows=ds.map(x=>x.slice(0,2));const repeatWindows=windows.length-new Set(windows).size;push(28,{windowLength:2,totalWindows:windows.length,uniqueWindows:new Set(windows).size,repeatedWindows:repeatWindows},n>1);const runs:number[]=[];let cur=0,prev='';for(const x of ds){if(x===prev)cur++;else{if(cur)runs.push(cur);prev=x;cur=1}}if(cur)runs.push(cur);push(29,{runs,mean:mean(runs),max:runs.length?Math.max(...runs):0},n>0);push(30,subsequenceStats(ds),n>2);push(31,motifStats(ds),n>2);
 const linear=fit(ns,1),quad=fit(ns,2),cub=fit(ns,3);push(32,linear,n>1);push(33,quad,n>2);push(34,cub,n>3);push(35,{first:{constant:d1.length>0&&d1.every(x=>x===d1[0]),value:d1[0]??null},second:{constant:d2.length>0&&d2.every(x=>x===d2[0]),value:d2[0]??null},third:{constant:d3.length>0&&d3.every(x=>x===d3[0]),value:d3[0]??null},detectedDegree:d1.length&&d1.every(x=>x===d1[0])?1:d2.length&&d2.every(x=>x===d2[0])?2:d3.length&&d3.every(x=>x===d3[0])?3:null},n>3);push(36,{residuals:linear.residuals,sd:Math.sqrt(variance(linear.residuals))},n>1);push(37,{penalties:{linear:2/Math.sqrt(Math.max(1,n)),quadratic:3/Math.sqrt(Math.max(1,n)),cubic:4/Math.sqrt(Math.max(1,n))}},n>0);
 [2,3,4,5,7,9,10,11].forEach((m,i)=>push(38+i,{modulus:m,residues:mod(ns,m)},n>0));
 push(46,{pairs:Object.fromEntries(pairs.map(([a,b])=>[`${a+1}${b+1}`,counts(ds.map(x=>x[a]+x[b]))]))},n>0);push(47,{triplets:Object.fromEntries(trips.map(t=>[t.map(i=>i+1).join(''),counts(ds.map(x=>t.map(i=>x[i]).join('')))]))},n>0);push(48,{permutationClasses:counts(ds.map(x=>x.split('').sort().join('')))},n>0);push(49,{uniquePairs:new Set(ds.flatMap(x=>pairs.map(([a,b])=>x[a]+x[b]))).size,uniqueTriplets:new Set(ds.flatMap(x=>trips.map(t=>t.map(i=>x[i]).join('')))).size},n>0);push(50,{matrices:pairs.map(([a,b])=>({positions:[a+1,b+1],counts:counts(ds.map(x=>x[a]+x[b]))}))},n>0);push(51,{classes:counts(ds.map(pattern))},n>0);
 const sd=Math.sqrt(variance(ns)), med=quant(ns,.5)??0,mad=quant(ns.map(x=>Math.abs(x-med)),.5)??0;push(52,{mean:mean(ns),median:med,mode:mode(ns)},n>0);push(53,{variance:variance(ns),stdDev:sd},n>1);push(54,{q1:quant(ns,.25),q2:med,q3:quant(ns,.75)},n>0);push(55,{zScores:sd?ns.map(x=>(x-mean(ns))/sd):[]},n>1);push(56,{robustZ:mad?ns.map(x=>.6745*(x-med)/mad):[]},n>1);push(57,bootstrap(ns),n>2);push(58,wilsonInterval(ns.filter(x=>x%2===0).length,n),n>0);
 push(59,autocorrelation(rs),n>3);push(60,pacf(ns),n>5);push(61,{correlations:pairs.map(([a,b])=>({positions:`${a+1}↔${b+1}`,r:corr(ds.map(x=>+x[a]),ds.map(x=>+x[b]))}))},n>2);push(62,{mutualInformation:pmi(ds)},n>10);push(63,digitIndependence(rs),n>10);push(64,{transitions:transition(ds)},n>1);
 push(65,rolling(ns,10,'mean'),n>2);push(66,rolling(ns,10,'variance'),n>3);push(67,smooth(ns,.2),n>1);push(68,changePoint(ns),n>20);push(69,trendDecomposition(ns),n>8);push(70,walkForwardWindows(ns),n>20);
 const spectrum=dft(ns.map(x=>x-mean(ns)));const periodogram=spectrum.map(x=>({...x,power:x.power/Math.max(1,n)}));push(71,spectrum,n>8);const positiveSpectrum=spectrum.filter(x=>x.frequency>0);const peakSpectrum=positiveSpectrum.length?positiveSpectrum.reduce((a,b)=>b.power>a.power?b:a):null;push(72,peakSpectrum,n>8);push(73,specEntropy(spectrum.filter(x=>x.frequency>0)),n>8);push(74,periodogram,n>8);push(75,periodogram.filter((x,i)=>i>0&&i<periodogram.length-1&&x.power>=periodogram[i-1].power&&x.power>=periodogram[i+1].power).sort((a,b)=>b.power-a.power).slice(0,10),n>8);
 const sym=ds.flatMap(x=>x.split(''));push(76,entropy(sym),n>0);push(77,minEnt(sym),n>0);push(78,renyi(sym,2),n>0);push(79,approxEntropy(ns),n>20);const cond=conditional(ds);push(80,cond,n>2);push(81,informationGain(ds),n>10);
 push(82,chiSquareUniform(rs),n>0);push(83,blockFreq(sym,10),n>10);push(84,runsTest(sym),n>20);push(85,longRun(sym),n>20);push(86,serial(sym),n>20);push(87,cusum(ns),n>10);push(88,permutationTest(ns),n>20);
 push(89,lz(sym),n>5);push(90,linearComplexity(sym),n>5);push(91,compressionEstimate(sym),n>5);push(92,{uniquePatterns:new Set(ds.flatMap(x=>[x.slice(0,2),x.slice(1,3),x.slice(2,4)])).size},n>5);push(93,{mdl:Math.log2(Math.max(1,new Set(ds).size))+Math.log2(Math.max(1,n))},n>5);
 const states=ds.map(pattern);push(94,{states,distribution:counts(states)},n>0);push(95,recurrence(states),n>2);push(96,clusterStates(states),n>10);push(97,transitionStability(states),n>20);push(98,{boundaries:states.reduce<number[]>((a,x,i)=>i&&x!==states[i-1]?a.concat(i):a,[])},n>20);
 push(99,symbolicCandidates(ns),n>20);push(100,ruleMining(ds),n>20);push(101,{associations:pmi(ds)},n>20);push(102,interactionSearch(ds),n>30);push(103,formulaRanking(ns),n>30);
 push(104,baselineModel(ns),n>20);const ar=arOos(ns);push(105,ar,n>30,ar.tests?'SUPPORT':'INSUFFICIENT_DATA');const tree=treeEnsembleOos(ds);push(106,tree,n>40,tree.tests?'SUPPORT':'INSUFFICIENT_DATA');const rec=recurrentOos(ds);push(107,rec,n>40,rec.tests?'SUPPORT':'INSUFFICIENT_DATA');
 return out;
}


function subsequenceStats(a:string[]){const out:Record<string,number>={};for(const x of a){for(let i=0;i<x.length;i++)for(let j=i+1;j<x.length;j++){const q=x[i]+x[j];out[q]=(out[q]??0)+1}}return{lengths:[2],counts:out,unique:Object.keys(out).length}}
function motifStats(a:string[]){const c:Record<string,number>={};for(const x of a){for(let i=0;i<=x.length-3;i++){const m=x.slice(i,i+3);c[m]=(c[m]??0)+1}}return{motifs:Object.entries(c).sort((a,b)=>b[1]-a[1]).slice(0,50).map(([motif,count])=>({motif,count,support:count/a.length}))}}
function trendDecomposition(a:number[]){if(a.length<3)return{trend:[],residual:[],seasonal:[],note:'insufficient data'};const trend=a.map((_,i)=>{const l=Math.max(0,i-2),r=Math.min(a.length,i+3);return mean(a.slice(l,r))});const residual=a.map((x,i)=>x-trend[i]);const seasonal=seasonalComponent(residual);return{trend,residual,seasonal,trendSlope:fit(trend,1).coefficients?.[1]??0}}
function seasonalComponent(a:number[]){if(a.length<6)return a.map(()=>0);const by=Array(3).fill(0).map(()=>[] as number[]);a.forEach((x,i)=>by[i%3].push(x));const gm=mean(a),sm=by.map(v=>mean(v)-gm);return a.map((_,i)=>sm[i%3])}
function walkForwardWindows(a:number[]){const minTrain=Math.max(10,Math.floor(a.length*.5)),results:any[]=[];for(let train=minTrain;train<a.length;train+=Math.max(1,Math.floor((a.length-minTrain)/5)||1)){const tr=a.slice(0,train),test=a.slice(train,Math.min(a.length,train+Math.max(1,Math.floor(a.length*.1))));if(!test.length)continue;const f=fit(tr,1),pred=test.map((_,i)=>f.coefficients?f.coefficients.reduce((s,c,j)=>s+c*(train+i)**j,0):mean(tr));const mae=mean(test.map((x,i)=>Math.abs(x-pred[i])));results.push({trainSize:train,testSize:test.length,mae});}return{windows:results,count:results.length}}
function informationGain(a:string[]){if(a.length<2)return null;const h=entropy(a.flatMap(x=>x.split(''))),c=conditional(a);return{baseEntropy:h,conditionalEntropy:c,informationGain:Math.max(0,h-c)}}
function symbolicCandidates(a:number[]){const l=fit(a,1),q=fit(a,2),c=fit(a,3);return{candidates:[l,q,c].map((x,i)=>({model:['linear','quadratic','cubic'][i],r2:x.r2,complexity:x.degree+1})).sort((x,y)=>(y.r2??-Infinity)-(x.r2??-Infinity))}}
function ruleMining(a:string[]){const c=counts(a.map(pattern));return{rules:Object.entries(c).map(([rule,count])=>({rule,support:count/a.length,confidence:count/a.length,lift:(count/a.length)/(1/5)})).sort((x,y)=>y.support-x.support)}}
function interactionSearch(a:string[]){return{interactions:pairs.map(([x,y])=>({positions:[x+1,y+1],r:corr(a.map(s=>+s[x]),a.map(s=>+s[y]))})).sort((x,y)=>Math.abs(y.r)-Math.abs(x.r))}}
function formulaRanking(a:number[]){const models=[fit(a,1),fit(a,2),fit(a,3)];return{ranked:models.map((m,i)=>({model:['linear','quadratic','cubic'][i],score:m.r2??0,complexity:m.degree+1,criterion:(m.r2??0)-0.01*(m.degree+1)})).sort((x,y)=>y.criterion-x.criterion)}}
function baselineModel(a:number[]){return{uniformExactRate:1/10000,meanBaseline:mean(a),medianBaseline:quant(a,.5),sampleSize:a.length}}
function ar1Forecast(train:number[]){
 if(train.length<3)return mean(train);
 const x=train.slice(0,-1),y=train.slice(1),mx=mean(x),my=mean(y);let num=0,den=0;
 for(let i=0;i<x.length;i++){num+=(x[i]-mx)*(y[i]-my);den+=(x[i]-mx)**2}
 const phi=Math.max(-.99,Math.min(.99,den?num/den:0)),c=my-phi*mx;
 return c+phi*train[train.length-1]
}
function arOos(a:number[]){
 const start=Math.max(20,Math.floor(a.length*.6)),end=a.length,step=Math.max(1,Math.floor((end-start)/60));
 const errors:number[]=[];
 for(let i=start;i<end;i+=step){const pred=ar1Forecast(a.slice(0,i));errors.push(a[i]-pred)}
 return{model:'AR(1)',tests:errors.length,mae:errors.length?mean(errors.map(Math.abs)):null,rmse:errors.length?Math.sqrt(mean(errors.map(x=>x*x))):null,bias:errors.length?mean(errors):null,walkForward:true,arTests:errors.length}
}

interface Stump { feature:number; threshold:number; low:number; high:number; }
function trainStumps(train:string[],position:number,trees=15):Stump[]{
 const stumps:Stump[]=[];
 for(let t=0;t<trees;t++){
  const feature=(t*3+position)%5; // previous digit positions 0..3, or previous sum feature 4
  let best:Stump|null=null,bestErr=Infinity;
  for(let threshold=0;threshold<=9;threshold++){
   const low:number[]=[],high:number[]=[];
   for(let i=1;i<train.length;i++){
    const prev=train[i-1], f=feature===4?[...prev].reduce((s,d)=>s+Number(d),0):Number(prev[feature]);
    (f<=threshold?low:high).push(Number(train[i][position]));
   }
   const majority=(v:number[])=>{const c=counts(v.map(String));return Number(Object.entries(c).sort((a,b)=>b[1]-a[1])[0]?.[0]??0)};
   const lo=majority(low),hi=majority(high);let err=0;
   for(let i=1;i<train.length;i++){const prev=train[i-1],f=feature===4?[...prev].reduce((s,d)=>s+Number(d),0):Number(prev[feature]);const pred=f<=threshold?lo:hi;if(pred!==Number(train[i][position]))err++}
   if(err<bestErr)bestErr=err,best={feature,threshold,low:lo,high:hi};
  }
  if(best)stumps.push(best);
 }
 return stumps;
}
function stumpPredict(stump:Stump,prev:string){const f=stump.feature===4?[...prev].reduce((s,d)=>s+Number(d),0):Number(prev[stump.feature]);return f<=stump.threshold?stump.low:stump.high}
function treeEnsembleOos(a:string[]){
 const start=Math.max(30,Math.floor(a.length*.6)),step=Math.max(1,Math.floor((a.length-start)/30));let hits=0,total=0,exact=0,tests=0;const trees=15;
 for(let i=start;i<a.length;i+=step){const train=a.slice(0,i),actual=a[i];let pred='';for(let p=0;p<4;p++){const model=trainStumps(train,p,trees);const votes=model.map(m=>stumpPredict(m,train[i-1]));const c=counts(votes.map(String));const digit=Object.entries(c).sort((x,y)=>y[1]-x[1])[0]?.[0]??'0';pred+=digit;if(Number(digit)===Number(actual[p]))hits++;total++;}if(pred===actual)exact++;tests++;}
 return{model:'Deterministic decision-stump ensemble',trees,tests,digitTests:total,digitAccuracy:total?hits/total:0,exact4DTests:tests,exact4DRate:tests?exact/tests:0,trainingWindow:'expanding chronological',walkForward:true,treeTests:tests}
}
function recurrentOos(a:string[]){
 const start=Math.max(20,Math.floor(a.length*.7)),step=Math.max(1,Math.floor((a.length-start)/20));let hits=0,total=0,exact=0,tests=0;
 for(let i=start;i<a.length;i+=step){const model=trainLstmDigitModel(a.slice(0,i),8,8);if(!model.every(x=>x.trained))continue;let pred='';for(let p=0;p<4;p++){const probs=model[p].probabilities;const d=probs.indexOf(Math.max(...probs));pred+=String(d);if(d===Number(a[i][p]))hits++;total++;}if(pred===a[i])exact++;tests++;}
 return{model:'Offline recurrent/LSTM-style digit encoder',tests,digitTests:total,digitAccuracy:total?hits/total:0,exact4DTests:tests,exact4DRate:tests?exact/tests:0,trainingWindow:'expanding chronological',holdoutTests:tests,walkForward:true,validated:true}
}

export function runSequenceFormulaChecks(first:number,difference:number,ratio:number,rank:number,term:number){return{arithmeticTerm:nthArithmeticTerm(first,difference,rank),geometricTerm:nthGeometricTerm(first,ratio,rank),arithmeticRank:arithmeticRankOfTerm(term,first,difference),geometricRank:geometricRankOfTerm(term,first,ratio),arithmeticSequence:analyzeArithmeticSequence([first,first+difference,first+2*difference]),geometricSequence:analyzeGeometricSequence([first,first*ratio,first*ratio*ratio])}}
function mode(a:number[]){const c:Record<string,number>={};for(const x of a)c[x]=(c[x]??0)+1;const e=Object.entries(c).sort((a,b)=>b[1]-a[1])[0];return e?Number(e[0]):null}
function fit(a:number[],degree:number){if(a.length<=degree)return{degree,r2:null,residuals:[]};const x=a.map((_,i)=>i),m=degree+1,A=Array.from({length:m},()=>Array(m).fill(0)),b=Array(m).fill(0);for(let r=0;r<m;r++){for(let c=0;c<m;c++)A[r][c]=x.reduce((s,v)=>s+v**(r+c),0);b[r]=a.reduce((s,y,i)=>s+y*x[i]**r,0)}const coef=solve(A,b),pred=a.map((_,i)=>coef.reduce((s,c,j)=>s+c*i**j,0)),ym=mean(a),sse=a.reduce((s,y,i)=>s+(y-pred[i])**2,0),sst=a.reduce((s,y)=>s+(y-ym)**2,0);return{degree,coefficients:coef,r2:sst?1-sse/sst:1,residuals:a.map((y,i)=>y-pred[i])}}
function solve(A:number[][],b:number[]){const n=b.length,M=A.map((r,i)=>[...r,b[i]]);for(let i=0;i<n;i++){let p=i;for(let r=i+1;r<n;r++)if(Math.abs(M[r][i])>Math.abs(M[p][i]))p=r;[M[i],M[p]]=[M[p],M[i]];if(Math.abs(M[i][i])<1e-12)continue;for(let r=i+1;r<n;r++){const q=M[r][i]/M[i][i];for(let c=i;c<=n;c++)M[r][c]-=q*M[i][c]}}const x=Array(n).fill(0);for(let i=n-1;i>=0;i--){let s=M[i][n];for(let c=i+1;c<n;c++)s-=M[i][c]*x[c];x[i]=Math.abs(M[i][i])<1e-12?0:s/M[i][i]}return x}
function bootstrap(a:number[]){let st=1234567,s=0,s2=0,reps=Math.min(1000,Math.max(100,a.length*10));for(let r=0;r<reps;r++){let z=0;for(let i=0;i<a.length;i++){st=(1664525*st+1013904223)>>>0;z+=a[st%a.length]}z/=a.length;s+=z;s2+=z*z}const m=s/reps,sd=Math.sqrt(Math.max(0,s2/reps-m*m));return{mean:m,lower:m-1.96*sd,upper:m+1.96*sd,reps}}
function solveLinear(A:number[][],b:number[]){const n=b.length,m=A.map(r=>[...r]),y=[...b];for(let i=0;i<n;i++){let p=i;for(let r=i+1;r<n;r++)if(Math.abs(m[r][i])>Math.abs(m[p][i]))p=r;if(Math.abs(m[p][i])<1e-12)continue;[m[i],m[p]]=[m[p],m[i]];[y[i],y[p]]=[y[p],y[i]];for(let r=i+1;r<n;r++){const q=m[r][i]/m[i][i];for(let c=i;c<n;c++)m[r][c]-=q*m[i][c];y[r]-=q*y[i]}}const x=Array(n).fill(0);for(let i=n-1;i>=0;i--){let z=y[i];for(let j=i+1;j<n;j++)z-=m[i][j]*x[j];x[i]=Math.abs(m[i][i])>1e-12?z/m[i][i]:0}return x}
function partialCorrAtLag(a:number[],lag:number){if(a.length<lag+6)return null;const y=a.slice(lag),x0=a.slice(0,-lag),controls:number[][]=[];for(let k=1;k<lag;k++)controls.push(a.slice(lag-k,a.length-k));if(!controls.length)return corr(y,x0);const X=Array.from({length:y.length},(_,i)=>[1,...controls.map(c=>c[i])]);const fit=(v:number[])=>{const A=Array.from({length:X[0].length},()=>Array(X[0].length).fill(0)),b=Array(X[0].length).fill(0);for(let i=0;i<X.length;i++)for(let j=0;j<X[0].length;j++){b[j]+=X[i][j]*v[i];for(let k=0;k<X[0].length;k++)A[j][k]+=X[i][j]*X[i][k]}const beta=solveLinear(A,b);return v.map((z,i)=>z-X[i].reduce((q,w,j)=>q+w*beta[j],0))};return corr(fit(y),fit(x0))}
function pacf(a:number[]){return Array.from({length:Math.min(12,Math.floor(a.length/5))},(_,i)=>({lag:i+1,value:partialCorrAtLag(a,i+1)}))}
function pmi(ns:string[]){return pairs.map(([a,b])=>{const joint:Record<string,number>={},ca:Record<string,number>={},cb:Record<string,number>={};for(const x of ns){const A=x[a],B=x[b];joint[A+B]=(joint[A+B]??0)+1;ca[A]=(ca[A]??0)+1;cb[B]=(cb[B]??0)+1}let v=0;for(const [k,c] of Object.entries(joint))v+=(c/ns.length)*Math.log2((c*ns.length)/((ca[k[0]]??1)*(cb[k[1]]??1)));return{positions:`${a+1}↔${b+1}`,mi:v}})}
function transition(ns:string[]){const o:Record<string,number>={};for(let i=0;i<ns.length-1;i++)for(let p=0;p<4;p++){const k=ns[i][p]+'→'+ns[i+1][p];o[k]=(o[k]??0)+1}return o}
function rolling(a:number[],w:number,k:'mean'|'variance'){return a.map((_,i)=>{const s=a.slice(Math.max(0,i-w+1),i+1);return{index:i,value:k==='mean'?mean(s):variance(s)}})}
function smooth(a:number[],alpha:number){let s=a[0]??0;return a.map((x,i)=>i?(s=alpha*x+(1-alpha)*s):s)}
function changePoint(a:number[]){if(a.length<20)return null;let best={index:0,score:0};for(let i=5;i<a.length-5;i++){const l=mean(a.slice(0,i)),r=mean(a.slice(i)),score=Math.abs(l-r)/Math.sqrt(variance(a.slice(0,i))+variance(a.slice(i))+1e-9);if(score>best.score)best={index:i,score}}return best}
function dft(a:number[]){const N=a.length,o:any[]=[];for(let k=0;k<=Math.floor(N/2);k++){let re=0,im=0;for(let t=0;t<N;t++){const q=2*Math.PI*k*t/N;re+=a[t]*Math.cos(q);im-=a[t]*Math.sin(q)}o.push({frequency:k/N,power:(re*re+im*im)/N})}return o}
function specEntropy(a:{power:number}[]){const t=a.reduce((s,x)=>s+x.power,0);return t?a.reduce((s,x)=>{const p=x.power/t;return p?s-p*Math.log2(p):s},0):0}
function minEnt(a:string[]){const m=Math.max(...Object.values(counts(a)),0)/(a.length||1);return m?-Math.log2(m):0}
function renyi(a:string[],q:number){const n=a.length||1;return Math.log2(Object.values(counts(a)).reduce((s,v)=>s+(v/n)**q,0))/(1-q)}
function approxEntropy(a:number[]){if(a.length<20)return null;const m=2,r=.2*(Math.sqrt(variance(a))||1);const phi=(k:number)=>{let s=0;for(let i=0;i<=a.length-k;i++){let c=0;for(let j=0;j<=a.length-k;j++)if(a.slice(i,i+k).every((x,t)=>Math.abs(x-a[j+t])<=r))c++;s+=Math.log((c/(a.length-k+1))||1)}return s/(a.length-k+1)};return phi(m)-phi(m+1)}
function conditional(ns:string[]){let h=0,n=0;for(let p=0;p<3;p++){const m:Record<string,Record<string,number>>={};for(const x of ns){m[x[p]]??={};m[x[p]][x[p+1]]=(m[x[p]][x[p+1]]??0)+1}for(const row of Object.values(m)){const t=Object.values(row).reduce((a,b)=>a+b,0);for(const c of Object.values(row)){const q=c/t;h+=-c*Math.log2(q);n+=c}}}return n?h/n:0}
function blockFreq(a:string[],w:number){const o=[];for(let i=0;i<a.length;i+=w){const s=a.slice(i,i+w),p=s.filter(x=>+x>=5).length/(s.length||1);o.push({block:i/w,p})}return o}
function runsTest(a:string[]){if(!a.length)return null;const b=a.map(x=>+x>=5?1:0);let r=1;for(let i=1;i<b.length;i++)if(b[i]!==b[i-1])r++;return{runs:r,ones:b.filter(x=>x).length,zeros:b.filter(x=>!x).length}}
function longRun(a:string[]){let m=0,c=0,p='';for(const x of a){c=x===p?c+1:1;p=x;m=Math.max(m,c)}return{maxRun:m}}
function serial(a:string[]){return{pairs:counts(a.map((x,i)=>x+(a[i+1]??'')))}}
function cusum(a:number[]){const m=mean(a),sd=Math.sqrt(variance(a))||1;let z=0,max=0,min=0;for(const x of a){z+=(x-m)/sd;max=Math.max(max,z);min=Math.min(min,z)}return{max,min,range:max-min}}
function permutationTest(a:number[]){if(a.length<4)return{observed:0,pValue:null,permutations:0};const observed=Math.abs(corr(a.slice(1),a.slice(0,-1)));let seed=0x51a7e,ge=0,B=Math.min(500,Math.max(100,a.length*5));for(let b=0;b<B;b++){const x=[...a];for(let i=x.length-1;i>0;i--){seed=(1664525*seed+1013904223)>>>0;const j=seed%(i+1);[x[i],x[j]]=[x[j],x[i]];}if(Math.abs(corr(x.slice(1),x.slice(0,-1)))>=observed)ge++;}return{observed,pValue:(ge+1)/(B+1),permutations:B}}

function lz(a:string[]){const s=a.join(''),seen=new Set<string>();let i=0,c=0;while(i<s.length){let j=i+1;while(j<=s.length&&seen.has(s.slice(i,j)))j++;seen.add(s.slice(i,j));c++;i=j}return{complexity:c,normalized:s.length?c/s.length:0}}
function linearComplexity(bits:string[]){let c=0,m=1,L=0,N=0;const C=Array(bits.length+1).fill(0);let B=Array(bits.length+1).fill(0);C[0]=B[0]=1;while(N<bits.length){let d=Number(bits[N])%2;for(let i=1;i<=L;i++)d^=(C[i]&Number(bits[N-i]));if(d===1){const T=C.slice();for(let j=0;j+m<bits.length+1;j++)C[j+m]^=B[j];if(2*L<=N){L=N+1-L;B=T;m=1}else m++;}else m++;N++;}c=L;return{linearComplexity:c,normalized:bits.length?c/bits.length:0}}
function compressionEstimate(a:string[]){const rawBits=a.length*4;const l=lz(a).complexity;const estimatedBits=l*Math.ceil(Math.log2(Math.max(2,a.length)))+Math.ceil(Math.log2(Math.max(2,l)));return{rawBits,estimatedCompressedBits:estimatedBits,estimatedCompressionRatio:rawBits?estimatedBits/rawBits:1,method:'LZ78 complexity estimate'}}
function recurrence(a:string[]){let same=0,total=0;for(let i=0;i<a.length;i++)for(let j=i+1;j<a.length;j++){total++;if(a[i]===a[j])same++}return{total,same,rate:total?same/total:0}}
function transitionStability(a:string[]){const mid=Math.floor(a.length/2),t=(x:string[])=>counts(x.slice(0,-1).map((v,i)=>v+'→'+x[i+1]));const first=t(a.slice(0,mid)),second=t(a.slice(mid));const keys=new Set([...Object.keys(first),...Object.keys(second)]);let l1=0;for(const k of keys)l1+=Math.abs((first[k]||0)/Math.max(1,mid-1)-(second[k]||0)/Math.max(1,a.length-mid-1));return{first,second,totalVariationDistance:l1/2}}
function clusterStates(a:string[]){const labels=['AAAA','AAAB','AABB','AABC','ABCD'];const countsBy:Record<string,number>={};for(const x of a)countsBy[x]=(countsBy[x]||0)+1;const top=labels.filter(x=>countsBy[x]!==undefined).sort((x,y)=>(countsBy[y]||0)-(countsBy[x]||0));return{method:'deterministic structural clustering',clusters:top.map((label,i)=>({id:i+1,label,count:countsBy[label]})),unassigned:a.filter(x=>!labels.includes(x)).length}}
function rankFormulaCandidates(a:number[]){const models=[{name:'linear',fit:fit(a,1),complexity:2},{name:'quadratic',fit:fit(a,2),complexity:3},{name:'cubic',fit:fit(a,3),complexity:4}];const ranked=models.map(m=>({model:m.name,r2:m.fit.r2,complexity:m.complexity,bic:bic(m.fit.residuals,m.complexity,a.length)})).sort((x,y)=>(x.bic??Infinity)-(y.bic??Infinity));return{candidates:models.map(m=>({model:m.name,r2:m.fit.r2,complexity:m.complexity})),ranked}}
function bic(residuals:number[],k:number,n:number){if(!n)return null;const rss=Math.max(1e-12,residuals.reduce((s,x)=>s+x*x,0));return n*Math.log(rss/n)+k*Math.log(n)}
function minePatternRules(a:string[]){const rules:Record<string,{support:number;nextDigit:Record<string,number>}>={};for(let i=0;i<a.length-1;i++){const key=pattern(a[i]);rules[key]??={support:0,nextDigit:{}};rules[key].support++;const d=a[i+1][0];rules[key].nextDigit[d]=(rules[key].nextDigit[d]||0)+1;}return Object.entries(rules).map(([pat,r])=>{const total=r.support;const best=Object.entries(r.nextDigit).sort((x,y)=>y[1]-x[1])[0];return{pattern:pat,support:total/Math.max(1,a.length-1),nextDigit:best?.[0]??null,confidence:best?best[1]/total:0}})}
