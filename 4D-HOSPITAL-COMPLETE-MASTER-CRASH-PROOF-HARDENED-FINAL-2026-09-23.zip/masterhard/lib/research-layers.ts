/**
 * 4D HOSPITAL — Core Research Engine meta-validation layers.
 * These layers validate/compare the existing 107 analyses; they do not add
 * new candidate-prediction signals and never claim a guaranteed future result.
 */

export interface ResearchDraw { first:string; second?:string; third?:string; special?:string[]; consolation?:string[]; date?:string; }
export interface LayerRanked { num:string; confidence?:number; contributions?:Array<{key:string;label?:string;score:number;weight:number;contribution:number}>; }

export interface WalkForward20 {
  windows:Array<{trainSize:number;tests:number;exact4D:number;exact4DRate:number;topN:number}>;
  aggregate:{tests:number;exact4D:number;exact4DRate:number};
  leakageSafe:boolean;
  note:string;
}
export interface OOSStability {
  windows:Array<{trainSize:number;top:string[]}>;
  meanJaccard:number;
  top1Agreement:number;
  rankSpread:number;
  status:'STABLE'|'MIXED'|'UNSTABLE'|'INSUFFICIENT_DATA';
}
export interface DriftRegime {
  recentSize:number; baselineSize:number; psi:number; meanShift:number; entropyShift:number;
  driftLevel:'LOW'|'MODERATE'|'HIGH'|'INSUFFICIENT_DATA';
  regimes:Array<{label:string;size:number;mean:number;entropy:number}>;
}
export interface ModelAgreement {
  methods:Array<{name:string;top:string[]}>;
  meanPairwiseJaccard:number;
  consensus:string[];
  disagreement:string[];
  status:'HIGH'|'MIXED'|'LOW'|'INSUFFICIENT_DATA';
}
export interface AblationSensitivity {
  rows:Array<{signal:string;baselineTop:string;ablationTop:string;top1Changed:boolean;scoreDrop:number}>;
  meanTop1Change:number;
  meanScoreDrop:number;
  sensitivity:'LOW'|'MODERATE'|'HIGH'|'INSUFFICIENT_DATA';
}
export interface EvidenceScorecard {
  sampleSize:number; dataQuality:number; oosCoverage:number; oosStability:number;
  modelAgreement:number; driftRisk:number; uncertainty:number; overallEvidence:number;
  grade:'A'|'B'|'C'|'D'|'INSUFFICIENT_DATA';
  caveats:string[];
}
export interface ResearchLayers {
  version:'research-layers-v1';
  walkForward20:WalkForward20;
  oosStability:OOSStability;
  driftRegime:DriftRegime;
  modelAgreement:ModelAgreement;
  ablationSensitivity:AblationSensitivity;
  evidenceScorecard:EvidenceScorecard;
}

const valid=(n:string)=>/^\d{4}$/.test(n);
const clamp=(x:number)=>Math.max(0,Math.min(1,x));
const mean=(a:number[])=>a.length?a.reduce((s,x)=>s+x,0)/a.length:0;
const entropy=(a:string[])=>{const c:Record<string,number>={};for(const x of a)c[x]=(c[x]??0)+1;const n=a.length||1;return Object.values(c).reduce((s,v)=>{const p=v/n;return s-p*Math.log2(p)},0)};
const jaccard=(a:string[],b:string[])=>{const A=new Set(a),B=new Set(b),u=new Set([...A,...B]).size;return u?([...A].filter(x=>B.has(x)).length/u):1};
const topBy=(draws:ResearchDraw[],topN:number,kind:'global'|'recent'|'sum'|'pair'|'position')=>{
  const rows=draws.map(x=>x.first).filter(valid); const c:Record<string,number>={};
  if(kind==='global'||kind==='recent'){const src=kind==='recent'?rows.slice(0,Math.min(30,rows.length)):rows;for(const n of src)for(const d of n)c[d]=(c[d]??0)+1;}
  const score=(n:string)=>{if(kind==='global'||kind==='recent')return [...n].reduce((s,d)=>s+(c[d]??0),0);if(kind==='sum'){const sums:Record<string,number>={};for(const n of rows)sums[[...n].reduce((s,d)=>s+Number(d),0)]=(sums[[...n].reduce((s,d)=>s+Number(d),0)]??0)+1;return sums[[...n].reduce((s,d)=>s+Number(d),0)]??0;}if(kind==='pair'){const p:Record<string,number>={};for(const n of rows){for(const [a,b] of [[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]]){const k=n[a]+n[b];p[k]=(p[k]??0)+1;}}return [[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]].reduce((s,[a,b])=>s+(p[n[a]+n[b]]??0),0);}const pos:Record<string,number>[]=[{}, {}, {}, {}];for(const n of rows)n.split('').forEach((d,i)=>pos[i][d]=(pos[i][d]??0)+1);return n.split('').reduce((s,d,i)=>s+(pos[i][d]??0),0)};
  return Array.from({length:10000},(_,i)=>String(i).padStart(4,'0')).sort((a,b)=>score(b)-score(a)||a.localeCompare(b)).slice(0,topN);
};

export function runResearchLayers(draws:ResearchDraw[], current:LayerRanked[], core107Count:number, rankFn:(train:ResearchDraw[],topN:number)=>string[]):ResearchLayers{
  const rows=draws.filter(x=>valid(x.first)); const n=rows.length; const topN=Math.min(10,Math.max(3,current.length||10));
  // 1) Walk-Forward 2.0: multiple expanding windows, newest-first input, no future leakage.
  const trainSizes=[30,60,120].filter(x=>n>x+2); const wfWindows=[] as WalkForward20['windows'];
  for(const trainSize of trainSizes){const tests=Math.min(8,n-trainSize);let hits=0,validTests=0;for(let i=0;i<tests;i++){const train=rows.slice(i+1,i+1+trainSize);const actual=rows[i].first;if(train.length<trainSize||!valid(actual))continue;const top=rankFn(train,topN);validTests++;if(top.includes(actual))hits++;}wfWindows.push({trainSize,tests:validTests,exact4D:hits,exact4DRate:validTests?Math.round(hits/validTests*100):0,topN});}
  const wfTests=wfWindows.reduce((s,x)=>s+x.tests,0),wfHits=wfWindows.reduce((s,x)=>s+x.exact4D,0);
  const walkForward20:WalkForward20={windows:wfWindows,aggregate:{tests:wfTests,exact4D:wfHits,exact4DRate:wfTests?Math.round(wfHits/wfTests*100):0},leakageSafe:true,note:'Expanding-window chronological OOS; training uses only observations older than each test draw.'};

  // 2) OOS Stability: top-set overlap and top-1 persistence across rolling windows.
  const stabilitySizes=[30,60,120].filter(x=>n>=x);const stabWindows=stabilitySizes.map(trainSize=>({trainSize,top:rankFn(rows.slice(0,trainSize),topN)}));
  const js:number[]=[];for(let i=1;i<stabWindows.length;i++)js.push(jaccard(stabWindows[i-1].top,stabWindows[i].top));
  const top1Agreement=stabWindows.length>1?stabWindows.filter(x=>x.top[0]===stabWindows[0].top[0]).length/stabWindows.length:0;
  const rankSpread=stabWindows.length?Math.min(1,mean(stabWindows.map(x=>{const idx=current.findIndex(c=>c.num===x.top[0]);return idx<0?1:idx/Math.max(1,current.length-1)}))):1;
  const meanJ=js.length?mean(js):0;const stabilityStatus=n<30?'INSUFFICIENT_DATA':meanJ>=.65?'STABLE':meanJ>=.4?'MIXED':'UNSTABLE';
  const oosStability:OOSStability={windows:stabWindows,meanJaccard:Math.round(meanJ*100)/100,top1Agreement:Math.round(top1Agreement*100)/100,rankSpread:Math.round(rankSpread*100)/100,status:stabilityStatus};

  // 3) Drift / regime detection: recent vs baseline digit distributions + rolling regimes.
  const recent=rows.slice(0,Math.min(50,n)), baseline=rows.slice(Math.min(50,n));const freq=(rs:ResearchDraw[])=>{const c=Array(10).fill(0);for(const r of rs)for(const d of r.first)c[+d]++;return c.map(v=>v/(rs.length*4||1));};
  const a=freq(recent),b=freq(baseline.length?baseline:rows);let psi=0;for(let i=0;i<10;i++){const aa=Math.max(a[i],1e-6),bb=Math.max(b[i],1e-6);psi+=(aa-bb)*Math.log(aa/bb);}const allNums=rows.map(x=>+x.first);const meanShift=Math.abs(mean(recent.map(x=>+x.first))-mean((baseline.length?baseline:rows).map(x=>+x.first)))/10000;const entropyShift=Math.abs(entropy(recent.flatMap(x=>x.first.split('')))-entropy((baseline.length?baseline:rows).flatMap(x=>x.first.split(''))))/Math.log2(10);const driftScore=psi+meanShift+entropyShift;const driftLevel=n<50?'INSUFFICIENT_DATA':driftScore<.05?'LOW':driftScore<.15?'MODERATE':'HIGH';
  const regimes=[50,100,200].filter(w=>n>=w).map((w,i)=>{const r=rows.slice(0,w);return{label:i===0?'Recent':`Window ${w}`,size:r.length,mean:Math.round(mean(r.map(x=>+x.first))),entropy:Math.round(entropy(r.flatMap(x=>x.first.split('')))*100)/100}});
  const driftRegime:DriftRegime={recentSize:recent.length,baselineSize:baseline.length||rows.length,psi:Math.round(psi*1000)/1000,meanShift:Math.round(meanShift*1000)/1000,entropyShift:Math.round(entropyShift*1000)/1000,driftLevel,regimes};

  // 4) Model agreement/disagreement: independent descriptive ranking families vs current engine.
  const methods=[['Core Engine',current.slice(0,topN).map(x=>x.num)],['Global Frequency',topBy(rows,topN,'global')],['Recent Frequency',topBy(rows,topN,'recent')],['Sum Structure',topBy(rows,topN,'sum')],['Pair Structure',topBy(rows,topN,'pair')],['Position Matrix',topBy(rows,topN,'position')]].map(([name,top])=>({name:String(name),top:top as string[]}));
  const pairs:number[]=[];for(let i=0;i<methods.length;i++)for(let j=i+1;j<methods.length;j++)pairs.push(jaccard(methods[i].top,methods[j].top));const meanPairwise=mean(pairs);const counts:Record<string,number>={};for(const m of methods)for(const x of m.top)counts[x]=(counts[x]??0)+1;const consensus=Object.entries(counts).filter(([,v])=>v>=Math.ceil(methods.length/2)).sort((a,b)=>b[1]-a[1]).slice(0,topN).map(([x])=>x);const disagreement=methods[0].top.filter(x=>methods.filter(m=>m.top.includes(x)).length<=1).slice(0,topN);const agreementStatus=n<30?'INSUFFICIENT_DATA':meanPairwise>=.6?'HIGH':meanPairwise>=.35?'MIXED':'LOW';
  const modelAgreement:ModelAgreement={methods,meanPairwiseJaccard:Math.round(meanPairwise*100)/100,consensus,disagreement,status:agreementStatus};

  // 5) Ablation + sensitivity: remove one active contribution from current top candidate.
  const rowsA=[] as AblationSensitivity['rows'];const ablationSignals=[...new Set(current.flatMap(c=>(c.contributions||[]).slice(0,8).map(x=>x.key)))];const baselineTop=current[0]?.num||'';for(const key of ablationSignals){const ranked=current.map(c=>{const cs=c.contributions||[];const kept=cs.filter(x=>x.key!==key);const score=kept.reduce((s,x)=>s+x.contribution,0)/Math.max(1,kept.reduce((s,x)=>s+x.weight,0));return{num:c.num,score,base:cs.reduce((s,x)=>s+x.contribution,0)/Math.max(1,cs.reduce((s,x)=>s+x.weight,0))}}).sort((a,b)=>b.score-a.score||a.num.localeCompare(b.num));const base=current.find(c=>c.num===baselineTop);const baseC=base?.contributions||[];const baseScore=baseC.reduce((s,x)=>s+x.contribution,0)/Math.max(1,baseC.reduce((s,x)=>s+x.weight,0));const ab=ranked[0];const label=baseC.find(x=>x.key===key)?.label||key;rowsA.push({signal:label,baselineTop,ablationTop:ab?.num||'',top1Changed:(ab?.num||'')!==baselineTop,scoreDrop:Math.max(0,baseScore-(ranked.find(x=>x.num===baselineTop)?.score??baseScore))});}
  const meanDrop=mean(rowsA.map(x=>x.scoreDrop));const ablationSensitivity:AblationSensitivity={rows:rowsA,meanTop1Change:mean(rowsA.map(x=>x.top1Changed?1:0)),meanScoreDrop:Math.round(meanDrop*1000)/1000,sensitivity:n<30?'INSUFFICIENT_DATA':meanDrop>.15?'HIGH':meanDrop>.05?'MODERATE':'LOW'};

  // 6) Evidence / uncertainty scorecard. Explicitly separates evidence strength from prediction probability.
  const dataQuality=n>=100?1:n>=50?.8:n>=20?.6:n>=10?.4:.2;const oosCoverage=clamp(wfTests/60);const oosStab=stabilityStatus==='STABLE'?.9:stabilityStatus==='MIXED'?.6:stabilityStatus==='UNSTABLE'?.3:0;const agreement=agreementStatus==='HIGH'?.9:agreementStatus==='MIXED'?.6:agreementStatus==='LOW'?.3:0;const driftRisk=driftLevel==='LOW'?.9:driftLevel==='MODERATE'?.6:driftLevel==='HIGH'?.25:0;const uncertainty=1-(.45*dataQuality+.25*oosCoverage+.15*oosStab+.15*agreement);const overall=.2*dataQuality+.2*oosCoverage+.2*oosStab+.2*agreement+.2*driftRisk;const grade=n<20?'INSUFFICIENT_DATA':overall>=.8?'A':overall>=.65?'B':overall>=.5?'C':'D';const caveats:string[]=[];if(n<100)caveats.push('Sample size is below the preferred 100-draw stability threshold.');if(wfTests<20)caveats.push('OOS coverage is limited.');if(driftLevel==='HIGH')caveats.push('Recent and baseline distributions differ materially.');if(agreementStatus==='LOW')caveats.push('Independent ranking families disagree substantially.');caveats.push('Evidence/uncertainty scores are descriptive research diagnostics, not winning probabilities.');
  const evidenceScorecard:EvidenceScorecard={sampleSize:n,dataQuality:Math.round(dataQuality*100),oosCoverage:Math.round(oosCoverage*100),oosStability:Math.round(oosStab*100),modelAgreement:Math.round(agreement*100),driftRisk:Math.round(driftRisk*100),uncertainty:Math.round(uncertainty*100),overallEvidence:Math.round(overall*100),grade,caveats};
  return{version:'research-layers-v1',walkForward20,oosStability,driftRegime,modelAgreement,ablationSensitivity,evidenceScorecard};
}
