/** 4D HOSPITAL — canonical dataset and explicit target contract. */

export interface CanonicalDraw {
  id: number;
  company: string;
  date: string;
  drawNo: string | null;
  first: string;
  second: string;
  third: string;
  special: string[];
  consolation: string[];
}

export interface DatasetMetadata {
  schemaVersion: 1;
  datasetVersion: string;
  source: 'sqlite' | 'localStorage-fallback' | 'import' | 'memory';
  recordCount: number;
  validRecordCount: number;
  companies: string[];
  oldestDate: string | null;
  newestDate: string | null;
}

export type TargetType = 'HISTORICAL_DESCRIPTIVE' | 'NEXT_OBSERVATION_OOS';

export interface AnalysisTarget {
  targetType: TargetType;
  targetDefinition: string;
  targetPosition: 'FIRST' | 'SECOND' | 'THIRD' | 'SPECIAL' | 'CONSOLATION' | 'NONE';
  horizon: number;
  evaluationWindow: number;
  leakageSafe: boolean;
}

export const CANONICAL_DATASET_SCHEMA_VERSION = 1;

export function isCanonicalDraw(r: Partial<CanonicalDraw>): boolean {
  return !!r && Number.isSafeInteger(Number(r.id)) && Number(r.id) >= 1 &&
    /^[a-z0-9_-]+$/i.test(String(r.company ?? '')) &&
    /^\d{4}-\d{2}-\d{2}$/.test(String(r.date ?? '')) &&
    /^\d{4}$/.test(String(r.first ?? '')) &&
    /^\d{4}$/.test(String(r.second ?? '')) &&
    /^\d{4}$/.test(String(r.third ?? '')) &&
    (r.drawNo == null || String(r.drawNo).trim() !== '') &&
    Array.isArray(r.special) && r.special.every(x => /^\d{4}$/.test(String(x))) &&
    Array.isArray(r.consolation) && r.consolation.every(x => /^\d{4}$/.test(String(x)));
}

export function canonicalizeDraw(r: Partial<CanonicalDraw>): CanonicalDraw {
  const clean4=(v:unknown)=>{ const raw=String(v??'').trim(); return /^\d{4}$/.test(raw) ? raw : null; };
  const cleanList=(v:unknown)=>Array.isArray(v) ? v.map(clean4).filter((x): x is string => !!x).slice(0,50) : [];
  const row:CanonicalDraw={
    id:Number(r.id), company:String(r.company??'').trim().toLowerCase(), date:String(r.date??'').slice(0,10),
    drawNo:r.drawNo==null||String(r.drawNo).trim()===''?null:String(r.drawNo).trim(),
    first:clean4(r.first) as string, second:clean4(r.second) as string, third:clean4(r.third) as string,
    special:cleanList(r.special), consolation:cleanList(r.consolation)
  };
  if(!isCanonicalDraw(row)) throw new Error('Invalid canonical draw record');
  return row;
}

export function datasetFingerprint(rows: CanonicalDraw[]): string {
  let h=0x811c9dc5;
  const stable=[...rows].sort((a,b)=>a.date.localeCompare(b.date)||a.company.localeCompare(b.company)||String(a.drawNo??'').localeCompare(String(b.drawNo??''))||a.id-b.id);
  const text=JSON.stringify(stable);
  for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,0x01000193);}
  return `ds1-${(h>>>0).toString(16).padStart(8,'0')}`;
}

export function buildDatasetMetadata(rows: CanonicalDraw[], source:DatasetMetadata['source']='memory'): DatasetMetadata {
  const valid=rows.filter(isCanonicalDraw);
  const dates=valid.map(x=>x.date).sort();
  return {
    schemaVersion:CANONICAL_DATASET_SCHEMA_VERSION,
    datasetVersion:datasetFingerprint(valid), source,
    recordCount:rows.length, validRecordCount:valid.length,
    companies:[...new Set(valid.map(x=>x.company))].sort(),
    oldestDate:dates[0]??null,newestDate:dates.at(-1)??null
  };
}

export function makeDescriptiveTarget(): AnalysisTarget {
  return {targetType:'HISTORICAL_DESCRIPTIVE',targetDefinition:'Historical structure/statistic only; no future-number guarantee.',targetPosition:'NONE',horizon:0,evaluationWindow:0,leakageSafe:true};
}

export function makeNextObservationTarget(position:'FIRST'|'SECOND'|'THIRD'|'SPECIAL'|'CONSOLATION'='FIRST', evaluationWindow=20): AnalysisTarget {
  return {targetType:'NEXT_OBSERVATION_OOS',targetDefinition:`Next ${position} observation evaluated only after the training cutoff.`,targetPosition:position,horizon:1,evaluationWindow:Math.max(1,evaluationWindow),leakageSafe:true};
}
