/** First-prize research observations captured by the leakage-safe Research Cycle.
 * These are intentionally separate from the canonical master draw table because
 * the Research Cycle may receive only the actual 4-digit first result. Once a
 * complete draw is imported, the matching observation is automatically ignored
 * for training to prevent double counting.
 */
export interface ResearchObservation {
  id: number;
  company: string;
  date: string;
  number: string;
  cycleId: string;
  createdAt: string;
}

const KEY = '4d_hospital_research_observations_v1';

export function loadResearchObservations(): ResearchObservation[] {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || '[]');
    return Array.isArray(raw) ? raw.filter(isObservation) : [];
  } catch { return []; }
}

export function saveResearchObservations(rows: ResearchObservation[]) {
  localStorage.setItem(KEY, JSON.stringify(rows.slice(-5000)));
}

function isObservation(x: any): x is ResearchObservation {
  return Number.isSafeInteger(Number(x?.id)) && Number(x.id) > 0 &&
    typeof x?.company === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(String(x?.date)) &&
    /^\d{4}$/.test(String(x?.number)) && typeof x?.cycleId === 'string';
}

export function addResearchObservations(
  rows: ResearchObservation[],
  company: string,
  date: string,
  numbers: string[],
  cycleId: string,
): ResearchObservation[] {
  const out = [...rows];
  const existing = new Set(out.map(x => `${x.company}|${x.date}|${x.number}`));
  let next = out.reduce((m, x) => Math.max(m, x.id), 0) + 1;
  const now = new Date().toISOString();
  for (const number of numbers) {
    if (!/^\d{4}$/.test(number)) continue;
    const key = `${company}|${date}|${number}`;
    if (existing.has(key)) continue;
    out.push({ id: next++, company, date, number, cycleId, createdAt: now });
    existing.add(key);
  }
  return out.slice(-5000);
}

export function observationsForTraining(
  observations: ResearchObservation[],
  masterRows: { company: string; date: string; first: string }[],
) {
  const masterKeys = new Set(masterRows.map(r => `${r.company}|${r.date}|${r.first}`));
  return observations.filter(o => !masterKeys.has(`${o.company}|${o.date}|${o.number}`));
}
