/**
 * 4D HOSPITAL — Advanced Mathematical Engine
 *
 * Offline, data-driven ranking engine. It does NOT predict a guaranteed future
 * result; it ranks candidates from the user's historical data.
 *
 * 28 base signals + advanced matrix layers + walk-forward reliability weighting.
 */

import { buildValidationReport, redundancyGroups, type ValidationReport } from "./advanced-validation";
import { trainLstmDigitModel, geneticOptimize } from "./advanced-models";
import { run107Analysis, type Analysis107Result } from "./analysis-engine-107";
import { runResearchLayers, type ResearchLayers } from "./research-layers";

export interface DrawEntry { first:string; second:string; third:string; special:string[]; consolation:string[]; date?:string; }

export interface SignalContribution { key:string; label:string; score:number; weight:number; contribution:number; }

export interface NumberScore {
  num:string; confidence:number; rank:number; signalsAgreed:number; mainReason:string;
  breakdown:{
    posFreq:number; pairScore:number; skipBonus:number; momentumScore:number; clusterScore:number; balanceBonus:number;
    hotDigit?:number; tripletScore?:number; transitionScore?:number; mirrorScore?:number; neighborScore?:number;
    highLowScore?:number; benfordScore?:number; overdueScore?:number; sumScore?:number; evenOddScore?:number;
    calendarScore?:number; trendingScore?:number; permutationScore?:number; diversityScore?:number;
    regressionScore?:number; sequenceScore?:number; geneticScore?:number; backtestScore?:number;
    spreadScore?:number; consensusScore?:number; bayesianScore?:number; antiRepeatScore?:number;
  };
  contributions?:SignalContribution[];
}

export interface DigitMomentum { digit:string; label:"উঠছে 🔥"|"স্থির ➡️"|"নামছে ❄️"; recentCount:number; olderCount:number; momentum:number; }
export interface PairInfo { pair:string; count:number; strength:"শক্তিশালী"|"মাঝারি"|"দুর্বল"; color:string; }
export interface PositionHeatmap { pos:number; label:string; digits:{d:string;weight:number;pct:number}[]; }
export interface ClusterGroup { digits:string[]; count:number; examples:string[]; }

export interface AdvancedMetrics {
  transitionMatrix:{from:string;to:string;count:number;pct:number}[];
  pairMatrix:{pair:string;count:number;pct:number}[];
  tripletPatterns:{triplet:string;count:number;pct:number}[];
  digitEntropy:{position:number;label:string;entropy:number;stability:number}[];
  mutualCorrelation:{positions:string;correlation:number}[];
  rollingWindows:{window:number;top:string[];draws:number}[];
  overdueGap:{position:number;digit:string;gap:number;avgGap:number;dueScore:number}[];
  patternClassification:{pattern:string;count:number;pct:number}[];
  signalReliability:{key:string;label:string;tests:number;hits:number;rate:number;weight:number}[];
  ensemble:{candidate:string;score:number;signals:string[]}[];
  validation: ValidationReport;
  quality:string;
}

export interface BacktestResult {
  total:number; exact4DHits:number; frontPairHits:number; backPairHits:number; anyDigitHits:number;
  exact4DRate:number; frontPairRate:number; backPairRate:number; anyDigitRate:number;
}

export interface EngineAnalysis {
  scores:NumberScore[];
  stats:{total:number;afterBadPattern:number;finalTop:number;drawsUsed:number};
  digitMomentum:DigitMomentum[]; topPairs:PairInfo[]; positionHeatmap:PositionHeatmap[]; clusterGroups:ClusterGroup[];
  backtest:BacktestResult; advanced:AdvancedMetrics; core107:Analysis107Result[]; researchLayers:ResearchLayers;
}

const LABELS:Record<string,string>={
  position:"Position Matrix",hot:"Hot Digit",pair:"Pair Matrix",triplet:"Triplet Pattern",transition:"Transition Matrix",
  mirror:"Mirror",neighbor:"Neighbor +1/-1",highlow:"High/Low",benford:"Benford-style",overdue:"Overdue/GAP",sum:"Sum Distribution",
  evenodd:"Even/Odd",calendar:"Calendar/Weekday",trending:"Recent Trend",permutation:"Permutation",diversity:"Digit Diversity",
  crosscompany:"Cross-Company",regression:"Regression Sum Trend",sequence:"Sequence Match",lstm:"Trained LSTM Signal",genetic:"Genetic Optimizer",skip:"Skip-Draw",
  cold:"Cold/Due",backtest:"Backtest Support",spread:"Digit Spread",consensus:"Consensus",bayesian:"Bayesian Smoothing",antiRepeat:"Anti-Repeat/Diversity Guard"
};
export const ACTIVE_SIGNAL_CATALOG = Object.entries(LABELS).map(([key,label])=>({key,label}));
const KEYS=Object.keys(LABELS);

function recencyWeight(i:number){ if(i<5)return 4; if(i<10)return 3; if(i<30)return 2; return 1; }
function valid(n:string){return /^\d{4}$/.test(n);}
function allPrize(r:DrawEntry){return [r.first,r.second,r.third,...(r.special||[]),...(r.consolation||[])].filter(valid);}
function firstNums(draws:DrawEntry[]){return draws.map(d=>d.first).filter(valid);}
// Canonical 4D mirror mapping used everywhere in the central engine: 0↔5, 1↔6, 2↔7, 3↔8, 4↔9.
function mirrorDigit(d:string){return String((Number(d)+5)%10);}
function neighborDigits(d:string){const n=Number(d);return [String((n+1)%10),String((n+9)%10)];}
function isBadPattern(_n:string){ return false; } // Candidate space is never silently filtered; structural guards remain soft evidence.
function norm(v:number,max:number){return max>0?Math.max(0,Math.min(1,v/max)):0;}
function entropy(counts:number[]){const t=counts.reduce((a,b)=>a+b,0);if(!t)return 0;let e=0;for(const c of counts){if(c){const p=c/t;e-=p*Math.log2(p);}}return e;}
function corr(a:number[],b:number[]){const n=Math.min(a.length,b.length);if(n<3)return 0;const ma=a.slice(0,n).reduce((x,y)=>x+y,0)/n,mb=b.slice(0,n).reduce((x,y)=>x+y,0)/n;let xy=0,aa=0,bb=0;for(let i=0;i<n;i++){const x=a[i]-ma,y=b[i]-mb;xy+=x*y;aa+=x*x;bb+=y*y;}return aa&&bb?xy/Math.sqrt(aa*bb):0;}

function buildContext(draws:DrawEntry[]){
  const first=firstNums(draws); const recent=first.slice(0,15); const older=first.slice(15,45);
  const pos:Array<Record<string,number>>=Array.from({length:4},()=>({}));
  const global:Array<Record<string,number>>=Array.from({length:4},()=>({}));
  const pairs:Record<string,number>={}; const trips:Record<string,number>={}; const transitions:Array<Record<string,number>>=Array.from({length:4},()=>({}));
  const sums:number[]=[]; const weekdays:Record<string,number>={};
  for(let i=0;i<draws.length;i++){
    const n=draws[i].first;if(!valid(n))continue;const w=recencyWeight(i);const d=n.split('');
    sums.push(d.reduce((a,x)=>a+Number(x),0));
    const day=draws[i].date ? new Date(`${draws[i].date}T00:00:00Z`).getUTCDay() : 0;weekdays[String(day)]=(weekdays[String(day)]||0)+w;
    d.forEach((x,p)=>{pos[p][x]=(pos[p][x]||0)+w;global[p][x]=(global[p][x]||0)+1;});
    for(const [a,b] of [[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]]){const k=d[a]+d[b];pairs[k]=(pairs[k]||0)+w;}
    for(const [a,b,c] of [[0,1,2],[0,1,3],[0,2,3],[1,2,3]]){const k=d[a]+d[b]+d[c];trips[k]=(trips[k]||0)+w;}
  }
  // Transition direction is chronological (older -> newer), while the UI stores
  // rows newest-first. Reversing here prevents an accidental time-direction flip.
  const chronological=[...first].reverse();
  for(let i=0;i+1<chronological.length;i++){
    const from=chronological[i],to=chronological[i+1];
    if(valid(from)&&valid(to)) for(let p=0;p<4;p++){
      const k=from[p]+to[p];
      transitions[p][k]=(transitions[p][k]||0)+recencyWeight(chronological.length-1-i);
    }
  }
  const recentFreq:Record<string,number>={};for(const n of recent)for(const d of n)recentFreq[d]=(recentFreq[d]||0)+1;
  const oldFreq:Record<string,number>={};for(const n of older)for(const d of n)oldFreq[d]=(oldFreq[d]||0)+1;
  const lastSeen:Array<Record<string,number>>=Array.from({length:4},()=>({}));for(let p=0;p<4;p++)for(let d=0;d<10;d++)lastSeen[p][String(d)]=draws.length;
  for(let i=0;i<first.length;i++){const d=first[i].split('');d.forEach((x,p)=>{if(lastSeen[p][x]===draws.length)lastSeen[p][x]=i;});}
  const avgGap:Array<Record<string,number>>=Array.from({length:4},()=>({}));
  for(let p=0;p<4;p++)for(let dg=0;dg<10;dg++){const ds=String(dg);const seen:number[]=[];for(let i=0;i<first.length;i++)if(first[i][p]===ds)seen.push(i);const gaps:number[]=[];for(let i=1;i<seen.length;i++)gaps.push(seen[i]-seen[i-1]);avgGap[p][ds]=gaps.length?gaps.reduce((a,b)=>a+b,0)/gaps.length:Math.max(5,draws.length/5);}
  const maxPos=[0,1,2,3].map(p=>Math.max(...Object.values(pos[p]),1));
  const maxPair=Math.max(...Object.values(pairs),1),maxTrip=Math.max(...Object.values(trips),1),maxTrans=transitions.map(t=>Math.max(...Object.values(t),1));
  const maxHot=Math.max(...Object.values(recentFreq),1);
  const sumMean=sums.length?sums.reduce((a,b)=>a+b,0)/sums.length:18;
  const sumSd=Math.sqrt(sums.reduce((s,x)=>s+(x-sumMean)**2,0)/(sums.length||1))||5;
  const dayTotal=Object.values(weekdays).reduce((a,b)=>a+b,0)||1, dayMax=Math.max(...Object.values(weekdays),0);
  return {first,pos,global,pairs,trips,transitions,sums,weekdays,recentFreq,oldFreq,lastSeen,avgGap,maxPos,maxPair,maxTrip,maxTrans,maxHot,sumMean,sumSd,dayTotal,dayMax};
}

function signalScores(num:string,ctx:ReturnType<typeof buildContext>,draws:DrawEntry[],model?:ReturnType<typeof trainLstmDigitModel>,ga?:Map<string,number>):Record<string,number>{
  const d=num.split('');
  const maxPos=ctx.maxPos, maxPair=ctx.maxPair, maxTrip=ctx.maxTrip, maxTrans=ctx.maxTrans;
  const out:Record<string,number>={lstm:0};
  out.position=d.reduce((s,x,p)=>s+norm(ctx.pos[p][x]||0,maxPos[p]),0)/4;
  const maxHot=ctx.maxHot;out.hot=d.reduce((s,x)=>s+norm(ctx.recentFreq[x]||0,maxHot),0)/4;
  // Canonical combinatorial coverage: all 6 unordered position-pairs and all 4 position-triplets.
  const pairKeys=[[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]].map(([a,b])=>d[a]+d[b]);
  const tripKeys=[[0,1,2],[0,1,3],[0,2,3],[1,2,3]].map(([a,b,c])=>d[a]+d[b]+d[c]);
  out.pair=pairKeys.reduce((s,p)=>s+norm(ctx.pairs[p]||0,maxPair),0)/pairKeys.length;
  out.triplet=tripKeys.reduce((s,t)=>s+norm(ctx.trips[t]||0,maxTrip),0)/tripKeys.length;
  out.transition=d.reduce((s,x,p)=>{const recent=ctx.first[0]?.[p];const observed=recent ? (ctx.transitions[p][recent+x]||0) : 0;return s+norm(observed,ctx.maxTrans[p]);},0)/4;
  out.mirror=d.reduce((s,x,p)=>s+norm(ctx.pos[p][mirrorDigit(x)]||0,maxPos[p]),0)/4;
  out.neighbor=d.reduce((s,x,p)=>{const ns=neighborDigits(x);return s+Math.max(...ns.map(z=>norm(ctx.pos[p][z]||0,maxPos[p])));},0)/4;
  const highs=d.filter(x=>Number(x)>=5).length,odds=d.filter(x=>Number(x)%2).length;out.highlow=highs===2?1:([1,3].includes(highs)?0.65:0.25);out.evenodd=odds===2?1:([1,3].includes(odds)?0.65:0.25);
  const lead=Number(d[0]);out.benford=lead===0?0.15:1/(1+Math.abs(lead-4.5)/4.5);
  let overdue=0;for(let p=0;p<4;p++){const gap=ctx.lastSeen[p][d[p]]??draws.length;const ag=ctx.avgGap[p][d[p]]||10;overdue+=Math.min(1,gap/Math.max(ag,1));}out.overdue=overdue/4;
  const sum=d.reduce((s,x)=>s+Number(x),0);const mean=ctx.sumMean;const sd=ctx.sumSd;out.sum=Math.exp(-Math.abs(sum-mean)/(sd*1.5));
  // Candidate-independent calendar totals cannot distinguish candidates; do not let them affect ranking.
  out.calendar=0;
  const trend=d.reduce((s,x)=>s+(ctx.recentFreq[x]||0)/Math.max(ctx.oldFreq[x]||1,1),0)/4;out.trending=Math.min(1,trend/2);
  const uniq=new Set(d).size;out.permutation=uniq>=3?1:uniq===2?0.6:0.2;out.diversity=(uniq-1)/3;
  // Cross-company evidence requires synchronized multi-company history. This engine receives one company at a time.
  out.crosscompany=0;
  // Proper one-step linear-trend estimate on the historical sum series.
  const ys=ctx.sums.slice().reverse(); let regressionPred=mean;
  if(ys.length>=2){const xbar=(ys.length-1)/2, ybar=ys.reduce((a,b)=>a+b,0)/ys.length;let num=0,den=0;for(let i=0;i<ys.length;i++){num+=(i-xbar)*(ys[i]-ybar);den+=(i-xbar)**2;}const slope=den?num/den:0;regressionPred=ybar+slope*ys.length;}
  out.regression=Math.exp(-Math.abs(sum-regressionPred)/Math.max(ctx.sumSd*1.5,1));
  const recentSeq=ctx.first.slice(0,3);let seq=0;for(const r of recentSeq){let m=0;for(let p=0;p<4;p++)if(r[p]===d[p])m++;seq+=m/4;}out.sequence=seq/Math.max(recentSeq.length,1);
  // Genetic score is valid only for candidates actually evaluated by the optimizer; never replace it with a proxy.
  out.genetic=ga?.has(num)?Math.max(0,Math.min(1,ga.get(num)??0)):0;
  if(model?.length===4 && model.every(m=>m.trained)){let ls=0;for(let p=0;p<4;p++)ls+=model[p].probabilities[Number(d[p])]??0;out.lstm=Math.max(0,Math.min(1,ls/4));out.sequence=Math.max(out.sequence,ls/4);} else out.lstm=0;
  let skip=0;for(let p=0;p<4;p++){const g=ctx.lastSeen[p][d[p]]??draws.length;skip+=g>=4&&g<=8?1:g>=9&&g<=15?0.7:g>=16?0.4:0.1;}out.skip=skip/4;out.cold=1-out.hot;
  // Candidate-specific backtest evidence is supplied by the validation layer, not fabricated here.
  out.backtest=0;out.spread=Math.min(1,(Math.max(...d.map(Number))-Math.min(...d.map(Number)))/9);
  // Consensus is a derived view, not an additional independent evidence channel.
  out.consensus=0;
  // Laplace/Bayesian smoothing: posterior mean with alpha=1,beta=1 against 10-digit prior.
  let bay=0;for(let p=0;p<4;p++){const c=ctx.pos[p][d[p]]||0;const total=Object.values(ctx.pos[p]).reduce((a,b)=>a+b,0);bay+=(c+1)/(total+10);}out.bayesian=bay/4;
  const repeats=d.length-new Set(d).size;out.antiRepeat=repeats===0?1:repeats===1?0.72:0.4;
  return out;
}

function reliabilityForSignals(draws:DrawEntry[],topN:number):AdvancedMetrics["signalReliability"]{
  const labels=KEYS.map(key=>({key,label:LABELS[key],tests:0,hits:0,rate:0,weight:1}));
  if(draws.length<15)return labels;
  // Use a data-dependent walk-forward window instead of an arbitrary 3-test cap.
  const maxTests=Math.min(20,draws.length-10);
  for(let t=0;t<maxTests;t++){
    // Data are newest-first. The actual draw is draws[t]; training may only use older rows.
    const train=draws.slice(t+1); const actual=draws[t]?.first;
    if(!valid(actual) || train.length<5)continue;
    const ctx=buildContext(train);
    const ranked:Record<string,{num:string;score:number}[]>=Object.fromEntries(KEYS.map(k=>[k,[]]));
    for(let n=0;n<10000;n++){
      const num=String(n).padStart(4,'0');
      if(isBadPattern(num))continue;
      const sig=signalScores(num,ctx,train);
      for(const k of KEYS)ranked[k].push({num,score:sig[k]??0});
    }
    for(const row of labels){
      row.tests++;
      ranked[row.key].sort((a,b)=>b.score-a.score);
      if(ranked[row.key].slice(0,topN).some(x=>x.num===actual))row.hits++;
    }
  }
  for(const row of labels){
    row.rate=row.tests?row.hits/row.tests:0;
    // Weakly informative Beta(1,1) prior prevents tiny samples from producing extreme weights.
    const posterior=(row.hits+1)/(row.tests+2);
    row.weight=0.5+Math.min(1.5,Math.max(0.25,posterior*2));
  }
  return labels;
}

interface RankedCandidate { num:string; score:number; signals:Record<string,number>; contributions:SignalContribution[]; }

function normalizeSignalMap(candidates:RankedCandidate[]):void{
  for(const key of KEYS){
    let min=Infinity,max=-Infinity;
    for(const c of candidates){const v=c.signals[key]??0; if(v<min)min=v; if(v>max)max=v;}
    const range=max-min;
    for(const c of candidates)c.signals[key]=range>1e-12?Math.max(0,Math.min(1,(c.signals[key]-min)/range)):0.5;
  }
}

function redundancyAdjustedWeights(candidates:RankedCandidate[], reliability:AdvancedMetrics["signalReliability"]):Record<string,number>{
  const series:Record<string,number[]>={};
  for(const key of KEYS)series[key]=candidates.map(c=>c.signals[key]??0);
  const groups=redundancyGroups(series);
  const base=Object.fromEntries(reliability.map(x=>[x.key,x.weight]));
  const out:Record<string,number>={};
  for(const group of groups){
    const divisor=Math.sqrt(Math.max(1,group.members.length));
    for(const key of group.members)out[key]=(base[key]??1)/divisor;
  }
  for(const key of KEYS)if(out[key]===undefined)out[key]=base[key]??1;
  return out;
}

function rankCandidates(draws:DrawEntry[],topN:number,reliability?:AdvancedMetrics["signalReliability"],useAdaptive=true):RankedCandidate[]{
  const rel=reliability??(useAdaptive?reliabilityForSignals(draws,topN):KEYS.map(key=>({key,label:LABELS[key],tests:0,hits:0,rate:0,weight:1})));
  const ctx=buildContext(draws);
  const model=trainLstmDigitModel(ctx.first,8,10);
  const baseFitness=(n:string)=>{const d=n.split('');let s=0;for(let p=0;p<4;p++)s+=(ctx.pos[p][d[p]]||0)/Math.max(ctx.maxPos[p],1);return s/4;};
  const ga=geneticOptimize(baseFitness,90,12);
  const candidates:RankedCandidate[]=[];
  for(let n=0;n<10000;n++){
    const num=String(n).padStart(4,'0');
    if(isBadPattern(num))continue;
    candidates.push({num,score:0,signals:signalScores(num,ctx,draws,model,ga),contributions:[]});
  }
  // Every signal is normalized across the same 0000–9999 candidate space before weighting.
  normalizeSignalMap(candidates);
  const weights=redundancyAdjustedWeights(candidates,rel);
  // Signals with no independent evidence in the current dataset are excluded from the denominator.
  const inactive=new Set(['crosscompany','calendar','backtest','consensus','cold','genetic']);
  if(!model || !model.every(m=>m.trained)) inactive.add('lstm');
  const totalW=KEYS.reduce((s,k)=>s+(inactive.has(k)?0:(weights[k]??1)),0)||1;
  for(const c of candidates){
    c.contributions=KEYS.map(key=>{
      const score=c.signals[key]??0, weight=inactive.has(key)?0:(weights[key]??1);
      return {key,label:LABELS[key],score,weight,contribution:score*weight};
    });
    c.score=c.contributions.reduce((sum,x)=>sum+x.contribution,0)/totalW;
  }
  candidates.sort((a,b)=>b.score-a.score || a.num.localeCompare(b.num));
  return candidates.slice(0,Math.max(1,topN));
}

function quickRank(draws:DrawEntry[],topN:number):string[]{
  return rankCandidates(draws,topN,undefined,true).map(x=>x.num);
}

function quickRankValidation(draws:DrawEntry[],topN:number):string[]{
  // K-fold is a validation of the ranking architecture itself. Adaptive signal reliability
  // is learned separately by the walk-forward tests; using equal prior weights here avoids
  // nesting another full walk-forward loop inside every fold.
  return rankCandidates(draws,topN,undefined,false).map(x=>x.num);
}

function deterministicCluster(draws:DrawEntry[]){const f:Record<string,number>={};for(const r of draws.slice(0,50)){if(!valid(r.first))continue;const d=[...new Set(r.first.split(''))].sort();for(let a=0;a<d.length;a++)for(let b=a+1;b<d.length;b++){const k=d[a]+d[b];f[k]=(f[k]||0)+1;}}return f;}

function computeAdvanced(draws:DrawEntry[],scores:NumberScore[],reliability:AdvancedMetrics["signalReliability"]):AdvancedMetrics{
  const first=firstNums(draws);const trans:Record<string,number>={};for(let i=0;i+1<first.length;i++)if(valid(first[i])&&valid(first[i+1]))for(let p=0;p<4;p++){const k=first[i][p]+first[i+1][p];trans[k]=(trans[k]||0)+1;}
  const pairs:Record<string,number>={},trips:Record<string,number>={};for(const n of first){const d=n.split('');for(const [a,b] of [[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]]){const k=d[a]+d[b];pairs[k]=(pairs[k]||0)+1;}for(const [a,b,c] of [[0,1,2],[0,1,3],[0,2,3],[1,2,3]]){const k=d[a]+d[b]+d[c];trips[k]=(trips[k]||0)+1;}}
  const transitionMatrix=Object.entries(trans).sort((a,b)=>b[1]-a[1]).slice(0,30).map(([k,c])=>({from:k[0],to:k[1],count:c,pct:Math.round(c/Math.max(...Object.values(trans),1)*100)}));
  const pairMatrix=Object.entries(pairs).sort((a,b)=>b[1]-a[1]).slice(0,30).map(([pair,count])=>({pair,count,pct:Math.round(count/Math.max(...Object.values(pairs),1)*100)}));
  const tripletPatterns=Object.entries(trips).sort((a,b)=>b[1]-a[1]).slice(0,30).map(([triplet,count])=>({triplet,count,pct:Math.round(count/Math.max(...Object.values(trips),1)*100)}));
  const digitEntropy=[] as AdvancedMetrics["digitEntropy"];for(let p=0;p<4;p++){const c=Array.from({length:10},()=>0);for(const n of first)if(valid(n))c[Number(n[p])]++;const e=entropy(c),stability=Math.round((1-e/Math.log2(10))*100)/100;digitEntropy.push({position:p,label:["১ম","২য়","৩য়","৪র্থ"][p],entropy:Math.round(e*100)/100,stability});}
  const posArrays:number[][]=Array.from({length:4},()=>[]);for(const n of first)if(valid(n))for(let p=0;p<4;p++)posArrays[p].push(Number(n[p]));const mutualCorrelation=[] as AdvancedMetrics["mutualCorrelation"];for(let a=0;a<4;a++)for(let b=a+1;b<4;b++)mutualCorrelation.push({positions:`${a+1}↔${b+1}`,correlation:Math.round(corr(posArrays[a],posArrays[b])*100)/100});
  const rollingWindows=[10,20,30,50].map(w=>{const train=draws.slice(0,Math.min(w,draws.length));const ctx=buildContext(train);const arr:Array<{num:string;s:number}>=[];for(let n=0;n<10000;n++){const num=String(n).padStart(4,'0');if(isBadPattern(num))continue;const s=signalScores(num,ctx,train);arr.push({num,s:(s.position+s.pair+s.triplet+s.sum+s.bayesian)/5});}arr.sort((a,b)=>b.s-a.s);return{window:w,top:arr.slice(0,5).map(x=>x.num),draws:train.length};});
  const ctx=buildContext(draws);const overdueGap:AdvancedMetrics["overdueGap"]=[];for(let p=0;p<4;p++)for(let d=0;d<10;d++){const dg=String(d),gap=ctx.lastSeen[p][dg]??draws.length,avg=ctx.avgGap[p][dg]||10;overdueGap.push({position:p,digit:dg,gap,avgGap:Math.round(avg*10)/10,dueScore:Math.round(Math.min(1,gap/Math.max(avg,1))*100)/100});}
  const ensemble=scores.slice(0,10).map(s=>({candidate:s.num,score:s.confidence,signals:(s.contributions||[]).sort((a,b)=>b.contribution-a.contribution).slice(0,6).map(x=>x.label)}));
  const patternCounts:Record<string,number>={AAAA:0,AABB:0,ABAB:0,ABBA:0,ABCD:0,Other:0};
  for(const n of first){if(!valid(n))continue;const d=n.split('');const u=new Set(d).size;let pattern="Other";if(u===1)pattern="AAAA";else if(u===2&&d[0]===d[1]&&d[2]===d[3]&&d[0]!==d[2])pattern="AABB";else if(u===2&&d[0]===d[2]&&d[1]===d[3]&&d[0]!==d[1])pattern="ABAB";else if(u===2&&d[0]===d[3]&&d[1]===d[2]&&d[0]!==d[1])pattern="ABBA";else if(u===4)pattern="ABCD";patternCounts[pattern]++;}
  const patternTotal=Object.values(patternCounts).reduce((a,b)=>a+b,0)||1;
  const patternClassification=Object.entries(patternCounts).map(([pattern,count])=>({pattern,count,pct:Math.round(count/patternTotal*100)})).sort((a,b)=>b.count-a.count);
  const signalSeries:Record<string,number[]> = {}; for(const key of KEYS) signalSeries[key]=scores.map(s=>((s.contributions||[]).find(c=>c.key===key)?.score??0));
  const validation = buildValidationReport(draws, 0, 0, Math.min(10, scores.length), signalSeries);
  return{transitionMatrix,pairMatrix,tripletPatterns,digitEntropy,mutualCorrelation,rollingWindows,overdueGap,patternClassification,signalReliability:reliability,ensemble,validation,quality:reliability.some(x=>x.tests>0)?"Adaptive signal weighting is active from historical walk-forward tests.":"Adaptive weighting is waiting for enough history (15+ draws)."};
}

function emptyEngine():EngineAnalysis{const researchLayers=runResearchLayers([],[],0,()=>[]);return{scores:[],stats:{total:10000,afterBadPattern:0,finalTop:0,drawsUsed:0},digitMomentum:[],topPairs:[],positionHeatmap:[],clusterGroups:[],backtest:{total:0,exact4DHits:0,frontPairHits:0,backPairHits:0,anyDigitHits:0,exact4DRate:0,frontPairRate:0,backPairRate:0,anyDigitRate:0},core107:[],advanced:{transitionMatrix:[],pairMatrix:[],tripletPatterns:[],digitEntropy:[],mutualCorrelation:[],rollingWindows:[],overdueGap:[],patternClassification:[],signalReliability:[],ensemble:[],validation:buildValidationReport([],0,0,20),quality:""},researchLayers};}


function walkForwardEnsembleBacktest(draws:DrawEntry[],topN:number):BacktestResult{
  if(draws.length<15)return{total:0,exact4DHits:0,frontPairHits:0,backPairHits:0,anyDigitHits:0,exact4DRate:0,frontPairRate:0,backPairRate:0,anyDigitRate:0};
  // Newest-first data: each test draw is ranked using only older observations.
  const tests=Math.min(20,draws.length-10);let exact4D=0,front=0,back=0,partial=0,validTests=0;
  for(let i=0;i<tests;i++){
    const train=draws.slice(i+1),actual=draws[i].first;
    if(!valid(actual)||train.length<5)continue;
    const top=quickRank(train,Math.max(1,topN));validTests++;
    if(top.includes(actual))exact4D++;
    if(top.some(n=>n.slice(0,2)===actual.slice(0,2)))front++;
    if(top.some(n=>n.slice(2)===actual.slice(2)))back++;
    if(top.some(n=>{let m=0;for(let p=0;p<4;p++)if(n[p]===actual[p])m++;return m>=2;}))partial++;
  }
  const rate=(x:number)=>validTests?Math.round(x/validTests*100):0;
  return{total:validTests,exact4DHits:exact4D,frontPairHits:front,backPairHits:back,anyDigitHits:partial,exact4DRate:rate(exact4D),frontPairRate:rate(front),backPairRate:rate(back),anyDigitRate:rate(partial)};
}

export function runPatternEngine(draws:DrawEntry[],topN=20):EngineAnalysis{
  if(draws.length<5)return emptyEngine();
  const finalTop=Math.max(1,Math.min(10000,topN));
  const reliability=reliabilityForSignals(draws,Math.min(10,finalTop));
  const ranked=rankCandidates(draws,finalTop,reliability);
  const scores:NumberScore[]=ranked.map((c,i)=>{
    const strong=c.contributions.filter(x=>x.score>=0.6).length;
    const topReason=c.contributions.reduce((a,b)=>b.contribution>a.contribution?b:a,c.contributions[0]);
    const b:any={
      posFreq:Math.round((c.signals.position??0)*100),pairScore:Math.round((c.signals.pair??0)*100),skipBonus:Math.round((c.signals.skip??0)*100),
      momentumScore:Math.round((c.signals.trending??0)*100),clusterScore:Math.round((c.signals.diversity??0)*100),balanceBonus:Math.round((((c.signals.evenodd??0)+(c.signals.highlow??0))/2)*100),
      hotDigit:Math.round((c.signals.hot??0)*100),tripletScore:Math.round((c.signals.triplet??0)*100),transitionScore:Math.round((c.signals.transition??0)*100),mirrorScore:Math.round((c.signals.mirror??0)*100),
      neighborScore:Math.round((c.signals.neighbor??0)*100),highLowScore:Math.round((c.signals.highlow??0)*100),benfordScore:Math.round((c.signals.benford??0)*100),overdueScore:Math.round((c.signals.overdue??0)*100),
      sumScore:Math.round((c.signals.sum??0)*100),evenOddScore:Math.round((c.signals.evenodd??0)*100),calendarScore:Math.round((c.signals.calendar??0)*100),trendingScore:Math.round((c.signals.trending??0)*100),
      permutationScore:Math.round((c.signals.permutation??0)*100),diversityScore:Math.round((c.signals.diversity??0)*100),regressionScore:Math.round((c.signals.regression??0)*100),sequenceScore:Math.round((c.signals.sequence??0)*100),lstmScore:Math.round((c.signals.lstm??0)*100),
      geneticScore:Math.round((c.signals.genetic??0)*100),backtestScore:Math.round((c.signals.backtest??0)*100),spreadScore:Math.round((c.signals.spread??0)*100),consensusScore:Math.round((c.signals.consensus??0)*100),
      bayesianScore:Math.round((c.signals.bayesian??0)*100),antiRepeatScore:Math.round((c.signals.antiRepeat??0)*100)
    };
    // Confidence is a normalized descriptive index, not a probability of winning.
    const confidence=Math.round(Math.min(99,Math.max(1,45+c.score*45+(strong/Math.max(KEYS.length,1))*9)));
    return{num:c.num,confidence,rank:i+1,signalsAgreed:strong,mainReason:topReason?.key??"consensus",breakdown:b,
      contributions:c.contributions.map(x=>({...x,score:Math.round(x.score*1000)/1000,weight:Math.round(x.weight*100)/100,contribution:Math.round(x.contribution*1000)/1000}))};
  });

  const ctx=buildContext(draws);
  const digitMomentum=Array.from({length:10},(_,i)=>{
    const d=String(i),r=ctx.recentFreq[d]||0,o=ctx.oldFreq[d]||0;
    const m=o?r/Math.max(o*(15/Math.max(15,Math.min(30,draws.length-15))),1):(r?2:1);
    return{digit:d,label:(m>1.3?"উঠছে 🔥":m<0.7?"নামছে ❄️":"স্থির ➡️") as DigitMomentum["label"],recentCount:r,olderCount:o,momentum:Math.round(m*100)/100};
  }).sort((a,b)=>b.momentum-a.momentum);
  const maxPair=Math.max(...Object.values(ctx.pairs),1);
  const topPairs=Object.entries(ctx.pairs).sort((a,b)=>b[1]-a[1]).slice(0,12).map(([pair,count])=>({pair,count,strength:(count/maxPair>.65?"শক্তিশালী":count/maxPair>.35?"মাঝারি":"দুর্বল") as PairInfo["strength"],color:count/maxPair>.65?"#4ade80":count/maxPair>.35?"#fbbf24":"#94a3b8"}));
  const positionHeatmap=Array.from({length:4},(_,p)=>{const total=Object.values(ctx.pos[p]).reduce((a,b)=>a+b,0)||1;return{pos:p,label:["১ম ঘর","২য় ঘর","৩য় ঘর","৪র্থ ঘর"][p],digits:Array.from({length:10},(_,i)=>{const d=String(i),w=ctx.pos[p][d]||0;return{d,weight:w,pct:Math.round(w/total*100)};}).sort((a,b)=>b.weight-a.weight)};});
  const clusters=deterministicCluster(draws);const clusterGroups=Object.entries(clusters).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([key,count])=>({digits:key.split(""),count,examples:scores.filter(s=>key.split("").every(d=>s.num.includes(d))).slice(0,3).map(s=>s.num)}));
  const backtest=walkForwardEnsembleBacktest(draws,Math.min(10,finalTop));
  const advanced=computeAdvanced(draws,scores,reliability);
  const signalSeries:Record<string,number[]>={};
  for(const key of KEYS)signalSeries[key]=scores.map(s=>((s.contributions||[]).find(c=>c.key===key)?.score??0));
  // K-fold is computed with the same no-look-ahead ranking architecture. To keep the Android UI responsive,
  // it is limited to 3 contiguous folds; each fold still ranks the full 0000–9999 candidate space.
  advanced.validation=buildValidationReport(draws,backtest.exact4DHits,backtest.total,Math.min(10,finalTop),signalSeries,(train,n)=>quickRankValidation(train.map(d=>({first:d.first,second:"",third:"",special:[],consolation:[],date:d.date})),Math.min(10,finalTop)),scores.flatMap(s=>(s.contributions||[]).map(c=>c.score)));
  const core107=run107Analysis(draws.map((d,i)=>({id:i+1,company:"unknown",date:d.date??"1970-01-01",drawNo:String(i+1),first:d.first,second:d.second,third:d.third,special:d.special||[],consolation:d.consolation||[]})));
  const researchRank=(train:DrawEntry[],n:number)=>{const rows=train.filter(d=>/^\d{4}$/.test(d.first));const pos:Array<Record<string,number>>=[{},{},{},{}];const pair:Record<string,number>={};for(const d of rows){d.first.split("").forEach((x,p)=>pos[p][x]=(pos[p][x]||0)+1);for(const [a,b] of [[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]]){const k=d.first[a]+d.first[b];pair[k]=(pair[k]||0)+1;}}const score=(num:string)=>num.split("").reduce((z,x,p)=>z+(pos[p][x]||0),0)+[[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]].reduce((z,[a,b])=>z+(pair[num[a]+num[b]]||0),0);return Array.from({length:10000},(_,i)=>String(i).padStart(4,"0")).sort((a,b)=>score(b)-score(a)||a.localeCompare(b)).slice(0,n)};
  const researchLayers=runResearchLayers(draws,scores,core107.length,researchRank);
  return{scores,stats:{total:10000,afterBadPattern:10000,finalTop:finalTop,drawsUsed:draws.length},digitMomentum,topPairs,positionHeatmap,clusterGroups,backtest,advanced,core107,researchLayers};
}
