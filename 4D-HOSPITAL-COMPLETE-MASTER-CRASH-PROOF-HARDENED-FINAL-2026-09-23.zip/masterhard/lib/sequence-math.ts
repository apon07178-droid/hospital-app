/**
 * 4D HOSPITAL — explicit sequence mathematics.
 *
 * These are mathematical analysis helpers, not prediction guarantees.
 * They intentionally operate on an ordered historical numeric series.
 */

export interface ArithmeticSequenceResult {
  applicable: boolean;
  firstTerm: number | null;
  commonDifference: number | null;
  differences: number[];
  maxDeviation: number | null;
  termCount: number;
}

export interface GeometricSequenceResult {
  applicable: boolean;
  firstTerm: number | null;
  commonRatio: number | null;
  ratios: number[];
  maxDeviation: number | null;
  termCount: number;
  zeroDenominatorCount: number;
}

const finite = (v: number) => Number.isFinite(v);
const approxEqual = (a: number, b: number, tolerance = 1e-10) => Math.abs(a - b) <= tolerance * Math.max(1, Math.abs(a), Math.abs(b));

export function differenceSeries(values: number[], order = 1): number[] {
  if (!Array.isArray(values) || order < 1 || !values.every(finite)) return [];
  let current = [...values];
  for (let k = 0; k < order; k++) {
    if (current.length < 2) return [];
    current = current.slice(1).map((v, i) => v - current[i]);
  }
  return current;
}

export function analyzeArithmeticSequence(values: number[], tolerance = 1e-10): ArithmeticSequenceResult {
  const differences = differenceSeries(values, 1);
  if (!values.length || !values.every(finite) || !differences.length) {
    return { applicable: false, firstTerm: values[0] ?? null, commonDifference: null, differences, maxDeviation: null, termCount: values.length };
  }
  const d = differences[0];
  const maxDeviation = Math.max(...differences.map(x => Math.abs(x - d)));
  return { applicable: differences.every(x => approxEqual(x, d, tolerance)), firstTerm: values[0], commonDifference: d, differences, maxDeviation, termCount: values.length };
}

export function nthArithmeticTerm(firstTerm: number, commonDifference: number, rank: number): number | null {
  if (![firstTerm, commonDifference].every(finite) || !Number.isInteger(rank) || rank < 1) return null;
  return firstTerm + (rank - 1) * commonDifference;
}

export function arithmeticRankOfTerm(term: number, firstTerm: number, commonDifference: number, tolerance = 1e-10): number | null {
  if (![term, firstTerm, commonDifference].every(finite)) return null;
  if (approxEqual(commonDifference, 0, tolerance)) return null;
  const n = 1 + (term - firstTerm) / commonDifference;
  return Number.isInteger(n) && n >= 1 && approxEqual(n, Math.round(n), tolerance) ? Math.round(n) : null;
}

export function analyzeGeometricSequence(values: number[], tolerance = 1e-10): GeometricSequenceResult {
  if (!Array.isArray(values) || !values.length || !values.every(finite)) {
    return { applicable: false, firstTerm: values[0] ?? null, commonRatio: null, ratios: [], maxDeviation: null, termCount: values.length, zeroDenominatorCount: 0 };
  }
  const ratios: number[] = [];
  let zeroDenominatorCount = 0;
  for (let i = 1; i < values.length; i++) {
    const prev = values[i - 1], next = values[i];
    if (prev === 0) { zeroDenominatorCount++; continue; }
    ratios.push(next / prev);
  }
  if (values.length < 2 || !ratios.length || zeroDenominatorCount > 0) {
    return { applicable: false, firstTerm: values[0], commonRatio: ratios[0] ?? null, ratios, maxDeviation: ratios.length ? Math.max(...ratios.map(x => Math.abs(x - ratios[0]))) : null, termCount: values.length, zeroDenominatorCount };
  }
  const r = ratios[0];
  const maxDeviation = Math.max(...ratios.map(x => Math.abs(x - r)));
  return { applicable: ratios.every(x => approxEqual(x, r, tolerance)), firstTerm: values[0], commonRatio: r, ratios, maxDeviation, termCount: values.length, zeroDenominatorCount };
}

export function nthGeometricTerm(firstTerm: number, commonRatio: number, rank: number): number | null {
  if (![firstTerm, commonRatio].every(finite) || !Number.isInteger(rank) || rank < 1) return null;
  return firstTerm * Math.pow(commonRatio, rank - 1);
}

export function geometricRankOfTerm(term: number, firstTerm: number, commonRatio: number, tolerance = 1e-10): number | null {
  if (![term, firstTerm, commonRatio].every(finite)) return null;
  if (approxEqual(firstTerm, 0, tolerance)) return approxEqual(term, 0, tolerance) ? 1 : null;
  if (approxEqual(commonRatio, 0, tolerance)) {
    if (approxEqual(term, firstTerm, tolerance) && !approxEqual(firstTerm, 0, tolerance)) return 1;
    return null;
  }
  if (commonRatio < 0 && term / firstTerm > 0) return null;
  if (commonRatio > 0 && term / firstTerm <= 0) return null;
  const ratio = term / firstTerm;
  const n = 1 + Math.log(Math.abs(ratio)) / Math.log(Math.abs(commonRatio));
  const rounded = Math.round(n);
  return Number.isFinite(n) && rounded >= 1 && approxEqual(n, rounded, tolerance) && approxEqual(nthGeometricTerm(firstTerm, commonRatio, rounded)!, term, tolerance) ? rounded : null;
}
