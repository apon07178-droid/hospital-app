import { runPatternEngine, type EngineAnalysis, type NumberScore } from './scorer';

export type ResearchCycleStatus = 'LOCKED' | 'VALIDATED' | 'APPLIED';
export type ResearchCompany = string;

export interface LockedCandidate {
  num: string;
  rank: number;
  confidence: number;
  signalsAgreed: number;
  methods: { key: string; label: string; score: number; contribution: number }[];
}

export interface ResearchCycle {
  id: string;
  company: ResearchCompany;
  createdAt: string;
  status: ResearchCycleStatus;
  batchSize: number;
  trainingCount: number;
  trainingLatestDate: string;
  datasetFingerprint: string;
  candidateLimit: number;
  lockedCandidates: LockedCandidate[];
  analysisFinal: {
    top: LockedCandidate[];
    methodCount: number;
    backtest: EngineAnalysis['backtest'];
    validation: EngineAnalysis['advanced']['validation'];
  };
  actualBatch: string[];
  actualDate?: string;
  validationFinal?: {
    totalActual: number;
    exactMatches: string[];
    trace: { num: string; predicted: boolean; rank?: number; methods: string[]; evidence: string[] }[];
    methodHits: { key: string; label: string; hits: number; rate: number; actualNumbers: string[] }[];
    unmatched: string[];
    /** Evidence-based post-result diagnostics. These describe measurable mismatch patterns; they do not claim a single causal reason. */
    mismatchDiagnostics: {
      num: string;
      nearestCandidates: { num: string; rank: number; digitDistance: number; matchingPositions: number }[];
      matchedPositions: number;
      positionMismatches: { position: number; actualDigit: string; candidateDigits: string[] }[];
      structure: { sum: number; evenDigits: number; uniqueDigits: number; range: number };
      nearestStructure: { num: string; sum: number; evenDigits: number; uniqueDigits: number; range: number }[];
      observedFactors: string[];
    }[];
    aggregate: {
      exactRate: number;
      digitPositionRate: number;
      averageNearestDigitDistance: number;
      rankCutoffMisses: number;
      commonFactors: { factor: string; count: number }[];
    };
  };
  appliedAt?: string;
}

const STORAGE_KEY = '4d_hospital_research_cycles_v1';

export function loadResearchCycles(): ResearchCycle[] {
  try {
    const x = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    if (!Array.isArray(x)) return [];
    // Backward-compatible hydration for cycles created before the mismatch-diagnostic layer.
    return x.map((c:any) => {
      if (!c?.validationFinal) return c;
      return {
        ...c,
        validationFinal: {
          ...c.validationFinal,
          mismatchDiagnostics: Array.isArray(c.validationFinal.mismatchDiagnostics) ? c.validationFinal.mismatchDiagnostics : [],
          aggregate: c.validationFinal.aggregate || {
            exactRate: c.validationFinal.totalActual ? (c.validationFinal.exactMatches?.length || 0) / c.validationFinal.totalActual : 0,
            digitPositionRate: 0,
            averageNearestDigitDistance: 0,
            rankCutoffMisses: c.validationFinal.unmatched?.length || 0,
            commonFactors: []
          }
        }
      } as ResearchCycle;
    });
  } catch { return []; }
}

export function saveResearchCycles(rows: ResearchCycle[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(rows.slice(0, 250)));
}

function hashString(input: string): string {
  // Deterministic 32-bit FNV-1a; used as a version fingerprint, not cryptographic security.
  let h = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) { h ^= input.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return (h >>> 0).toString(16).padStart(8, '0');
}

export function fingerprintDraws(rows: { id:number; company:string; date:string; drawNo:string|null; first:string }[]): string {
  const stable = rows.map(r => [r.id,r.company,r.date,r.drawNo,r.first]).sort((a,b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
  return hashString(JSON.stringify(stable));
}

function candidateFromScore(s: NumberScore): LockedCandidate {
  const methods = (s.contributions || [])
    .filter(c => c.score >= 0.6)
    .sort((a,b) => b.contribution - a.contribution)
    .map(c => ({ key:c.key, label:c.label, score:c.score, contribution:c.contribution }));
  return { num:s.num, rank:s.rank, confidence:s.confidence, signalsAgreed:s.signalsAgreed, methods };
}

export function createLockedCycle(
  company: string,
  draws: { id:number; company:string; date:string; drawNo:string|null; first:string; second?:string; third?:string; special?:string[]; consolation?:string[] }[],
  batchSize = 23,
  candidateLimit = 100,
): ResearchCycle {
  const filtered = draws
    .filter(r => r.company === company && /^\d{4}$/.test(r.first))
    .sort((a,b) => b.date.localeCompare(a.date) || b.id-a.id);
  if (filtered.length < 10) throw new Error('কমপক্ষে ১০টি valid historical draw প্রয়োজন।');

  // IMPORTANT: this function receives only the pre-lock dataset. No future/actual batch is accepted.
  const engine = runPatternEngine(filtered.map(r => ({
    date:r.date, first:r.first, second:r.second || '', third:r.third || '', special:r.special || [], consolation:r.consolation || []
  })), Math.max(20, Math.min(250, candidateLimit)));
  const top = engine.scores.slice(0, Math.max(1, Math.min(candidateLimit, engine.scores.length))).map(candidateFromScore);
  const now = new Date().toISOString();
  const token = typeof crypto !== 'undefined' && crypto.getRandomValues ? Array.from(crypto.getRandomValues(new Uint32Array(2))).map(x=>x.toString(36)).join('').slice(0,8).toUpperCase() : hashString(now + company);
  const id = `RC-${now.replace(/[-:.TZ]/g,'').slice(0,14)}-${token}`;
  return {
    id, company, createdAt:now, status:'LOCKED', batchSize:Math.max(1,batchSize), trainingCount:filtered.length,
    trainingLatestDate:filtered[0]?.date || '', datasetFingerprint:fingerprintDraws(filtered), candidateLimit:top.length,
    lockedCandidates:top,
    analysisFinal:{top:top.slice(0,Math.min(20,top.length)),methodCount:28,backtest:engine.backtest,validation:engine.advanced.validation},
    actualBatch:[],
  };
}

function digitDistance(a: string, b: string): number {
  let d = 0;
  for (let i = 0; i < 4; i++) if (a[i] !== b[i]) d++;
  return d;
}

function structureOf(n: string) {
  const digits = n.split('').map(Number);
  return { sum: digits.reduce((a,b)=>a+b,0), evenDigits: digits.filter(d=>d%2===0).length, uniqueDigits: new Set(digits).size, range: Math.max(...digits)-Math.min(...digits) };
}

function buildMismatchDiagnostics(actual: string[], candidates: LockedCandidate[]) {
  const rankMap = new Map(candidates.map(c => [c.num, c.rank]));
  const pool = candidates.slice().sort((a,b)=>a.rank-b.rank);
  const diagnostics = actual.filter(n=>!rankMap.has(n)).map(num => {
    const ranked = pool.map(c => ({ c, d: digitDistance(num,c.num) }))
      .sort((a,b)=>a.d-b.d || a.c.rank-b.c.rank);
    const nearest = ranked.slice(0,5);
    const s = structureOf(num);
    const nearestStructure = nearest.slice(0,3).map(x => ({num:x.c.num, ...structureOf(x.c.num)}));
    const positionMismatches = [0,1,2,3].map(position => ({
      position, actualDigit:num[position], candidateDigits:[...new Set(nearest.map(x=>x.c.num[position]))]
    })).filter(x => x.candidateDigits.length && !x.candidateDigits.includes(x.actualDigit));
    const factors:string[]=[];
    if (nearest.length) {
      const best=nearest[0];
      if (best.d>=3) factors.push('চারটি position-এর মধ্যে ৩ বা ৪টি digit আলাদা ছিল');
      else if (best.d===2) factors.push('নিকটতম candidate-এ ২টি position mismatch ছিল');
      if (nearestStructure.every(x=>Math.abs(x.sum-s.sum)>=5)) factors.push('digit-sum pattern-এর সঙ্গে নিকটতম candidate-গুলোর পার্থক্য ছিল');
      if (nearestStructure.every(x=>x.evenDigits!==s.evenDigits)) factors.push('even/odd composition আলাদা ছিল');
      if (nearestStructure.every(x=>x.uniqueDigits!==s.uniqueDigits)) factors.push('unique-digit/diversity pattern আলাদা ছিল');
      if (nearestStructure.every(x=>x.range!==s.range)) factors.push('digit-range/spread pattern আলাদা ছিল');
      factors.push(`actual candidate pool-এর rank cutoff-এর বাইরে ছিল (নিকটতম rank #${best.c.rank})`);
    } else factors.push('তুলনার জন্য locked candidate pool পাওয়া যায়নি');
    return {
      num,
      nearestCandidates: nearest.map(x=>({num:x.c.num,rank:x.c.rank,digitDistance:x.d,matchingPositions:4-x.d})),
      matchedPositions: nearest.length ? 4-nearest[0].d : 0,
      positionMismatches,
      structure:s,
      nearestStructure,
      observedFactors:[...new Set(factors)]
    };
  });
  const factorCounts=new Map<string,number>();
  for(const d of diagnostics) for(const f of d.observedFactors) factorCounts.set(f,(factorCounts.get(f)||0)+1);
  const totalDigits=actual.length*4;
  const digitPositionRate=totalDigits ? actual.reduce((sum,num)=>{
    const nearest=pool.map(c=>digitDistance(num,c.num)).sort((a,b)=>a-b)[0];
    return sum+(nearest==null?0:4-nearest);
  },0)/totalDigits : 0;
  const nearestDistances=diagnostics.flatMap(d=>d.nearestCandidates.length?[d.nearestCandidates[0].digitDistance]:[]);
  return { diagnostics, aggregate:{
    exactRate:actual.length?actual.filter(n=>rankMap.has(n)).length/actual.length:0,
    digitPositionRate,
    averageNearestDigitDistance:nearestDistances.length?nearestDistances.reduce((a,b)=>a+b,0)/nearestDistances.length:0,
    rankCutoffMisses:diagnostics.length,
    commonFactors:[...factorCounts.entries()].map(([factor,count])=>({factor,count})).sort((a,b)=>b.count-a.count).slice(0,10)
  }};
}

export function validateLockedCycle(cycle: ResearchCycle, actualInput: string[], actualDate?: string): ResearchCycle {
  if (cycle.status !== 'LOCKED') throw new Error('এই cycle ইতিমধ্যে validate করা হয়েছে।');
  const actual = [...new Set(actualInput.map(x => x.trim()).filter(Boolean).map(x => x.padStart(4,'0')).filter(x => /^\d{4}$/.test(x)))];
  if (!actual.length) throw new Error('কমপক্ষে ১টি valid 4-digit actual number দিন।');
  const byNum = new Map(cycle.lockedCandidates.map(c => [c.num,c]));
  const trace = actual.map(num => {
    const c = byNum.get(num);
    const methods = c?.methods.map(m => m.label) || [];
    const evidence = c ? c.methods.slice(0,8).map(m => `${m.label}: ${Math.round(m.score*100)}% signal`) : [];
    return {num,predicted:!!c,rank:c?.rank,methods,evidence};
  });
  const exactMatches = [...new Set(actual.filter(n => byNum.has(n)))];
  const keys = new Map<string,{key:string;label:string;hits:number;actualNumbers:string[]}>();
  for (const t of trace) for (const c of (byNum.get(t.num)?.methods || [])) {
    const x=keys.get(c.key) || {key:c.key,label:c.label,hits:0,actualNumbers:[]};
    x.hits++; if(!x.actualNumbers.includes(t.num)) x.actualNumbers.push(t.num); keys.set(c.key,x);
  }
  const methodHits = [...keys.values()].map(x => ({...x,rate:actual.length?x.hits/actual.length:0})).sort((a,b)=>b.hits-a.hits || a.label.localeCompare(b.label));
  const mismatch=buildMismatchDiagnostics(actual,cycle.lockedCandidates);
  return {...cycle,status:'VALIDATED',actualBatch:actual,actualDate:actualDate || new Date().toISOString().slice(0,10),validationFinal:{totalActual:actual.length,exactMatches,trace,methodHits,unmatched:[...new Set(actual.filter(n=>!byNum.has(n)))],mismatchDiagnostics:mismatch.diagnostics,aggregate:mismatch.aggregate}};
}

export function markCycleApplied(cycle: ResearchCycle): ResearchCycle {
  if (cycle.status !== 'VALIDATED') throw new Error('Validate করার আগে dataset-এ apply করা যাবে না।');
  return {...cycle,status:'APPLIED',appliedAt:new Date().toISOString()};
}

export function cycleSummary(cycles: ResearchCycle[]) {
  const validated = cycles.filter(c => c.validationFinal);
  const methodMap = new Map<string,{key:string;label:string;cycles:number;hits:number;opportunities:number;cycleRates:number[]}>();
  for (const c of validated) for (const m of (c.validationFinal?.methodHits || [])) {
    const x=methodMap.get(m.key)||{key:m.key,label:m.label,cycles:0,hits:0,opportunities:0,cycleRates:[]};
    x.cycles++; x.hits+=m.hits; x.opportunities+=c.validationFinal?.totalActual || 0; x.cycleRates.push(m.rate); methodMap.set(m.key,x);
  }
  const methods=[...methodMap.values()].map(x=>({...x,rate:x.opportunities?x.hits/x.opportunities:0,stability:x.cycleRates.length?x.cycleRates.reduce((a,b)=>a+b,0)/x.cycleRates.length:0})).sort((a,b)=>b.rate-a.rate);
  return {totalCycles:cycles.length,locked:cycles.filter(c=>c.status==='LOCKED').length,validated:validated.length,applied:cycles.filter(c=>c.status==='APPLIED').length,methods};
}
