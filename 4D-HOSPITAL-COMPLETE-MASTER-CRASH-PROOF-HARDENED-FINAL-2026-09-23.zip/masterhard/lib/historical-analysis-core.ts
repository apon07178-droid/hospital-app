import { run107Analysis, type Analysis107Result } from './analysis-engine-107';
import { runPatternEngine, type EngineAnalysis, type DrawEntry } from './scorer';
import type { CanonicalDraw } from './canonical-data';

export interface HistoricalAnalysisCoreResult {
  datasetVersion: string;
  generatedAt: string;
  recordCount: number;
  analysis107: Analysis107Result[];
  signal28: EngineAnalysis;
  quality: { valid: boolean; minRecords: number; message: string };
}

/** Single orchestration boundary: canonical historical data -> 107 evidence + 28 signal engine. */
export function runHistoricalAnalysisCore(draws: CanonicalDraw[], datasetVersion='runtime'): HistoricalAnalysisCoreResult {
  const canonical = draws.filter(d => /^\d{4}$/.test(d.first));
  const analysis107 = run107Analysis(draws);
  const signalInput: DrawEntry[] = canonical.map(d => ({first:d.first, second:d.second, third:d.third, special:d.special ?? [], consolation:d.consolation ?? [], date:d.date}));
  const signal28 = runPatternEngine(signalInput, 20);
  return {
    datasetVersion, generatedAt: new Date().toISOString(), recordCount: canonical.length, analysis107, signal28,
    quality: { valid: canonical.length >= 10, minRecords: 10, message: canonical.length >= 10 ? 'Historical analysis dataset is eligible.' : 'At least 10 valid historical 4-digit records are required for the complete analysis layer.' }
  };
}
