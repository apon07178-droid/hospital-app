# 4D HOSPITAL — Deep Internal Audit
## 2026-09-22 — Mathematical correctness, data flow, storage, analysis execution

### উদ্দেশ্য
শুধু 107টি নাম আছে কি না তা নয়; প্রতিটি অংশের ভিতরের calculation/data-flow বাস্তবে কী করছে তা যাচাই করা।

## A. এই pass-এ সরাসরি সংশোধিত সমস্যা

### A1. Sequence mathematics ছিল metadata-নির্ভর
বর্তমান 107 catalog-এ First/Second/Third Difference ও Ratio Analysis ছিল, কিন্তু explicit arithmetic/geometric sequence rules-এর executable mathematical helper ছিল না।

যোগ করা হয়েছে `src/lib/sequence-math.ts`:
- differenceSeries(order)
- analyzeArithmeticSequence
- nthArithmeticTerm
- arithmeticRankOfTerm
- analyzeGeometricSequence
- nthGeometricTerm
- geometricRankOfTerm

এগুলো historical ordered series-এর mathematics; prediction guarantee নয়।

### A2. Transition signal position-blind ছিল
আগের signal engine সব position-এর transition একই `from+to` bucket-এ রাখত, পরে candidate score-এ position অনুযায়ী ব্যবহার করত। ফলে একই digit transition অন্য position-এর evidence-এর সঙ্গে মিশে যেত।

সংশোধন: 4টি position-এর জন্য আলাদা transition map রাখা হয়েছে এবং candidate-এর প্রতিটি position-এর latest digit → candidate digit transition ব্যবহার করা হচ্ছে।

### A3. Import conflict-এ silent replacement-এর ঝুঁকি ছিল
`mergeRows()` আগে একই logical key-এ incoming row দিয়ে existing row replace করতে পারত, যদিও UI/documentation বলছিল historical data overwrite করা হবে না।

সংশোধন:
- default merge এখন additive; existing logical record wins
- `preferIncoming:true` শুধু trusted native-source reconciliation-এ ব্যবহৃত
- `findMergeConflicts()` যোগ করা হয়েছে
- migration conflict detection একই central key/fingerprint ব্যবহার করছে

### A4. Canonicalization blank value-কে `0000` বানাতে পারত
`canonicalizeDraw()`-এর পুরোনো normalization blank/non-digit input-কে pad করে `0000` বানানোর সম্ভাবনা রাখত।

সংশোধন: strict 4-digit validation; invalid/blank value এখন canonical record-এ ঢোকে না। Special/Consolation list-ও strict 4-digit validation পায়।

### A5. Web/PWA 10,000+ data persistence
Native Android-এর SQLite থাকলেও browser/PWA fallback-এ বড় dataset localStorage quota অতিক্রম করতে পারত। quota failure হলে reload-এর পরে data হারানোর ঝুঁকি ছিল।

সংশোধন: free, dependency-free IndexedDB result store যোগ করা হয়েছে।
- localStorage = legacy migration/fallback
- IndexedDB = web/PWA result persistence
- native Android = SQLite

## B. এখনও গুরুত্বপূর্ণ এবং পরবর্তী repair gate

### P0 — 107 catalog ≠ 107 executable modules
`analysis-catalog.ts` এবং `analysis-contract.ts` 107টি metadata/contract entry দেয়। কিন্তু source-এ 107টি আলাদা executable analysis runner নেই। বাস্তবে calculation বিভিন্ন জায়গায় ছড়ানো:
- `scorer.ts` — 28 active signals
- `advanced-validation.ts` — selected statistical/validation metrics
- `App.tsx` — বহু UI-local calculation
- `pipeline.ts` — আলাদা prediction/consensus engine

ফলে “107 analysis” বলা হলেও একই canonical input দিয়ে 107টি module-এর raw result পাওয়া যায় না। এটি সবচেয়ে বড় architectural gap।

### P0 — একাধিক independent analysis engine
একই dataset-এর জন্য `scorer.ts`, `pipeline.ts`, `MasterPredictionView`, 6D logic এবং Research Cycle আলাদা পথে calculation করে। Central EvidenceBus/AnalysisCore এখনো বাস্তব executable orchestration layer হয়নি।

### P0 — Result Sheet এখনও prediction-centric
বর্তমান UI-তে “Result Sheet” নামে যে অংশ আছে তা মূলত Borda/model consensus/prediction pipeline output। এটি 107 historical analysis-এর complete audited result sheet নয়।

### P1 — 6D representation conceptual mismatch
4D main result, Special এবং Consolation-কে synthetic position 5/6 বানিয়ে 6D candidate তৈরি করা হচ্ছে। এগুলো প্রকৃত 6-position draw নয়। এই module-কে আলাদা structural exploration হিসেবে রাখা উচিত; canonical 4D target-এর সঙ্গে মেশানো উচিত নয়।

### P1 — candidate “confidence” language
কিছু UI calculation raw heuristic score-কে confidence/probability-style percentage হিসেবে দেখায়। Historical evidence score, validation rate, uncertainty এবং model probability আলাদা না করলে user ভুল interpretation করতে পারে।

### P1 — Benford-style signal
Fixed-width 4-digit historical records-এর candidate ranking-এ ব্যবহৃত Benford-style formula প্রকৃত Benford goodness-of-fit test নয়। এটি heuristic হলে heuristic নামেই থাকা উচিত; statistical Benford test হিসেবে নয়।

### P1 — `isBadPattern()` no-op
Candidate filter function বর্তমানে সবসময় `false` দেয়। এটি silent filtering বন্ধ রাখার দিক থেকে নিরাপদ, কিন্তু function-এর নাম দেখে যে filtering হওয়ার কথা মনে হয় তা বাস্তবে হচ্ছে না। এটি either remove অথবা explicit structural rule হিসেবে implement করতে হবে।

### P1 — 107 implementation status এখনও maturity metadata
বর্তমান status values-এর অনেকগুলো `ADVANCED_METRIC` হলেও তার অর্থ “standalone executable module” নয়। UI-তে status এবং actual executable capability আরও কঠোরভাবে আলাদা করতে হবে।

### P1 — model code
`advanced-models.ts`-এর recurrent model নিজেই “LSTM-style”, full backpropagation-through-time LSTM নয়। এটি lightweight research signal হিসেবে ঠিকভাবে label করা দরকার; full LSTM হিসেবে নয়।

### P2 — dependency reproducibility
`package.json`-এ বহু `latest` dependency আছে এবং lockfile নেই। ফলে ভবিষ্যতে একই source থেকে একই dependency tree পাওয়া নিশ্চিত নয়। Release-এর আগে pinned versions + lockfile দরকার।

### P2 — Android E2E
Static audit PASS হলেও dependency installation, Android SDK/Gradle build, APK install এবং real emulator/device E2E এখনও runtime-verified নয়।

## C. প্রধান architectural repair order

1. **Central AnalysisCore** — canonical dataset থেকে 107 module একবার চালাবে।
2. **Executable 107 registry** — প্রতিটি ID-এর বাস্তব runner বা explicit INSUFFICIENT_DATA/NOT_APPLICABLE state।
3. **EvidenceBus** — raw result, sample size, coverage, uncertainty, null comparison, validation, stability।
4. **Redundancy control** — একই evidence দ্বিতীয়বার count নয়।
5. **Historical Result Sheet** — 107 module/family/result/evidence/validation এক জায়গায়।
6. Prediction/model engines থাকলে আলাদা optional validation section; historical analysis-এর সঙ্গে মিশবে না।
7. তারপর Android E2E.

## D. Release principle

“107টি নাম” নয় — **107টি যাচাইযোগ্য calculation contract** হলো completion criterion।

কোনো module-এর calculation বাস্তবে না থাকলে সেটিকে implemented বলা যাবে না।

Historical analysis ≠ guaranteed future result.
