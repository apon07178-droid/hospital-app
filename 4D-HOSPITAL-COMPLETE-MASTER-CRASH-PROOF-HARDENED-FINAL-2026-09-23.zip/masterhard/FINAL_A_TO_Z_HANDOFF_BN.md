# 4D HOSPITAL — A-to-Z Handoff Status — 2026-09-22

## Included
- Original project files and documentation retained.
- 107-analysis catalog and production 107 runner retained.
- 28-signal layer, pairs/triplets, advanced model layer, sequence mathematics and validation layers retained.
- Cumulative/additive data merge retained.
- SQLite + web persistence/migration layers retained.
- Research cycle: cumulative dataset → locked analysis → actual result → exact/digit/position match → mismatch diagnostics → observations for later cycles.
- Runtime source is the root `App.tsx` + `lib/` + `components/` tree.
- The older duplicated `src/` tree is retained as an archive snapshot but excluded from runtime typecheck/build so it cannot silently diverge from the production tree.

## Verified in this environment
- Static audit: PASS.
- 107 catalog/runner structural audit: PASS.
- Model-layer audit: PASS.
- Runtime-source contract audit: PASS.
- Sequence/reconciliation/canonical guards: PASS.

## Environment-limited gates
- npm registry dependency installation timed out in this sandbox.
- Therefore local Vite production build and local Android Gradle APK build are not falsely marked PASS.
- Java 21 is present; Gradle/Android SDK tooling is not installed in this sandbox.
- GitHub Actions workflows are included to perform dependency installation, typecheck, web build, Capacitor Android generation/sync, Gradle debug APK build and artifact upload in a networked CI runner.

## Data safety rule
No import operation is intended to replace the historical dataset. New valid rows are merged additively; invalid rows are rejected; conflicts are retained for audit; research-cycle actual results are validated separately to prevent future-data leakage.

## Mathematical/research scope
All outputs are historical/statistical evidence and validation measurements. No module is treated as a guarantee of a future result.
