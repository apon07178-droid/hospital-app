# 4D HOSPITAL — Core Research Engine v2

## সিদ্ধান্ত
Public analysis catalog **107-ই থাকবে**। নতুন 100–200টি redundant analysis যোগ করা হয়নি।

বর্তমান 107টি analysis হলো **Core Research Engine**। তার উপরে ছয়টি meta-validation layer যোগ করা হয়েছে:

1. Walk-Forward 2.0 — একাধিক expanding chronological OOS window।
2. OOS Stability — rolling window top-set overlap, top-1 persistence ও stability status।
3. Drift / Regime Detection — recent বনাম baseline distribution shift, PSI-style diagnostic ও regime windows।
4. Model Agreement / Disagreement — Core Engine ও কয়েকটি independent structural ranking family-এর overlap/consensus।
5. Ablation + Sensitivity — active contribution একবারে বাদ দিলে score/top-1 কীভাবে বদলায় তার sensitivity diagnostic।
6. Evidence / Uncertainty Scorecard — sample size, OOS coverage, stability, agreement, drift-risk ও uncertainty আলাদা করে research evidence summary।

## Data workflow
Layers একই growing canonical dataset ব্যবহার করে: `2000 → 2023 → 10000+`। Import পুরোনো data replace না করে additive merge করে; তাই নতুন observation যোগ হলে research layers-ও পুরো dataset-এর বর্তমান snapshot থেকে পুনরায় গণনা হয়।

## গুরুত্বপূর্ণ বৈজ্ঞানিক সীমা
- এগুলো research validation/diagnostic layers; guaranteed future number বা winning probability নয়।
- Walk-Forward layer-এর benchmark ranking lightweight structural baseline ব্যবহার করে যাতে Android runtime-এ অতিরিক্ত full 0000–9999 genetic/model retraining না হয়। Existing Core Engine-এর chronological backtest আলাদাভাবে থাকে।
- Evidence score ≠ prediction probability.
- Drift high হলে পুরোনো ও সাম্প্রতিক আচরণের পার্থক্য স্পষ্টভাবে দেখানো হবে; এটি নিজে কোনো future outcome প্রমাণ করে না।

## Verification
- `research-layers-audit.mjs` PASS
- static audit PASS
- 107 engine audit PASS
- reconciliation audit PASS
- sequence math audit PASS
- final model layer audit PASS
- runtime contract audit PASS
- research-cycle E2E PASS

Android APK/device E2E এই source environment-এ এখনও independently verified নয়।
