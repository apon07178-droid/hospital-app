# 4D HOSPITAL — A-to-Z Fixes Applied

তারিখ: 2026-09-21

## যা বাস্তবে source code-এ সংশোধন করা হয়েছে

1. **107 Analysis catalog** — public catalog 107 unique entry হিসেবে রাখা হয়েছে।
2. **Canonical pair analysis** — scorer-এ সব 6 position-pair: 01,02,03,12,13,23 ব্যবহার করা হয়েছে।
3. **Canonical triplet analysis** — সব 4 position-triplet: 012,013,023,123 ব্যবহার করা হয়েছে।
4. **Cross-company proxy বন্ধ** — multi-company synchronized evidence না থাকলে cross-company score ranking-এ evidence হিসেবে ব্যবহার করা হয় না।
5. **Fake backtest 0.5 বন্ধ** — candidate backtest প্রমাণ না থাকলে fake neutral score দেওয়া হয় না।
6. **Untrained LSTM neutralized** — model trained না হলে 0.5 probability/score দিয়ে masquerade করা হয় না; signal inactive থাকে।
7. **Genetic fallback proxy বন্ধ** — genetic optimizer candidate evaluate না করলে position/pair/triplet-কে genetic score নামে চালানো হয় না।
8. **Consensus double-counting কমানো** — consensus-কে independent signal হিসেবে পুনরায় যোগ করা বন্ধ; এটি derived view।
9. **Hot/Cold duplicate evidence** — cold-কে hot-এর complement হিসেবে আলাদা independent evidence হিসেবে weight করা বন্ধ।
10. **Calendar candidate-neutral bug** — dataset-level weekday total দিয়ে সব candidate-কে একই score দেওয়ার bug বন্ধ; candidate-specific evidence না থাকলে inactive।
11. **Reliability test window** — arbitrary 3-test cap বাদ দিয়ে data-dependent সর্বোচ্চ 20 walk-forward tests করা হয়েছে।
12. **Additive import merge** — company+date-only overwrite বাদ; draw number থাকলে company+date+draw number logical key, আর একই date-এর আলাদা draw additive রাখা যায়।
13. **SQLite schema** — legacy `UNIQUE(company,date)` schema migrate করার ব্যবস্থা যোগ করা হয়েছে, যাতে একই দিনে একাধিক draw রাখা যায়।
14. **SQLite conflict rule** — same company+date+drawNo হলে conflict; একই date-এর অন্য draw overwrite হয় না।
15. **Atomic restore validation** — invalid restore/import row silently skip না করে transaction rollback করার ব্যবস্থা করা হয়েছে।
16. **SQLite source-of-truth** — native Android-এ 10k+ dataset বারবার full localStorage-এ duplicate না করার ব্যবস্থা করা হয়েছে; SQLite primary storage।
17. **Central merge helper** — `src/lib/data-merge.ts` যোগ করা হয়েছে, যাতে import/migration merge logic এক জায়গায় থাকে।
18. **Research Cycle data-model conflict** — incomplete `first + blank second/third` record আর master SQLite dataset-এ ঢোকানো হয় না। Research validation আলাদা থাকে; master dataset-এ যোগ করতে complete draw record import/add করতে হবে।
19. **Static audit strengthened** — canonical pair/triplet, no fake backtest, no cross-company proxy, additive merge, SQLite multi-draw schema এবং incomplete research insertion-এর guard যোগ করা হয়েছে।

## যা ইচ্ছাকৃতভাবে claim করা হয়নি

- এই environment-এ dependency install সম্পূর্ণ হয়নি; তাই full TypeScript/build এবং Android APK E2E PASS independently verified বলা হচ্ছে না।
- Static audit PASS হয়েছে।
- Changed TypeScript files parse-level compilation check-এ external dependency missing ছাড়া syntax error পাওয়া যায়নি।
- Android device/emulator test এই run-এ চালানো হয়নি।

## গুরুত্বপূর্ণ data rule

`2000 + 23 = 2023` ধরনের additive dataset workflow এখন design-level এ overwrite না করে merge করার জন্য প্রস্তুত। তবে 23টি নতুন record যদি একই তারিখে হয়, প্রতিটি draw-এর জন্য আলাদা `drawNo` দেওয়া উচিত। Complete record ছাড়া master result table-এ partial 4-digit row ঢোকানো হবে না।
