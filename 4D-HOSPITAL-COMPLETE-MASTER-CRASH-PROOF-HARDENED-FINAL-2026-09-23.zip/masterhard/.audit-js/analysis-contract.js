"use strict";
/**
 * 4D HOSPITAL — Canonical 107 Analysis Contract
 *
 * This file is the single metadata contract for the public 107 analysis
 * entries. It deliberately separates implementation status, true computation
 * dependencies, redundancy, data requirements and target semantics.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ANALYSIS_CONTRACTS = exports.IMPLEMENTATION_STATUS = void 0;
exports.getAnalysisContract = getAnalysisContract;
exports.validateAnalysisContracts = validateAnalysisContracts;
exports.IMPLEMENTATION_STATUS = {
    1: 'IMPLEMENTED',
    2: 'PARTIAL',
    3: 'ADVANCED_METRIC',
    4: 'VALIDATION',
    5: 'INSUFFICIENT_DATA',
    6: 'NOT_APPLICABLE',
    7: 'REQUIRES_FIX',
};
const familyById = {
    1: 'F01 Data Integrity & Eligibility', 2: 'F01 Data Integrity & Eligibility', 3: 'F01 Data Integrity & Eligibility', 4: 'F01 Data Integrity & Eligibility', 5: 'F01 Data Integrity & Eligibility', 6: 'F01 Data Integrity & Eligibility',
    7: 'F02 Numeric Change & Algebraic Structure', 8: 'F02 Numeric Change & Algebraic Structure', 9: 'F02 Numeric Change & Algebraic Structure', 10: 'F02 Numeric Change & Algebraic Structure', 11: 'F02 Numeric Change & Algebraic Structure', 12: 'F02 Numeric Change & Algebraic Structure',
    13: 'F03 Number Theory', 14: 'F03 Number Theory', 15: 'F03 Number Theory', 16: 'F03 Number Theory', 17: 'F03 Number Theory', 18: 'F03 Number Theory',
    19: 'F04 Digit & Position Structure', 20: 'F04 Digit & Position Structure', 21: 'F04 Digit & Position Structure', 22: 'F04 Digit & Position Structure', 23: 'F04 Digit & Position Structure', 24: 'F04 Digit & Position Structure', 25: 'F04 Digit & Position Structure',
    26: 'F05 Sequence, Recurrence & Motif', 27: 'F05 Sequence, Recurrence & Motif', 28: 'F05 Sequence, Recurrence & Motif', 29: 'F05 Sequence, Recurrence & Motif', 30: 'F05 Sequence, Recurrence & Motif', 31: 'F05 Sequence, Recurrence & Motif',
    32: 'F06 Regression & Functional Structure', 33: 'F06 Regression & Functional Structure', 34: 'F06 Regression & Functional Structure', 35: 'F06 Regression & Functional Structure', 36: 'F06 Regression & Functional Structure', 37: 'F06 Regression & Functional Structure',
    38: 'F07 Modular Mathematics', 39: 'F07 Modular Mathematics', 40: 'F07 Modular Mathematics', 41: 'F07 Modular Mathematics', 42: 'F07 Modular Mathematics', 43: 'F07 Modular Mathematics', 44: 'F07 Modular Mathematics', 45: 'F07 Modular Mathematics',
    46: 'F08 Combinatorics & Joint Structure', 47: 'F08 Combinatorics & Joint Structure', 48: 'F08 Combinatorics & Joint Structure', 49: 'F08 Combinatorics & Joint Structure', 50: 'F08 Combinatorics & Joint Structure', 51: 'F08 Combinatorics & Joint Structure',
    52: 'F09 Descriptive & Robust Statistics', 53: 'F09 Descriptive & Robust Statistics', 54: 'F09 Descriptive & Robust Statistics', 55: 'F09 Descriptive & Robust Statistics', 56: 'F09 Descriptive & Robust Statistics', 57: 'F09 Descriptive & Robust Statistics', 58: 'F09 Descriptive & Robust Statistics',
    59: 'F10 Dependency & Information', 60: 'F10 Dependency & Information', 61: 'F10 Dependency & Information', 62: 'F10 Dependency & Information', 63: 'F10 Dependency & Information', 64: 'F10 Dependency & Information',
    65: 'F11 Temporal Dynamics', 66: 'F11 Temporal Dynamics', 67: 'F11 Temporal Dynamics', 68: 'F11 Temporal Dynamics', 69: 'F11 Temporal Dynamics', 70: 'F11 Temporal Dynamics',
    71: 'F12 Frequency Domain', 72: 'F12 Frequency Domain', 73: 'F12 Frequency Domain', 74: 'F12 Frequency Domain', 75: 'F12 Frequency Domain',
    76: 'F13 Entropy & Information Theory', 77: 'F13 Entropy & Information Theory', 78: 'F13 Entropy & Information Theory', 79: 'F13 Entropy & Information Theory', 80: 'F13 Entropy & Information Theory', 81: 'F13 Entropy & Information Theory',
    82: 'F14 Randomness & Null-Model Diagnostics', 83: 'F14 Randomness & Null-Model Diagnostics', 84: 'F14 Randomness & Null-Model Diagnostics', 85: 'F14 Randomness & Null-Model Diagnostics', 86: 'F14 Randomness & Null-Model Diagnostics', 87: 'F14 Randomness & Null-Model Diagnostics', 88: 'F14 Randomness & Null-Model Diagnostics',
    89: 'F15 Complexity', 90: 'F15 Complexity', 91: 'F15 Complexity', 92: 'F15 Complexity', 93: 'F15 Complexity',
    94: 'F16 State, Recurrence & Regimes', 95: 'F16 State, Recurrence & Regimes', 96: 'F16 State, Recurrence & Regimes', 97: 'F16 State, Recurrence & Regimes', 98: 'F16 State, Recurrence & Regimes',
    99: 'F17 Symbolic & Discovery Methods', 100: 'F17 Symbolic & Discovery Methods', 101: 'F17 Symbolic & Discovery Methods', 102: 'F17 Symbolic & Discovery Methods', 103: 'F17 Symbolic & Discovery Methods',
    104: 'F18 Model & Validation Governance', 105: 'F18 Model & Validation Governance', 106: 'F18 Model & Validation Governance', 107: 'F18 Model & Validation Governance',
};
// True computational dependencies only. Redundancy is stored separately.
const dependencyIds = {
    8: [7], 9: [8], 10: [7], 11: [7], 12: [7],
    20: [19],
    35: [32, 33, 34], 36: [32, 33, 34], 37: [32, 33, 34],
    50: [46],
    55: [52, 53], 56: [52, 53], 57: [52], 58: [52],
    72: [71], 73: [71], 75: [74],
    80: [62],
    95: [94], 96: [94], 97: [64], 98: [94],
    103: [99, 100, 101, 102],
};
const dependencyType = {
    8: 'COMPUTATION', 9: 'COMPUTATION', 10: 'COMPUTATION', 11: 'COMPUTATION', 12: 'COMPUTATION',
    20: 'FEATURE', 35: 'COMPUTATION', 36: 'COMPUTATION', 37: 'COMPUTATION', 50: 'COMPUTATION',
    55: 'FEATURE', 56: 'FEATURE', 57: 'FEATURE', 58: 'FEATURE', 72: 'COMPUTATION', 73: 'COMPUTATION', 75: 'COMPUTATION',
    80: 'FEATURE', 95: 'FEATURE', 96: 'FEATURE', 97: 'FEATURE', 98: 'FEATURE', 103: 'COMPUTATION',
};
const definitions = {
    1: 'Validate schema, types, ranges and required fields.', 2: 'Measure required-field missingness and affected records.', 3: 'Detect exact and logical duplicates without silently deleting conflicts.', 4: 'Verify chronological order, date consistency and draw ordering.', 5: 'Report sample size and minimum-data eligibility.', 6: 'Describe empirical distributions and coverage.',
    7: 'Compute first chronological difference of the selected numeric series.', 8: 'Compute second finite difference.', 9: 'Compute third finite difference.', 10: 'Measure absolute consecutive change.', 11: 'Measure ratio between consecutive values with zero-denominator handling.', 12: 'Measure percentage change with zero-denominator handling.',
    13: 'Classify applicable integer values as prime/composite.', 14: 'Test divisibility by declared divisors.', 15: 'Compute prime-factor decomposition.', 16: 'Compute GCD/LCM for declared value pairs.', 17: 'Classify even/odd values and positions.', 18: 'Compute digital roots and their empirical distribution.',
    19: 'Count digits globally and by position.', 20: 'Build the 4×10 position-frequency matrix.', 21: 'Compute 4-digit digit-sum distribution.', 22: 'Compute digit-product distribution with zero handling.', 23: 'Classify repeated-digit structures.', 24: 'Count distinct digits per 4-digit record.', 25: 'Compare each value with its canonical reverse.',
    26: 'Search repeated observations and patterns over lags.', 27: 'Compare features at declared historical lags.', 28: 'Detect repeated short patterns across windows.', 29: 'Measure consecutive same/related-symbol run lengths.', 30: 'Search repeated subsequences.', 31: 'Mine frequent local sequence motifs.',
    32: 'Fit a linear chronological trend.', 33: 'Fit a quadratic chronological trend.', 34: 'Fit a cubic chronological trend.', 35: 'Check finite-difference evidence for low-order polynomial structure.', 36: 'Analyze residual spread, autocorrelation and outliers.', 37: 'Penalize unnecessary model complexity.',
    38: 'Compute residue distribution modulo 2.', 39: 'Compute residue distribution modulo 3.', 40: 'Compute residue distribution modulo 4.', 41: 'Compute residue distribution modulo 5.', 42: 'Compute residue distribution modulo 7.', 43: 'Compute residue distribution modulo 9.', 44: 'Compute residue distribution modulo 10.', 45: 'Compute residue distribution modulo 11.',
    46: 'Count all six canonical unordered position-pairs.', 47: 'Count all four canonical position-triplets.', 48: 'Classify digit permutations/order classes.', 49: 'Measure combinatorial coverage of observed configurations.', 50: 'Build the position-pair matrix across all six pairs.', 51: 'Classify structural pattern classes.',
    52: 'Compute mean, median and mode.', 53: 'Compute variance and standard deviation.', 54: 'Compute configurable quantiles.', 55: 'Standardize observations with z-scores.', 56: 'Compute robust outlier scores.', 57: 'Estimate uncertainty with bootstrap resampling.', 58: 'Estimate binomial proportion uncertainty with Wilson intervals.',
    59: 'Measure autocorrelation across chronological lags.', 60: 'Measure partial autocorrelation.', 61: 'Measure cross-position correlation.', 62: 'Measure mutual information between declared variables.', 63: 'Test categorical independence with chi-square.', 64: 'Build transition probabilities between declared states.',
    65: 'Compute rolling mean over declared windows.', 66: 'Compute rolling variance over declared windows.', 67: 'Compute deterministic exponential smoothing.', 68: 'Detect statistically meaningful change points where supported.', 69: 'Separate trend/seasonal/residual components where identifiable.', 70: 'Define and evaluate walk-forward windows.',
    71: 'Compute discrete Fourier/frequency spectrum.', 72: 'Identify dominant frequency from the spectrum.', 73: 'Compute spectral entropy.', 74: 'Compute a periodogram.', 75: 'Detect candidate periodic peaks from the periodogram.',
    76: 'Compute Shannon entropy.', 77: 'Compute min-entropy.', 78: 'Compute Rényi entropy for declared order.', 79: 'Compute approximate entropy for supported sequence lengths.', 80: 'Compute conditional entropy from joint/transition distributions.', 81: 'Measure information gain from conditioning on a feature.',
    82: 'Compare observed frequencies with a declared null distribution.', 83: 'Run frequency diagnostics inside blocks/windows.', 84: 'Test run structure under a declared null.', 85: 'Test unusually long runs under a declared null.', 86: 'Test serial pair/tuple frequencies under a declared null.', 87: 'Apply cumulative-sum deviation diagnostics.', 88: 'Use a declared permutation/randomization null for a statistic.',
    89: 'Estimate Lempel-Ziv sequence complexity.', 90: 'Estimate linear recurrence complexity over a declared alphabet/field.', 91: 'Report deterministic compression ratio.', 92: 'Measure structural pattern diversity/rarity.', 93: 'Apply description-length/MDL-style complexity penalty.',
    94: 'Encode observations into declared discrete states.', 95: 'Construct a recurrence matrix from state/feature distance.', 96: 'Cluster encoded states and report separation/stability.', 97: 'Compare transition matrices across time windows.', 98: 'Detect persistent regimes and regime boundaries.',
    99: 'Search bounded symbolic expressions over declared features.', 100: 'Mine rules using support/confidence/lift.', 101: 'Discover feature/value associations.', 102: 'Search interactions with held-out validation.', 103: 'Rank discovered formulas by fit, complexity and out-of-sample stability.',
    104: 'Benchmark models against simple historical/random baselines.', 105: 'Fit AR/ARIMA-style models only when requirements pass.', 106: 'Fit tree/ensemble models with time-aware validation.', 107: 'Fit a recurrent sequence model only when data and validation requirements pass.',
};
const outputs = {
    1: 'quality status + affected rows', 2: 'missingness counts/rates', 3: 'duplicate groups + conflicts', 4: 'ordering warnings/status', 5: 'n + eligibility status', 6: 'frequency/distribution summary',
    7: 'difference series + distribution', 8: 'second-difference series', 9: 'third-difference series', 10: 'absolute-change distribution', 11: 'ratio distribution + undefined count', 12: 'percentage-change distribution + undefined count',
    13: 'prime/composite counts', 14: 'divisibility counts/deviations', 15: 'factor-pattern frequencies', 16: 'GCD/LCM distributions', 17: 'parity distributions', 18: 'digital-root distribution',
    19: 'digit counts + baseline comparison', 20: '4×10 position matrix', 21: 'sum distribution + candidate distance', 22: 'product distribution', 23: 'repeat-pattern frequencies', 24: 'distinct-count distribution', 25: 'reverse relations',
    26: 'recurrence rates', 27: 'lag similarity', 28: 'repetition rates', 29: 'run-length statistics', 30: 'subsequence support', 31: 'motif support/ranking',
    32: 'slope + fit + residuals', 33: 'quadratic fit diagnostics', 34: 'cubic fit diagnostics', 35: 'difference-order evidence', 36: 'residual diagnostics', 37: 'complexity penalty',
    38: 'mod-2 residues', 39: 'mod-3 residues', 40: 'mod-4 residues', 41: 'mod-5 residues', 42: 'mod-7 residues', 43: 'mod-9 residues', 44: 'mod-10 residues', 45: 'mod-11 residues',
    46: 'six pair-frequency tables', 47: 'four triplet-frequency tables', 48: 'permutation classes', 49: 'coverage metrics', 50: 'position-pair matrix', 51: 'pattern-class frequencies',
    52: 'mean/median/mode', 53: 'variance/std-dev', 54: 'quantiles', 55: 'z-score distribution', 56: 'robust outlier scores', 57: 'bootstrap interval', 58: 'Wilson interval',
    59: 'ACF by lag', 60: 'PACF by lag', 61: 'position correlations', 62: 'mutual-information values', 63: 'chi-square statistic/p-value', 64: 'transition matrix',
    65: 'rolling means', 66: 'rolling variances', 67: 'smoothed series', 68: 'change points', 69: 'trend/decomposition components', 70: 'walk-forward window results',
    71: 'frequency spectrum', 72: 'dominant frequency', 73: 'spectral entropy', 74: 'periodogram', 75: 'periodic peak candidates',
    76: 'Shannon entropy', 77: 'min-entropy', 78: 'Rényi entropy', 79: 'approximate entropy', 80: 'conditional entropy', 81: 'information gain',
    82: 'null-test statistic/effect', 83: 'block diagnostics', 84: 'runs statistic/effect', 85: 'long-run diagnostics', 86: 'serial statistic/effect', 87: 'CUSUM diagnostics', 88: 'permutation statistic/p-value',
    89: 'LZ complexity', 90: 'linear complexity', 91: 'compression ratio', 92: 'pattern complexity', 93: 'MDL penalty',
    94: 'state encoding + frequencies', 95: 'recurrence matrix/metrics', 96: 'clusters + stability', 97: 'transition stability', 98: 'regime labels/boundaries',
    99: 'candidate formulas', 100: 'rules + support/confidence/lift', 101: 'associations + effect sizes', 102: 'validated interactions', 103: 'ranked formula candidates',
    104: 'baseline OOS metrics', 105: 'AR/ARIMA OOS metrics', 106: 'tree/ensemble OOS metrics', 107: 'recurrent-model OOS metrics',
};
const requirements = {};
for (let id = 1; id <= 107; id++)
    requirements[id] = id <= 6 ? 'Canonical dataset; schema/date/draw validation' : 'Canonical 4D historical sequence; chronological order';
for (const id of [19, 20, 21, 22, 23, 24, 25, 46, 47, 48, 49, 50, 51])
    requirements[id] = 'Canonical 4-digit values with all four positions';
for (const id of [59, 60, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 79, 87, 89, 90, 91, 92, 94, 95, 96, 97, 98])
    requirements[id] = 'At least 2 ordered observations; larger samples required for stable inference';
for (const id of [82, 83, 84, 85, 86, 88])
    requirements[id] = 'Declared null model + sufficient sample; effect size and multiple-testing control';
for (const id of [99, 100, 101, 102, 103])
    requirements[id] = 'Declared feature set + sufficient sample; leakage-safe validation';
for (const id of [104, 105, 106, 107])
    requirements[id] = 'Chronological target + sufficient historical training data + blocked/walk-forward OOS';
const targets = {};
for (let id = 1; id <= 103; id++)
    targets[id] = 'Historical descriptive/structural statistic; no guaranteed future-number target';
for (const id of [104, 105, 106, 107])
    targets[id] = 'Explicit next-observation target defined by evaluation window; OOS benchmark only';
const validation = {};
for (let id = 1; id <= 6; id++)
    validation[id] = 'Data-quality gate';
for (let id = 7; id <= 81; id++)
    validation[id] = 'Stability across windows; OOS validation when used as evidence';
for (let id = 82; id <= 88; id++)
    validation[id] = 'Declared null + effect size + multiple-testing correction';
for (let id = 89; id <= 98; id++)
    validation[id] = 'Stability/robustness; OOS when used as evidence';
for (let id = 99; id <= 103; id++)
    validation[id] = 'Blocked/walk-forward OOS + complexity control';
for (let id = 104; id <= 107; id++)
    validation[id] = 'Blocked/walk-forward OOS + baseline comparison + calibration/error';
const redundancy = {};
for (let id = 1; id <= 107; id++)
    redundancy[id] = 'R0';
for (const id of [19, 20])
    redundancy[id] = 'R1 Frequency/position';
for (const id of [27, 59, 60, 64, 97])
    redundancy[id] = 'R3 Temporal/dependency';
for (const id of [37, 71, 73, 76, 77, 78, 79, 89, 90, 91, 92, 93])
    redundancy[id] = 'R4 Information/complexity';
for (const id of [99, 100, 101, 102, 103])
    redundancy[id] = 'R9 Hypothesis discovery';
for (const id of [104, 105, 106, 107])
    redundancy[id] = 'R10 Predictive model';
for (const id of [82, 83, 84, 85, 86, 87, 88])
    redundancy[id] = 'R7 Randomness';
// Status is intentionally truthful to the current source baseline. A contract
// entry may be PARTIAL/ADVANCED/VALIDATION even when its calculation is not yet
// a standalone ranking signal. This prevents documentation from overstating
// implementation maturity.
const status = {};
for (let id = 1; id <= 107; id++)
    status[id] = 1;
for (const id of [1, 2, 3, 4, 5, 6, 82, 83, 84, 85, 86, 87, 88])
    status[id] = 4;
for (const id of [99, 100, 101, 102, 103])
    status[id] = 3;
for (const id of [104, 105, 106, 107])
    status[id] = 3;
function getAnalysisContract(id) {
    if (id < 1 || id > 107)
        throw new Error(`Unknown public analysis id: ${id}`);
    return {
        id,
        family: familyById[id],
        definition: definitions[id],
        input: id <= 6 ? 'Canonical dataset rows + data-quality metadata' : 'Canonical chronological 4-digit sequence',
        output: outputs[id],
        dataRequirement: requirements[id],
        dependencyIds: dependencyIds[id] ?? [],
        dependencyType: dependencyType[id] ?? 'DATA',
        implementationStatus: status[id],
        target: targets[id],
        validation: validation[id],
        redundancyGroup: redundancy[id],
    };
}
exports.ANALYSIS_CONTRACTS = Array.from({ length: 107 }, (_, i) => getAnalysisContract(i + 1));
function validateAnalysisContracts() {
    const errors = [];
    const ids = new Set(exports.ANALYSIS_CONTRACTS.map(x => x.id));
    if (ids.size !== 107)
        errors.push(`Expected 107 contracts, found ${ids.size}`);
    for (const c of exports.ANALYSIS_CONTRACTS) {
        for (const d of c.dependencyIds) {
            if (!ids.has(d))
                errors.push(`${c.id}: dependency ${d} does not exist`);
            if (d === c.id)
                errors.push(`${c.id}: self dependency is forbidden`);
        }
    }
    // Detect dependency cycles with a DFS over the actual contract graph.
    const visiting = new Set(), visited = new Set();
    const dfs = (id) => {
        if (visiting.has(id)) {
            errors.push(`Dependency cycle detected at ${id}`);
            return;
        }
        if (visited.has(id))
            return;
        visiting.add(id);
        for (const d of getAnalysisContract(id).dependencyIds)
            dfs(d);
        visiting.delete(id);
        visited.add(id);
    };
    for (let i = 1; i <= 107; i++)
        dfs(i);
    return errors;
}
