"use strict";
/** 4D HOSPITAL — canonical dataset and explicit target contract. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CANONICAL_DATASET_SCHEMA_VERSION = void 0;
exports.isCanonicalDraw = isCanonicalDraw;
exports.canonicalizeDraw = canonicalizeDraw;
exports.datasetFingerprint = datasetFingerprint;
exports.buildDatasetMetadata = buildDatasetMetadata;
exports.makeDescriptiveTarget = makeDescriptiveTarget;
exports.makeNextObservationTarget = makeNextObservationTarget;
exports.CANONICAL_DATASET_SCHEMA_VERSION = 1;
function isCanonicalDraw(r) {
    return !!r && Number.isSafeInteger(Number(r.id)) && Number(r.id) >= 1 &&
        /^[a-z0-9_-]+$/i.test(String(r.company ?? '')) &&
        /^\d{4}-\d{2}-\d{2}$/.test(String(r.date ?? '')) &&
        /^\d{4}$/.test(String(r.first ?? '')) &&
        /^\d{4}$/.test(String(r.second ?? '')) &&
        /^\d{4}$/.test(String(r.third ?? '')) &&
        (r.drawNo == null || String(r.drawNo).trim() !== '') &&
        Array.isArray(r.special) && r.special.every(x => /^\d{4}$/.test(String(x))) &&
        Array.isArray(r.consolation) && r.consolation.every(x => /^\d{4}$/.test(String(x)));
}
function canonicalizeDraw(r) {
    const clean4 = (v) => { const raw = String(v ?? '').trim(); return /^\d{4}$/.test(raw) ? raw : null; };
    const cleanList = (v) => Array.isArray(v) ? v.map(clean4).filter((x) => !!x).slice(0, 50) : [];
    const row = {
        id: Number(r.id), company: String(r.company ?? '').trim().toLowerCase(), date: String(r.date ?? '').slice(0, 10),
        drawNo: r.drawNo == null || String(r.drawNo).trim() === '' ? null : String(r.drawNo).trim(),
        first: clean4(r.first), second: clean4(r.second), third: clean4(r.third),
        special: cleanList(r.special), consolation: cleanList(r.consolation)
    };
    if (!isCanonicalDraw(row))
        throw new Error('Invalid canonical draw record');
    return row;
}
function datasetFingerprint(rows) {
    let h = 0x811c9dc5;
    const stable = [...rows].sort((a, b) => a.date.localeCompare(b.date) || a.company.localeCompare(b.company) || String(a.drawNo ?? '').localeCompare(String(b.drawNo ?? '')) || a.id - b.id);
    const text = JSON.stringify(stable);
    for (let i = 0; i < text.length; i++) {
        h ^= text.charCodeAt(i);
        h = Math.imul(h, 0x01000193);
    }
    return `ds1-${(h >>> 0).toString(16).padStart(8, '0')}`;
}
function buildDatasetMetadata(rows, source = 'memory') {
    const valid = rows.filter(isCanonicalDraw);
    const dates = valid.map(x => x.date).sort();
    return {
        schemaVersion: exports.CANONICAL_DATASET_SCHEMA_VERSION,
        datasetVersion: datasetFingerprint(valid), source,
        recordCount: rows.length, validRecordCount: valid.length,
        companies: [...new Set(valid.map(x => x.company))].sort(),
        oldestDate: dates[0] ?? null, newestDate: dates.at(-1) ?? null
    };
}
function makeDescriptiveTarget() {
    return { targetType: 'HISTORICAL_DESCRIPTIVE', targetDefinition: 'Historical structure/statistic only; no future-number guarantee.', targetPosition: 'NONE', horizon: 0, evaluationWindow: 0, leakageSafe: true };
}
function makeNextObservationTarget(position = 'FIRST', evaluationWindow = 20) {
    return { targetType: 'NEXT_OBSERVATION_OOS', targetDefinition: `Next ${position} observation evaluated only after the training cutoff.`, targetPosition: position, horizon: 1, evaluationWindow: Math.max(1, evaluationWindow), leakageSafe: true };
}
