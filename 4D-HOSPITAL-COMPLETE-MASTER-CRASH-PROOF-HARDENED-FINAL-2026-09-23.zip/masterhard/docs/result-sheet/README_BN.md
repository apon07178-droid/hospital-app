# Result Sheet
Historical result-sheet specification: dataset snapshot, module results, evidence state, uncertainty, validation and stability. Prediction/consensus output must remain a separate optional section.
