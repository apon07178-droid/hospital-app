# Project Structure

```text
4D-HOSPITAL/
├─ src/                     # runtime source
│  ├─ App.tsx               # main UI container
│  ├─ lib/
│  │  ├─ analysis-catalog.ts
│  │  ├─ analysis-contract.ts
│  │  ├─ canonical-data.ts
│  │  ├─ data-merge.ts
│  │  ├─ advanced-validation.ts
│  │  ├─ advanced-models.ts
│  │  ├─ scorer.ts
│  │  ├─ pipeline.ts
│  │  ├─ research-cycle.ts
│  │  └─ sqlite-results.ts
├─ public/
├─ scripts/
├─ docs/
│  ├─ 00-MASTER/
│  ├─ 01-107-ANALYSIS/
│  ├─ 02-RESULT-SHEET/
│  ├─ 03-DATA-STORAGE/
│  ├─ 04-MATHEMATICAL-ARCHITECTURE/
│  ├─ 05-E2E-RELEASE/
│  └─ 06-PROJECT-STRUCTURE/
└─ package.json
```

The documentation folders are intentionally separated. Runtime source has not been falsely claimed as fully refactored into one file per UI screen.
