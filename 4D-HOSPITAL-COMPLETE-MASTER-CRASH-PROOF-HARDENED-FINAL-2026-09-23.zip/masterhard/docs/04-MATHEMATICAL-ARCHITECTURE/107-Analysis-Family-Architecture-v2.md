# 4D HOSPITAL --- 107 Analysis Family Architecture v2

## উদ্দেশ্য

এই v2 architecture-এ 107টি analysis শুধু UI-তে নাম হিসেবে থাকবে না।
প্রত্যেকটি analysis একটি **স্বাধীন, audit-able module** হবে এবং তার নিজস্ব
data, calculation, result, evidence, stability ও coverage প্রকাশ করবে।

এটি **calculation / historical-analysis architecture**। কোনো module-কে
ভবিষ্যৎ ফলের নিশ্চয়তা বা probability হিসেবে উপস্থাপন করা হবে না।

## ZIP-এর বর্তমান অবস্থা থেকে গুরুত্বপূর্ণ ভিত্তি

-   `analysis-catalog.ts`-এ 18টি domain-এ মোট 115টি definition আছে, কিন্তু
    code `slice(0, 107)` করে প্রথম 107টিকে public catalog করে।
-   `scorer.ts`-এ 28টি active signal আছে; তাই 107 catalog ≠ 107
    implemented analysis engine।
-   বর্তমান scorer-এ কিছু signal fixed heuristic/default score ব্যবহার করে,
    যেমন `backtest=0.5`, model unavailable হলে `lstm=0.5`; v2-তে এগুলো
    `NOT_CALCULATED`/`INSUFFICIENT_DATA` হবে।
-   Pair/Triplet context এবং advanced matrix-এ বেশি positional
    combinations আছে, কিন্তু candidate scoring-এর কিছু অংশ কেবল contiguous
    combinations নেয়; v2-তে catalog ও engine একই definition ব্যবহার করবে।
-   Cross-company signal বর্তমানে proxy; v2-তে বাস্তব multi-company data
    না থাকলে `NOT_APPLICABLE` হবে।
-   বর্তমান validation code-এ blocked/time-aware validation, Monte Carlo
    baseline, redundancy grouping ও Wilson interval আছে; v2-তে এগুলো
    governance layer হিসেবে ব্যবহার হবে, score তৈরির shortcut হিসেবে নয়।

## v2 মূল নীতি

1.  **107/107 modules execute or explicitly report why they cannot.**
2.  কোনো module calculation না করলে fake `0.5` নয়।
3.  একই historical evidence একাধিক correlated module দিয়ে বারবার vote
    করতে পারবে না।
4.  Descriptive/statistical/structural/model/validation আলাদা layer।
5.  `SUPPORT / NEUTRAL / CONFLICT / INSUFFICIENT_DATA / NOT_APPLICABLE`
    evidence state থাকবে।
6.  Raw result কখনো হারানো যাবে না।
7.  Candidate score-এর আগে family-level aggregation হবে।
8.  Validation gate pass না করলে module final evidence-এ weight পাবে না।
9.  Score এবং uncertainty আলাদা জিনিস।
10. Historical repeat/high-frequency evidence এবং independent evidence
    আলাদা করে দেখাতে হবে।

## 12টি orchestration family

  -----------------------------------------------------------------------
  Family                              কাজ
  ----------------------------------- -----------------------------------
  F01 Data Integrity & Eligibility    ডেটা valid কি না, sample যথেষ্ট কি
                                      না

  F02 Numeric Change & Algebraic      difference, ratio, polynomial,
  Structure                           number-theory structure

  F03 Digit & Position Structure      digit, position, sum/product,
                                      repetition

  F04 Sequence, Recurrence & Motif    lag, recurrence, subsequence, motif

  F05 Modular & Combinatorial         modulo, pair, triplet, permutation,
  Structure                           coverage

  F06 Distribution & Uncertainty      mean, variance, quantile, intervals

  F07 Dependency & Transition         ACF, MI, chi-square, transition

  F08 Temporal Dynamics               rolling, smoothing, change-point,
                                      regime

  F09 Frequency, Information &        spectral, entropy, complexity
  Complexity                          

  F10 Randomness & Null-Model         randomness compatibility and null
  Diagnostics                         tests

  F11 Hypothesis Discovery            symbolic/rule/interaction
                                      hypotheses

  F12 Model & Validation Governance   model channels, backtest, OOS,
                                      reproducibility
  -----------------------------------------------------------------------

## প্রতিটি module-এর বাধ্যতামূলক contract

``` text
AnalysisModule {
  id
  name
  family
  inputScope
  prerequisites
  compute(data, context)
  rawResult
  normalizedEvidence
  evidenceState
  sampleSize
  coverage
  stability
  uncertainty
  validationStatus
  dependencies
  redundancyGroup
  explanation
}
```

### Evidence states

-   `SUPPORT`
-   `NEUTRAL`
-   `CONFLICT`
-   `INSUFFICIENT_DATA`
-   `NOT_APPLICABLE`

### Score rule

কোনো module সরাসরি final score লিখবে না। Module → EvidenceBus →
FamilyAggregator → CrossFamilyAggregator → ValidationGate → Report।

------------------------------------------------------------------------

## সম্পূর্ণ 107-module matrix

  -------------------------------------------------------------------------------------------------
                 ID Analysis             Family          v2 ভূমিকা                 বর্তমান ZIP অবস্থা
  ----------------- -------------------- --------------- ------------------------ -----------------
                  1 Data integrity audit F01 • Data      Gate / data-quality      বর্তমানে
                                         Integrity &     report; no candidate     validation
                                         Eligibility     score.                   

                  2 Missing-value audit  F01 • Data      Gate / data-quality      বর্তমানে
                                         Integrity &     report; no candidate     validation
                                         Eligibility     score.                   

                  3 Duplicate detection  F01 • Data      Gate / data-quality      বর্তমানে
                                         Integrity &     report; no candidate     catalog-only
                                         Eligibility     score.                   

                  4 Ordering audit       F01 • Data      Gate / data-quality      বর্তমানে
                                         Integrity &     report; no candidate     validation
                                         Eligibility     score.                   

                  5 Sample-size adequacy F01 • Data      Gate / data-quality      বর্তমানে
                                         Integrity &     report; no candidate     catalog-only
                                         Eligibility     score.                   

                  6 Distribution profile F01 • Data      Gate / data-quality      বর্তমানে
                                         Integrity &     report; no candidate     catalog-only
                                         Eligibility     score.                   

                  7 First difference     F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                  8 Second difference    F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                  9 Third difference     F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 10 Absolute difference  F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 11 Ratio analysis       F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 12 Percentage change    F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 13 Prime/composite      F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 14 Divisibility         F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 15 Factorization        F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 16 GCD/LCM              F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 17 Parity               F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 18 Digital root         F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 19 Digit frequency      F03 • Digit &   Historical structural    বর্তমানে
                                         Position        evidence; must expose    active-signal
                                         Structure       raw counts, expected     
                                                         baseline, stability and  
                                                         coverage.                

                 20 Position frequency   F03 • Digit &   Historical structural    বর্তমানে
                                         Position        evidence; must expose    active-signal
                                         Structure       raw counts, expected     
                                                         baseline, stability and  
                                                         coverage.                

                 21 Digit sum            F03 • Digit &   Independent module;      বর্তমানে
                                         Position        compute its own          catalog-only
                                         Structure       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 22 Digit product        F03 • Digit &   Independent module;      বর্তমানে
                                         Position        compute its own          catalog-only
                                         Structure       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 23 Repeated digits      F03 • Digit &   Independent module;      বর্তমানে
                                         Position        compute its own          catalog-only
                                         Structure       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 24 Distinct-digit count F03 • Digit &   Independent module;      বর্তমানে
                                         Position        compute its own          catalog-only
                                         Structure       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 25 Reverse number       F03 • Digit &   Independent module;      বর্তমানে
                                         Position        compute its own          catalog-only
                                         Structure       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 26 Recurrence search    F04 • Sequence, Independent module;      বর্তমানে
                                         Recurrence &    compute its own          catalog-only
                                         Motif           statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 27 Lag matching         F04 • Sequence, Independent module;      বর্তমানে
                                         Recurrence &    compute its own          catalog-only
                                         Motif           statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 28 Pattern repetition   F04 • Sequence, Independent module;      বর্তমানে
                                         Recurrence &    compute its own          advanced-metric
                                         Motif           statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 29 Run-length analysis  F04 • Sequence, Independent module;      বর্তমানে
                                         Recurrence &    compute its own          catalog-only
                                         Motif           statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 30 Subsequence search   F04 • Sequence, Independent module;      বর্তমানে
                                         Recurrence &    compute its own          catalog-only
                                         Motif           statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 31 Motif discovery      F04 • Sequence, Independent module;      বর্তমানে
                                         Recurrence &    compute its own          catalog-only
                                         Motif           statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 32 Linear fit           F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 33 Quadratic fit        F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 34 Cubic fit            F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 35 Finite-difference    F02 • Numeric   Independent module;      বর্তমানে
                    polynomial           Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 36 Residual analysis    F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          catalog-only
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 37 Complexity penalty   F02 • Numeric   Independent module;      বর্তমানে
                                         Change &        compute its own          advanced-metric
                                         Algebraic       statistic, expose        
                                         Structure       evidence state,          
                                                         stability and data       
                                                         coverage.                

                 38 Modulo 2             F05 • Modular & Independent module;      বর্তমানে
                                         Combinatorial   compute its own          catalog-only
                                         Structure       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 39 Modulo 3             F05 • Modular & Independent module;      বর্তমানে
                                         Combinatorial   compute its own          catalog-only
                                         Structure       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 40 Modulo 4             F05 • Modular & Independent module;      বর্তমানে
                                         Combinatorial   compute its own          catalog-only
                                         Structure       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 41 Modulo 5             F05 • Modular & Independent module;      বর্তমানে
                                         Combinatorial   compute its own          catalog-only
                                         Structure       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 42 Modulo 7             F05 • Modular & Independent module;      বর্তমানে
                                         Combinatorial   compute its own          catalog-only
                                         Structure       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 43 Modulo 9             F05 • Modular & Independent module;      বর্তমানে
                                         Combinatorial   compute its own          catalog-only
                                         Structure       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 44 Modulo 10            F05 • Modular & Independent module;      বর্তমানে
                                         Combinatorial   compute its own          catalog-only
                                         Structure       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 45 Modulo 11            F05 • Modular & Independent module;      বর্তমানে
                                         Combinatorial   compute its own          catalog-only
                                         Structure       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 46 Pair frequency       F05 • Modular & Historical structural    বর্তমানে
                                         Combinatorial   evidence; must expose    active-signal
                                         Structure       raw counts, expected     
                                                         baseline, stability and  
                                                         coverage.                

                 47 Triplet frequency    F05 • Modular & Historical structural    বর্তমানে
                                         Combinatorial   evidence; must expose    active-signal
                                         Structure       raw counts, expected     
                                                         baseline, stability and  
                                                         coverage.                

                 48 Permutation groups   F05 • Modular & Independent module;      বর্তমানে
                                         Combinatorial   compute its own          catalog-only
                                         Structure       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 49 Combination coverage F05 • Modular & Historical structural    বর্তমানে
                                         Combinatorial   evidence; must expose    catalog-only
                                         Structure       raw counts, expected     
                                                         baseline, stability and  
                                                         coverage.                

                 50 Position-pair matrix F05 • Modular & Historical structural    বর্তমানে
                                         Combinatorial   evidence; must expose    advanced-metric
                                         Structure       raw counts, expected     
                                                         baseline, stability and  
                                                         coverage.                

                 51 Pattern class        F05 • Modular & Historical structural    বর্তমানে
                    frequency            Combinatorial   evidence; must expose    advanced-metric
                                         Structure       raw counts, expected     
                                                         baseline, stability and  
                                                         coverage.                

                 52 Mean/median/mode     F06 •           Distribution descriptor; বর্তমানে
                                         Distribution &  feeds evidence context,  catalog-only
                                         Uncertainty     not an automatic         
                                                         candidate vote.          

                 53 Variance/std-dev     F06 •           Distribution descriptor; বর্তমানে
                                         Distribution &  feeds evidence context,  catalog-only
                                         Uncertainty     not an automatic         
                                                         candidate vote.          

                 54 Quantiles            F06 •           Distribution descriptor; বর্তমানে
                                         Distribution &  feeds evidence context,  catalog-only
                                         Uncertainty     not an automatic         
                                                         candidate vote.          

                 55 Z-score              F06 •           Distribution descriptor; বর্তমানে
                                         Distribution &  feeds evidence context,  catalog-only
                                         Uncertainty     not an automatic         
                                                         candidate vote.          

                 56 Robust outlier score F06 •           Distribution descriptor; বর্তমানে
                                         Distribution &  feeds evidence context,  catalog-only
                                         Uncertainty     not an automatic         
                                                         candidate vote.          

                 57 Bootstrap interval   F06 •           Uncertainty layer;       বর্তমানে
                                         Distribution &  report interval, never   validation
                                         Uncertainty     convert to a fake        
                                                         confidence probability.  

                 58 Wilson interval      F06 •           Uncertainty layer;       বর্তমানে
                                         Distribution &  report interval, never   validation
                                         Uncertainty     convert to a fake        
                                                         confidence probability.  

                 59 Autocorrelation      F07 •           Statistical diagnostic;  বর্তমানে
                                         Dependency &    emits evidence +         active-signal
                                         Transition      p/effect/stability where 
                                                         applicable.              

                 60 Partial              F07 •           Statistical diagnostic;  বর্তমানে
                    autocorrelation      Dependency &    emits evidence +         advanced-metric
                                         Transition      p/effect/stability where 
                                                         applicable.              

                 61 Cross-position       F07 •           Statistical diagnostic;  বর্তমানে
                    correlation          Dependency &    emits evidence +         active-signal
                                         Transition      p/effect/stability where 
                                                         applicable.              

                 62 Mutual information   F07 •           Statistical diagnostic;  বর্তমানে
                                         Dependency &    emits evidence +         catalog-only
                                         Transition      p/effect/stability where 
                                                         applicable.              

                 63 Chi-square           F07 •           Statistical diagnostic;  বর্তমানে
                    independence         Dependency &    emits evidence +         catalog-only
                                         Transition      p/effect/stability where 
                                                         applicable.              

                 64 Transition matrix    F07 •           Historical structural    বর্তমানে
                                         Dependency &    evidence; must expose    active-signal
                                         Transition      raw counts, expected     
                                                         baseline, stability and  
                                                         coverage.                

                 65 Rolling mean         F08 • Temporal  Independent module;      বর্তমানে
                                         Dynamics        compute its own          advanced-metric
                                                         statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 66 Rolling variance     F08 • Temporal  Independent module;      বর্তমানে
                                         Dynamics        compute its own          advanced-metric
                                                         statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 67 Exponential          F08 • Temporal  Independent module;      বর্তমানে
                    smoothing            Dynamics        compute its own          catalog-only
                                                         statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 68 Change-point         F08 • Temporal  Independent module;      বর্তমানে
                    detection            Dynamics        compute its own          catalog-only
                                                         statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 69 Trend decomposition  F08 • Temporal  Independent module;      বর্তমানে
                                         Dynamics        compute its own          catalog-only
                                                         statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 70 Walk-forward windows F08 • Temporal  Validation/governance;   বর্তমানে
                                         Dynamics        controls whether other   catalog-only
                                                         modules are allowed to   
                                                         contribute.              

                 71 DFT/FFT spectrum     F09 •           Independent module;      বর্তমানে
                                         Frequency,      compute its own          advanced-metric
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 72 Dominant frequency   F09 •           Independent module;      বর্তমানে
                                         Frequency,      compute its own          advanced-metric
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 73 Spectral entropy     F09 •           Independent module;      বর্তমানে
                                         Frequency,      compute its own          advanced-metric
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 74 Periodogram          F09 •           Independent module;      বর্তমানে
                                         Frequency,      compute its own          catalog-only
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 75 Peak periodicity     F09 •           Independent module;      বর্তমানে
                                         Frequency,      compute its own          catalog-only
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 76 Shannon entropy      F09 •           Independent module;      বর্তমানে
                                         Frequency,      compute its own          advanced-metric
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 77 Min-entropy          F09 •           Independent module;      বর্তমানে
                                         Frequency,      compute its own          advanced-metric
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 78 Rényi entropy        F09 •           Independent module;      বর্তমানে
                                         Frequency,      compute its own          advanced-metric
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 79 Approximate entropy  F09 •           Independent module;      বর্তমানে
                                         Frequency,      compute its own          advanced-metric
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 80 Conditional entropy  F09 •           Independent module;      বর্তমানে
                                         Frequency,      compute its own          advanced-metric
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 81 Information gain     F09 •           Independent module;      বর্তমানে
                                         Frequency,      compute its own          catalog-only
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 82 Frequency test       F10 •           Statistical diagnostic;  বর্তমানে
                                         Randomness &    emits evidence +         validation
                                         Null-Model      p/effect/stability where 
                                         Diagnostics     applicable.              

                 83 Block frequency      F10 •           Statistical diagnostic;  বর্তমানে
                                         Randomness &    emits evidence +         advanced-metric
                                         Null-Model      p/effect/stability where 
                                         Diagnostics     applicable.              

                 84 Runs test            F10 •           Statistical diagnostic;  বর্তমানে
                                         Randomness &    emits evidence +         validation
                                         Null-Model      p/effect/stability where 
                                         Diagnostics     applicable.              

                 85 Long-run test        F10 •           Statistical diagnostic;  বর্তমানে
                                         Randomness &    emits evidence +         validation
                                         Null-Model      p/effect/stability where 
                                         Diagnostics     applicable.              

                 86 Serial test          F10 •           Statistical diagnostic;  বর্তমানে
                                         Randomness &    emits evidence +         validation
                                         Null-Model      p/effect/stability where 
                                         Diagnostics     applicable.              

                 87 Cumulative sums      F10 •           Statistical diagnostic;  বর্তমানে
                                         Randomness &    emits evidence +         catalog-only
                                         Null-Model      p/effect/stability where 
                                         Diagnostics     applicable.              

                 88 Permutation test     F10 •           Statistical diagnostic;  বর্তমানে
                                         Randomness &    emits evidence +         validation
                                         Null-Model      p/effect/stability where 
                                         Diagnostics     applicable.              

                 89 Lempel-Ziv           F09 •           Independent module;      বর্তমানে
                    complexity           Frequency,      compute its own          advanced-metric
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 90 Linear complexity    F09 •           Independent module;      বর্তমানে
                                         Frequency,      compute its own          advanced-metric
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 91 Compression ratio    F09 •           Independent module;      বর্তমানে
                                         Frequency,      compute its own          catalog-only
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 92 Pattern complexity   F09 •           Independent module;      বর্তমানে
                                         Frequency,      compute its own          advanced-metric
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 93 Description-length   F09 •           Independent module;      বর্তমানে
                    penalty              Frequency,      compute its own          catalog-only
                                         Information &   statistic, expose        
                                         Complexity      evidence state,          
                                                         stability and data       
                                                         coverage.                

                 94 State-space encoding F08 • Temporal  Independent module;      বর্তমানে
                                         Dynamics        compute its own          catalog-only
                                                         statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 95 Recurrence plot      F08 • Temporal  Independent module;      বর্তমানে
                                         Dynamics        compute its own          catalog-only
                                                         statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 96 Attractor-style      F08 • Temporal  Independent module;      বর্তমানে
                    clustering           Dynamics        compute its own          catalog-only
                                                         statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 97 Transition stability F08 • Temporal  Independent module;      বর্তমানে
                                         Dynamics        compute its own          active-signal
                                                         statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 98 Regime detection     F08 • Temporal  Independent module;      বর্তমানে
                                         Dynamics        compute its own          catalog-only
                                                         statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                 99 Symbolic regression  F11 •           Independent module;      বর্তমানে
                                         Hypothesis      compute its own          catalog-only
                                         Discovery       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                100 Rule mining          F11 •           Independent module;      বর্তমানে
                                         Hypothesis      compute its own          catalog-only
                                         Discovery       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                101 Association patterns F11 •           Independent module;      বর্তমানে
                                         Hypothesis      compute its own          advanced-metric
                                         Discovery       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                102 Feature interaction  F11 •           Independent module;      বর্তমানে
                    search               Hypothesis      compute its own          catalog-only
                                         Discovery       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                103 Formula candidate    F11 •           Independent module;      বর্তমানে
                    ranking              Hypothesis      compute its own          catalog-only
                                         Discovery       statistic, expose        
                                                         evidence state,          
                                                         stability and data       
                                                         coverage.                

                104 Baseline prediction  F12 • Model &   Model channel; candidate বর্তমানে
                                         Validation      evidence only after      catalog-only
                                         Governance      leakage-safe validation. 

                105 AR/ARIMA-style       F12 • Model &   Model channel; candidate বর্তমানে
                    signal               Validation      evidence only after      catalog-only
                                         Governance      leakage-safe validation. 

                106 Tree/ensemble signal F12 • Model &   Model channel; candidate বর্তমানে
                                         Validation      evidence only after      catalog-only
                                         Governance      leakage-safe validation. 

                107 Recurrent model      F12 • Model &   Model channel; candidate বর্তমানে
                    signal               Validation      evidence only after      catalog-only
                                         Governance      leakage-safe validation. 
  -------------------------------------------------------------------------------------------------

## 107 modules-এর family-level execution

### F01 --- Data Integrity & Eligibility

1--6 সব module আগে চলবে। কোনো data-quality gate fail করলে downstream
module তার status-এ কারণ দেখাবে।

### F02 --- Numeric Change & Algebraic Structure

7--18 এবং 32--37। এগুলো candidate vote নয়; observed arithmetic/algebraic
structure-এর evidence তৈরি করবে।

### F03 --- Digit & Position Structure

19--25। Digit frequency, position frequency, sum/product, repetition ও
reverse relation আলাদা raw metrics হিসেবে থাকবে।

### F04 --- Sequence, Recurrence & Motif

26--31। recurrence/motif থাকলে তার frequency, window stability ও
out-of-sample persistence দেখাবে।

### F05 --- Modular & Combinatorial Structure

38--51। সব 6 positional pairs এবং সব 4 positional triplets এক canonical
generator থেকে আসবে। Candidate scorer এবং UI একই matrix ব্যবহার করবে।

### F06 --- Distribution & Uncertainty

52--58। descriptive statistics এবং interval আলাদা থাকবে। interval-কে
probability বলা যাবে না।

### F07 --- Dependency & Transition

59--64। dependency থাকলে effect size, p-value, sample size এবং
time-window stability দেখাবে।

### F08 --- Temporal Dynamics

65--70 এবং 94--98। newest-first/oldest-first orientation একবার normalize
হবে; কোনো future row training-এ ঢুকবে না।

### F09 --- Frequency, Information & Complexity

71--81 এবং 89--93। entropy/complexity raw value + normalized
interpretation + stability দেবে; এগুলোকে automatic predictive votes
বানানো যাবে না।

### F10 --- Randomness & Null-Model Diagnostics

82--88। null compatibility পরীক্ষা করবে। `not random` মানেই `predictable`
হবে না।

### F11 --- Hypothesis Discovery

99--103। symbolic/rule/interaction ফলকে hypothesis হিসেবে report করবে;
validation ছাড়া final evidence নয়।

### F12 --- Model & Validation Governance

104--107 public catalog-এর model channels। ZIP-এ catalog-এর পরে থাকা
108--115 definitions---Genetic optimizer, Ensemble ranking, Uncertainty
interval, Blocked K-fold, Monte Carlo null test, Multiple-testing audit,
Out-of-sample validation, Reproducibility check---v2-তে
**infrastructure/governance layer** হিসেবে থাকবে, public 107 count-এর
বাইরে।

## Cross-family Evidence Bus

প্রতিটি candidate-এর জন্য:

``` text
candidate
  ↓
F01 eligibility
  ↓
F02..F11 module results
  ↓
redundancy grouping
  ↓
family aggregation
  ↓
support/conflict matrix
  ↓
validation gate
  ↓
historical analytical profile
```

একই family-এর correlated modules-এর vote একাধিকবার গোনা হবে না।

### Example

``` text
Candidate: XXXX

F03 Digit/Position        SUPPORT
F05 Combinatorial         SUPPORT
F07 Dependency            NEUTRAL
F08 Temporal              CONFLICT
F09 Information           NEUTRAL
F10 Randomness            CONFLICT
F11 Hypothesis            INSUFFICIENT_DATA

Independent family support: 2
Family conflict: 2
Unvalidated evidence: 1
```

এখানে system কোনো "prediction confidence" বানাবে না; এটি **analysis
evidence profile** দেখাবে।

## Anti-repeat redesign

পুরোনো number বারবার ওঠার সমস্যা আলাদা করে মাপা হবে:

-   Historical frequency
-   Recent frequency
-   Recency
-   Repeat count
-   Pattern reuse
-   Evidence diversity
-   Redundancy count

`Anti-Repeat/Diversity Guard` অন্য modules-এর historical frequency মুছে
দেবে না; বরং report করবে একই evidence কতবার পুনরাবৃত্ত হয়েছে।

## Hard rules

### Rule 1 --- No fake score

`0.5` default result নিষিদ্ধ।\
পরিবর্তে `INSUFFICIENT_DATA`।

### Rule 2 --- No proxy masquerading

বাস্তব cross-company data না থাকলে `NOT_APPLICABLE`।

### Rule 3 --- No duplicate pair/triplet logic

Canonical combination generator ব্যবহার হবে: - Pairs: 01, 02, 03, 12, 13,
23 - Triplets: 012, 013, 023, 123

### Rule 4 --- Validation is a gate

Backtest/OOS validation score নিজে final score নয়। এটি module-এর
evidence eligibility নির্ধারণ করবে।

### Rule 5 --- No double counting

Position, digit frequency, hot/cold, pair, triplet ইত্যাদি correlated হলে
redundancy group-এ যাবে।

### Rule 6 --- Raw result is immutable

প্রতিটি run-এ raw input hash, analysis version, parameters, sample size
এবং timestamp সংরক্ষণ হবে।

### Rule 7 --- Historical order normalization

একটি canonical chronological dataset তৈরি হবে; সব temporal analysis একই
orientation ব্যবহার করবে।

## v2 output structure

``` text
DATA QUALITY
  ├─ valid rows
  ├─ invalid rows
  ├─ duplicates
  ├─ missing
  └─ ordering

107 ANALYSIS
  ├─ 12 families
  ├─ module results
  ├─ evidence states
  ├─ uncertainty
  └─ stability

CROSS-FAMILY MATRIX
  ├─ support
  ├─ conflict
  ├─ neutral
  └─ insufficient

VALIDATION
  ├─ walk-forward
  ├─ blocked validation
  ├─ null baseline
  ├─ multiple-testing control
  └─ reproducibility

FINAL ANALYTICAL REPORT
  ├─ historical evidence profile
  ├─ strongest independent structures
  ├─ conflicting structures
  ├─ data limitations
  └─ audit trail
```

## Implementation order for the ZIP

1.  `src/types/analysis-v2.ts` --- module contracts and result types
2.  `src/lib/analysis-catalog.ts` --- convert catalog to strict metadata
    registry
3.  `src/lib/analysis-modules/` --- 107 module implementations
4.  `src/lib/evidence-bus.ts` --- common result bus
5.  `src/lib/family-orchestrator.ts` --- 12-family execution
6.  `src/lib/redundancy-v2.ts` --- source/family-aware redundancy
    control
7.  `src/lib/validation-v2.ts` ---
    walk-forward/OOS/null/multiple-testing gate
8.  `src/lib/scorer-v2.ts` --- family-level analytical aggregation
9.  `src/lib/pipeline.ts` --- remove independent prediction-style
    shortcuts and consume EvidenceBus
10. `src/App.tsx` --- show module status, family matrix,
    conflict/support and audit details

## Final architecture

``` text
                 USER HISTORICAL DATA
                         │
                         ▼
                ┌─────────────────┐
                │ F01 DATA GATE   │
                └────────┬────────┘
                         │
              ┌──────────┴──────────┐
              ▼                     ▼
        107 MODULES            DATA PROFILE
              │
      ┌───────┴────────┐
      ▼                ▼
  12 FAMILIES     MODULE AUDIT
      │                │
      └───────┬────────┘
              ▼
       REDUNDANCY CONTROL
              │
              ▼
       EVIDENCE BUS
              │
      ┌───────┼────────┐
      ▼       ▼        ▼
   SUPPORT  NEUTRAL  CONFLICT
              │
              ▼
       VALIDATION GATE
              │
              ▼
     HISTORICAL ANALYTICAL
           REPORT
```

**মূল লক্ষ্য:** 107টি নাম দেখানো নয়; **107টি module-এর প্রত্যেকটির নিজস্ব কাজ,
ফল, evidence, limitation এবং validation status বাধ্যতামূলক করা।**
