# 107 Calculation Layer — Deep Audit

## সিদ্ধান্ত
আগের source-এ 107 নামের catalog ছিল, কিন্তু সব 107-এর জন্য একটি কেন্দ্রীয় executable calculation path ছিল না। নতুন `src/lib/analysis-engine-107.ts` public 1–107-এর জন্য একক calculation entry point করেছে: `run107Analysis()`। `scorer.ts` এখন একই dataset থেকে `core107` ফলও সংযুক্ত করে।

## যে সমস্যাগুলো ঠিক করা হয়েছে
- Arithmetic/Geometric sequence formula helpers-এর edge-case ঠিক করা হয়েছে: zero common difference/ratio-এ non-unique rank-কে জোর করে rank 1 দেখানো হয় না।
- 6 canonical position-pairs এবং 4 canonical triplets কেন্দ্রীয় layer-এ রাখা হয়েছে।
- Digital root calculation canonical করা হয়েছে।
- Run-length calculation আর সবসময় 1 ফেরত দেয় না।
- Position-pair matrix আর একই pair বারবার কপি করে না; ছয়টি আলাদা matrix তৈরি করে।
- Spectral peak calculation local-peak ভিত্তিক করা হয়েছে।
- 105–107-এর জন্য কোনো fake fallback score নেই; প্রয়োজনীয় model runtime/OOS না থাকলে NOT_APPLICABLE।
- Validation family (82–88) আলাদা status পায়; discovery family (99–103) advanced status পায়।
- Central engine-এর ফল scorer-এর `core107`-এ যুক্ত হয়েছে।

## Runtime status on a 150-record synthetic canonical dataset
- Public modules: **107/107**
- Executable descriptive/structural calculations: **81**
- Validation calculations: **17**
- Advanced discovery: **6**
- Model-dependent modules not substituted by proxies: **3**

## গুরুত্বপূর্ণ সীমা
105–107-কে proxy দিয়ে “implemented” দেখানো হয়নি। Real AR/ARIMA, tree/ensemble, recurrent model এবং leakage-safe OOS validation আলাদা release gate।

## Verification
- Selected TypeScript compilation: PASS
- 107 engine static audit: PASS
- Runtime 107 count/ID check: PASS
- Existing static audit: PASS
- App/engine syntax transpilation: PASS
