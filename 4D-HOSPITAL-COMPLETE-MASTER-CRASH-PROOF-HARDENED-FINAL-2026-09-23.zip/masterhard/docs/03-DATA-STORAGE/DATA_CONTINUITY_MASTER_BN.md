# Data Continuity Master Contract

### Example
Old dataset: 2,000+ valid 4-digit records
New import: 23 valid records
Expected logical total: **2,023** (subject to duplicate/conflict rules).

### Identity
`company + date + drawNo` is the preferred logical draw identity. If drawNo is absent, import must use explicit conflict handling rather than silently overwriting an existing same-date draw.

### Safety
- Validate before merge.
- Merge additively.
- Reject/skip invalid rows with an audit reason.
- Persist transactionally where SQLite path is available.
- Preserve backup/restore rollback semantics.
- Never convert blank user input into `0000` as a valid record.

### Source of truth
SQLite is the intended persistent source. Any browser/local fallback is a compatibility fallback and must not silently discard SQLite data.
