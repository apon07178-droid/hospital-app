# Storage
Native Android: SQLite. Web/PWA: IndexedDB. localStorage remains legacy/fallback only for result rows. Import/merge must be additive and conflict-safe.
