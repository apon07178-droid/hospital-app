# Result Sheet — Final Output Contract

## উদ্দেশ্য
107 analysis ও model/validation evidence-এর পরে ব্যবহারকারীকে একটি পরিষ্কার historical analytical result sheet দেখানো। এটি guaranteed future result নয়।

## Result Sheet sections
1. Dataset summary — valid record count, date range, companies, dataset fingerprint.
2. Data-quality gate — missing/duplicate/order/sample-size state.
3. Family evidence — 18 analysis families-এর consolidated state.
4. Candidate/structural signals — pair, triplet, digit/position, recurrence, modular, statistical ও information signals.
5. Validation — OOS/backtest/walk-forward metrics যেখানে applicable.
6. Uncertainty — interval/effect size/sample size/stability.
7. Conflict/neutral evidence — শুধু support দেখিয়ে misleading output নয়।
8. Final historical report — methods used, limitations, data version, analysis version.

## Rules
- কোনো unavailable model-এর জন্য fake score নয়।
- একই evidence একাধিক correlated signal দিয়ে অতিরিক্ত count করা যাবে না।
- `INSUFFICIENT_DATA` এবং `NOT_APPLICABLE` আলাদা দেখাতে হবে।
- Prediction-like outputs থাকলে এগুলো OOS benchmark/evidence হিসেবে labelled হবে, guarantee হিসেবে নয়।
