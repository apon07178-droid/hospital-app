# 4D Hospital — MASTER RECONCILIATION
## গত আলোচনায় সংরক্ষিত সব প্রধান requirement এক baseline-এ

এই নথি বর্তমান conversation context ও আগের তৈরি source/audit artifacts-এ সংরক্ষিত requirements একত্র করে তৈরি। এটি সম্পূর্ণ chat transcript দাবি করে না; বরং সংরক্ষিত/যাচাইযোগ্য requirements-এর master ledger।

### A. App identity ও scope
- App: **4D Hospital** / 4-digit historical analysis system.
- লক্ষ্য: historical data analysis, mathematical/statistical research, evidence validation.
- কোনো guaranteed future result বা magical prediction claim নয়।
- Free-first architecture; paid external service বাধ্যতামূলক নয়।

### B. Data continuity
- 2,000+ historical records + 23 নতুন records = 2,023 records—নতুন data পুরোনো data-র সঙ্গে additive merge হবে।
- ভবিষ্যতে 10,000+ 4-digit records support করতে হবে।
- SQLite/source-of-truth continuity, migration, backup/restore, rollback গুরুত্বপূর্ণ।
- একই company/date-এ একাধিক draw হলে `drawNo` দিয়ে logical identity রাখা হবে।
- Invalid import/restore master dataset নষ্ট করবে না।

### C. Analysis
- Public **107 Analysis** catalogue বজায় থাকবে।
- প্রতিটি analysis-এর Definition, Input, Output, Data Requirement, Dependency, Validation, Implementation Status, Target ও Redundancy metadata থাকবে।
- Dependency শুধু প্রকৃত computational dependency; correlation/redundancy dependency নয়।
- Evidence states: SUPPORT, NEUTRAL, CONFLICT, INSUFFICIENT_DATA, NOT_APPLICABLE.
- Fake `0.5` evidence, proxy masquerading, duplicate evidence double-counting নিষিদ্ধ।
- Canonical pair = 6 position-pairs; canonical triplet = 4 position-triplets।

### D. Mathematical extension
Probability, statistical inference, Bayesian methods, number theory, combinatorics, sequence/recurrence, time series, information theory, randomness/null models, complexity, nonlinear/state/regime methods, hypothesis discovery, multiple-testing control, walk-forward/OOS validation ও reproducibility—এগুলো architecture-এর extension layer।

### E. Result Sheet
Result output-কে আলাদা presentation section হিসেবে রাখতে হবে। বর্তমান source-এ final-result/result folders এবং ranking pipeline UI আছে; এই package-এ Result Sheet specification-ও আলাদা নথিভুক্ত করা হয়েছে যাতে output contract পরিষ্কার থাকে।

### F. Folder / organization requirement
Analysis, Result Sheet, Data/Storage, Mathematical Architecture এবং E2E/Release concern আলাদা documentation folders-এ সাজানো হয়েছে। Source runtime-এ বড় `App.tsx` এখনও প্রধান UI container; documentation folder separation source refactor-এর সমান নয়।

### G. E2E
শেষ release gate:
1. fresh install
2. historical import
3. 2,000+ + 23 additive merge → 2,023
4. app restart/persistence
5. 107 analysis refresh
6. result sheet/output verification
7. backup/restore
8. migration/conflict handling
9. OCR/research-cycle checks
10. 10,000+ stress test

বর্তমান runtime environment-এ Android SDK/emulator/Gradle এবং dependency installation সম্পূর্ণভাবে চালানো হয়নি; তাই Android E2E PASS দাবি করা যাবে না।

## Master release principle
**Implemented / documented / statically verified / Android-E2E verified—এই চারটি status আলাদা রাখতে হবে।**
