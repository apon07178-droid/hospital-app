# 4D HOSPITAL — Master Analysis / Module Inventory
## 2026-09-23 consolidated source-of-truth

এই নথি সংখ্যা যোগ করে একটি misleading total তৈরি করে না। একই method একাধিক layer-এ ব্যবহৃত হতে পারে; তাই প্রতিটি layer আলাদাভাবে গণনা করা হয়েছে এবং overlap স্পষ্ট রাখা হয়েছে।

## 1. Canonical analysis layer

- **107টি Public Core Analysis** — `lib/analysis-engine-107.ts` দ্বারা execute হয় এবং `analysis-catalog.ts`-এর public 107 registry-এর সঙ্গে যুক্ত।
- 18টি catalog division/domain-এর মধ্যে প্রথম 107টি public contract হিসেবে প্রকাশিত।
- প্রতিটি analysis-এর result state: `SUPPORT`, `NEUTRAL`, `CONFLICT`, `INSUFFICIENT_DATA`, `NOT_APPLICABLE`।
- unavailable calculation-এর জন্য fake evidence score ব্যবহার করা উচিত নয়।

## 2. Central active signal layer

- **28টি Active Signal** — `lib/scorer.ts` / `ACTIVE_SIGNAL_CATALOG`।
- এগুলো 107 Core-এর বিকল্প নয়; candidate ranking/evidence aggregation-এর আলাদা signal layer।
- 28টি: Position, Hot Digit, Pair, Triplet, Transition, Mirror, Neighbor, High/Low, Benford-style, Overdue/GAP, Sum, Even/Odd, Calendar, Recent Trend, Permutation, Digit Diversity, Cross-Company, Regression, Sequence, LSTM-style, Genetic, Skip-Draw, Cold/Due, Backtest Support, Digit Spread, Consensus, Bayesian Smoothing, Anti-Repeat/Diversity Guard।

## 3. Legacy Smart Generator

Source comments অনুযায়ী **27টি numbered analytical path** আছে, এবং এর পরে একটি আলাদা aggregation/ranking stage আছে।

- Position frequency
- Hot digits
- Pair frequency
- Triplet frequency
- Markov chain
- Mirror + Neighbor
- High/Low
- Benford-style weighting
- Gap/overdue
- Digit sum pattern
- Even/Odd balance
- Calendar/day-of-week
- Sliding-window trend
- Permutation
- Digit diversity
- Cross-company correlation
- Regression trend
- LSTM-like sequence signal
- Genetic search
- Skip-draw
- Cold-digit opportunity
- Backtest proxy
- Digit spread
- Consensus boost
- Recency penalty
- Bayesian/Laplace smoothing
- Anti-repeat/diversity guard

**গুরুত্বপূর্ণ:** এই 27টি path-এর অনেকগুলো 28 Active Signal-এর সঙ্গে overlap করে। তাই 27 + 28 করে 55টি independent analysis বলা যাবে না।

## 4. Legacy/secondary model channels

**11টি model channel** source-এ আছে:

1. 30-Day Position Frequency
2. 90-Day Position Frequency
3. Triplet + Position
4. Hot Digit Frequency
5. Benford's Law
6. Mirror Digit
7. Neighbor Digits (n±1)
8. High/Low Pattern
9. Calendar Day Sync
10. Permutation Box
11. Markov Chain

এগুলোরও কয়েকটি 107/28/Smart Generator-এর সঙ্গে overlap করে।

## 5. Six validation layers

1. Walk-Forward 2.0
2. OOS Stability
3. Drift / Regime Detection
4. Model Agreement / Disagreement
5. Ablation + Sensitivity
6. Evidence / Uncertainty Scorecard

এগুলো নতুন candidate analysis নয়; 107/28/other evidence-এর validation/governance layer।

## 6. Special / advanced research modules

- Sequence Mathematics
- Advanced Validation & Null Diagnostics
- Lightweight Recurrent/LSTM-style Model
- Genetic Optimizer
- Central 107 Analysis Executor
- Central Analysis Orchestrator
- Historical Analysis Core
- Leakage-Safe Research Cycle
- 6D Analysis View

এগুলো orchestration/model/research infrastructure হিসেবে আলাদা inventory-তে রাখা হয়েছে, যাতে একই analysis আবার count না হয়।

## 7. What the user should see

Result Center-এ আলাদা card/section থাকবে:

`Dataset → 107 Core Results → 28 Active Signals → Special/Advanced Modules → 6 Validation Layers → Evidence/Uncertainty`

নতুন historical data যোগ হলে সব layer cumulative dataset থেকে পুনরায় গণনা হবে।

### Example

`2000 old records + 23 new records = 2023 records`

পরবর্তী run-এ 2000-কে বাদ দিয়ে শুধু 23টি ব্যবহার করা যাবে না। আবার পুরোনো ফল copy করে দেখানোও যাবে না। Dataset version/fingerprint বদলালে result engine নতুন cumulative calculation করবে।

## 8. Final counting rule

সুতরাং “অ্যাপে মোট কত analysis?” প্রশ্নের জন্য একটি একক additive সংখ্যা দেওয়া নিরাপদ নয়, কারণ overlap আছে। Source-of-truth হিসেবে:

- **107 Core Analysis** = canonical analysis count
- **28 Active Signals** = separate signal layer
- **27 Smart Generator paths + 1 aggregation stage** = legacy/secondary pipeline
- **11 legacy model channels** = secondary model view
- **6 Validation Layers** = validation/governance
- **9 Special/Advanced modules** = research/model/orchestration infrastructure

এইভাবে কোনো পুরোনো module বাদ গেছে কি না এবং একই module একাধিক জায়গায় double-count হয়েছে কি না—দুটিই দেখা যায়।
