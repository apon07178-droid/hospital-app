# Requirements Ledger — 4D Hospital

| ID | Requirement | Current package evidence | Status |
|---|---|---|---|
| R01 | Free-first app | Capacitor/web source; no paid service required by core | PRESENT |
| R02 | 107 public analyses | `src/lib/analysis-catalog.ts` + contract | STATIC VERIFIED |
| R03 | 107 definitions/matrix | `src/lib/analysis-contract.ts` + docs matrix | PRESENT |
| R04 | Implementation Status | numbered status contract + catalog UI | PRESENT |
| R05 | Formal dependencies | `dependencyIds` + `dependencyType` + cycle check | PRESENT |
| R06 | Canonical dataset | `canonical-data.ts` | PRESENT |
| R07 | Explicit target | descriptive/OOS target contract | PRESENT |
| R08 | 6 canonical pairs | scorer guard | STATIC VERIFIED |
| R09 | 4 canonical triplets | scorer guard | STATIC VERIFIED |
| R10 | additive import | central merge path | STATIC VERIFIED |
| R11 | multiple draws/date | SQLite schema uses draw identity | STATIC VERIFIED |
| R12 | invalid restore rollback | repair docs/source guards | PRESENT |
| R13 | 10k+ data intent | architecture/storage design | DESIGN + STRESS TEST PENDING |
| R14 | Result Sheet | result folders/pipeline output in `App.tsx` + dedicated spec | PRESENT |
| R15 | separate organization | UI folder sections + docs folders | PRESENT; source refactor not claimed |
| R16 | mathematical master architecture | architecture document | PRESENT |
| R17 | randomness/null-model layer | advanced validation + architecture | PRESENT |
| R18 | OOS/walk-forward validation | validation/research cycle | PRESENT; runtime verification pending |
| R19 | E2E free | scripts/build instructions | ANDROID E2E PENDING |
| R20 | final Android APK proof | environment lacks completed Android toolchain | BLOCKED/PENDING |

### Interpretation
`PRESENT` means source/documentation evidence exists. `STATIC VERIFIED` means the included static audit checks it. `PENDING` means it still needs runtime execution. `BLOCKED` means the current execution environment did not provide the required Android toolchain.
