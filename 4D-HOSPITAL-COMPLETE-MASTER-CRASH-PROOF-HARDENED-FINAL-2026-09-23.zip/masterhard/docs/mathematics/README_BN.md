# Mathematics
Explicit mathematical extensions including arithmetic/geometric sequence analysis, term/rank calculations, differences and related historical sequence methods.
