# Final Release Gate

## Static gate
- [x] 107 public entries
- [x] unique names
- [x] implementation-status contract
- [x] formal dependency contract and cycle guard
- [x] canonical dataset/target contract
- [x] 6 pair / 4 triplet coverage
- [x] no fake backtest 0.5 guard
- [x] no cross-company proxy guard
- [x] additive merge guard
- [x] multi-draw SQLite schema guard

## Runtime gate
- [ ] npm dependency installation
- [ ] full TypeScript typecheck
- [ ] production web build
- [ ] Capacitor Android generation/sync
- [ ] debug APK build
- [ ] APK install
- [ ] 2,000+ → +23 → 2,023 persistence test
- [ ] backup/restore
- [ ] 107-analysis runtime pass
- [ ] Result Sheet runtime pass
- [ ] 10,000+ stress test

**Important:** unchecked Android/runtime items are not represented as PASS merely because source/static checks exist.
