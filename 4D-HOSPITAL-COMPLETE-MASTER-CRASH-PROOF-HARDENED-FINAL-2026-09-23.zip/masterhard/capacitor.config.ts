import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.cbc.lt4my.hospital',
  appName: '4D HOSPITAL',
  webDir: 'dist',
  bundledWebRuntime: false,
  server: {
    androidScheme: 'https'
  },
  plugins: {
    CapacitorSQLite: {
      androidIsEncryption: true,
      androidBiometric: { biometricAuth: false, biometricTitle: '4D Hospital Database', biometricSubTitle: 'Local database protection' }
    }
  }
};

export default config;
