# 4D Hospital — Release Readiness 2026-09-23

এই package-এ source-level stability, storage/security এবং research-cycle hardening সম্পন্ন রাখা হয়েছে।

## PASS করা checks
- 107 Analysis catalog/runner
- Research Cycle E2E
- SQLite encryption configuration
- Legacy SQLite migration path
- Encrypted backup
- IndexedDB atomic/durability handling
- Heavy historical analysis Web Worker-এ
- Analysis timeout/termination
- Stale analysis job protection
- React crash boundary
- Global error/unhandled rejection logging
- SQLite/IndexedDB write queues
- SQLite rollback handling
- No remote OCR CDN loading
- No duplicate `src/` tree
- ZIP integrity

## Environment-only release gates
1. `package-lock.json` must be generated in a networked build environment and committed. Do not fabricate integrity hashes.
2. Android debug/release APK must be built with JDK/Android SDK/Gradle.
3. Android emulator/device stress test must run with 10,000+ records, repeated import/save/restart, 107 analysis, OCR and backup/restore.
4. Fully offline OCR must be verified on an APK with the OCR engine/model bundled locally. Network-off test is required.

এই চারটি জিনিস sandbox-এ সত্যিকারের device/build access ছাড়া PASS হিসেবে দেখানো হয়নি।
